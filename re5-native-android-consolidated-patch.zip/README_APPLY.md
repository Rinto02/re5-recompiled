# RE5 native Android renderer foundation — consolidated patch

This is the **only patch to apply from the earlier renderer work**. Do not apply the old Phase 1, Batch 1, or Step 2 ZIPs separately.

## What this patch changes

- Adds the RE5-facing renderer frontend API and its validation/state tracking.
- Adds a thread-safe, bounded shader compilation cache that delegates actual Xenos microcode translation to an `IRe5ShaderCompiler` implementation.
- Adds both source files to `app/CMakeLists.txt`.
- Leaves the existing `rexgpu-xenos` Vulkan plugin and current rendering path untouched.

## Important scope boundary

This is a consolidated **renderer foundation**, not a completed native Vulkan renderer and not a replacement for the Xbox 360 runtime. It does not create a second Vulkan device, translate live RE5 shaders, allocate Vulkan resources, intercept generated guest graphics imports, or replace kernel/audio/input/filesystem services. The Step 2 translator adapter is intentionally not compiled into the app: the SDK translator is currently built inside the hidden-symbol `rexgpu-xenos` plugin and depends on live Vulkan-device features and Xenos pipeline modifications. Compiling a detached adapter with guessed defaults would be misleading and unsafe. The existing renderer remains the fallback.

## Apply in GitHub Codespaces

1. Upload this ZIP into the repository root (`/workspaces/re5-recompiled`). Name it `re5-native-android-consolidated-patch.zip`.
2. Run:

```bash
cd /workspaces/re5-recompiled
unzip -o re5-native-android-consolidated-patch.zip -d .
git diff --check
git status --short
```

3. Review the changes. If you want to undo just this patch before committing:

```bash
git checkout -- app/CMakeLists.txt
rm -f app/src/native_renderer/re5_renderer.h \
      app/src/native_renderer/re5_renderer.cpp \
      app/src/native_renderer/re5_shader_cache.h \
      app/src/native_renderer/re5_shader_cache.cpp
```

Only use that undo command if those files were not already part of your own work.

## Build after applying

Use your repository's existing Android build configuration. From the repository root:

```bash
cd android
./gradlew assembleDebug
```

If Gradle reports that the generated `app/generated` files are missing, run the repository's existing code-generation/configuration step first; do not delete or replace generated files. This patch has not been built against your live Codespace checkout, so the build result must be verified there.

## After the build

Keep the existing Xenos Vulkan renderer enabled. Capture a real gameplay scene and compare rendering, frame time, and logcat before any renderer switch. Do not disable the current renderer based only on successful compilation.
