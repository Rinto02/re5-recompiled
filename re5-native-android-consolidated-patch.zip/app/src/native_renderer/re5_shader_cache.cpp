#include "re5_shader_cache.h"

#include <algorithm>
#include <utility>

namespace re5::render {

CachingRe5ShaderCompiler::CachingRe5ShaderCompiler(
    IRe5ShaderCompiler& compiler, size_t maximum_cache_bytes)
    : compiler_(compiler), maximum_cache_bytes_(maximum_cache_bytes) {}

size_t CachingRe5ShaderCompiler::KeyHash::operator()(const Key& key) const noexcept {
  const size_t hash = std::hash<uint64_t>{}(key.hash);
  return hash ^ (static_cast<size_t>(key.stage) + 0x9E3779B9u + (hash << 6) + (hash >> 2));
}

bool CachingRe5ShaderCompiler::Compile(
    ShaderStage stage, uint64_t guest_ucode_hash,
    std::span<const uint32_t> guest_ucode_dwords,
    std::vector<uint32_t>& spirv_words, std::string* error) {
  if (!guest_ucode_hash || guest_ucode_dwords.empty()) {
    if (error) *error = "shader cache requires a non-zero guest hash and non-empty microcode";
    return false;
  }

  const Key key{stage, guest_ucode_hash};
  {
    std::lock_guard lock(mutex_);
    const auto it = entries_.find(key);
    // Compare the full microcode as well as the guest hash. This prevents a
    // hash collision from returning another shader's compiled module.
    if (it != entries_.end() &&
        it->second.source.size() == guest_ucode_dwords.size() &&
        std::equal(it->second.source.begin(), it->second.source.end(),
                   guest_ucode_dwords.begin())) {
      spirv_words = it->second.spirv;
      return true;
    }
  }

  std::vector<uint32_t> translated;
  if (!compiler_.Compile(stage, guest_ucode_hash, guest_ucode_dwords,
                         translated, error)) {
    return false;
  }
  if (translated.size() < 5 || translated.front() != 0x07230203u) {
    if (error) *error = "Xenos compiler returned an invalid SPIR-V module";
    return false;
  }

  spirv_words = translated;
  const size_t entry_bytes =
      (guest_ucode_dwords.size() + translated.size()) * sizeof(uint32_t);
  if (!maximum_cache_bytes_ || entry_bytes > maximum_cache_bytes_) return true;

  std::lock_guard lock(mutex_);
  // Another thread may have compiled this exact shader while we translated.
  auto existing = entries_.find(key);
  if (existing != entries_.end()) {
    cached_bytes_ -= existing->second.bytes;
    entries_.erase(existing);
  }
  while (!insertion_order_.empty() &&
         cached_bytes_ + entry_bytes > maximum_cache_bytes_) {
    const Key oldest = insertion_order_.front();
    insertion_order_.pop_front();
    auto it = entries_.find(oldest);
    if (it == entries_.end()) continue;
    cached_bytes_ -= it->second.bytes;
    entries_.erase(it);
  }

  Entry entry;
  entry.source.assign(guest_ucode_dwords.begin(), guest_ucode_dwords.end());
  entry.spirv = std::move(translated);
  entry.bytes = entry_bytes;
  entries_.emplace(key, std::move(entry));
  insertion_order_.push_back(key);
  cached_bytes_ += entry_bytes;
  return true;
}

void CachingRe5ShaderCompiler::Clear() {
  std::lock_guard lock(mutex_);
  entries_.clear();
  insertion_order_.clear();
  cached_bytes_ = 0;
}

size_t CachingRe5ShaderCompiler::cached_bytes() const {
  std::lock_guard lock(mutex_);
  return cached_bytes_;
}

}  // namespace re5::render
