#pragma once

#include "re5_renderer.h"

#include <cstddef>
#include <cstdint>
#include <deque>
#include <mutex>
#include <unordered_map>
#include <vector>

namespace re5::render {

// Thread-safe, bounded memoization wrapper for a real Xenos-to-SPIR-V
// compiler. It deliberately delegates translation; it does not pretend that
// raw Xenos microcode is SPIR-V or bypass the SDK's shader analysis.
class CachingRe5ShaderCompiler final : public IRe5ShaderCompiler {
 public:
  explicit CachingRe5ShaderCompiler(IRe5ShaderCompiler& compiler,
                                    size_t maximum_cache_bytes = 64u * 1024u * 1024u);

  bool Compile(ShaderStage stage, uint64_t guest_ucode_hash,
               std::span<const uint32_t> guest_ucode_dwords,
               std::vector<uint32_t>& spirv_words,
               std::string* error) override;

  void Clear();
  size_t cached_bytes() const;

 private:
  struct Key {
    ShaderStage stage;
    uint64_t hash;
    bool operator==(const Key&) const = default;
  };
  struct KeyHash {
    size_t operator()(const Key& key) const noexcept;
  };
  struct Entry {
    std::vector<uint32_t> source;
    std::vector<uint32_t> spirv;
    size_t bytes = 0;
  };

  IRe5ShaderCompiler& compiler_;
  const size_t maximum_cache_bytes_;
  mutable std::mutex mutex_;
  std::unordered_map<Key, Entry, KeyHash> entries_;
  std::deque<Key> insertion_order_;
  size_t cached_bytes_ = 0;
};

}  // namespace re5::render
