# Implementation status

## Included now
- RE5-facing renderer frontend interface and command/state validation.
- Thread-safe bounded shader compilation cache wrapper with full-source collision verification and SPIR-V magic validation.
- CMake source registration.

## Deliberately not enabled yet
- A concrete Vulkan backend and Vulkan object/resource lifecycle.
- Live Xenos-to-SPIR-V translation at the generated RE5 draw callsites.
- Live Vulkan feature/modification propagation into the translator.
- Guest `Vd*` graphics import interception and Android surface/presentation bridge.
- Native replacements for Xbox 360 kernel/threading, memory, file, audio, and input services.

## Why these are deferred
The existing Xenos Vulkan plugin owns the Vulkan device-dependent translator configuration, EDRAM/render-target emulation, descriptors, shader modifications, and pipeline state. Its symbols are hidden and it is loaded as a plugin. A detached translator or second Vulkan device would not faithfully reuse that live state. The generated guest import layer also needs an explicit, tested bridge to the runtime graphics system. Those are integration tasks, not safe places to guess APIs or silently route live draws.

## Verification
Not built or runtime-tested against the user's Codespace checkout. Keep the current `rexgpu-xenos` renderer active until a real-scene parity test passes.
