/*    0.0 */       exec
/*   10   */          vfetch_full r9.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*   11   */          vfetch_mini r4.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   12   */          vfetch_mini r3, Offset=3, DataFormat=FMT_8_8_8_8
/*   13   */          vfetch_mini r6.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   14   */          vfetch_mini r0._xy_, Offset=5, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   15   */          vfetch_mini r1.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       exec    // PredicateClean=false
/*   16   */          vfetch_full r8, r0.x, vf1, DataFormat=FMT_8_8_8_8, Stride=1, Signed=true
/*   17   */          serialize
                      mul r0.x__w, r4.zwww, c255.wwww
/*   18   */          maxas r0._, r0.ww
/*   19   */          mul r7, r3.yyyy, c[30+a0]
/*   20   */          mul r5, r3.yyyy, c[29+a0]
              +       setp_gt r0._, r3.z
/*   21   */          mul r2, r3.yyyy, c[28+a0]
              +       maxas r0._, r0.xx
/*    1.0 */       exec
/*   22   */          mad r2, r3.xxxx, c[28+a0], r2
/*   23   */          mad r5, r3.xxxx, c[29+a0], r5
/*   24   */          mad r7, r3.xxxx, c[30+a0], r7
/*    1.1 */  (p0) exec
/*   25   */     (p0) mul r0.x__w, r4.xyyy, c255.wwww
/*   26   */     (p0) maxas r0._, r0.ww
/*   27   */     (p0) mad r4, r3.wwww, c[30+a0], r7
/*   28   */     (p0) mad r5, r3.wwww, c[29+a0], r5
/*   29   */     (p0) mad r2, r3.wwww, c[28+a0], r2
/*   30   */     (p0) maxas r0._, r0.xx
/*    2.0 */  (p0) exec
/*   31   */     (p0) mad r2, r3.zzzz, c[28+a0], r2
/*   32   */     (p0) mad r5, r3.zzzz, c[29+a0], r5
/*   33   */     (p0) mad r7, r3.zzzz, c[30+a0], r4
/*    2.1 */       exec
/*   34   */          mul r0.xy__, r0.yzzz, c9.xyyy
/*   35   */          tfetch2D r0.xyz_, r0.xy, tf16, UseComputedLOD=false
/*   36   */          serialize
                      mad r3.xyz_, r9.zyxx, c3.zyxx, c4.zyxx
/*   37   */          add r0.xyz_, r3.zyxx, r0.xyzz
/*   38   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   39   */          dp4 r3.x___, r2.zxyw, r0
/*    3.0 */       exec
/*   40   */          dp4 r3._y__, r5.zxyw, r0
/*   41   */          dp4 r3.__z_, r7.zxyw, r0
/*    3.1 */       cjmp !b0, L12
/*    4.0 */       exec
/*   42   */          cndeq r0, c255.zzzx, r3.zxyy, c255.xxxx
/*   43   */          dp4 r4.x___, c0.zxyw, r0
/*   44   */          dp4 r4._y__, c1.zxyw, r0
/*   45   */          dp4 r4.__z_, c2.zxyw, r0
/*   46   */          dp2add r0.x___, r4.xyyy, r4.xyyy, c255.zzzz
/*   47   */          dp3 r0._y__, r4.zxyy, r4.zxyy
/*    4.1 */       exec
/*   48   */          sqrt r0.___w, r_abs[0].y
/*   49   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   50   */          add r0._y__, -r4.zzzz, r0.wwww
/*   51   */          mul r1.__zw, r4.xxxy, r0.wwww
/*   52   */          mul r1.__zw, r1.wwwz, r0.yyyy
              +       rcp r0.x___, r0.x
/*   53   */          mul r0.xy__, r1.wzzz, r0.xxxx
/*    5.0 */       exec
/*   54   */          cndge r0.__zw, r4.zzzz, r0.zzzw, c255.xxxy
/*    5.1 */       jmp L13
                label L12
/*    6.0 */       exec
/*   55   */          cndeq r4, c255.zzzx, r3.zxyy, c255.xxxx
/*   56   */          dp4 r0.x___, c23.zxyw, r4
/*   57   */          dp4 r0._y__, c24.zxyw, r4
/*   58   */          dp4 r0.__z_, c25.zxyw, r4
/*   59   */          dp4 r0.___w, c26.zxyw, r4
                label L13
/*    6.1 */       alloc position
/*    7.0 */       exec
/*   60   */          mad r0.__z_, -r0.wwww, c10.xxxx, r0.zzzz
/*   61   */          max oPos, r0, r0
/*    7.1 */       alloc interpolators
/*    8.0 */       exec
/*   62   */          dp3 r4.x___, r8.zxyy, r5.zxyy
/*   63   */          dp3 r4._y__, r8.zxyy, r7.zxyy
/*   64   */          dp3 r4.__z_, r8.zxyy, r2.zxyy
/*   65   */          dp3 r2.x___, r6.zxyy, r2.zxyy
/*   66   */          dp3 r2._y__, r6.zxyy, r5.zxyy
/*   67   */          dp3 r2.__z_, r6.zxyy, r7.zxyy
/*    8.1 */       exec
/*   68   */          add r8.xy__, r1.xyyy, c7.xyyy
              +       maxs r8.__z_, c5.xx
/*   69   */          add o3.xy__, r1.xyyy, c8.xyyy
/*   70   */          max o2.xyz_, r3.xyzz, r3.xyzz
/*   71   */          max o1, r8, r8
/*   72   */          max o0, r0, r0
/*   73   */          dp3 r0._y__, r2.zxyy, r2.zxyy
/*    9.0 */       exec
/*   74   */          dp3 r0.x___, r4.yzxx, r4.yzxx
              +       rsq r0._y__, r_abs[0].y
/*   75   */          mul r1.xyz_, r2.xyzz, r0.yyyy
              +       rsq r0.x___, r_abs[0].x
/*   76   */          mul o4.xyz_, r4.zxyy, r0.xxxx
/*   77   */          mul o6.xyz_, r2.xyzz, r0.yyyy
/*   78   */          mul r2.xyz_, r4.xyzz, r0.xxxx
/*   79   */          mul r0.xyz_, r2.yzxx, r1.yzxx
/*    9.1 */       exece
/*   80   */          mad r0._yzw, r2.xxyz, r1.zzxy, -r0.xxyz
/*   81   */          dp3 r0.x___, r0.wyzz, r0.wyzz
/*   82   */          rsq r0.x___, r_abs[0].x
/*   83   */          mul r0.xyz_, r0.yzww, r0.xxxx
/*   84   */          mul o5.xyz_, r0.xyzz, c6.zzzz
