/*    0.0 */       exec
/*    8   */          vfetch_full r2.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    9   */          vfetch_mini r1.xy__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   10   */          vfetch_mini r0.___x, Offset=3, DataFormat=FMT_8_8_8_8
/*   11   */          vfetch_mini r6.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   12   */          vfetch_mini r0._w__, Offset=5, DataFormat=FMT_8_8_8_8, Signed=true
/*   13   */          vfetch_mini r0.y_x_, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       exec
/*   14   */          serialize
                      mad r3.xyz_, r2.xyzz, c3.xyzz, c4.xyzz
/*   15   */          mul r5.xy__, r1.xyyy, c255.wwww
/*   16   */          add r1.x___, -r0.wwww, c255.xxxx
              +       maxas r0._, r5.yy
/*   17   */          mul r2, r1.xxxx, c[30+a0]
/*   18   */          mul r4, r1.xxxx, c[29+a0]
/*   19   */          mul r1, r1.xxxx, c[28+a0]
              +       maxas r0._, r5.xx
/*    1.0 */       exec
/*   20   */          mad r1, r0.wwww, c[28+a0], r1
/*   21   */          mad r5, r0.wwww, c[29+a0], r4
/*   22   */          mad r2, r0.wwww, c[30+a0], r2
/*   23   */          cndeq r4, c255.zzzx, r3.zxyy, c255.xxxx
/*   24   */          dp4 r3.x___, r1.zxyw, r4
/*   25   */          dp4 r3._y__, r5.zxyw, r4
/*    1.1 */       exec
/*   26   */          dp4 r3.__z_, r2.zxyw, r4
/*    2.0 */       cjmp !b0, L9
/*    2.1 */       exec
/*   27   */          cndeq r4, c255.zzzx, r3.zxyy, c255.xxxx
/*   28   */          dp4 r7.x___, c0.zxyw, r4
/*   29   */          dp4 r7._y__, c1.zxyw, r4
/*   30   */          dp4 r7.__z_, c2.zxyw, r4
/*   31   */          dp2add r0.___w, r7.xyyy, r7.xyyy, c255.zzzz
/*   32   */          dp3 r3.___w, r7.zxyy, r7.zxyy
/*    3.0 */       exec
/*   33   */          sqrt r4._y__, r_abs[3].w
/*   34   */          mad r4.x___, r4.yyyy, c27.xxxx, c27.yyyy
/*   35   */          add r3.___w, -r7.zzzz, r4.yyyy
/*   36   */          mul r4.__zw, r7.xxxy, r4.yyyy
/*   37   */          mul r4.__zw, r4.wwwz, r3.wwww
              +       rcp r0.___w, r0.w
/*   38   */          mul r4.__zw, r4.wwwz, r0.wwww
/*    3.1 */       exec
/*   39   */          cndge r4.xy__, r7.zzzz, r4.xyyy, c255.xyyy
/*    4.0 */       jmp L10
                label L9
/*    4.1 */       exec
/*   40   */          cndeq r7, c255.zzzx, r3.zxyy, c255.xxxx
/*   41   */          dp4 r4.__z_, c23.zxyw, r7
/*   42   */          dp4 r4.___w, c24.zxyw, r7
/*   43   */          dp4 r4.x___, c25.zxyw, r7
/*   44   */          dp4 r4._y__, c26.zxyw, r7
                label L10
/*    5.0 */       alloc position
/*    5.1 */       exec
/*   45   */          mad r4.x___, -r4.yyyy, c7.xxxx, r4.xxxx
/*   46   */          max oPos, r4.zwxy, r4.zwxy
/*    6.0 */       alloc interpolators
/*    6.1 */       exec
/*   47   */          dp3 r1.x___, r6.zxyy, r1.zxyy
/*   48   */          dp3 r1._y__, r6.zxyy, r5.zxyy
/*   49   */          dp3 r1.__z_, r6.zxyy, r2.zxyy
/*   50   */          add r0.x_z_, r0.xzzz, c6.xyyy
              +       maxs r0.___w, c5.xx
/*   51   */          max o2.xyz_, r3.xyzz, r3.xyzz
/*   52   */          max o1, r0.xzwy, r0.xzwy
/*    7.0 */       exece
/*   53   */          max o0, r4.zwxy, r4.zwxy
/*   54   */          dp3 r0.x___, r1.zxyy, r1.zxyy
/*   55   */          rsq r0.x___, r_abs[0].x
/*   56   */          mul o3.xyz_, r1.xyzz, r0.xxxx
/*    7.1 */       cnop
