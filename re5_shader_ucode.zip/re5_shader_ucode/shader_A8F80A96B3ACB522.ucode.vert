/*    0.0 */       exec
/*    5   */          vfetch_full r2.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=4
/*    6   */          vfetch_mini r4, Offset=3, DataFormat=FMT_8_8_8_8
/*    7   */          vfetch_mini r0, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    8   */          serialize
                      mul r0.xy__, r0.xyyy, c255.xxxx
/*    9   */          maxas r0._, r0.yy
/*   10   */          mul r3, r4.yyyy, c[25+a0]
/*    0.1 */       exec    // PredicateClean=false
/*   11   */          mul r5, r4.yyyy, c[24+a0]
              +       setp_gt r0._, r4.z
/*   12   */          mul r1, r4.yyyy, c[23+a0]
              +       maxas r0._, r0.xx
/*   13   */          mad r1.xyz_, r4.xxxx, c[23+a0].xyzz, r1.xyzz
/*   14   */          mad r0.x___, r4.xxxx, c[23+a0].wwww, r1.wwww
/*   15   */          mad r5, r4.xxxx, c[24+a0], r5
/*   16   */          mad r3.xyz_, r4.xxxx, c[25+a0].xyzz, r3.xyzz
/*    1.0 */       exec
/*   17   */          mad r0._y__, r4.xxxx, c[25+a0].wwww, r3.wwww
/*    1.1 */  (p0) exec
/*   18   */     (p0) mul r0.__zw, r0.zzzw, c255.xxxx
/*   19   */     (p0) maxas r0._, r0.ww
/*   20   */     (p0) mul r7, r4.wwww, c[23+a0]
/*   21   */     (p0) mad r5, r4.wwww, c[24+a0], r5
/*   22   */     (p0) mul r6, r4.wwww, c[25+a0]
              +  (p0) maxas r0._, r0.zz
/*   23   */     (p0) mad r5, r4.zzzz, c[24+a0], r5
/*    2.0 */  (p0) exec
/*   24   */     (p0) mad r6, r4.zzzz, c[25+a0], r6
/*   25   */     (p0) mad r4, r4.zzzz, c[23+a0], r7
/*   26   */     (p0) add r0.x___, r4.wwww, r0.xxxx
/*   27   */     (p0) add r1.xyz_, r4.xyzz, r1.xyzz
              +  (p0) maxs r0._, r6.ww
/*   28   */     (p0) add r3.xyz_, r6.xyzz, r3.xyzz
              +  (p0) adds_prev r0._y__, r0.y
/*    2.1 */       alloc position
/*    3.0 */       exec
/*   29   */          mad r2.xyz_, r2.xyzz, c215.xyzz, c4.xyzz
/*   30   */          dp3 r0.__z_, r2.zxyy, r1.zxyy
/*   31   */          dp3 r0.___w, r2.zxyy, r3.zxyy
              +       sges r2.___w, r_abs[0].x
/*   32   */          dp4 r1._y__, r5.zxyw, r2.zxyw
/*   33   */          add r1.x_z_, r0.zwww, r0.xyyy
              +       sges r0.___w, r_abs[0].x
/*   34   */          mad r0.xyz_, c6.xyzz, c5.xxxx, r1.xyzz
/*    3.1 */       exec
/*   35   */          dp4 oPos.x___, c0.zxyw, r0.zxyw
/*   36   */          dp4 oPos._y__, c1.zxyw, r0.zxyw
/*   37   */          dp4 oPos.__z_, c2.zxyw, r0.zxyw
/*   38   */          dp4 oPos.___w, c3.zxyw, r0.zxyw
/*    4.0 */       alloc interpolators
/*    4.1 */       exece
