/*    0.0 */       exec
/*    2   */          tfetch2D r0.xyz_, r0.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    3   */          mul r0.xyz_, r0.xzyy, c0.xxxx
/*    4   */          max r0.___w, r0.zzzz, c255.xxxx
              +       maxs r1.x___, r0.xy
/*    5   */          max r0.___w, r1.xxxx, r0.wwww
/*    6   */          rcp r0.___w, r0.w
/*    7   */          mul r0.xyz_, r0.xzyy, r0.wwww
/*    8   */          max oC0, r0, r0
/*    1.1 */       cnop
