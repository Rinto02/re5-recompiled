/*    0.0 */       exec
/*    2   */          add r4._y__, c2.zzzz, c255.xxxx
              +       rcp r4.x___, r2.w
/*    3   */          mad r4.x_z_, r4.xxxx, r2.xyyy, c3.xyyy
/*    4   */          mul r4.x_z_, r4.xzzz, c4.xyyy
/*    5   */          tfetch2D r5, r1.xy, tf0
/*    6   */          tfetch2D r4.x___, r4.xz, tf1
/*    0.1 */       alloc colors
/*    1.0 */       exec
/*    7   */          add r4.x___, r4.yyyy, -r4.xxxx
/*    8   */          mul r0, r5.xwyz, r0.xwyz
/*    9   */          add r4._yzw, -r0.xxzw, r3.xxyz
              +       rcp r4.x___, r4.x
/*   10   */          mad r3.xyz_, r4.yzww, r3.wwww, r0.xzww
/*   11   */          mad r2.x___, r4.xxxx, c2.wwww, -r2.zzzz
/*   12   */          mul r1.x___, r_abs[2].xxxx, r1.wwww
/*    1.1 */       exece
/*   13   */          mul oC0.xyz_, r3.xyzz, c23.xxxx
/*   14   */          min r0.x___, r1.xxxx, c255.xxxx
/*   15   */          mul oC0.___w, r0.yyyy, r0.xxxx
