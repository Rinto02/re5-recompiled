/*    0.0 */       exec
/*    8   */          vfetch_full r4.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*    9   */          vfetch_mini r2.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*   10   */          vfetch_mini r9, Offset=4, DataFormat=FMT_8_8_8_8, Signed=true
/*   11   */          vfetch_mini r0._yx_, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   12   */          vfetch_mini r1.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   13   */          vfetch_mini r7.zyxw, Offset=7, DataFormat=FMT_8_8_8_8
/*    0.1 */       exec
/*   14   */          serialize
                      max r8, c28, c28
/*   15   */          max r3, c29, c29
/*   16   */          max r6, c30, c30
/*   17   */          cndeq r4, c255.zzzx, r4.zxyy, c255.xxxx
/*   18   */          dp4 r5.x___, r8.zxyw, r4
/*   19   */          dp4 r5._y__, r3.zxyw, r4
/*    1.0 */       exec
/*   20   */          dp4 r5.__z_, r6.zxyw, r4
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   21   */          cndeq r4, c255.zzzx, r5.zxyy, c255.xxxx
/*   22   */          dp4 r10.x___, c0.zxyw, r4
/*   23   */          dp4 r10._y__, c1.zxyw, r4
/*   24   */          dp4 r10.__z_, c2.zxyw, r4
/*   25   */          dp2add r1.__z_, r10.xyyy, r10.xyyy, c255.zzzz
/*   26   */          dp3 r0.x___, r10.zxyy, r10.zxyy
/*    2.1 */       exec
/*   27   */          sqrt r0.___w, r_abs[0].x
/*   28   */          mad r0.x___, r0.wwww, c27.xxxx, c27.yyyy
/*   29   */          add r1.___w, -r10.zzzz, r0.wwww
/*   30   */          mul r4.xy__, r10.xyyy, r0.wwww
/*   31   */          mul r4.xy__, r4.yxxx, r1.wwww
              +       rcp r1.__z_, r1.z
/*   32   */          mul r4.xy__, r4.yxxx, r1.zzzz
/*    3.0 */       exec
/*   33   */          cndge r4.__zw, r10.zzzz, r0.xxxw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   34   */          cndeq r10, c255.zzzx, r5.zxyy, c255.xxxx
/*   35   */          dp4 r4.x___, c23.zxyw, r10
/*   36   */          dp4 r4._y__, c24.zxyw, r10
/*   37   */          dp4 r4.__z_, c25.zxyw, r10
/*   38   */          dp4 r4.___w, c26.zxyw, r10
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   39   */          mad r4.__z_, -r4.wwww, c6.xxxx, r4.zzzz
/*   40   */          max oPos, r4, r4
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   41   */          dp3 r10.x___, r2.zxyy, r3.zxyy
/*   42   */          dp3 r10._y__, r2.zxyy, r8.zxyy
/*   43   */          dp3 r10.__z_, r2.zxyy, r6.zxyy
              +       maxs r2.x___, r9.xx
/*   44   */          max r2._y__, r9.yyyy, r9.yyyy
              +       maxs r2.__z_, r9.zz
/*   45   */          dp3 r6.__z_, r2.zxyy, r6.zxyy
              +       maxs r9.__z_, c31.xx
/*   46   */          dp3 r6._y__, r2.zxyy, r3.zxyy
              +       addsc r9.x___, c4.x, r0.y
/*    6.1 */       exec
/*   47   */          dp3 r6.x___, r2.zxyy, r8.zxyy
              +       addsc r9._y__, c4.y, r0.z
/*   48   */          add o3.xy__, r1.xyyy, c5.xyyy
/*   49   */          max o2.xyz_, r5.xyzz, r5.xyzz
/*   50   */          max o5.xyz_, r6.xyzz, r6.xyzz
/*   51   */          max o7.xyz_, r10.yxzz, r10.yxzz
/*   52   */          max o1, r9, r9
/*    7.0 */       exec
/*   53   */          max o0, r4, r4
/*   54   */          mul r1.xy__, r6.xxxx, r10.zxxx
              +       rcp r0.x___, r7.w
/*   55   */          mul o4.xyz_, r0.xxxx, r7.xyzz
/*   56   */          mul r0, r6.yzyz, r10.zxyy
/*   57   */          add r0.__z_, r1.yyyy, -r0.zzzz
/*   58   */          add r0.___w, r0.wwww, -r1.xxxx
              +       subs r0._y__, r0.xy
/*    7.1 */       exece
/*   59   */          dp3 r0.x___, r0.zyww, r0.zyww
/*   60   */          rsq r0.x___, r_abs[0].x
/*   61   */          mul r0.xyz_, r0.yzww, r0.xxxx
/*   62   */          mul o6.xyz_, r0.xzyy, c3.zzzz
