/*    0.0 */       exec
/*    6   */          vfetch_full r4.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=6
/*    7   */          vfetch_mini r1.yx__, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    8   */          serialize
                      max r2, c28, c28
/*    9   */          max r0, c29, c29
/*   10   */          max r3, c30.zyxw, c30.zyxw
/*   11   */          cndeq r4, c255.zzzx, r4.zxyy, c255.xxxx
/*    0.1 */       exec
/*   12   */          dp4 r2.x___, r2.zxyw, r4
/*   13   */          dp4 r2._y__, r0.zxyw, r4
/*   14   */          dp4 r2.__z_, r3.xzyw, r4
/*    1.0 */       cjmp !b0, L7
/*    1.1 */       exec
/*   15   */          cndeq r0, c255.zzzx, r2.zxyy, c255.xxxx
/*   16   */          dp4 r2.x___, c0.zxyw, r0
/*   17   */          dp4 r2._y__, c1.zxyw, r0
/*   18   */          dp4 r2.__z_, c2.zxyw, r0
/*   19   */          dp2add r0.x___, r2.xyyy, r2.xyyy, c255.zzzz
/*   20   */          dp3 r0._y__, r2.zxyy, r2.zxyy
/*    2.0 */       exec
/*   21   */          sqrt r0.___w, r_abs[0].y
/*   22   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   23   */          add r0._y__, -r2.zzzz, r0.wwww
/*   24   */          mul r1.__zw, r2.xxxy, r0.wwww
/*   25   */          mul r1.__zw, r1.wwwz, r0.yyyy
              +       rcp r0.x___, r0.x
/*   26   */          mul r0.xy__, r1.wzzz, r0.xxxx
/*    2.1 */       exec
/*   27   */          cndge r0.__zw, r2.zzzz, r0.zzzw, c255.xxxy
/*    3.0 */       jmp L8
                label L7
/*    3.1 */       exec
/*   28   */          cndeq r2, c255.zzzx, r2.zxyy, c255.xxxx
/*   29   */          dp4 r0.x___, c23.zxyw, r2
/*   30   */          dp4 r0._y__, c24.zxyw, r2
/*   31   */          dp4 r0.__z_, c25.zxyw, r2
/*   32   */          dp4 r0.___w, c26.zxyw, r2
                label L8
/*    4.0 */       alloc position
/*    4.1 */       exec
/*   33   */          max oPos, r0, r0
/*    5.0 */       alloc interpolators
/*    5.1 */       exece
/*   34   */          add o0.xy__, r1.xyyy, c31.xyyy
