/*    0.0 */       exec
/*   14   */          add r3.xyz_, r0.xyzz, -c23.xyzz
/*   15   */          dp3 r1.___w, r3.zxyy, r3.zxyy
/*   16   */          sgt r2.___w, -r_abs[0].xxxx, c255.xxxx
              +       sqrt r0.___w, r_abs[1].w
/*    0.1 */       cjmp !b132, L5
/*    1.0 */       exec
/*   17   */          mad r2.__z_, r0.wwww, c4.yyyy, c4.zzzz
/*   18   */          add r4.x___, r0.wwww, -c1.xxxx
              +       rsq r0.___w, r_abs[1].w
/*   19   */          mul r3.xyz_, r3.xyzz, r0.wwww
/*   20   */          cndeq r5, c255.xxxy, r0.zxyy, c255.yyyy
/*   21   */          dp4 r4._y__, c2.zxyw, r5
/*   22   */          dp3 r4.__z_, r3.zxyy, c2.zxyy
/*    1.1 */       exec
/*   23   */          mul r3.__zw, r4.xxxy, c1.zzzw
/*   24   */          min r3.xy__, r4.yzzz, c255.xzzz
/*   25   */          max r1.___w, r3.zzzz, r3.wwww
              +       rcp r0.___w, r3.y
/*   26   */          mulsc r0.___w, c4.x, r0.w
/*   27   */          mad r0.___w, r0.wwww, r3.xxxx, r2.zzzz
/*   28   */          max r0.___w, r1.wwww, r0.wwww
/*    2.0 */       exec
/*   29   */          min r0.___w, r0.wwww, c3.wwww
/*   30   */          max r0.___w, r0.wwww, c255.xxxx
/*   31   */          mulsc r2.___w, c5.x, r0.w
                label L5
/*    2.1 */       exec
/*   32   */          maxs r3.x___, c255.yy
/*    3.0 */       cjmp !b128, L23
/*    3.1 */       exec
/*   33   */          add r3.xyz_, -r0.zyxx, c25.zyxx
/*   34   */          dp3 r3.___w, r3.xzyy, r3.xzyy
/*   35   */          rsq r0.___w, r_abs[3].w
/*   36   */          mul r3, r3, r0.wwww
/*   37   */          dp3 r1.___w, r3.xzyy, r1.zxyy
/*   38   */          dp3 r0.___w, r3.xzyy, -c26.zxyy
/*    4.0 */       exec
/*   39   */          add r0.___w, r0.wwww, -c27.xxxx
              +       maxs r2.__z_, r3.ww
/*   40   */          mul r0.___w, r0.wwww, c27.yyyy
              +       subsc r2.__z_, -c24.w, -r2.z
/*   41   */          max r3.x___, r0.wwww, c27.wwww
              +       mulsc_sat r0.___w, c25.w, r2.z
/*   42   */          min r3.x___, r3.xxxx, c255.yyyy
              +       subsc r0.___w, c255.y, r0.w
/*   43   */          mul r3._y__, r0.wwww, r3.xxxx
              +       maxs r4.x___, r1.ww
/*   44   */          mul r3.xy_w, r3.yyxx, c24.zyxx
              +       maxs r4._y__, c255.xx
/*    4.1 */       exec
/*   45   */          mul r3.__z_, r3.wwww, r0.wwww
              +       maxs r0.___w, r4.xy
/*   46   */          mul r3.xyz_, r3.xyzz, r0.wwww
/*   47   */          mad r3.xyz_, r3.zyxx, c27.zzzz, c255.yyyy
/*    5.0 */       cjmp !b129, L22
/*    5.1 */       exec
/*   48   */          add r4.xyz_, -r0.xyzz, c29.xyzz
/*   49   */          dp3 r4.___w, r4.zxyy, r4.zxyy
/*   50   */          rsq r0.___w, r_abs[4].w
/*   51   */          mul r4, r4, r0.wwww
/*   52   */          dp3 r1.___w, r4.zxyy, r1.zxyy
/*   53   */          dp3 r0.___w, r4.zxyy, -c30.zxyy
/*    6.0 */       exec
/*   54   */          add r0.___w, r0.wwww, -c31.xxxx
              +       maxs r2.__z_, r4.ww
/*   55   */          mul r0.___w, r0.wwww, c31.yyyy
              +       subsc r2.__z_, -c28.w, -r2.z
/*   56   */          max r3.___w, r0.wwww, c31.wwww
              +       mulsc_sat r0.___w, c29.w, r2.z
/*   57   */          min r4.x___, r3.wwww, c255.yyyy
              +       subsc r0.___w, c255.y, r0.w
/*   58   */          mul r4._y__, r0.wwww, r4.xxxx
              +       maxs r5.x___, r1.ww
/*   59   */          mul r4.xy_w, r4.yyxx, c28.zyxx
              +       maxs r5._y__, c255.xx
/*    6.1 */       exec
/*   60   */          mul r4.__z_, r4.wwww, r0.wwww
              +       maxs r0.___w, r5.xy
/*   61   */          mul r4.xyz_, r4.xyzz, r0.wwww
/*   62   */          mad r3.xyz_, r4.zyxx, c31.zzzz, r3.xyzz
/*    7.0 */       cjmp !b130, L22
/*    7.1 */       exec
/*   63   */          add r4.xyz_, -r0.zyxx, c33.zyxx
/*   64   */          dp3 r4.___w, r4.xzyy, r4.xzyy
/*   65   */          rsq r0.___w, r_abs[4].w
/*   66   */          mul r4, r4, r0.wwww
/*   67   */          dp3 r1.___w, r4.xzyy, r1.zxyy
/*   68   */          dp3 r0.___w, r4.xzyy, -c34.zxyy
/*    8.0 */       exec
/*   69   */          add r0.___w, r0.wwww, -c35.xxxx
              +       maxs r2.__z_, r4.ww
/*   70   */          mul r0.___w, r0.wwww, c35.yyyy
              +       subsc r2.__z_, -c32.w, -r2.z
/*   71   */          max r3.___w, r0.wwww, c35.wwww
              +       mulsc_sat r0.___w, c33.w, r2.z
/*   72   */          min r4.x___, r3.wwww, c255.yyyy
              +       subsc r0.___w, c255.y, r0.w
/*   73   */          mul r4._y__, r0.wwww, r4.xxxx
              +       maxs r5.x___, r1.ww
/*   74   */          mul r4.xy_w, r4.yyxx, c32.zyxx
              +       maxs r5._y__, c255.xx
/*    8.1 */       exec
/*   75   */          mul r4.__z_, r4.wwww, r0.wwww
              +       maxs r0.___w, r5.xy
/*   76   */          mul r4.xyz_, r4.xyzz, r0.wwww
/*   77   */          mad r3.xyz_, r4.zyxx, c35.zzzz, r3.xyzz
/*    9.0 */       cjmp !b131, L22
/*    9.1 */       exec
/*   78   */          add r4.xyz_, -r0.xyzz, c37.xyzz
/*   79   */          dp3 r4.___w, r4.zxyy, r4.zxyy
/*   80   */          rsq r0.x___, r_abs[4].w
/*   81   */          mul r0, r4.wxyz, r0.xxxx
/*   82   */          dp3 r1.x___, r0.wyzz, r1.zxyy
/*   83   */          dp3 r1._y__, r0.wyzz, -c38.zxyy
/*   10.0 */       exec
/*   84   */          add r0._y__, r1.yyyy, -c39.xxxx
              +       maxs r0.x___, r0.xx
/*   85   */          mul r0._y__, r0.yyyy, c39.yyyy
              +       subsc r0.x___, -c36.w, -r0.x
/*   86   */          max r0._y__, r0.yyyy, c39.wwww
              +       mulsc_sat r0.x___, c37.w, r0.x
/*   87   */          min r0._y__, r0.yyyy, c255.yyyy
              +       subsc r0.__z_, c255.y, r0.x
/*   88   */          mul r0.___w, r0.zzzz, r0.yyyy
              +       maxs r0.x___, r1.xx
/*   89   */          mul r1.xy_w, r0.wwyy, c36.zyxx
              +       maxs r0._y__, c255.xx
/*   10.1 */       exec
/*   90   */          mul r1.__z_, r1.wwww, r0.zzzz
              +       maxs r0.x___, r0.xy
/*   91   */          mul r0.xyz_, r1.xyzz, r0.xxxx
/*   92   */          mad r3.xyz_, r0.zyxx, c39.zzzz, r3.xyzz
                label L22
/*   11.0 */       jmp L24
                label L23
/*   11.1 */       exec
/*   93   */          max r3._yz_, c255.yyyy, c255.yyyy
                label L24
/*   12.0 */       exec
/*   94   */          tfetch2D r0, r2.xy, tf0
/*   95   */          tfetch2D r1, r2.xy, tf1
/*   12.1 */       alloc colors
/*   13.0 */       exec
/*   96   */          max r2.x___, r1.wwww, c255.wwww
/*   97   */          max r1.___w, r0.wwww, c255.wwww
              +       rcp r2.x___, r2.x
/*   98   */          mul r1.xyz_, r2.xxxx, r1.xyzz
              +       rcp r1.___w, r1.w
/*   99   */          mul r0.xyz_, r1.wwww, r0.xyzz
/*  100   */          mul r0.xyz_, r0.xyzz, c6.xyzz
/*  101   */          mad r1.xyz_, r1.xyzz, c7.xyzz, -r0.xyzz
/*   13.1 */       exece
/*  102   */          mad r0.xyz_, r1.xyzz, c7.wwww, r0.xyzz
/*  103   */          mul r0.xyz_, r0.xyzz, r3.xyzz
/*  104   */          add r1.xyz_, -r0.xyzz, c3.xyzz
/*  105   */          mad r0.xyz_, r1.xyzz, r2.wwww, r0.xyzz
/*  106   */          mul oC0.xyz1, r0.xyzz, c0.xxxx
