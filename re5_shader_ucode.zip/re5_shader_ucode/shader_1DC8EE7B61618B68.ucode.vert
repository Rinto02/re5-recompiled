/*    0.0 */       exec
/*    8   */          vfetch_full r2.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=4
/*    9   */          vfetch_mini r3.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   10   */          vfetch_mini r0, Offset=3, DataFormat=FMT_8_8_8_8
/*   11   */          serialize
                      mul r6.xy__, r3.zwww, c255.wwww
/*   12   */          maxas r0._, r6.yy
/*   13   */          mul r5, r0.yyyy, c[30+a0]
/*    0.1 */       exec    // PredicateClean=false
/*   14   */          mul r1, r0.yyyy, c[29+a0]
              +       setp_gt r0._, r0.z
/*   15   */          mul r4, r0.yyyy, c[28+a0]
              +       maxas r0._, r6.xx
/*   16   */          mad r4, r0.xxxx, c[28+a0], r4
/*   17   */          mad r1, r0.xxxx, c[29+a0], r1
/*   18   */          mad r5, r0.xxxx, c[30+a0].zyxw, r5.zyxw
/*    1.0 */  (p0) exec
/*   19   */     (p0) mul r0.xy__, r3.xyyy, c255.wwww
/*   20   */     (p0) maxas r0._, r0.yy
/*   21   */     (p0) mad r3, r0.wwww, c[30+a0], r5.zyxw
/*   22   */     (p0) mad r1, r0.wwww, c[29+a0], r1
/*   23   */     (p0) mad r4, r0.wwww, c[28+a0], r4
/*   24   */     (p0) maxas r0._, r0.xx
/*    1.1 */  (p0) exec
/*   25   */     (p0) mad r4, r0.zzzz, c[28+a0], r4
/*   26   */     (p0) mad r1, r0.zzzz, c[29+a0], r1
/*   27   */     (p0) mad r5, r0.zzzz, c[30+a0].zyxw, r3.zyxw
/*    2.0 */       exec
/*   28   */          mad r0.xyz_, r2.xyzz, c3.xyzz, c4.xyzz
/*   29   */          cndeq r2, c255.zzzx, r0.zxyy, c255.xxxx
/*   30   */          dp4 r0.x___, r4.zxyw, r2
/*   31   */          dp4 r0._y__, r1.zxyw, r2
/*   32   */          dp4 r0.__z_, r5.xzyw, r2
/*    2.1 */       cjmp !b0, L10
/*    3.0 */       exec
/*   33   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   34   */          dp4 r1.x___, c0.zxyw, r0
/*   35   */          dp4 r1._y__, c1.zxyw, r0
/*   36   */          dp4 r1.__z_, c2.zxyw, r0
/*   37   */          dp2add r0.__z_, r1.xyyy, r1.xyyy, c255.zzzz
/*   38   */          dp3 r0.x___, r1.zxyy, r1.zxyy
/*    3.1 */       exec
/*   39   */          sqrt r0._y__, r_abs[0].x
/*   40   */          mad r0.x___, r0.yyyy, c27.xxxx, c27.yyyy
/*   41   */          add r0.___w, -r1.zzzz, r0.yyyy
/*   42   */          mul r2.xy__, r1.xyyy, r0.yyyy
/*   43   */          mul r2.xy__, r2.yxxx, r0.wwww
              +       rcp r0.__z_, r0.z
/*   44   */          mul r0.__zw, r2.yyyx, r0.zzzz
/*    4.0 */       exec
/*   45   */          cndge r0.xy__, r1.zzzz, r0.xyyy, c255.xyyy
/*    4.1 */       jmp L11
                label L10
/*    5.0 */       exec
/*   46   */          cndeq r1, c255.zzzx, r0.zxyy, c255.xxxx
/*   47   */          dp4 r0.__z_, c23.zxyw, r1
/*   48   */          dp4 r0.___w, c24.zxyw, r1
/*   49   */          dp4 r0.x___, c25.zxyw, r1
/*   50   */          dp4 r0._y__, c26.zxyw, r1
                label L11
/*    5.1 */       alloc position
/*    6.0 */       exec
/*   51   */          max oPos, r0.zwxy, r0.zwxy
/*    6.1 */       alloc interpolators
/*    7.0 */       exece
/*    7.1 */       cnop
