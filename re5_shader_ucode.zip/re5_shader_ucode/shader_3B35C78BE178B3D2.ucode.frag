/*    0.0 */       exec
/*    7   */          tfetch2D r10, r5.xy, tf0
/*    8   */          tfetch2D r14, r5.zw, tf0
/*    9   */          tfetch2D r13, r0.xy, tf0
/*   10   */          tfetch2D r12, r0.zw, tf0
/*   11   */          tfetch2D r16, r4.zw, tf0
/*   12   */          tfetch2D r11.xwyz, r7.xy, tf0
/*    0.1 */       exec
/*   13   */          tfetch2D r9, r7.zw, tf0
/*   14   */          tfetch2D r7, r3.zw, tf0
/*   15   */          tfetch2D r17, r4.xy, tf0
/*   16   */          tfetch2D r8, r1.xy, tf0
/*   17   */          tfetch2D r1, r1.zw, tf0
/*   18   */          tfetch2D r15, r6.xy, tf0
/*    1.0 */       exec
/*   19   */          tfetch2D r18, r2.xy, tf0
/*   20   */          tfetch2D r5, r2.zw, tf0
/*   21   */          tfetch2D r2, r3.xy, tf0
/*   22   */          tfetch2D r0.xwyz, r6.zw, tf0
/*    1.1 */       alloc colors
/*    2.0 */       exec
/*   23   */          dp3 r0.__z_, r0.wxzz, c255.xyzz
/*   24   */          dp3 r0.___w, r2.zxyy, c255.xyzz
/*   25   */          dp3 r4.x___, r5.zxyy, c255.xyzz
/*   26   */          dp3 r4._y__, r18.zxyy, c255.xyzz
/*   27   */          dp3 r4.__z_, r15.zxyy, c255.xyzz
/*   28   */          dp3 r4.___w, r1.zxyy, c255.xyzz
/*    2.1 */       exec
/*   29   */          dp3 r8.x___, r8.zxyy, c255.xyzz
/*   30   */          dp3 r8._y__, r17.zxyy, c255.xyzz
/*   31   */          dp3 r8.__z_, r7.zxyy, c255.xyzz
/*   32   */          dp3 r9.x___, r9.zxyy, c255.xyzz
/*   33   */          dp3 r9._y__, r11.wxzz, c255.xyzz
              +       maxs r0.x___, r18.ww
/*   34   */          add r6.x___, r0.yyyy, -c254.wwww
              +       subsc r6.__z_, -c254.w, -r0.x
/*    3.0 */       exec
/*   35   */          dp3 r9.__z_, r16.zxyy, c255.xyzz
              +       maxs r0.x___, r2.ww
/*   36   */          add r2._y__, r17.wwww, -c254.wwww
              +       subsc r6._y__, -c254.w, -r0.x
/*   37   */          dp3 r11.x___, r12.zxyy, c255.xyzz
              +       maxs r0.x___, r16.ww
/*   38   */          add r2.__z_, r15.wwww, -c254.wwww
              +       subsc r2.x___, -c254.w, -r0.x
/*   39   */          add r3._y__, r11.yyyy, -c254.wwww
              +       maxs r0._y__, r8.ww
/*   40   */          dp3 r11._y__, r13.zxyy, c255.xyzz
              +       maxs r0.x___, r9.ww
/*    3.1 */       exec
/*   41   */          add r3.__z_, r1.wwww, -c254.wwww
              +       subsc r3.x___, -c254.w, -r0.x
/*   42   */          dp3 r11.__z_, r14.zxyy, c255.xyzz
              +       maxs r0.x___, r14.ww
/*   43   */          add r1.x___, r13.wwww, -c254.wwww
              +       subsc r1.__z_, -c254.w, -r0.x
/*   44   */          dp3 r11.___w, r10.zxyy, c255.xyzz
              +       maxs r0.x___, r12.ww
/*   45   */          add r1.___w, r10.wwww, -c254.wwww
              +       subsc r1._y__, -c254.w, -r0.x
/*   46   */          sgt r13, r1.zwxy, -r1.zwxy
              +       maxs r0.x___, r7.ww
/*    4.0 */       exec
/*   47   */          sgt r10, -r1.yxzw, r1.yxzw
              +       subsc r3.___w, -c254.w, -r0.x
/*   48   */          sgt r12, r3.wzxy, -r3.wzxy
              +       subsc r2.___w, -c254.w, -r0.y
/*   49   */          sgt r1, -r2.zwyx, r2.zwyx
              +       maxs r0.x___, r5.ww
/*   50   */          sgt r5, r2.zxwy, -r2.zxwy
              +       subsc r6.___w, -c254.w, -r0.x
/*   51   */          sgt r2, -r6.wzxy, r6.wzxy
/*   52   */          sgt r6, r6.wzxy, -r6.wzxy
/*    4.1 */       exec
/*   53   */          add r7.x___, r5.yyyy, -r1.wwww
/*   54   */          sgt r3, -r3.wzxy, r3.wzxy
              +       maxs r0._, r5.xx
/*   55   */          add r5.xy__, r12.xyyy, -r3.xyyy
              +       adds_prev r1.x___, -r1.x
/*   56   */          add r5.__zw, r5.zzzw, -r1.yyyz
              +       maxs r0._, r12.ww
/*   57   */          add r1._yzw, r6.xxyw, -r2.xxyw
              +       adds_prev r7._y__, -r3.w
/*   58   */          add r10, r13.zwxy, -r10.yxzw
              +       maxs r0._, r12.zz
/*    5.0 */       exec
/*   59   */          dp4 r8.___w, r11.zwyx, r10.zwxy
              +       adds_prev r7.__z_, -r3.z
/*   60   */          cndeq r3, c254.xxxy, r1.xyzz, c255.wwww
/*   61   */          dp3 r0.x___, r9.xyzz, r7.zyxx
/*   62   */          cndeq r7, c254.xxxy, r5.wxzz, c255.wwww
/*   63   */          dp4 r0._y__, r8.yzxw, r7
/*   64   */          add r0.x___, r0.yyyy, r0.xxxx
              +       maxs r0._, r6.zz
/*    5.1 */       exec
/*   65   */          mad r4.___w, r4.wwww, r5.yyyy, r0.xxxx
/*   66   */          dp4 r0.x___, r4.zxyw, r3
              +       adds_prev r0._y__, -r2.z
/*   67   */          mad r0.x___, r0.wwww, r1.wwww, r0.xxxx
/*   68   */          mad r0._y__, r0.zzzz, r0.yyyy, r0.xxxx
/*   69   */          mulsc r0.x___, c253.x, r0.y
/*   70   */          sgt r0._y__, r0.xxxx, -r0.xxxx
              +       maxs r0._, r_abs[0].xx
/*    6.0 */       exece
/*   71   */          sgt r0.x___, -r0.xxxx, r0.xxxx
              +       muls_prev r0.___w, c253.y
/*   72   */          add r0.x___, r0.yyyy, -r0.xxxx
              +       frcs r0.__z_, r0.w
/*   73   */          mulsc r0._y__, c253.y, r0.z
/*   74   */          floor r1.xy__, r0.ywww
              +       addsc r1.__z_, c255.w, r0.x
/*   75   */          mul oC0.x_zw, r1.xyyz, c254.zzzw
              +       frcs oC0._y__, r0.y
/*    6.1 */       cnop
