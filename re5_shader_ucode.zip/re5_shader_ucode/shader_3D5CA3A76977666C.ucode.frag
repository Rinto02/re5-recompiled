/*    0.0 */       exec
/*   21   */          tfetch2D r7.yxzw, r1.xy, tf0
/*   22   */          serialize
                      mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r7.ww
/*   23   */          add r8.xyz_, r2.xyzz, -c23.xyzz
              +       rcp r1.x___, r0.w
/*   24   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   25   */          mul r0.__zw, r3.zzzw, r0.yyyx
              +       subsc r1.x___, -c1.x, -r1.y
/*   26   */          kill_gt r1._, c254.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   27   */          tfetch2D r0.xy__, r3.xy, tf1
/*   28   */          tfetch2D r9, r0.zw, tf2
/*    1.0 */       alloc colors
/*    1.1 */       exec
/*   29   */          sgt r3.xyz_, -r_abs[1].xxxx, c254.xxxx
              +       retain_prev r1._
/*   30   */          dp3 r3.___w, r8.zxyy, r8.zxyy
              +       maxs r1.x___, r7.zz
/*   31   */          mul r9, r9.wzyx, c5.wzyx
              +       mulsc r7.__z_, c12.z, r1.x
/*   32   */          mad r0.x__w, r0.yxxx, c254.wwww, c255.xxxx
              +       retain_prev r1._
/*   33   */          dp2add r2.___w, -r0.xwww, r0.xwww, c254.yyyy
              +       retain_prev r1._
/*   34   */          min r9, r9, c6.xxxx
              +       sqrt r2.___w, r_abs[2].w
/*    2.0 */       exec
/*   35   */          mul r6.xyz_, r2.wwww, r6.xyzz
              +       mulsc r7.x___, c12.y, r7.x
/*   36   */          mad r0.xyz_, r0.xxxx, r5.zyxx, r6.zyxx
              +       retain_prev r1._
/*   37   */          mad r0.xyz_, r0.wwww, r4.xzyy, r0.zxyy
              +       retain_prev r1._
/*   38   */          dp3 r2.___w, r0.yxzz, r0.yxzz
              +       mulsc r7._y__, c12.x, r7.y
/*   39   */          max r4, r9.wzyx, c7.xxxx
              +       rsq r2.___w, r_abs[2].w
/*   40   */          mul r5.xyz_, r0.xzyy, r2.wwww
              +       sqrt r5.___w, r_abs[3].w
/*    2.1 */       cjmp !b128, L21
/*    3.0 */       exec
/*   41   */          mul r0, r4.wzyx, c48.wzyx
              +       retain_prev r1._
/*   42   */          add r6.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   43   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   44   */          max4 r0.__z_, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   45   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   46   */          dp3 r0._y__, r5.zxyy, r6.xzyy
              +       retain_prev r1._
/*    3.1 */       exec
/*   47   */          dp3 r2.___w, r6.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   48   */          add r1.x___, r6.wwww, -c32.wwww
              +       retain_prev r1._
/*   49   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   50   */          max r0._y__, r0.yyyy, c254.xxxx
              +       mulsc r2.___w, c35.y, r2.w
/*   51   */          max r2.___w, r2.wwww, c35.wwww
              +       subsc r0.___w, c254.y, r0.x
/*   52   */          min r3.x___, r2.wwww, c254.yyyy
              +       subsc r2.___w, c254.y, r0.z
/*    4.0 */       exec
/*   53   */          mul r3._y__, r0.wwww, r3.xxxx
              +       retain_prev r1._
/*   54   */          mul r6._yzw, r3.xxyy, c32.xxzy
              +       retain_prev r1._
/*   55   */          mul r6.x___, r6.yyyy, r0.wwww
              +       retain_prev r1._
/*   56   */          mul r0.xyz_, r6.xzww, r0.yyyy
              +       retain_prev r1._
/*   57   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       retain_prev r1._
/*   58   */          mul r3.xyz_, r0.xzyy, c35.zzzz
              +       retain_prev r1._
/*    4.1 */       cjmp !b129, L21
/*    5.0 */       exec
/*   59   */          mul r0, r4.wzyx, c49.wzyx
              +       retain_prev r1._
/*   60   */          add r6.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   61   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*   62   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   63   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   64   */          dp3 r0._y__, r5.zxyy, r6.zxyy
              +       retain_prev r1._
/*    5.1 */       exec
/*   65   */          dp3 r2.___w, r6.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   66   */          add r1.x___, r6.wwww, -c36.wwww
              +       retain_prev r1._
/*   67   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   68   */          max r0._y__, r0.yyyy, c254.xxxx
              +       mulsc r2.___w, c39.y, r2.w
/*   69   */          max r0.___w, r2.wwww, c39.wwww
              +       subsc r2.___w, c254.y, r0.x
/*   70   */          min r6.x___, r0.wwww, c254.yyyy
              +       subsc r0.x___, c254.y, r0.z
/*    6.0 */       exec
/*   71   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*   72   */          mul r6.xy_w, r6.yyxx, c36.zyxx
              +       retain_prev r1._
/*   73   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*   74   */          mul r0.xyz_, r6.xyzz, r0.yyyy
              +       retain_prev r1._
/*   75   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   76   */          mad r3.xyz_, r0.xzyy, c39.zzzz, r3.xyzz
              +       retain_prev r1._
/*    6.1 */       cjmp !b130, L21
/*    7.0 */       exec
/*   77   */          mul r0, r4, c50
              +       retain_prev r1._
/*   78   */          add r6.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   79   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   80   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[6].w
/*   81   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   82   */          dp3 r0._y__, r5.zxyy, r6.xzyy
              +       retain_prev r1._
/*    7.1 */       exec
/*   83   */          dp3 r2.___w, r6.xzyy, -c42.zxyy
              +       retain_prev r1._
/*   84   */          add r1.x___, r6.wwww, -c40.wwww
              +       retain_prev r1._
/*   85   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*   86   */          max r0._y__, r0.yyyy, c254.xxxx
              +       mulsc r2.___w, c43.y, r2.w
/*   87   */          max r0.___w, r2.wwww, c43.wwww
              +       subsc r2.___w, c254.y, r0.x
/*   88   */          min r6.x___, r0.wwww, c254.yyyy
              +       subsc r0.x___, c254.y, r0.z
/*    8.0 */       exec
/*   89   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*   90   */          mul r6.xy_w, r6.yyxx, c40.zyxx
              +       retain_prev r1._
/*   91   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*   92   */          mul r0.xyz_, r6.xyzz, r0.yyyy
              +       retain_prev r1._
/*   93   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   94   */          mad r3.xyz_, r0.xzyy, c43.zzzz, r3.xyzz
              +       retain_prev r1._
/*    8.1 */       cjmp !b131, L21
/*    9.0 */       exec
/*   95   */          mul r0, r4.wzyx, c51.wzyx
              +       retain_prev r1._
/*   96   */          add r6.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*   97   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*   98   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   99   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*  100   */          dp3 r0._y__, r5.zxyy, r6.zxyy
              +       retain_prev r1._
/*    9.1 */       exec
/*  101   */          dp3 r2.___w, r6.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  102   */          add r1.x___, r6.wwww, -c44.wwww
              +       retain_prev r1._
/*  103   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  104   */          max r0._y__, r0.yyyy, c254.xxxx
              +       mulsc r2.___w, c47.y, r2.w
/*  105   */          max r0.___w, r2.wwww, c47.wwww
              +       subsc r2.___w, c254.y, r0.x
/*  106   */          min r6.x___, r0.wwww, c254.yyyy
              +       subsc r0.x___, c254.y, r0.z
/*   10.0 */       exec
/*  107   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*  108   */          mul r6.xy_w, r6.yyxx, c44.zyxx
              +       retain_prev r1._
/*  109   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*  110   */          mul r0.xyz_, r6.xyzz, r0.yyyy
              +       retain_prev r1._
/*  111   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  112   */          mad r3.xyz_, r0.xzyy, c47.zzzz, r3.xyzz
              +       retain_prev r1._
                label L21
/*   10.1 */       cjmp !b132, L33
/*   11.0 */       exec
/*  113   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  114   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  115   */          mul r6, r4.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  116   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  117   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  118   */          dp3 r2.___w, r0.xzyy, r5.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   11.1 */       exec
/*  119   */          max4 r0._y__, r6.zxwy
              +       maxs r0.__z_, r2.ww
/*  120   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  121   */          mul r6.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  122   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  123   */          mad r3.xyz_, r6.zxyy, r0.yyyy, r3.xyzz
              +       retain_prev r1._
/*   12.0 */       cjmp !b133, L33
/*   12.1 */       exec
/*  124   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  125   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  126   */          mul r6, r4, c53
              +       rsq r1.x___, r_abs[0].w
/*  127   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  128   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  129   */          dp3 r2.___w, r0.zxyy, r5.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   13.0 */       exec
/*  130   */          max4 r0._y__, r6.ywxz
              +       maxs r0.__z_, r2.ww
/*  131   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  132   */          mul r6.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  133   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  134   */          mad r3.xyz_, r6.zxyy, r0.yyyy, r3.xyzz
              +       retain_prev r1._
/*   13.1 */       cjmp !b134, L33
/*   14.0 */       exec
/*  135   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  136   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  137   */          mul r6, r4.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  138   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  139   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  140   */          dp3 r2.___w, r0.xzyy, r5.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   14.1 */       exec
/*  141   */          max4 r0._y__, r6.zxwy
              +       maxs r0.__z_, r2.ww
/*  142   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  143   */          mul r6.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  144   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  145   */          mad r3.xyz_, r6.zxyy, r0.yyyy, r3.xyzz
              +       retain_prev r1._
/*   15.0 */       cjmp !b135, L33
/*   15.1 */       exec
/*  146   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  147   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  148   */          mul r4, r4, c55
              +       rsq r1.x___, r_abs[0].w
/*  149   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  150   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  151   */          dp3 r2.___w, r0.zxyy, r5.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   16.0 */       exec
/*  152   */          max4 r0._y__, r4.ywxz
              +       maxs r0.__z_, r2.ww
/*  153   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  154   */          mul r4.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  155   */          mul r4.xyz_, r4.xyzz, r2.wwww
              +       retain_prev r1._
/*  156   */          mad r3.xyz_, r4.zxyy, r0.yyyy, r3.xyzz
              +       retain_prev r1._
                label L33
/*   16.1 */       exec
/*  157   */          mul r6, r5.xyzz, r5.yzzx
              +       retain_prev r1._
/*  158   */          cndeq r0, c254.xxxy, r5.zxyy, c254.yyyy
              +       retain_prev r1._
/*  159   */          dp4 r4.x___, c16.zxyw, r0
              +       retain_prev r1._
/*  160   */          dp4 r4._y__, c18.zxyw, r0
              +       retain_prev r1._
/*  161   */          dp4 r4.__z_, c17.zxyw, r0
              +       retain_prev r1._
/*  162   */          dp4 r0.x___, r6.wzxy, c19.wzxy
              +       muls r1.x___, r5.xx
/*   17.0 */       exec    // PredicateClean=false
/*  163   */          dp4 r0._y__, r6.wzxy, c21.wzxy
              +       muls r1._y__, r5.yy
/*  164   */          dp4 r0.__z_, r6.wzxy, c20.wzxy
              +       subs r1.x___, r1.xy
/*  165   */          add r0.xyz_, r4.zxyy, r0.zxyy
              +       setp_gt r1._, c_abs[13].x
/*  166   */          mad r0.xyz_, r1.xxxx, c22.xyzz, r0.yxzz
              +       retain_prev r1._
/*  167   */          mad r1.xy_w, r3.xzyy, r1.wwww, r0.xyzz
              +       retain_prev r1._
/*   17.1 */  (p0) exec
/*  168   */     (p0) mul r0.xyz_, r1.wyxx, c56.xxxx
              +  (p0) retain_prev r1._
/*  169   */     (p0) mul r1.xy_w, r1.wyxx, c57.xxxx
              +  (p0) retain_prev r1._
/*  170   */     (p0) mul r1.xy_w, r1.xyww, c15.xxxx
              +  (p0) retain_prev r1._
/*  171   */     (p0) mad r1.xy_w, r0.zyxx, c14.xxxx, r1.wyxx
              +  (p0) retain_prev r1._
/*   18.0 */       exec
/*  172   */          mul r0, r7.yxzw, r1.xywz
              +       retain_prev r1._
/*   18.1 */       cjmp !b136, L41
/*   19.0 */       exec
/*  173   */          mad r1.___w, r5.wwww, c11.yyyy, c11.zzzz
              +       retain_prev r1._
/*  174   */          add r1.x___, r5.wwww, -c8.xxxx
              +       rsq r1._y__, r_abs[3].w
/*  175   */          mul r3.xyz_, r8.xyzz, r1.yyyy
              +       retain_prev r1._
/*  176   */          cndeq r2, c254.xxxy, r2.zxyy, c254.yyyy
              +       retain_prev r1._
/*  177   */          dp4 r1._y__, c9.zxyw, r2
              +       retain_prev r1._
/*  178   */          dp3 r1.__z_, r3.zxyy, c9.zxyy
              +       retain_prev r1._
/*   19.1 */       exec
/*  179   */          add r2.xyz_, -r0.xyzz, c10.xyzz
              +       mulsc r2.___w, c8.z, r1.x
/*  180   */          min r3.xy__, r1.yzzz, c254.xzzz
              +       mulsc r1.x___, c8.w, r1.y
/*  181   */          max r1.__z_, r2.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  182   */          max r1._, r1, r1
              +       mulsc r1.x___, c11.x, r1.y
/*  183   */          mad r1.x___, r1.xxxx, r3.xxxx, r1.wwww
              +       retain_prev r1._
/*  184   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*   20.0 */       exec
/*  185   */          min r1.x___, r1.xxxx, c10.wwww
              +       retain_prev r1._
/*  186   */          max r1.x___, r1.xxxx, c254.xxxx
              +       retain_prev r1._
/*  187   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L41
/*   20.1 */       exece
/*  188   */          mul r0.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  189   */          max oC0, r0, r0
