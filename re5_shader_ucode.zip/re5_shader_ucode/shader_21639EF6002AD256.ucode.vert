/*    0.0 */       exec
/*   19   */          vfetch_full r10.wxy_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*   20   */          vfetch_mini r1, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   21   */          vfetch_mini r2, Offset=3, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   22   */          vfetch_mini r3, Offset=4, DataFormat=FMT_8_8_8_8
/*   23   */          vfetch_mini r9, Offset=5, DataFormat=FMT_8_8_8_8
/*   24   */          vfetch_mini r12.xyz_, Offset=6, DataFormat=FMT_2_10_10_10, Signed=true
/*    0.1 */       exec    // PredicateClean=false
/*   25   */          serialize
                      mul r6, r1, c255.xxxx
/*   26   */          maxas r0._, r6.zz
/*   27   */          mul r0, r3.zzzz, c[37+a0].xzyw
/*   28   */          mul r4, r3.zzzz, c[36+a0].xzyw
              +       setp_gt r0._, r9.x
/*   29   */          mul r5, r3.zzzz, c[35+a0].xzyw
              +       maxas r0._, r6.yy
/*   30   */          mad r5, r3.yyyy, c[35+a0].wzxy, r5.wyxz
/*    1.0 */       exec
/*   31   */          mad r4, r3.yyyy, c[36+a0].wzxy, r4.wyxz
/*   32   */          mad r0, r3.yyyy, c[37+a0].wzxy, r0.wyxz
/*   33   */          maxas r0._, r6.xx
/*   34   */          mad r0, r3.xxxx, c[37+a0].xzyw, r0.zywx
/*   35   */          mad r4, r3.xxxx, c[36+a0].xzyw, r4.zywx
/*   36   */          mad r5, r3.xxxx, c[35+a0].xzyw, r5.zywx
/*    1.1 */       exec
/*   37   */          maxas r0._, r6.ww
/*   38   */          mad r11.x___, r3.wwww, c[35+a0].wwww, r5.wwww
/*   39   */          mad r8.xyz_, r3.wwww, c[35+a0].xyzz, r5.xzyy
/*   40   */          mad r11._y__, r3.wwww, c[36+a0].wwww, r4.wwww
/*   41   */          mad r6.xyz_, r3.wwww, c[36+a0].xyzz, r4.xzyy
/*   42   */          mad r11.__z_, r3.wwww, c[37+a0].wwww, r0.wwww
/*    2.0 */       exec
/*   43   */          mad r7.xyz_, r3.wwww, c[37+a0].xyzz, r0.xzyy
/*    2.1 */  (p0) exec
/*   44   */     (p0) mul r13, r2, c255.xxxx
/*   45   */     (p0) maxas r0._, r13.ww
/*   46   */     (p0) mul r5, r9.wwww, c[35+a0].xzyw
/*   47   */     (p0) mul r4, r9.wwww, c[36+a0].xzyw
/*   48   */     (p0) mul r0, r9.wwww, c[37+a0].xzyw
              +  (p0) maxas r0._, r13.zz
/*   49   */     (p0) mad r0, r9.zzzz, c[37+a0].wyzx, r0.wzyx
/*    3.0 */  (p0) exec
/*   50   */     (p0) mad r4, r9.zzzz, c[36+a0].wyzx, r4.wzyx
/*   51   */     (p0) mad r5, r9.zzzz, c[35+a0].wyzx, r5.wzyx
/*   52   */     (p0) maxas r0._, r13.yy
/*   53   */     (p0) mad r5, r9.yyyy, c[35+a0].wzxy, r5.xzwy
/*   54   */     (p0) mad r4, r9.yyyy, c[36+a0].wzxy, r4.xzwy
/*   55   */     (p0) mad r0, r9.yyyy, c[37+a0].wzxy, r0.xzwy
/*    3.1 */  (p0) exec
/*   56   */          max r0._, c0, c0
/*   57   */     (p0) maxas r0._, r13.xx
/*   58   */     (p0) mad r0, r9.xxxx, c[37+a0].xzyw, r0.zywx
/*   59   */     (p0) mad r4, r9.xxxx, c[36+a0].xzyw, r4.zywx
/*   60   */     (p0) mad r5, r9.xxxx, c[35+a0].xzyw, r5.zywx
/*   61   */     (p0) add r11._y__, r4.wwww, r11.yyyy
              +  (p0) maxs r0._, r5.ww
/*    4.0 */  (p0) exec
/*   62   */     (p0) add r8.xyz_, r5.xzyy, r8.xyzz
              +  (p0) adds_prev r11.x___, r11.x
/*   63   */     (p0) add r6.xyz_, r4.xzyy, r6.xyzz
              +  (p0) maxs r0._, r0.ww
/*   64   */     (p0) add r7.xyz_, r0.xzyy, r7.xyzz
              +  (p0) adds_prev r11.__z_, r11.z
/*    4.1 */       exec
/*   65   */          add r1, r1, c4.xxxx
/*   66   */          mul r0._y__, r1.wwww, c4.zzzz
              +       maxs r0.x___, c4.yy
/*   67   */          mul r5._yzw, r1.xxyz, c4.zzzz
              +       maxs r5.x___, c4.yy
/*   68   */          tfetch2D r4, r0.yx, tf16, UseComputedLOD=false, OffsetX=2
/*   69   */          tfetch2D r14, r0.yx, tf16, UseComputedLOD=false, OffsetX=1
/*   70   */          tfetch2D r1, r0.yx, tf16, UseComputedLOD=false
/*    5.0 */       exec
/*   71   */          tfetch2D r15, r5.yx, tf16, UseComputedLOD=false
/*   72   */          tfetch2D r16, r5.yx, tf16, UseComputedLOD=false, OffsetX=1
/*   73   */          tfetch2D r17, r5.yx, tf16, UseComputedLOD=false, OffsetX=2
/*   74   */          tfetch2D r18, r5.zx, tf16, UseComputedLOD=false, OffsetX=2
/*   75   */          tfetch2D r19, r5.zx, tf16, UseComputedLOD=false, OffsetX=1
/*   76   */          tfetch2D r20, r5.zx, tf16, UseComputedLOD=false
/*    5.1 */       exec
/*   77   */          tfetch2D r0, r5.wx, tf16, UseComputedLOD=false
/*   78   */          tfetch2D r13, r5.wx, tf16, UseComputedLOD=false, OffsetX=1
/*   79   */          tfetch2D r21, r5.wx, tf16, UseComputedLOD=false, OffsetX=2
/*   80   */          serialize
                      add r5, r2, c4.xxxx
/*   81   */          mul r2, r3.zzzz, r21
/*   82   */          mul r13, r3.zzzz, r13
/*    6.0 */       exec    // PredicateClean=false
/*   83   */          mul r0, r3.zzzz, r0
/*   84   */          mul r5, r5.wzyx, c4.zzzz
              +       setp_gt r0._, r9.x
/*   85   */          mad r0, r3.yyyy, r20.wzyx, r0.wzyx
/*   86   */          mad r13, r3.yyyy, r19.wzyx, r13.wzyx
/*   87   */          mad r2, r3.yyyy, r18.wzyx, r2.wzyx
/*   88   */          mad r2, r3.xxxx, r17.wyxz, r2.xzwy
/*    6.1 */       exec
/*   89   */          mad r13, r3.xxxx, r16.wyxz, r13.xzwy
/*   90   */          mad r0, r3.xxxx, r15.wyxz, r0.xzwy
/*   91   */          mad r0.x___, r3.wwww, r1.wwww, r0.xxxx
/*   92   */          mad r1.xyz_, r3.wwww, r1.xyzz, r0.zyww
/*   93   */          mad r0.__z_, r3.wwww, r14.wwww, r13.xxxx
/*   94   */          mad r3.xyz_, r3.wwww, r14.xyzz, r13.zyww
/*    7.0 */       exec
/*   95   */          mad r0._y__, r3.wwww, r4.wwww, r2.xxxx
/*   96   */          mad r4.xyz_, r3.wwww, r4.xyzz, r2.zyww
/*    7.1 */  (p0) exec
/*   97   */     (p0) max r13.x___, c4.yyyy, c4.yyyy
              +  (p0) maxs r2.x___, c4.yy
/*   98   */     (p0) max r2.___w, r5.yyyy, r5.yyyy
              +  (p0) maxs r13._y__, r5.xx
/*   99   */     (p0) max r2.__z_, r5.zzzz, r5.zzzz
              +  (p0) maxs r2._y__, r5.ww
/*  100   */     (p0) tfetch2D r14, r2.yx, tf16, UseComputedLOD=false
/*  101   */     (p0) tfetch2D r15, r2.yx, tf16, UseComputedLOD=false, OffsetX=1
/*  102   */     (p0) tfetch2D r16, r2.yx, tf16, UseComputedLOD=false, OffsetX=2
/*    8.0 */  (p0) exec
/*  103   */     (p0) tfetch2D r17, r2.zx, tf16, UseComputedLOD=false, OffsetX=2
/*  104   */     (p0) tfetch2D r18, r2.zx, tf16, UseComputedLOD=false, OffsetX=1
/*  105   */     (p0) tfetch2D r19, r2.zx, tf16, UseComputedLOD=false
/*  106   */     (p0) tfetch2D r20, r2.wx, tf16, UseComputedLOD=false
/*  107   */     (p0) tfetch2D r21, r2.wx, tf16, UseComputedLOD=false, OffsetX=1
/*  108   */     (p0) tfetch2D r22, r2.wx, tf16, UseComputedLOD=false, OffsetX=2
/*    8.1 */  (p0) exec
/*  109   */     (p0) tfetch2D r2, r13.yx, tf16, UseComputedLOD=false, OffsetX=2
/*  110   */     (p0) tfetch2D r5, r13.yx, tf16, UseComputedLOD=false, OffsetX=1
/*  111   */     (p0) tfetch2D r13, r13.yx, tf16, UseComputedLOD=false
/*  112   */          serialize
                 (p0) mul r13, r9.wwww, r13.wxyz
/*  113   */     (p0) mul r5, r9.wwww, r5.wxyz
/*  114   */     (p0) mul r2, r9.wwww, r2.wxyz
/*    9.0 */  (p0) exec
/*  115   */     (p0) mad r2, r9.zzzz, r22.wzyx, r2.xwzy
/*  116   */     (p0) mad r5, r9.zzzz, r21.wzyx, r5.xwzy
/*  117   */     (p0) mad r13, r9.zzzz, r20.wzyx, r13.xwzy
/*  118   */     (p0) mad r13, r9.yyyy, r19.wyxz, r13.xzwy
/*  119   */     (p0) mad r5, r9.yyyy, r18.wyxz, r5.xzwy
/*  120   */     (p0) mad r2, r9.yyyy, r17.wyxz, r2.xzwy
/*    9.1 */  (p0) exec
/*  121   */     (p0) mad r2, r9.xxxx, r16, r2.zywx
/*  122   */     (p0) mad r5, r9.xxxx, r15, r5.zywx
/*  123   */     (p0) mad r9, r9.xxxx, r14, r13.zywx
/*  124   */     (p0) add r0.__z_, r5.wwww, r0.zzzz
              +  (p0) maxs r0._, r9.ww
/*  125   */     (p0) add r1.xyz_, r9.xyzz, r1.xyzz
              +  (p0) adds_prev r0.x___, r0.x
/*  126   */     (p0) add r3.xyz_, r5.xyzz, r3.xyzz
              +  (p0) maxs r0._, r2.ww
/*   10.0 */  (p0) exec
/*  127   */     (p0) add r4.xyz_, r2.xyzz, r4.xyzz
              +  (p0) adds_prev r0._y__, r0.y
/*   10.1 */       exec
/*  128   */          dp3 r5.x___, r12.zxyy, r8.zxyy
/*  129   */          dp3 r5._y__, r12.zxyy, r6.zxyy
/*  130   */          dp3 r5.__z_, r12.zxyy, r7.zxyy
/*  131   */          mad r2.xyz_, r10.xyzz, c227.zyxx, c3.zyxx
/*  132   */          dp3 r1.x___, r2.xzyy, r1.zxyy
/*  133   */          dp3 r1._y__, r2.xzyy, r4.zxyy
/*   11.0 */       exec
/*  134   */          dp3 r1.__z_, r2.xzyy, r3.zxyy
/*  135   */          dp3 r3.x___, r2.xzyy, r8.zxyy
/*  136   */          dp3 r3._y__, r2.xzyy, r6.zxyy
/*  137   */          dp3 r3.__z_, r2.xzyy, r7.zxyy
/*  138   */          dp3 r2._y__, r5.zxyy, c1.zxyy
/*  139   */          dp3 r2.__z_, r5.zxyy, c2.zxyy
/*   11.1 */       exec
/*  140   */          add r3.xyz_, r3.xyzz, r11.xyzz
/*  141   */          add r0.xyz_, r1.xyzz, r0.xyzz
              +       sges r0.___w, r_abs[0].x
/*  142   */          dp4 r1.x___, c27.zxyw, r0.yxzw
/*  143   */          dp4 r1._y__, c29.zxyw, r0.yxzw
/*  144   */          dp4 r1.___w, c28.zxyw, r0.yxzw
              +       sges r3.___w, r_abs[0].x
/*  145   */          dp4 r4.x___, c0.zxyw, r3.zxyw
/*   12.0 */       exec
/*  146   */          dp4 r4.__z_, c1.zxyw, r3.zxyw
/*  147   */          dp4 r4._y__, c2.zxyw, r3.zxyw
              +       sges r4.___w, r_abs[0].x
/*  148   */          mad r1.__z_, -r4.yyyy, c5.xxxx, -c5.wwww
/*  149   */          dp4 r3.x___, c23.zxyw, r4.yxzw
/*  150   */          dp4 r3._y__, c24.zxyw, r4.yxzw
/*  151   */          dp4 r0.__z_, c25.zxyw, r4.yxzw
/*   12.1 */       exec
/*  152   */          dp4 r3.__z_, c26.zxyw, r4.yxzw
/*  153   */          add r0.xy_w, r4.xzyy, -r1.xwyy
/*  154   */          dp3 r0.x___, r0.wxyy, r0.wxyy
/*  155   */          add r1.xy_w, r1.xyww, -r4.xyzz
              +       rsq r0.x___, r_abs[0].x
/*  156   */          dp3 r2.x___, r5.zxyy, c0.zxyy
              +       mulsc r0.x___, c5.y, r0.x
/*  157   */          min r0.x___, r0.xxxx, c255.zzzz
/*   13.0 */       exec
/*  158   */          mad r0.xy_w, r1.xyww, r0.xxxx, r4.xyzz
/*  159   */          add r0.xy_w, -r0.xyww, r4.xyzz
/*  160   */          mul r0.xy_w, r0.xwyy, c5.zzzz
/*  161   */          add r5.xyz_, r4.xzyy, -r0.xyww
              +       sges r5.___w, r_abs[0].x
/*  162   */          dp4 r1.x___, c30.zxyw, r5.zxyw
/*  163   */          dp4 r1._y__, c31.zxyw, r5.zxyw
              +       maxs r4.x___, r1.zz
/*   13.1 */       exec
/*  164   */          dp4 r1.___w, c32.zxyw, r5.zxyw
              +       maxs r4._y__, c255.zz
/*  165   */          dp4 r1.__z_, c33.zxyw, r5.zxyw
              +       mins r3.___w, r4.xy
/*   14.0 */       cjmp b0, L32
/*   14.1 */       exec
/*  166   */          rcp r0.x___, r3.z
/*  167   */          mad r0.__z_, -r0.xxxx, c255.wwww, r0.zzzz
/*  168   */          dp2add r0.x___, r2.xyyy, r2.xyyy, c255.yyyy
/*  169   */          max r0.___w, r3.zzzz, r3.zzzz
              +       rsq r0.x___, r_abs[0].x
/*  170   */          mul r0.xy__, r2.xyyy, r0.xxxx
/*  171   */          mul r0.xy__, r0.yxxx, c34.wzzz
/*   15.0 */       exec
/*  172   */          mad r0.xy__, r0.yxxx, r3.zzzz, r3.xyyy
/*   15.1 */       jmp L33
                label L32
/*   16.0 */       exec
/*  173   */          dp3 r2.x___, r0.wxyy, r2.zxyy
/*  174   */          cndgt r0.xy_w, r2.xxxx, r3.xyzz, r1.xyzz
/*  175   */          cndgt r0.__z_, r2.xxxx, r0.zzzz, r1.wwww
                label L33
/*   16.1 */       alloc position
/*   17.0 */       exec
/*  176   */          max oPos, r0, r0
/*   17.1 */       alloc interpolators
/*   18.0 */       exece
/*  177   */          max o0, r3.xywz, r3.xywz
/*  178   */          max o1, r1.xywz, r1.xywz
/*   18.1 */       cnop
