/*    0.0 */       exec
/*    8   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    9   */          vfetch_mini r3.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   10   */          vfetch_mini r1, Offset=3, DataFormat=FMT_8_8_8_8
/*   11   */          vfetch_mini r4.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   12   */          serialize
                      mul r4.__zw, r3.zzzw, c255.wwww
/*   13   */          maxas r0._, r4.ww
/*    0.1 */       exec    // PredicateClean=false
/*   14   */          mul r6, r1.yyyy, c[30+a0]
/*   15   */          mul r2, r1.yyyy, c[29+a0]
              +       setp_gt r0._, r1.z
/*   16   */          mul r5, r1.yyyy, c[28+a0]
              +       maxas r0._, r4.zz
/*   17   */          mad r5, r1.xxxx, c[28+a0], r5
/*   18   */          mad r2, r1.xxxx, c[29+a0], r2
/*   19   */          mad r6, r1.xxxx, c[30+a0].zyxw, r6.zyxw
/*    1.0 */  (p0) exec
/*   20   */     (p0) mul r1.xy__, r3.xyyy, c255.wwww
/*   21   */     (p0) maxas r0._, r1.yy
/*   22   */     (p0) mad r3, r1.wwww, c[30+a0], r6.zyxw
/*   23   */     (p0) mad r2, r1.wwww, c[29+a0], r2
/*   24   */     (p0) mad r5, r1.wwww, c[28+a0], r5
/*   25   */     (p0) maxas r0._, r1.xx
/*    1.1 */  (p0) exec
/*   26   */     (p0) mad r5, r1.zzzz, c[28+a0], r5
/*   27   */     (p0) mad r2, r1.zzzz, c[29+a0], r2
/*   28   */     (p0) mad r6, r1.zzzz, c[30+a0].zyxw, r3.zyxw
/*    2.0 */       exec
/*   29   */          mad r0.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*   30   */          cndeq r1, c255.zzzx, r0.zxyy, c255.xxxx
/*   31   */          dp4 r0.x___, r5.zxyw, r1
/*   32   */          dp4 r0._y__, r2.zxyw, r1
/*   33   */          dp4 r0.__z_, r6.xzyw, r1
/*    2.1 */       cjmp !b0, L10
/*    3.0 */       exec
/*   34   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   35   */          dp4 r1.x___, c0.zxyw, r0
/*   36   */          dp4 r1._y__, c1.zxyw, r0
/*   37   */          dp4 r1.__z_, c2.zxyw, r0
/*   38   */          dp2add r0.__z_, r1.xyyy, r1.xyyy, c255.zzzz
/*   39   */          dp3 r0.x___, r1.zxyy, r1.zxyy
/*    3.1 */       exec
/*   40   */          sqrt r0._y__, r_abs[0].x
/*   41   */          mad r0.x___, r0.yyyy, c27.xxxx, c27.yyyy
/*   42   */          add r0.___w, -r1.zzzz, r0.yyyy
/*   43   */          mul r2.xy__, r1.xyyy, r0.yyyy
/*   44   */          mul r2.xy__, r2.yxxx, r0.wwww
              +       rcp r0.__z_, r0.z
/*   45   */          mul r0.__zw, r2.yyyx, r0.zzzz
/*    4.0 */       exec
/*   46   */          cndge r0.xy__, r1.zzzz, r0.xyyy, c255.xyyy
/*    4.1 */       jmp L11
                label L10
/*    5.0 */       exec
/*   47   */          cndeq r1, c255.zzzx, r0.zxyy, c255.xxxx
/*   48   */          dp4 r0.__z_, c23.zxyw, r1
/*   49   */          dp4 r0.___w, c24.zxyw, r1
/*   50   */          dp4 r0.x___, c25.zxyw, r1
/*   51   */          dp4 r0._y__, c26.zxyw, r1
                label L11
/*    5.1 */       alloc position
/*    6.0 */       exec
/*   52   */          max oPos, r0.zwxy, r0.zwxy
/*    6.1 */       alloc interpolators
/*    7.0 */       exece
/*   53   */          add o0.xy__, r4.xyyy, c5.xyyy
/*    7.1 */       cnop
