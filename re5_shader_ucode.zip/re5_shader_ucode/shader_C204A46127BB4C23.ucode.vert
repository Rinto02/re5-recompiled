/*    0.0 */       exec
/*   10   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*   11   */          vfetch_mini r2, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   12   */          vfetch_mini r6, Offset=3, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   13   */          vfetch_mini r7, Offset=4, DataFormat=FMT_8_8_8_8
/*   14   */          vfetch_mini r1, Offset=5, DataFormat=FMT_8_8_8_8
/*   15   */          vfetch_mini r5.xyz_, Offset=6, DataFormat=FMT_2_10_10_10, Signed=true
/*    0.1 */       exec    // PredicateClean=false
/*   16   */          serialize
                      mul r8, r2, c255.wwww
/*   17   */          maxas r0._, r8.ww
/*   18   */          mul r2, r7.wwww, c[30+a0]
/*   19   */          mul r4, r7.wwww, c[29+a0]
              +       setp_gt r0._, r1.x
/*   20   */          mul r3, r7.wwww, c[28+a0]
              +       maxas r0._, r8.zz
/*   21   */          mad r3, r7.zzzz, c[28+a0].wyzx, r3.wyzx
/*    1.0 */       exec
/*   22   */          mad r4, r7.zzzz, c[29+a0].wyzx, r4.wyzx
/*   23   */          mad r2, r7.zzzz, c[30+a0].wyzx, r2.wyzx
/*   24   */          maxas r0._, r8.yy
/*   25   */          mad r2, r7.yyyy, c[30+a0].wzxy, r2.xzwy
/*   26   */          mad r4, r7.yyyy, c[29+a0].wzxy, r4.xzwy
/*   27   */          mad r3, r7.yyyy, c[28+a0].wzxy, r3.xzwy
/*    1.1 */       exec
/*   28   */          maxas r0._, r8.xx
/*   29   */          mad r3, r7.xxxx, c[28+a0], r3.zwyx
/*   30   */          mad r4, r7.xxxx, c[29+a0], r4.zwyx
/*   31   */          mad r2, r7.xxxx, c[30+a0], r2.zwyx
/*    2.0 */  (p0) exec
/*   32   */     (p0) mul r6, r6, c255.wwww
/*   33   */     (p0) maxas r0._, r6.ww
/*   34   */     (p0) mad r2, r1.wwww, c[30+a0].xywz, r2.xywz
/*   35   */     (p0) mad r4, r1.wwww, c[29+a0].xywz, r4.xywz
/*   36   */     (p0) mad r3, r1.wwww, c[28+a0].xywz, r3.xywz
/*   37   */     (p0) maxas r0._, r6.zz
/*    2.1 */  (p0) exec
/*   38   */     (p0) mad r3, r1.zzzz, c[28+a0].wxzy, r3.zxwy
/*   39   */     (p0) mad r4, r1.zzzz, c[29+a0].wxzy, r4.zxwy
/*   40   */     (p0) mad r2, r1.zzzz, c[30+a0].wxzy, r2.zxwy
/*   41   */     (p0) maxas r0._, r6.yy
/*   42   */     (p0) mad r2, r1.yyyy, c[30+a0].wzyx, r2.xzwy
/*   43   */     (p0) mad r4, r1.yyyy, c[29+a0].wzyx, r4.xzwy
/*    3.0 */  (p0) exec
/*   44   */     (p0) mad r3, r1.yyyy, c[28+a0].wzyx, r3.xzwy
/*   45   */     (p0) maxas r0._, r6.xx
/*   46   */     (p0) mad r3, r1.xxxx, c[28+a0], r3.wzyx
/*   47   */     (p0) mad r4, r1.xxxx, c[29+a0], r4.wzyx
/*   48   */     (p0) mad r2, r1.xxxx, c[30+a0], r2.wzyx
/*    3.1 */       exec
/*   49   */          mad r0.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*   50   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   51   */          dp4 r1.x___, r3.zxyw, r0
/*   52   */          dp4 r1._y__, r4.zxyw, r0
/*   53   */          dp4 r1.__z_, r2.zxyw, r0
/*    4.0 */       cjmp !b0, L13
/*    4.1 */       exec
/*   54   */          cndeq r0, c255.zzzx, r1.zxyy, c255.xxxx
/*   55   */          dp4 r6.x___, c0.zxyw, r0
/*   56   */          dp4 r6._y__, c1.zxyw, r0
/*   57   */          dp4 r6.__z_, c2.zxyw, r0
/*   58   */          dp2add r0.x___, r6.xyyy, r6.xyyy, c255.zzzz
/*   59   */          dp3 r0._y__, r6.zxyy, r6.zxyy
/*    5.0 */       exec
/*   60   */          sqrt r0.___w, r_abs[0].y
/*   61   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   62   */          add r0._y__, -r6.zzzz, r0.wwww
/*   63   */          mul r7.xy__, r6.xyyy, r0.wwww
/*   64   */          mul r7.xy__, r7.yxxx, r0.yyyy
              +       rcp r0.x___, r0.x
/*   65   */          mul r0.xy__, r7.yxxx, r0.xxxx
/*    5.1 */       exec
/*   66   */          cndge r0.__zw, r6.zzzz, r0.zzzw, c255.xxxy
/*    6.0 */       jmp L14
                label L13
/*    6.1 */       exec
/*   67   */          cndeq r6, c255.zzzx, r1.zxyy, c255.xxxx
/*   68   */          dp4 r0.x___, c23.zxyw, r6
/*   69   */          dp4 r0._y__, c24.zxyw, r6
/*   70   */          dp4 r0.__z_, c25.zxyw, r6
/*   71   */          dp4 r0.___w, c26.zxyw, r6
                label L14
/*    7.0 */       alloc position
/*    7.1 */       exec
/*   72   */          max oPos, r0, r0
/*    8.0 */       alloc interpolators
/*    8.1 */       exec
/*   73   */          dp3 r4._y__, r5.zxyy, r4.zxyy
/*   74   */          dp3 r4.__z_, r5.zxyy, r2.zxyy
/*   75   */          dp3 r0.x___, r1.zxyy, c2.zxyy
/*   76   */          dp3 r4.x___, r5.zxyy, r3.zxyy
              +       addsc r0.___w, -c2.w, -r0.x
/*   77   */          mad r1.xyz_, -r0.wwww, c5.xyzz, r1.xyzz
/*   78   */          dp3 r0.x___, r4.zxyy, r4.zxyy
/*    9.0 */       exec
/*   79   */          sge r1.___w, r_abs[0].xxxx, c255.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   80   */          dp4 o1.x___, c220.zxyw, r1.zxyw
/*   81   */          dp4 o1._y__, c221.zxyw, r1.zxyw
/*   82   */          dp4 o1.__z_, c222.zxyw, r1.zxyw
/*   83   */          dp4 o1.___w, c223.zxyw, r1.zxyw
/*   84   */          mul r0.xyz_, r4.xyzz, r0.xxxx
/*    9.1 */       exece
/*   85   */          max o0, r0, r0
