/*    0.0 */       exec
/*    8   */          vfetch_full r3.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=6
/*    9   */          vfetch_mini r4.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   10   */          vfetch_mini r2, Offset=3, DataFormat=FMT_8_8_8_8
/*   11   */          vfetch_mini r0.xy__, Offset=5, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   12   */          serialize
                      mul r0.__zw, r4.zzzw, c255.wwww
/*   13   */          maxas r0._, r0.ww
/*    0.1 */       exec    // PredicateClean=false
/*   14   */          mul r6, r2.yyyy, c[30+a0]
/*   15   */          mul r1, r2.yyyy, c[29+a0]
              +       setp_gt r0._, r2.z
/*   16   */          mul r5, r2.yyyy, c[28+a0]
              +       maxas r0._, r0.zz
/*   17   */          mad r5, r2.xxxx, c[28+a0], r5
/*   18   */          mad r1, r2.xxxx, c[29+a0], r1
/*   19   */          mad r6, r2.xxxx, c[30+a0].zyxw, r6.zyxw
/*    1.0 */  (p0) exec
/*   20   */     (p0) mul r0.__zw, r4.xxxy, c255.wwww
/*   21   */     (p0) maxas r0._, r0.ww
/*   22   */     (p0) mad r4, r2.wwww, c[30+a0], r6.zyxw
/*   23   */     (p0) mad r1, r2.wwww, c[29+a0], r1
/*   24   */     (p0) mad r5, r2.wwww, c[28+a0], r5
/*   25   */     (p0) maxas r0._, r0.zz
/*    1.1 */  (p0) exec
/*   26   */     (p0) mad r5, r2.zzzz, c[28+a0], r5
/*   27   */     (p0) mad r1, r2.zzzz, c[29+a0], r1
/*   28   */     (p0) mad r6, r2.zzzz, c[30+a0].zyxw, r4.zyxw
/*    2.0 */       exec
/*   29   */          mul r0.xy__, r0.xyyy, c5.xyyy
/*   30   */          tfetch2D r0.xyz_, r0.xy, tf16, UseComputedLOD=false
/*   31   */          serialize
                      mad r2.xyz_, r3.zyxx, c3.zyxx, c4.zyxx
/*   32   */          add r0.xyz_, r2.zyxx, r0.xyzz
/*   33   */          cndeq r2, c255.zzzx, r0.zxyy, c255.xxxx
/*   34   */          dp4 r0.x___, r5.zxyw, r2
/*    2.1 */       exec
/*   35   */          dp4 r0._y__, r1.zxyw, r2
/*   36   */          dp4 r0.__z_, r6.xzyw, r2
/*    3.0 */       cjmp !b0, L11
/*    3.1 */       exec
/*   37   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   38   */          dp4 r1.x___, c0.zxyw, r0
/*   39   */          dp4 r1._y__, c1.zxyw, r0
/*   40   */          dp4 r1.__z_, c2.zxyw, r0
/*   41   */          dp2add r0.__z_, r1.xyyy, r1.xyyy, c255.zzzz
/*   42   */          dp3 r0.x___, r1.zxyy, r1.zxyy
/*    4.0 */       exec
/*   43   */          sqrt r0._y__, r_abs[0].x
/*   44   */          mad r0.x___, r0.yyyy, c27.xxxx, c27.yyyy
/*   45   */          add r0.___w, -r1.zzzz, r0.yyyy
/*   46   */          mul r2.xy__, r1.xyyy, r0.yyyy
/*   47   */          mul r2.xy__, r2.yxxx, r0.wwww
              +       rcp r0.__z_, r0.z
/*   48   */          mul r0.__zw, r2.yyyx, r0.zzzz
/*    4.1 */       exec
/*   49   */          cndge r0.xy__, r1.zzzz, r0.xyyy, c255.xyyy
/*    5.0 */       jmp L12
                label L11
/*    5.1 */       exec
/*   50   */          cndeq r1, c255.zzzx, r0.zxyy, c255.xxxx
/*   51   */          dp4 r0.__z_, c23.zxyw, r1
/*   52   */          dp4 r0.___w, c24.zxyw, r1
/*   53   */          dp4 r0.x___, c25.zxyw, r1
/*   54   */          dp4 r0._y__, c26.zxyw, r1
                label L12
/*    6.0 */       alloc position
/*    6.1 */       exec
/*   55   */          max oPos, r0.zwxy, r0.zwxy
/*    7.0 */       alloc interpolators
/*    7.1 */       exece
