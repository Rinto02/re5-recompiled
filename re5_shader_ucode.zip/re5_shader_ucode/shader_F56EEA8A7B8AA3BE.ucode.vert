/*    0.0 */       exec
/*    3   */          vfetch_full r1.xyz1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=6
/*    4   */          vfetch_mini r0.__xy, Offset=4, DataFormat=FMT_32_32_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    5   */          max oPos, r1, r1
/*    1.1 */       alloc interpolators
/*    2.0 */       exece
/*    6   */          mad r0.xy__, c48.wzzz, c255.xxxx, r0.wzzz
/*    7   */          mad r0.__zw, -c48.wwwz, c255.xxxx, r0.wwwz
/*    8   */          max o0, r0.wzyz, r0.wzyz
/*    9   */          max o1, r0.wxyx, r0.wxyx
/*    2.1 */       cnop
