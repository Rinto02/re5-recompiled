/*    0.0 */       exec
/*    7   */          tfetch2D r9._w__, r2.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exec    // PredicateClean=false
/*    8   */          sgt r2.x___, c2.xxxx, r0.wwww
/*    9   */          setp_ne_push r9.x___, c255.yyyy, r2.xxxx
/*   10   */          add r2._y__, r9.yyyy, -c23.xxxx
              +       sgts r2.x___, -r_abs[0].x
/*   11   */          kill_gt r0._, c255.yyyy, r2.yyyy
              +       sgts r2._y__, -r_abs[0].x
/*    1.1 */ (!p0) jmp L12
/*    2.0 */  (p0) exec
/*   12   */     (p0) rcp r1.___w, r1.w
/*   13   */     (p0) mul r2.xyz_, r1.wwww, r1.yzxx
/*   14   */     (p0) tfetch2D r10.x___, r2.zx, tf1, OffsetX=-2, OffsetY=1
/*   15   */     (p0) tfetch2D r10.___x, r2.zx, tf1, OffsetX=1, OffsetY=1
/*   16   */     (p0) tfetch2D r10.__x_, r2.zx, tf1, OffsetY=1
/*   17   */     (p0) tfetch2D r10._x__, r2.zx, tf1, OffsetX=-1, OffsetY=1
/*    2.1 */  (p0) exec
/*   18   */     (p0) tfetch2D r6.x___, r2.zx, tf1, OffsetX=-2
/*   19   */     (p0) tfetch2D r6.___x, r2.zx, tf1, OffsetX=1
/*   20   */     (p0) tfetch2D r6.__x_, r2.zx, tf1
/*   21   */     (p0) tfetch2D r6._x__, r2.zx, tf1, OffsetX=-1
/*   22   */     (p0) tfetch2D r4.x___, r2.zx, tf1, OffsetX=-2, OffsetY=-1
/*   23   */     (p0) tfetch2D r4.___x, r2.zx, tf1, OffsetX=1, OffsetY=-1
/*    3.0 */  (p0) exec
/*   24   */     (p0) tfetch2D r4.__x_, r2.zx, tf1, OffsetY=-1
/*   25   */     (p0) tfetch2D r4._x__, r2.zx, tf1, OffsetX=-1, OffsetY=-1
/*   26   */     (p0) tfetch2D r5.x___, r2.zx, tf1, OffsetX=-2, OffsetY=-2
/*   27   */     (p0) tfetch2D r5.___x, r2.zx, tf1, OffsetX=1, OffsetY=-2
/*   28   */     (p0) tfetch2D r5.__x_, r2.zx, tf1, OffsetY=-2
/*   29   */     (p0) tfetch2D r5._x__, r2.zx, tf1, OffsetX=-1, OffsetY=-2
/*    3.1 */  (p0) exec
/*   30   */          serialize
                 (p0) dp3 r2.x___, r0.zxyy, r0.zxyy
/*   31   */     (p0) add r1.__z_, -r2.yyyy, c255.xxxx
              +  (p0) rsq r2.x___, r_abs[2].x
/*   32   */     (p0) mul r11.xyz_, r2.xxxx, -c0.xyzz
/*   33   */     (p0) sge r8, r5, r1.zzzz
/*   34   */     (p0) sge r2, r4, r1.zzzz
/*   35   */     (p0) sge r3, r6, r1.zzzz
/*    4.0 */       exec    // PredicateClean=false
/*   36   */     (p0) sge r7, r10, r1.zzzz
/*   37   */     (p0) dp3 r0._y__, r11.zxyy, r0.zxyy
              +  (p0) mulsc r0.x___, c1.y, r1.w
/*   38   */          setp_gt_push r9.x___, r9.xxxx, c5.xxxx
/*   39   */     (p0) add r7, -r1.zzzz, r10
/*   40   */     (p0) add r3, -r1.zzzz, r6
/*   41   */     (p0) add r2, -r1.zzzz, r4
/*    4.1 */       exec    // PredicateClean=false
/*   42   */     (p0) add r4, -r1.zzzz, r5
/*   43   */     (p0) mul_sat r8, r4, c5.xxxx
/*   44   */     (p0) mul_sat r2, r2, c5.xxxx
/*   45   */     (p0) mul_sat r3, r3, c5.xxxx
/*   46   */     (p0) mul_sat r7, r7, c5.xxxx
/*   47   */          setp_pop r9.x___, r9.x
/*    5.0 */  (p0) exec
/*   48   */     (p0) mad_sat r4._y__, r0.wwww, c3.xxxx, c3.yyyy
/*   49   */     (p0) mul r0.x_z_, r0.xxxx, r1.xyyy
/*   50   */     (p0) add r1, r3, r2
/*   51   */     (p0) frc r4.__zw, r0.zzzx
              +  (p0) mulsc_sat r4.x___, c4.x, r0.y
/*   52   */     (p0) add r0.xyz_, -r4.zxyy, c255.xxxx
/*   53   */     (p0) mad r1, r0.xxxx, r8, r1
/*    5.1 */  (p0) exec
/*   54   */     (p0) mad r1, r4.zzzz, r7, r1
/*   55   */     (p0) dp3 r0.___w, r1.zxyy, c255.xxxx
              +  (p0) subs r1.x___, r1.wx
/*   56   */     (p0) mad r0.___w, r1.xxxx, r4.wwww, r0.wwww
/*   57   */     (p0) mul r1.x___, r0.wwww, c255.zzzz
              +  (p0) mulsc r0.___w, c7.x, r0.y
/*   58   */     (p0) max r0.___w, r1.xxxx, r0.wwww
/*   59   */     (p0) mul r2.x___, r0.zzzz, r0.wwww
              +  (p0) maxs r2._y__, r9.yy
                label L12
/*    6.0 */       exece
/*   60   */          mulsc r2._y__, c6.x, r2.y
/*   61   */          max oC0, r2.xxxy, r2.xxxy
/*    6.1 */       cnop
