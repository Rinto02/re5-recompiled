/*    0.0 */       exec
/*    4   */          add r0.__zw, r0.xxxy, c28.xxxy
/*    5   */          add r12.xy__, r0.xyyy, c26.xyyy
/*    6   */          add r11.xy__, r0.yxxx, c25.yxxx
/*    7   */          add r10.xy__, r0.xyyy, c24.xyyy
              +       maxs r0._, r0.yy
/*    8   */          add r8.xy__, r0.xyyy, c22.xyyy
              +       adds_prev r9.x___, c23.y
/*    9   */          add r7.xy__, r0.yxxx, c21.yxxx
              +       maxs r0._, r0.xx
/*    0.1 */       exec
/*   10   */          add r6.xy__, r0.xyyy, c20.xyyy
              +       adds_prev r9._y__, c23.x
/*   11   */          add r5.xy__, r0.yxxx, c19.yxxx
              +       maxs r0._, r0.xx
/*   12   */          add r3.xy__, r0.xyyy, c16.xyyy
              +       adds_prev r4.x___, c18.x
/*   13   */          add r2.xy__, r0.yxxx, c17.yxxx
              +       maxs r0._, r0.yy
/*   14   */          add r0.xy__, r0.yxxx, c27.yxxx
              +       adds_prev r4._y__, c18.y
/*   15   */          tfetch2D r1, r0.yx, tf0
/*    1.0 */       exec
/*   16   */          tfetch2D r2, r2.yx, tf0
/*   17   */          tfetch2D r3, r3.xy, tf0
/*   18   */          tfetch2D r4, r4.xy, tf0
/*   19   */          tfetch2D r5, r5.yx, tf0
/*   20   */          tfetch2D r6, r6.xy, tf0
/*   21   */          tfetch2D r7, r7.yx, tf0
/*    1.1 */       exec
/*   22   */          tfetch2D r8, r8.xy, tf0
/*   23   */          tfetch2D r9, r9.yx, tf0
/*   24   */          tfetch2D r10, r10.xy, tf0
/*   25   */          tfetch2D r11, r11.yx, tf0
/*   26   */          tfetch2D r12, r12.xy, tf0
/*   27   */          tfetch2D r0, r0.zw, tf0
/*    2.0 */       alloc colors
/*    2.1 */       exec
/*   28   */          mul r0, r0.xwzy, c28.wwww
/*   29   */          mad r0, r12.xwzy, c26.wwww, r0
/*   30   */          mad r0, r11.xywz, c25.wwww, r0.xwyz
/*   31   */          mad r0, r10.xwzy, c24.wwww, r0.xzwy
/*   32   */          mad r0, r9.xzyw, c23.wwww, r0.xzwy
/*   33   */          mad r0, r8.xywz, c22.wwww, r0.xzwy
/*    3.0 */       exec
/*   34   */          mad r0, r7.xwzy, c21.wwww, r0.xzwy
/*   35   */          mad r0, r6.xzyw, c20.wwww, r0.xzwy
/*   36   */          mad r0, r5.xywz, c19.wwww, r0.xzwy
/*   37   */          mad r0, r4.xwzy, c18.wwww, r0.xzwy
/*   38   */          mad r0, r3.xzyw, c16.wwww, r0.xzwy
/*   39   */          mad r0, r2.xywz, c17.wwww, r0.xzwy
/*    3.1 */       exece
/*   40   */          mad oC0, r1, c27.wwww, r0.xywz
