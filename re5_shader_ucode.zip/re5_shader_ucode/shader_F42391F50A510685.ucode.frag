/*    0.0 */       alloc colors
/*    0.1 */       exec
/*    5   */          sgt r0.__z_, c49.xxxx, r0.xxxx
/*    6   */          sgt r0.___w, c50.xxxx, r0.xxxx
/*    7   */          sgt r1.x___, c51.xxxx, r0.xxxx
/*    8   */          sgt r1._y__, c52.xxxx, r0.xxxx
/*    9   */          sgt r1.__z_, c53.xxxx, r0.xxxx
/*   10   */          sgt r1.___w, c54.xxxx, r0.xxxx
/*    1.0 */       exec
/*   11   */          sgt r0._y__, c55.xxxx, r0.xxxx
/*   12   */          cndeq r0._y__, r0.yyyy, c253.xxxx, c253.yyyy
/*   13   */          cndeq r0._y__, r1.wwww, r0.yyyy, c255.wwww
/*   14   */          cndeq r0._y__, r1.zzzz, r0.yyyy, c254.yyyy
/*   15   */          cndeq r0._y__, r1.yyyy, r0.yyyy, c255.zzzz
/*   16   */          cndeq r0._y__, r1.xxxx, r0.yyyy, c254.wwww
/*    1.1 */       exec
/*   17   */          cndeq r0._y__, r0.wwww, r0.yyyy, c254.zzzz
/*   18   */          cndeq r0._y__, r0.zzzz, r0.yyyy, c253.xxxx
/*   19   */          subsc r1.x___, -c254.z, -r0.y
/*   20   */          maxas r0._, r1.xx
/*   21   */          max r0.___w, c[48+a0].xxxx, c[48+a0].xxxx
              +       maxas r0._, r0.yy
/*   22   */          add r0.__z_, c[50+a0].xxxx, -c[49+a0].xxxx
              +       maxs r1.___w, c[48+a0].yy
/*    2.0 */       exec
/*   23   */          add r0.___w, -r0.wwww, c[48+a0].xxxx
/*   24   */          add r2._y__, -c[49+a0].yyyy, c[50+a0].yyyy
              +       rcp r1.__z_, r0.z
/*   25   */          add r0.__z_, -c[48+a0].xxxx, c[49+a0].xxxx
              +       maxas r0._, r1.xx
/*   26   */          add r1._y__, r1.wwww, -c[48+a0].yyyy
              +       rcp r1.x___, r0.w
/*   27   */          mul r1.x_z_, r0.zzzz, r1.xzzz
/*   28   */          subsc r2.x___, c254.z, r1.x
/*    2.1 */       exec
/*   29   */          mul r1.x_z_, r1.yzzz, r2.xyyy
/*   30   */          add r1._y__, r1.xxxx, c[48+a0].yyyy
              +       maxas r0._, r0.yy
/*   31   */          sne r1.x___, c[49+a0].xxxx, c254.zzzz
/*   32   */          add r0.___w, c[49+a0].yyyy, -c[48+a0].yyyy
/*   33   */          add r2.x___, r0.xxxx, -c[48+a0].xxxx
              +       rcp r2.__z_, r0.z
/*   34   */          mul r2._y__, r2.xxxx, r2.zzzz
/*    3.0 */       exec
/*   35   */          add r0.__z_, r1.zzzz, c[49+a0].yyyy
/*   36   */          add r0.x___, -r1.yyyy, c[49+a0].yyyy
/*   37   */          add r0.__z_, r0.zzzz, -c[48+a0].yyyy
/*   38   */          mul r0.x_z_, r0.xzzz, c254.xxxx
/*   39   */          cndeq r0.__z_, r1.xxxx, r0.wwww, r0.zzzz
/*   40   */          cndeq r1._y__, r0.yyyy, r0.wwww, r0.xxxx
/*    3.1 */       exec
/*   41   */          mul r2.___w, r2.zzzz, r1.yyyy
              +       maxs r1.x___, c[49+a0].yy
/*   42   */          mad r0._y__, c[49+a0].yyyy, c255.xxxx, r1.yyyy
/*   43   */          dp3 r0.x___, r1.ywxx, c255.xyzz
/*   44   */          mad r1.__z_, c[48+a0].yyyy, c254.wwww, r0.yyyy
/*   45   */          add r1._y__, r0.xxxx, -r0.zzzz
              +       muls r1.x___, r2.yy
/*   46   */          mul r0.xy_w, r2.wxyy, r2.xzyy
              +       maxs r0._, r1.zz
/*    4.0 */       exec
/*   47   */          mul r0._y_w, r0.yyww, r1.xxyy
              +       adds_prev r0.__z_, r0.z
/*   48   */          mad r0.__z_, r0.yyyy, r0.zzzz, r0.wwww
/*   49   */          add r0.x___, r0.zzzz, r0.xxxx
/*   50   */          add_sat r0.___w, r0.xxxx, c[48+a0].yyyy
/*   51   */          log r0.x___, r0.w
/*   52   */          mul r0.xyz_, r0.xxxx, c56.xyzz
/*    4.1 */       exece
/*   53   */          exp r0.__z_, r0.z
/*   54   */          exp r0._y__, r0.y
/*   55   */          exp r0.x___, r0.x
/*   56   */          max oC0, r0, r0
