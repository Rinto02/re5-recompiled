/*    0.0 */       exec
/*    5   */          vfetch_full r3.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    6   */          vfetch_mini r6.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    7   */          vfetch_mini r5, Offset=3, DataFormat=FMT_8_8_8_8
/*    8   */          vfetch_mini r1.__yx, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    9   */          serialize
                      mul r1.xy__, r6.zwww, c255.xxxx
/*   10   */          maxas r0._, r1.yy
/*    0.1 */       exec    // PredicateClean=false
/*   11   */          mul r4, r5.yyyy, c[25+a0]
/*   12   */          mul r0, r5.yyyy, c[24+a0]
              +       setp_gt r0._, r5.z
/*   13   */          mul r2, r5.yyyy, c[23+a0]
              +       maxas r0._, r1.xx
/*   14   */          mad r2.xyz_, r5.xxxx, c[23+a0].xyzz, r2.xyzz
/*   15   */          mad r1.x___, r5.xxxx, c[23+a0].wwww, r2.wwww
/*   16   */          mad r0, r5.xxxx, c[24+a0], r0
/*    1.0 */       exec
/*   17   */          mad r4.xyz_, r5.xxxx, c[25+a0].xyzz, r4.xyzz
/*   18   */          mad r1._y__, r5.xxxx, c[25+a0].wwww, r4.wwww
/*    1.1 */  (p0) exec
/*   19   */     (p0) mul r5.xy__, r6.xyyy, c255.xxxx
/*   20   */     (p0) maxas r0._, r5.yy
/*   21   */     (p0) mul r7, r5.wwww, c[23+a0]
/*   22   */     (p0) mad r0, r5.wwww, c[24+a0], r0
/*   23   */     (p0) mul r6, r5.wwww, c[25+a0]
              +  (p0) maxas r0._, r5.xx
/*   24   */     (p0) mad r0, r5.zzzz, c[24+a0], r0
/*    2.0 */  (p0) exec
/*   25   */     (p0) mad r6, r5.zzzz, c[25+a0], r6
/*   26   */     (p0) mad r5, r5.zzzz, c[23+a0], r7
/*   27   */     (p0) add r1.x___, r5.wwww, r1.xxxx
/*   28   */     (p0) add r2.xyz_, r5.xyzz, r2.xyzz
              +  (p0) maxs r0._, r6.ww
/*   29   */     (p0) add r4.xyz_, r6.xyzz, r4.xyzz
              +  (p0) adds_prev r1._y__, r1.y
/*    2.1 */       alloc position
/*    3.0 */       exec
/*   30   */          mad r3.xyz_, r3.xyzz, c215.xyzz, c4.xyzz
/*   31   */          dp3 r2.x___, r3.zxyy, r2.zxyy
/*   32   */          dp3 r2._y__, r3.zxyy, r4.zxyy
              +       sges r3.___w, r_abs[0].x
/*   33   */          dp4 r0._y__, r0.zxyw, r3.zxyw
/*   34   */          add r0.x_z_, r2.xyyy, r1.xyyy
              +       sges r0.___w, r_abs[0].x
/*   35   */          mad r0.xyz_, c7.xyzz, c6.xxxx, r0.xyzz
/*    3.1 */       exec
/*   36   */          dp4 oPos.x___, c0.zxyw, r0.zxyw
/*   37   */          dp4 oPos._y__, c1.zxyw, r0.zxyw
/*   38   */          dp4 oPos.__z_, c2.zxyw, r0.zxyw
/*   39   */          dp4 oPos.___w, c3.zxyw, r0.zxyw
/*    4.0 */       alloc interpolators
/*    4.1 */       exece
/*   40   */          add o0.xy__, r1.zwww, c5.xyyy
