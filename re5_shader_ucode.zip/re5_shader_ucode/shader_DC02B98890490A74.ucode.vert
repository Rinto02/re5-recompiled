/*    0.0 */       exec
/*    7   */          vfetch_full r1.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=4
/*    8   */          vfetch_mini r0._xy_, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    9   */          vfetch_mini r3.___x, Offset=3, DataFormat=FMT_8_8_8_8
/*   10   */          serialize
                      mad r3.xyz_, r1.xyzz, c3.xyzz, c4.xyzz
/*   11   */          mul r4.xy__, r0.yzzz, c255.wwww
/*   12   */          add r1.x___, -r3.wwww, c255.xxxx
              +       maxas r0._, r4.yy
/*    0.1 */       exec
/*   13   */          mul r2, r1.xxxx, c[30+a0]
/*   14   */          mul r0, r1.xxxx, c[29+a0]
/*   15   */          mul r1, r1.xxxx, c[28+a0]
              +       maxas r0._, r4.xx
/*   16   */          mad r1, r3.wwww, c[28+a0], r1
/*   17   */          mad r0, r3.wwww, c[29+a0], r0
/*   18   */          mad r2, r3.wwww, c[30+a0].zyxw, r2.zyxw
/*    1.0 */       exec
/*   19   */          cndeq r3, c255.zzzx, r3.zxyy, c255.xxxx
/*   20   */          dp4 r1.x___, r1.zxyw, r3
/*   21   */          dp4 r1._y__, r0.zxyw, r3
/*   22   */          dp4 r1.__z_, r2.xzyw, r3
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   23   */          cndeq r0, c255.zzzx, r1.zxyy, c255.xxxx
/*   24   */          dp4 r1.x___, c0.zxyw, r0
/*   25   */          dp4 r1._y__, c1.zxyw, r0
/*   26   */          dp4 r1.__z_, c2.zxyw, r0
/*   27   */          dp2add r0.__z_, r1.xyyy, r1.xyyy, c255.zzzz
/*   28   */          dp3 r0.x___, r1.zxyy, r1.zxyy
/*    2.1 */       exec
/*   29   */          sqrt r0._y__, r_abs[0].x
/*   30   */          mad r0.x___, r0.yyyy, c27.xxxx, c27.yyyy
/*   31   */          add r0.___w, -r1.zzzz, r0.yyyy
/*   32   */          mul r2.xy__, r1.xyyy, r0.yyyy
/*   33   */          mul r2.xy__, r2.yxxx, r0.wwww
              +       rcp r0.__z_, r0.z
/*   34   */          mul r0.__zw, r2.yyyx, r0.zzzz
/*    3.0 */       exec
/*   35   */          cndge r0.xy__, r1.zzzz, r0.xyyy, c255.xyyy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   36   */          cndeq r1, c255.zzzx, r1.zxyy, c255.xxxx
/*   37   */          dp4 r0.__z_, c23.zxyw, r1
/*   38   */          dp4 r0.___w, c24.zxyw, r1
/*   39   */          dp4 r0.x___, c25.zxyw, r1
/*   40   */          dp4 r0._y__, c26.zxyw, r1
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   41   */          max oPos, r0.zwxy, r0.zwxy
/*    5.1 */       alloc interpolators
/*    6.0 */       exece
/*    6.1 */       cnop
