/*    0.0 */       exec
/*   16   */          vfetch_full r3.zyx1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*   17   */          vfetch_mini r4, Offset=3, DataFormat=FMT_8_8_8_8
/*   18   */          vfetch_mini r1.xywz, Offset=4, DataFormat=FMT_16_16_16_16, Signed=true
/*   19   */          vfetch_mini r2.yzwx, Offset=6, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   20   */          vfetch_mini r0.zyxw, Offset=7, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   21   */          serialize
                      mulsc r1.__z_, c252.y, r1.z
/*    0.1 */       exec
/*   22   */          dp4 r1.__z_, r1.zzzz, c7.wzxy
/*    1.0 */       cjmp !b1, L5
/*    1.1 */       exec
/*   23   */          dp4 r2.x___, r3.wxzy, c28.wzxy
/*   24   */          dp4 r6.x___, r3.wxzy, c26.wzxy
              +       mulsc r5._y__, c253.w, r1.x
/*   25   */          dp4 r2.___w, r3.wxzy, c29.wzxy
              +       mulsc r5.x___, c253.w, r1.y
/*   26   */          dp4 r6._y__, r3.wxzy, c27.wzxy
              +       rcp r2._y__, r2.w
/*   27   */          mad r6.__z_, r1.zzzz, r2.yyyy, r2.xxxx
/*    2.0 */       jmp L15
                label L5
/*    2.1 */       exec
/*   28   */          mul r5.xy__, r1.xyyy, c251.xxxx
              +       addsc r0._y__, c253.x, r0.y
/*   29   */          mul r5.xy__, r5.yxxx, c6.xyyy
              +       addsc r0.__z_, c253.x, r0.z
/*    3.0 */       cjmp !b2, L11
/*    3.1 */       exec
/*   30   */          subsc r2.x___, -c251.x, -r2.y
/*   31   */          mad r2.x___, r2.zzzz, c255.yyyy, r2.xxxx
/*   32   */          mul r7.xy__, r0.yzzz, c254.wwww
              +       subsc r0.x___, -c253.z, -r0.x
/*   33   */          add r6.xyz_, r3.xyzz, -c30.zyxx
              +       mulsc r7.__z_, c254.w, r0.x
/*   34   */          mul r2._yzw, r7.xxzy, r6.xxzy
/*   35   */          mad r6.xyz_, r7.zyxx, r6.yxzz, -r2.yzww
/*    4.0 */       exec
/*   36   */          dp3 r2.__z_, r6.zxyy, r6.zxyy
/*   37   */          mul r2.xy__, r2.xxxx, c255.zwww
              +       rsq r2.__z_, r_abs[2].z
/*   38   */          mul r6.xyz_, r6.zyxx, r2.zzzz
/*   39   */          mul r6.xyz_, r6.zxyy, c255.zwww
/*   40   */          mad r3.xyz_, r6.yzxx, r2.xxyy, r3.xyzz
/*   41   */          dp4 r2.x___, r3.wxzy, c28.wzxy
/*    4.1 */       exec
/*   42   */          dp4 r6.x___, r3.wxzy, c26.wzxy
/*   43   */          dp4 r2.___w, r3.wxzy, c29.wzxy
/*   44   */          dp4 r6._y__, r3.wxzy, c27.wzxy
              +       rcp r2._y__, r2.w
/*   45   */          mad r6.__z_, r1.zzzz, r2.yyyy, r2.xxxx
/*    5.0 */       jmp L15
                label L11
/*    5.1 */       exec
/*   46   */          mad r2.x_z_, r2.yxxx, c255.xyyy, r2.zwww
/*   47   */          mad r2._y__, r2.zzzz, c253.yyyy, c251.zzzz
/*   48   */          frc r2._y__, r2.yyyy
              +       mulsc r6.x___, c251.y, r0.x
/*   49   */          mad r2.__z_, r2.yyyy, c252.wwww, c254.xxxx
/*   50   */          mul r2._y_w, r0.yyzz, c252.zzzz
              +       cos r6._y__, r2.z
/*   51   */          mul r2.xy__, r2.ywww, r2.xxxx
              +       sin r6.__z_, r2.z
/*    6.0 */       exec
/*   52   */          mul r2.xyz_, r2.xxyy, r6.yzxx
/*   53   */          mul r5.__zw, r2.zzzz, r6.yyyz
/*   54   */          add r2.__z_, r5.zzzz, -r2.yyyy
/*   55   */          add r2.___w, r5.wwww, r2.xxxx
/*   56   */          dp2add r2.x___, r2.wzzz, c0.yxxx, c252.xxxx
/*   57   */          dp2add r2._y__, r2.wzzz, c2.yxxx, c252.xxxx
/*    6.1 */       exec
/*   58   */          dp2add r2.__z_, r2.wzzz, c1.yxxx, c252.xxxx
/*   59   */          add r7.xyz_, r3.zxyy, r2.xyzz
              +       sges r7.___w, r_abs[0].x
/*   60   */          dp4 r2.x___, c28.zxyw, r7.yxzw
/*   61   */          dp4 r6.x___, c26.zxyw, r7.yxzw
/*   62   */          dp4 r2.___w, c29.zxyw, r7.yxzw
/*   63   */          dp4 r6._y__, c27.zxyw, r7.yxzw
              +       rcp r2._y__, r2.w
/*    7.0 */       exec
/*   64   */          mad r6.__z_, r1.zzzz, r2.yyyy, r2.xxxx
                label L15
/*    7.1 */       exec
/*   65   */          mul r0._y__, r1.wwww, c253.zzzz
              +       rcp r0.x___, r2.w
/*   66   */          mad r0.x___, r0.xxxx, r6.zzzz, c25.zzzz
/*   67   */          mul r4.xyz_, r0.yyyy, r4.xyzz
              +       rcp r0.x___, r0.x
/*   68   */          mul r2.__z_, r0.xxxx, c25.wwww
              +       mulsc r5.__z_, c4.x, r0.w
/*    8.0 */       cjmp !b4, L18
/*    8.1 */       exec
/*   69   */          dp4 r0._y__, r3.wxzy, c5.wzxy
/*   70   */          subsc r0.x___, -c8.x, -r0.y
/*   71   */          mulsc_sat r0.x___, c8.y, r0.x
/*   72   */          mul r4.___w, r0.xxxx, r4.wwww
                label L18
/*    9.0 */       cjmp !b0, L22
/*    9.1 */       exec
/*   73   */          add r0.xyz_, r3.xyzz, -c30.zyxx
/*   74   */          dp3 r0.x___, r0.xzyy, r0.xzyy
/*   75   */          max r1.xyz_, c3.xyzz, c3.xyzz
              +       sqrt r0._y__, r_abs[0].x
/*   76   */          subsc r0.x___, -c31.x, -r0.y
/*   77   */          mulsc r0.x___, c31.z, r0.x
/*   78   */          min r0.x___, r0.xxxx, c3.wwww
/*   10.0 */       exec
/*   79   */          max r1.___w, r0.xxxx, c252.xxxx
/*   10.1 */       jmp L23
                label L22
/*   11.0 */       exec
/*   80   */          sgt r1, -r_abs[0].xxxx, c252.xxxx
                label L23
/*   11.1 */       cjmp !b3, L26
/*   12.0 */       exec
/*   81   */          sgt r0.x___, c254.zzzz, r4.wwww
/*   82   */          cndeq r6.___w, r0.xxxx, r2.wwww, c254.yyyy
/*   12.1 */       jmp L27
                label L26
/*   13.0 */       exec
/*   83   */          maxs r6.___w, r2.ww
                label L27
/*   13.1 */       alloc position
/*   14.0 */       exec
/*   84   */          max oPos, r6, r6
/*   14.1 */       alloc interpolators
/*   15.0 */       exece
/*   85   */          max r2.xy__, r6.xyyy, r6.xyyy
/*   86   */          max o1.xy0w, r5.xyzz, r5.xyzz
/*   87   */          max o0, r4.zyxw, r4.zyxw
/*   88   */          max o3, r1, r1
/*   89   */          max o2, r2, r2
/*   15.1 */       cnop
