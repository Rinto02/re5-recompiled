/*    0.0 */       exec
/*    2   */          tfetch2D r0.xyz_, r0.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    3   */          mul r0.xyz_, r0.xyzz, c1.xxxx
/*    4   */          mul oC0.xyz1, r0.xyzz, c0.yyyy
/*    1.1 */       cnop
