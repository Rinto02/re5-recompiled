/*    0.0 */       exec
/*    5   */          tfetch2D r4.xy_z, r0.xy, tf0, FetchValidOnly=false
/*    6   */          serialize
                      add r0.__zw, r4.xxxy, c253.zzzz
/*    7   */          mad r5, r0.zwzw, c253.xxyy, r0.xyxy
/*    8   */          mad r1, r0.zwzw, c254.xxyy, r0.xyxy
/*    9   */          mad r6, r0.zwzw, c254.zzww, r0.xyxy
/*   10   */          mad r0.__zw, r0.zzzw, c253.wwww, r0.xxxy
/*    0.1 */       exec
/*   11   */          tfetch2D r2, r0.zw, tf1
/*   12   */          tfetch2D r7, r6.zw, tf1
/*   13   */          tfetch2D r0, r0.xy, tf1
/*   14   */          tfetch2D r8, r1.zw, tf1
/*   15   */          tfetch2D r3, r5.xy, tf1
/*   16   */          tfetch2D r9, r6.xy, tf1
/*    1.0 */       exec
/*   17   */          tfetch2D r5, r5.zw, tf1
/*   18   */          tfetch2D r6, r1.xy, tf1
/*    1.1 */       alloc colors
/*    2.0 */       exec
/*   19   */          sge r4.__z_, r6.wwww, r4.wwww
/*   20   */          sge r1.x___, r5.wwww, r4.wwww
/*   21   */          sge r4.x___, r9.wwww, r4.wwww
/*   22   */          sge r4._y__, r3.wwww, r4.wwww
/*   23   */          sge r1.__z_, r8.wwww, r4.wwww
/*   24   */          sge r1.___w, r0.wwww, r4.wwww
/*    2.1 */       exec
/*   25   */          sge r1._y__, r7.wwww, r4.wwww
/*   26   */          sge r4.___w, r2.wwww, r4.wwww
/*   27   */          mul r2.xyz_, r4.wwww, r2.xyzz
/*   28   */          mad r2.xyz_, r1.yyyy, r7.xzyy, r2.xzyy
/*   29   */          add r7.xy__, r4.xyyy, r1.zwww
/*   30   */          add r7.xy__, r7.yxxx, r1.xyyy
/*    3.0 */       exec
/*   31   */          mad r2.xyz_, r4.xxxx, r9.xyzz, r2.xzyy
/*   32   */          mad r2.xyz_, r1.zzzz, r8.xzyy, r2.xzyy
/*   33   */          add r7.xy__, r7.xyyy, r4.zwww
/*   34   */          adds r0.___w, r7.xy
/*   35   */          mad r2.xyz_, r4.zzzz, r6.xyzz, r2.xzyy
/*   36   */          mad r2.xyz_, r1.xxxx, r5.xzyy, r2.xzyy
/*    3.1 */       exec
/*   37   */          max r1._y__, r0.wwww, c255.xxxx
/*   38   */          min r1.x___, r0.wwww, c255.xxxx
              +       rcp r1._y__, r1.y
/*   39   */          mad r2.xyz_, r4.yyyy, r3.xyzz, r2.xzyy
/*   40   */          mad r2.xyz_, r1.wwww, r0.xzyy, r2.xzyy
/*   41   */          mad r1._yzw, r2.xxzy, r1.yyyy, -r0.xxyz
/*   42   */          mad r0.xyz_, r1.yzww, r1.xxxx, r0.xyzz
/*    4.0 */       exece
/*   43   */          max oC0, r0, r0
/*    4.1 */       cnop
