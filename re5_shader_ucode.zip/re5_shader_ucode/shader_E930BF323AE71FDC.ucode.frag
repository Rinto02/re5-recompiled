/*    0.0 */       exec
/*   26   */          tfetch2D r7.yxzw, r1.xy, tf0
/*   27   */          serialize
                      mul r8.xy__, r3.xyyy, c14.yyyy
              +       rcp r1.x___, r0.w
/*   28   */          mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r7.ww
/*   29   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   30   */          mul r3.__zw, r3.zzzw, r0.yyyx
              +       subsc r1.x___, -c1.x, -r1.y
/*   31   */          kill_gt r1._, c255.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   32   */          tfetch2D r11.xyz_, r3.xy, tf2
/*   33   */          tfetch2D r0.xy__, r8.xy, tf5
/*   34   */          tfetch2D r0.__xy, r3.xy, tf1
/*   35   */          tfetch2D r9, r3.zw, tf4
/*   36   */          serialize
                      sgt r10.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       maxs r4.___w, c56.xx
/*   37   */          add r3.xyz_, r2.xyzz, -c23.xyzz
              +       sgts r8._y__, -r_abs[1].x
/*    1.0 */       exec
/*   38   */          mul r9, r9.wzyx, c5.wzyx
              +       sgts r8.__z_, -r_abs[1].x
/*   39   */          dp3 r1._y__, r3.zxyy, r3.zxyy
              +       sgts r8.x___, -r_abs[1].x
/*   40   */          mad r0, r0.xywz, c254.xxxx, c255.wwww
              +       retain_prev r1._
/*   41   */          min r9, r9, c7.xxxx
              +       rsq r1.x___, r_abs[1].y
/*   42   */          mul r3.x_zw, r3.zyyx, r1.xxxx
              +       maxs r1.x___, r7.zz
/*   43   */          max r9, r9.wzyx, c8.xxxx
              +       mulsc r6.___w, c13.z, r1.x
/*    1.1 */       exec
/*   44   */          mad r0.x__w, r0.yxxx, c14.xxxx, r0.zwww
              +       retain_prev r1._
/*   45   */          dp2add r2.___w, -r0.xwww, r0.xwww, c255.yyyy
              +       retain_prev r1._
/*   46   */          max r12.xy__, r9.yxxx, r9.wzzz
              +       sqrt r2.___w, r_abs[2].w
/*   47   */          mul r13.xyz_, r2.wwww, r6.xyzz
              +       mulsc r6._y__, c13.y, r7.x
/*   48   */          mad r0.xyz_, r0.xxxx, r5.zyxx, r13.zyxx
              +       retain_prev r1._
/*   49   */          mad r0.xyz_, r0.wwww, r4.xzyy, r0.zxyy
              +       retain_prev r1._
/*    2.0 */       exec
/*   50   */          dp3 r2.___w, r0.yxzz, r0.yxzz
              +       mulsc r6.x___, c13.x, r7.y
/*   51   */          max r3._y__, r12.yyyy, r12.xxxx
              +       rsq r2.___w, r_abs[2].w
/*   52   */          mul r4.xyz_, r0.xzyy, r2.wwww
              +       sqrt r1._y__, r_abs[1].y
/*    2.1 */       cjmp !b128, L25
/*    3.0 */       exec
/*   53   */          mul r0, r9.wzyx, c48.wzyx
              +       retain_prev r1._
/*   54   */          add r5.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   55   */          dp3 r5.___w, r5.xzyy, r5.xzyy
              +       retain_prev r1._
/*   56   */          max4 r0.__z_, r0.zxwy
              +       rsq r1.x___, r_abs[5].w
/*   57   */          mul r8, r5, r1.xxxx
              +       retain_prev r1._
/*   58   */          dp3 r5.__z_, r4.zxyy, r8.xzyy
              +       retain_prev r1._
/*    3.1 */       exec
/*   59   */          add r5.xy_w, r8.zyxx, -r3.wzxx
              +       retain_prev r1._
/*   60   */          dp3 r2.___w, r8.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   61   */          add r1.x___, r8.wwww, -c32.wwww
              +       retain_prev r1._
/*   62   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   63   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c35.y, r2.w
/*   64   */          max r1.x___, r1.xxxx, c35.wwww
              +       rsq r2.___w, r_abs[0].y
/*    4.0 */       exec
/*   65   */          mul r8.xyz_, r5.wyxx, r2.wwww
              +       subsc r0.___w, c255.y, r0.x
/*   66   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r2.___w, c255.y, r0.z
/*   67   */          dp3 r5._y__, r4.zxyy, r8.xzyy
              +       maxs r1._, r0.ww
/*   68   */          max r0._yz_, r5.zzyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*   69   */          mul r5._yzw, r5.xxyy, c32.xxzy
              +       log r1.x___, r_abs[0].z
/*   70   */          max r1._, r1, r1
              +       mulsc r0.x___, c15.z, r1.x
/*    4.1 */       exec
/*   71   */          mul r5.x___, r5.yyyy, r0.wwww
              +       exp r0.x___, r0.x
/*   72   */          mul r8.xy__, r5.zwww, r0.xxxx
              +       retain_prev r1._
/*   73   */          mul r10.xy__, r8.xyyy, r2.wwww
              +       retain_prev r1._
/*   74   */          mul r0, r5.xzwx, r0.yyyx
              +       retain_prev r1._
/*   75   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       maxs r1._, r0.ww
/*   76   */          mul r8.xyz_, r0.xzyy, c35.zzzz
              +       muls_prev r10.__z_, r2.w
/*    5.0 */       cjmp !b129, L25
/*    5.1 */       exec
/*   77   */          mul r0, r9.wzyx, c49.wzyx
              +       retain_prev r1._
/*   78   */          add r5.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   79   */          dp3 r5.___w, r5.zxyy, r5.zxyy
              +       retain_prev r1._
/*   80   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[5].w
/*   81   */          mul r12, r5, r1.xxxx
              +       retain_prev r1._
/*   82   */          dp3 r5.__z_, r4.zxyy, r12.zxyy
              +       retain_prev r1._
/*    6.0 */       exec
/*   83   */          add r5.xy_w, r12.xyzz, -r3.wzxx
              +       retain_prev r1._
/*   84   */          dp3 r2.___w, r12.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   85   */          add r1.x___, r12.wwww, -c36.wwww
              +       retain_prev r1._
/*   86   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   87   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c39.y, r2.w
/*   88   */          max r1.x___, r1.xxxx, c39.wwww
              +       rsq r2.___w, r_abs[0].y
/*    6.1 */       exec
/*   89   */          mul r12.xyz_, r5.wyxx, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   90   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*   91   */          dp3 r5._y__, r4.zxyy, r12.xzyy
              +       maxs r1._, r0.yy
/*   92   */          max r0.x__w, r5.zyyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*   93   */          mul r5.xy_w, r5.yyxx, c36.zyxx
              +       log r1.x___, r_abs[0].w
/*   94   */          mul r5.__z_, r5.wwww, r0.yyyy
              +       mulsc r0.___w, c15.z, r1.x
/*    7.0 */       exec
/*   95   */          mul r0.xyz_, r5.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*   96   */          mul r5.xyz_, r5.xyzz, r0.wwww
              +       retain_prev r1._
/*   97   */          mad r10.xyz_, r5.xyzz, r2.wwww, r10.xyzz
              +       retain_prev r1._
/*   98   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   99   */          mad r8.xyz_, r0.xzyy, c39.zzzz, r8.xyzz
              +       retain_prev r1._
/*    7.1 */       cjmp !b130, L25
/*    8.0 */       exec
/*  100   */          mul r0, r9, c50
              +       retain_prev r1._
/*  101   */          add r5.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*  102   */          dp3 r5.___w, r5.xzyy, r5.xzyy
              +       retain_prev r1._
/*  103   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[5].w
/*  104   */          mul r12, r5, r1.xxxx
              +       retain_prev r1._
/*  105   */          dp3 r5.__z_, r4.zxyy, r12.xzyy
              +       retain_prev r1._
/*    8.1 */       exec
/*  106   */          add r5.xy_w, r12.zyxx, -r3.wzxx
              +       retain_prev r1._
/*  107   */          dp3 r2.___w, r12.xzyy, -c42.zxyy
              +       retain_prev r1._
/*  108   */          add r1.x___, r12.wwww, -c40.wwww
              +       retain_prev r1._
/*  109   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*  110   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c43.y, r2.w
/*  111   */          max r1.x___, r1.xxxx, c43.wwww
              +       rsq r2.___w, r_abs[0].y
/*    9.0 */       exec
/*  112   */          mul r12.xyz_, r5.xyww, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  113   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*  114   */          dp3 r5._y__, r4.zxyy, r12.zxyy
              +       maxs r1._, r0.yy
/*  115   */          max r0.x__w, r5.zyyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*  116   */          mul r5.xy_w, r5.yyxx, c40.zyxx
              +       log r1.x___, r_abs[0].w
/*  117   */          mul r5.__z_, r5.wwww, r0.yyyy
              +       mulsc r0.___w, c15.z, r1.x
/*    9.1 */       exec
/*  118   */          mul r0.xyz_, r5.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  119   */          mul r5.xyz_, r5.xyzz, r0.wwww
              +       retain_prev r1._
/*  120   */          mad r10.xyz_, r5.xyzz, r2.wwww, r10.xyzz
              +       retain_prev r1._
/*  121   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  122   */          mad r8.xyz_, r0.xzyy, c43.zzzz, r8.xyzz
              +       retain_prev r1._
/*   10.0 */       cjmp !b131, L25
/*   10.1 */       exec
/*  123   */          mul r0, r9.wzyx, c51.wzyx
              +       retain_prev r1._
/*  124   */          add r5.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*  125   */          dp3 r5.___w, r5.zxyy, r5.zxyy
              +       retain_prev r1._
/*  126   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[5].w
/*  127   */          mul r12, r5, r1.xxxx
              +       retain_prev r1._
/*  128   */          dp3 r5.__z_, r4.zxyy, r12.zxyy
              +       retain_prev r1._
/*   11.0 */       exec
/*  129   */          add r5.xy_w, r12.xyzz, -r3.wzxx
              +       retain_prev r1._
/*  130   */          dp3 r2.___w, r12.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  131   */          add r1.x___, r12.wwww, -c44.wwww
              +       retain_prev r1._
/*  132   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  133   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c47.y, r2.w
/*  134   */          max r1.x___, r1.xxxx, c47.wwww
              +       rsq r2.___w, r_abs[0].y
/*   11.1 */       exec
/*  135   */          mul r12.xyz_, r5.wyxx, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  136   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*  137   */          dp3 r5._y__, r4.zxyy, r12.xzyy
              +       maxs r1._, r0.yy
/*  138   */          max r0.x__w, r5.zyyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*  139   */          mul r5.xy_w, r5.yyxx, c44.zyxx
              +       log r1.x___, r_abs[0].w
/*  140   */          mul r5.__z_, r5.wwww, r0.yyyy
              +       mulsc r0.___w, c15.z, r1.x
/*   12.0 */       exec
/*  141   */          mul r0.xyz_, r5.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  142   */          mul r5.xyz_, r5.xyzz, r0.wwww
              +       retain_prev r1._
/*  143   */          mad r10.xyz_, r5.xyzz, r2.wwww, r10.xyzz
              +       retain_prev r1._
/*  144   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  145   */          mad r8.xyz_, r0.xzyy, c47.zzzz, r8.xyzz
              +       retain_prev r1._
                label L25
/*   12.1 */       cjmp !b132, L37
/*   13.0 */       exec
/*  146   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  147   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  148   */          mul r5, r9.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  149   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  150   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  151   */          dp3 r2.___w, r0.xzyy, r4.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   13.1 */       exec
/*  152   */          max4 r0._y__, r5.zxwy
              +       maxs r0.__z_, r2.ww
/*  153   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  154   */          mul r5.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  155   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  156   */          mad r8.xyz_, r5.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   14.0 */       cjmp !b133, L37
/*   14.1 */       exec
/*  157   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  158   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  159   */          mul r5, r9, c53
              +       rsq r1.x___, r_abs[0].w
/*  160   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  161   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  162   */          dp3 r2.___w, r0.zxyy, r4.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   15.0 */       exec
/*  163   */          max4 r0._y__, r5.ywxz
              +       maxs r0.__z_, r2.ww
/*  164   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  165   */          mul r5.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  166   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  167   */          mad r8.xyz_, r5.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   15.1 */       cjmp !b134, L37
/*   16.0 */       exec
/*  168   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  169   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  170   */          mul r5, r9.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  171   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  172   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  173   */          dp3 r2.___w, r0.xzyy, r4.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   16.1 */       exec
/*  174   */          max4 r0._y__, r5.zxwy
              +       maxs r0.__z_, r2.ww
/*  175   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  176   */          mul r5.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  177   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  178   */          mad r8.xyz_, r5.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   17.0 */       cjmp !b135, L37
/*   17.1 */       exec
/*  179   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  180   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  181   */          mul r5, r9, c55
              +       rsq r1.x___, r_abs[0].w
/*  182   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  183   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  184   */          dp3 r2.___w, r0.zxyy, r4.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   18.0 */       exec
/*  185   */          max4 r0._y__, r5.ywxz
              +       maxs r0.__z_, r2.ww
/*  186   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  187   */          mul r5.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  188   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  189   */          mad r8.xyz_, r5.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
                label L37
/*   18.1 */       exec
/*  190   */          mul r12, r4.xyzz, r4.yzzx
              +       retain_prev r1._
/*  191   */          cndeq r0, c255.xxxy, r4.zxyy, c255.yyyy
              +       retain_prev r1._
/*  192   */          dp4 r5.x___, c16.zxyw, r0
              +       retain_prev r1._
/*  193   */          dp4 r5._y__, c18.zxyw, r0
              +       retain_prev r1._
/*  194   */          dp4 r5.__z_, c17.zxyw, r0
              +       retain_prev r1._
/*  195   */          dp4 r0.x___, r12.wzxy, c19.wzxy
              +       muls r9.x___, r4.xx
/*   19.0 */       exec    // PredicateClean=false
/*  196   */          dp4 r0._y__, r12.wzxy, c21.wzxy
              +       muls r9._y__, r4.yy
/*  197   */          dp4 r0.__z_, r12.wzxy, c20.wzxy
              +       subs r2.___w, r9.xy
/*  198   */          add r0.xyz_, r5.zxyy, r0.zxyy
              +       setp_gt r1._, c_abs[57].x
/*  199   */          mad r0.xyz_, r2.wwww, c22.xyzz, r0.yxzz
              +       retain_prev r1._
/*  200   */          mad r5.xyz_, r8.xzyy, r1.wwww, r0.xyzz
              +       retain_prev r1._
/*   19.1 */  (p0) exec
/*  201   */     (p0) mul r8.xyz_, r5.zyxx, c60.xxxx
              +  (p0) retain_prev r1._
/*  202   */     (p0) mul r0.xyz_, r5.zyxx, c61.xxxx
              +  (p0) retain_prev r1._
/*  203   */     (p0) mul r0.xyz_, r0.xyzz, c59.xxxx
              +  (p0) retain_prev r1._
/*  204   */     (p0) mad r5.xyz_, r8.zyxx, c58.xxxx, r0.zyxx
              +  (p0) retain_prev r1._
/*   20.0 */       exec
/*  205   */          dp3 r8._y__, r3.xwzz, r4.zxyy
              +       retain_prev r1._
/*  206   */          max r1._, r1, r1
              +       adds r1.x___, r8.yy
/*  207   */          mad r0.xyz_, -r4.xyzz, r1.xxxx, r3.wzxx
              +       retain_prev r1._
/*  208   */          cube r0, r0.zzxy, r0.yxzz
              +       retain_prev r1._
/*  209   */          max r4.__z_, r0.wwww, r0.wwww
              +       rcp r1.x___, r_abs[0].z
/*  210   */          mad r4.xy__, r0.yxxx, r1.xxxx, c254.yyyy
              +       retain_prev r1._
/*   20.1 */       exec
/*  211   */          setTexLOD r4.w
/*  212   */          tfetchCube r4, r4.xyz, tf3, UseComputedLOD=false, UseRegisterLOD=true
/*   21.0 */       alloc colors
/*   21.1 */       exec
/*  213   */          max r1.x___, r4.wwww, c254.zzzz
              +       mulsc r8.x___, c6.x, r3.y
/*  214   */          add r0.xy__, -r8.xyyy, c255.yyyy
              +       rcp r1.x___, r1.x
/*  215   */          mul r4.xyz_, r1.xxxx, r4.xyzz
              +       retain_prev r1._
/*  216   */          mul r4.xyz_, r4.zyxx, r0.xxxx
              +       muls r1.x___, r_abs[0].yy
/*  217   */          max r1._, r1, r1
              +       muls r1.x___, r1.xx
/*  218   */          mul r4.___w, r1.xxxx, r_abs[0].yyyy
              +       retain_prev r1._
/*   22.0 */       exec    // PredicateClean=false
/*  219   */          mad r0.xyz_, r4.zyxx, c15.wwww, r10.zyxx
              +       retain_prev r1._
/*  220   */          mad_sat r1.x___, r4.wwww, c15.xxxx, c15.yyyy
              +       retain_prev r1._
/*  221   */          max r1._, r1, r1
              +       subsc r1.x___, c255.y, r1.x
/*  222   */          mul r1.x___, r1.xxxx, r1.wwww
              +       setp_ne r1._, c57.x
/*  223   */     (p0) mul r0.xyz_, r0.xyzz, c62.xxxx
              +  (p0) retain_prev r1._
/*  224   */          mul r4.xyz_, r1.xxxx, r11.xyzz
              +       maxs r1._, r7.ww
/*   22.1 */       exec
/*  225   */          mul r0.xyz_, r4.xyzz, r0.xyzz
              +       muls_prev r1.___w, r1.z
/*  226   */          mad r0.xyz_, r6.xyww, r5.xyzz, r0.xyzz
              +       retain_prev r1._
/*   23.0 */       cjmp !b136, L50
/*   23.1 */       exec
/*  227   */          mad r2.___w, r1.yyyy, c12.yyyy, c12.zzzz
              +       retain_prev r1._
/*  228   */          dp3 r1.__z_, r3.xwzz, c10.zxyy
              +       retain_prev r1._
/*  229   */          cndeq r3, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  230   */          dp4 r1.x___, c10.zxyw, r3
              +       subsc r1._y__, -c9.x, -r1.y
/*  231   */          add r2.xyz_, -r0.xyzz, c11.xyzz
              +       mulsc r0.___w, c9.z, r1.y
/*  232   */          min r3.xy__, r1.xzzz, c255.xzzz
              +       mulsc r1.x___, c9.w, r1.x
/*   24.0 */       exec
/*  233   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  234   */          max r1._, r1, r1
              +       mulsc r1.x___, c12.x, r1.y
/*  235   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  236   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  237   */          min r1.x___, r1.xxxx, c11.wwww
              +       retain_prev r1._
/*  238   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*   24.1 */       exec
/*  239   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L50
/*   25.0 */       exece
/*  240   */          mul r1.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  241   */          max oC0, r1, r1
/*   25.1 */       cnop
