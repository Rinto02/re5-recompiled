/*    0.0 */       alloc colors
/*    0.1 */       exece
/*    1   */          mul r2.xy__, c23.xyyy, c255.xxxx
              +       rcp r2.__z_, r1.w
/*    2   */          max oC0.00_1, r0, r0
              +       maxs oC0.__z_, r0.zz
/*    3   */          mul r1.xy__, r2.zzzz, r1.xyyy
              +       rcp r1.__z_, r0.w
/*    4   */          mad r0.xy__, r1.zzzz, r0.xyyy, -r1.xyyy
/*    5   */          mad oC0.xy__, r2.xyyy, r0.xyyy, c255.yyyy
