/*    0.0 */       exec
/*    3   */          tfetch2D r0.___x, r0.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exec
/*    4   */          dp2add r4.__z_, r1.xyyy, c51.xyyy, c255.xxxx
/*    5   */          dp2add r3.x___, r1.xyyy, c52.xyyy, c255.xxxx
/*    6   */          subsc r0.___w, c255.z, r0.w
/*    7   */          subsc_sat oDepth.x___, c255.z, r0.w
/*    8   */          mulsc r2._y__, c53.z, r0.w
/*    9   */          mul r3._yz_, r1.xxyy, c53.xxyy
              +       mulsc r2.x___, c54.z, r0.w
/*    1.1 */       exec
/*   10   */          mul r3.___w, r0.wwww, c52.zzzz
              +       mulsc r4.___w, c51.z, r0.w
/*   11   */          mul r4.xy__, r1.xyyy, c54.xyyy
              +       adds r1._y__, r3.xw
/*   12   */          add r1.x_z_, r4.zxxx, r4.wyyy
              +       adds r1.___w, r3.yz
/*   13   */          add r0.__zw, r1.zzzw, r2.xxxy
/*   14   */          add r0.__z_, r0.zzzz, c54.wwww
              +       addsc r3.x___, c51.w, r1.x
/*   15   */          add r3.__z_, r0.wwww, c53.wwww
              +       rcp r0.__z_, r0.z
/*    2.0 */       exec
/*   16   */          mul r4.xyz_, r0.zzzz, c50.xyzz
              +       addsc r3._y__, c52.w, r1.y
/*   17   */          mul r2.xyz_, r3.xyzz, r0.zzzz
/*   18   */          dp3 r0.__z_, r4.zxyy, r3.zxyy
              +       maxs r2.___w, c255.zz
/*   19   */          max oC0.00_1, r0, r0
              +       addsc oC0.__z_, c50.w, r0.z
/*   20   */          dp4 r1.x___, c55.zxyw, r2.zxyw
/*   21   */          dp4 r0.__z_, c58.zxyw, r2.zxyw
/*    2.1 */       exece
/*   22   */          dp4 r1._y__, c56.zxyw, r2.zxyw
              +       rcp r0.__z_, r0.z
/*   23   */          mad r0.__zw, r1.xxxy, r0.zzzz, c59.xxxy
/*   24   */          mad r0.xy__, -r0.zwww, c60.xyyy, r0.xyyy
/*   25   */          max r0.xy__, r0.xyyy, -c61.yyyy
              +       maxs r0._, c61.zz
/*   26   */          min r0.xy__, r0.xyyy, c61.yyyy
              +       muls_prev r0.__z_, c255.y
/*   27   */          mad oC0.xy__, r0.zzzz, r0.xyyy, c255.wwww
