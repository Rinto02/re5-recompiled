/*    0.0 */       exec
/*    4   */          tfetch2D r8.xyz_, r0.xy, tf0
/*    5   */          tfetch2D r9.xyz_, r7.xy, tf0
/*    6   */          tfetch2D r7.xyz_, r7.zw, tf0
/*    7   */          tfetch2D r11.xyz_, r6.xy, tf0
/*    8   */          tfetch2D r10.xyz_, r6.zw, tf0
/*    9   */          tfetch2D r12.xyz_, r5.xy, tf0
/*    0.1 */       exec
/*   10   */          tfetch2D r5.xyz_, r5.zw, tf0
/*   11   */          tfetch2D r13.xyz_, r4.xy, tf0
/*   12   */          tfetch2D r4.xyz_, r4.zw, tf0
/*   13   */          tfetch2D r14.xyz_, r2.xy, tf0
/*   14   */          tfetch2D r2.xyz_, r2.zw, tf0
/*   15   */          tfetch2D r6.xz_y, r3.xy, tf0
/*    1.0 */       exec
/*   16   */          tfetch2D r0.xz_y, r3.zw, tf0
/*   17   */          tfetch2D r3.xyz_, r1.xy, tf0
/*   18   */          tfetch2D r1.xyz_, r1.zw, tf0
/*    1.1 */       alloc colors
/*    2.0 */       exec
/*   19   */          add r1.xyz_, r3.xzyy, r1.xzyy
/*   20   */          add r2.xyz_, r14.xzyy, r2.xzyy
              +       maxs r0._, r6.xx
/*   21   */          add r4.xyz_, r13.xzyy, r4.xzyy
              +       adds_prev r3.x___, r0.x
/*   22   */          add r5.xyz_, r12.xzyy, r5.xzyy
              +       maxs r0._, r6.yy
/*   23   */          add r6.xyz_, r11.xzyy, r10.xzyy
              +       adds_prev r3._y__, r0.y
/*   24   */          add r7.xyz_, r9.xzyy, r7.xzyy
              +       maxs r0._, r6.ww
/*    2.1 */       exec
/*   25   */          mul r0.xyz_, r7.xzyy, c17.wwww
              +       adds_prev r3.__z_, r0.w
/*   26   */          mad r0.xyz_, r6.xyzz, c17.zzzz, r0.xzyy
/*   27   */          mad r0.xyz_, r5.xyzz, c17.yyyy, r0.xyzz
/*   28   */          mad r0.xyz_, r4.xyzz, c17.xxxx, r0.xyzz
/*   29   */          mad r0.xyz_, r3.xyzz, c16.wwww, r0.xyzz
/*   30   */          mad r0.xyz_, r2.xyzz, c16.zzzz, r0.xyzz
/*    3.0 */       exece
/*   31   */          mad r0.xyz_, r1.xyzz, c16.yyyy, r0.xyzz
/*   32   */          mad oC0.xyz1, r8.xyzz, c16.xxxx, r0.xzyy
/*    3.1 */       cnop
