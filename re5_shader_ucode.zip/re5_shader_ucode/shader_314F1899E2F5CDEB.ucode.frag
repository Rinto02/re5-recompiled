/*    0.0 */       exec
/*    4   */          tfetch2D r5, r4.zw, tf0
/*    5   */          tfetch2D r4, r4.xy, tf0
/*    6   */          tfetch2D r7, r3.xy, tf0
/*    7   */          tfetch2D r8, r2.zw, tf0
/*    8   */          tfetch2D r3, r3.zw, tf0
/*    9   */          tfetch2D r2, r2.xy, tf0
/*    0.1 */       exec
/*   10   */          tfetch2D r6, r1.zw, tf0
/*   11   */          tfetch2D r9, r1.xy, tf0
/*   12   */          tfetch2D r1, r0.xy, tf0
/*   13   */          tfetch2D r0, r0.zw, tf0
/*    1.0 */       alloc colors
/*    1.1 */       exec
/*   14   */          add r0.___w, r1.wwww, r0.wwww
/*   15   */          add r11.xyz_, r0.xyzz, -c48.xxxx
              +       maxs r0._y__, r1.xx
/*   16   */          add r10.xyz_, r9.xyzz, -c48.xxxx
              +       subsc r12.x___, -c48.x, -r0.y
/*   17   */          add r9.xyz_, r6.xyzz, -c48.xxxx
              +       subsc r12._y__, -c48.x, -r1.y
/*   18   */          add r14.xyz_, r2.xyzz, -c48.xxxx
              +       subsc r12.__z_, -c48.x, -r1.z
/*   19   */          add r13._yzw, r8.xxyz, -c48.xxxx
              +       maxs r0._y__, r3.xx
/*    2.0 */       exec
/*   20   */          add r6.xyz_, r7.xyzz, -c48.xxxx
              +       subsc r15.x___, -c48.x, -r0.y
/*   21   */          add r1.xyz_, r4.xyzz, -c48.xxxx
              +       subsc r15._y__, -c48.x, -r3.y
/*   22   */          add r0.xyz_, r5.xyzz, -c48.xxxx
              +       subsc r15.__z_, -c48.x, -r3.z
/*   23   */          max r0.xyz_, r0.xyzz, c255.xxxx
              +       maxs r0._, r0.ww
/*   24   */          max r1.xyz_, r1.xyzz, c255.xxxx
              +       adds_prev r0.___w, r9.w
/*   25   */          max r2.xyz_, r15.xyzz, c255.xxxx
              +       maxs r13.x___, r6.xx
/*    2.1 */       exec
/*   26   */          max r7.xyz_, r13.yzww, c255.xxxx
              +       maxs r13._y__, c255.xx
/*   27   */          max r8.xyz_, r14.xyzz, c255.xxxx
              +       maxs r6.x___, r13.xy
/*   28   */          max r9.xyz_, r9.xyzz, c255.xxxx
              +       maxs r13.x___, r6.yy
/*   29   */          max r10.xyz_, r10.xyzz, c255.xxxx
              +       maxs r13._y__, c255.xx
/*   30   */          max r12.xyz_, r12.xyzz, c255.xxxx
              +       maxs r6._y__, r13.xy
/*   31   */          max r11.xyz_, r11.xyzz, c255.xxxx
              +       maxs r6.__z_, r6.zz
/*    3.0 */       exec
/*   32   */          add r0.___w, r0.wwww, r6.wwww
              +       maxs r6.___w, c255.xx
/*   33   */          add r11.xyz_, r12.xyzz, r11.xyzz
              +       maxs r0._, r0.ww
/*   34   */          add r10.xyz_, r11.xyzz, r10.xyzz
              +       adds_prev r0.___w, r2.w
/*   35   */          add r0.___w, r0.wwww, r8.wwww
              +       maxs r6.__z_, r6.zw
/*   36   */          add r9.xyz_, r10.xyzz, r9.xyzz
              +       maxs r0._, r0.ww
/*   37   */          add r8.xyz_, r9.xyzz, r8.xyzz
              +       adds_prev r0.___w, r7.w
/*    3.1 */       exece
/*   38   */          add r7.xyz_, r8.xyzz, r7.xyzz
              +       maxs r0._, r0.ww
/*   39   */          add r6.xyz_, r7.xyzz, r6.xyzz
              +       adds_prev r0.___w, r3.w
/*   40   */          add r2.xyz_, r6.xyzz, r2.xyzz
              +       maxs r0._, r0.ww
/*   41   */          add r1.xyz_, r2.xyzz, r1.xyzz
              +       adds_prev r0.___w, r4.w
/*   42   */          add r0.xyz_, r1.xyzz, r0.xyzz
              +       maxs r0._, r0.ww
/*   43   */          mul oC0.xyz_, r0.xyzz, c49.xyzz
              +       adds_prev oC0.___w, r5.w
