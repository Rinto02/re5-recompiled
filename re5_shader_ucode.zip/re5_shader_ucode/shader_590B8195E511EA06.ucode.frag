/*    0.0 */       exec
/*   22   */          add r6.xyz_, r2.zyxx, -c23.zyxx
              +       rcp r2.___w, r3.w
/*   23   */          mad r5.xy__, r2.wwww, r3.xyyy, c5.xyyy
              +       retain_prev r1._
/*   24   */          mul r7.xy__, r5.xyyy, c6.xyyy
              +       retain_prev r1._
/*   25   */          tfetch2D r5, r1.xy, tf0
/*   26   */          tfetch2D r4.___x, r7.xy, tf2
/*   27   */          serialize
                      add r6.___w, c2.zzzz, c255.yyyy
              +       rcp r7.x___, r0.w
/*    0.1 */       exec
/*   28   */          mad r2.___w, r2.wwww, r3.zzzz, c2.zzzz
              +       retain_prev r1._
/*   29   */          mad r0.x_z_, r7.xxxx, r0.yxxx, c5.yxxx
              +       retain_prev r1._
/*   30   */          add r0._y__, r6.wwww, -r4.wwww
              +       retain_prev r1._
/*   31   */          mul r3.xy__, c7.zwww, c6.xyyy
              +       rcp r0._y__, r0.y
/*   32   */          mul r0.x_z_, r3.xyyy, r0.zxxx
              +       rcp r0.___w, r2.w
/*   33   */          mul r0._y_w, r0.yyww, c2.wwww
              +       retain_prev r1._
/*    1.0 */       exec
/*   34   */          add r0._y__, r0.yyyy, -r0.wwww
              +       rcp r2.___w, c56.x
/*   35   */          mul r2.___w, r_abs[0].yyyy, r2.wwww
              +       retain_prev r1._
/*   36   */          min r0._y__, r2.wwww, c255.yyyy
              +       retain_prev r1._
/*   37   */          mad r2.___w, r0.yyyy, r5.wwww, -c4.xxxx
              +       retain_prev r1._
/*   38   */          kill_gt r1._, c255.xxxx, r2.wwww
              +       retain_prev r1._
/*   39   */          tfetch2D r3, r0.xz, tf1
/*    1.1 */       alloc colors
/*    2.0 */       exec
/*   40   */          mul r10.___w, r5.wwww, r1.zzzz
              +       retain_prev r1._
/*   41   */          sgt r7.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       retain_prev r1._
/*   42   */          dp3 r2.___w, r4.zxyy, r4.zxyy
              +       retain_prev r1._
/*   43   */          mul r10.xyz_, r5.zyxx, c55.zyxx
              +       retain_prev r1._
/*   44   */          dp3 r5.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   45   */          mul r3, r3.wzyx, c40.wzyx
              +       rsq r2.___w, r_abs[2].w
/*    2.1 */       exec
/*   46   */          mul r8.xyz_, r2.wwww, c18.zyxx
              +       retain_prev r1._
/*   47   */          mul r9.xyz_, r2.wwww, c17.zyxx
              +       mulsc r11.__z_, c16.x, r2.w
/*   48   */          mul r5.xyz_, r2.wwww, r4.zxyy
              +       mulsc r11._y__, c16.y, r2.w
/*   49   */          min r3, r3, c49.xxxx
              +       mulsc r11.x___, c16.z, r2.w
/*   50   */          max r3, r3.wzyx, c50.xxxx
              +       sqrt r4.___w, r_abs[5].w
/*    3.0 */       cjmp !b128, L22
/*    3.1 */       exec
/*   51   */          mul r12, r3.wzyx, c41.wzyx
              +       retain_prev r1._
/*   52   */          add r7.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*   53   */          dp3 r7.___w, r7.xzyy, r7.xzyy
              +       retain_prev r1._
/*   54   */          max4 r1.__z_, r12.zxwy
              +       rsq r1.x___, r_abs[7].w
/*   55   */          mul r7, r7, r1.xxxx
              +       retain_prev r1._
/*   56   */          dp3 r0.x___, r5.xyzz, r7.xzyy
              +       retain_prev r1._
/*    4.0 */       exec
/*   57   */          dp3 r2.___w, r7.xzyy, -c26.zxyy
              +       retain_prev r1._
/*   58   */          add r1.x___, r7.wwww, -c24.wwww
              +       retain_prev r1._
/*   59   */          add r2.___w, r2.wwww, -c27.xxxx
              +       mulsc_sat r1.x___, c25.w, r1.x
/*   60   */          max r0.x___, r0.xxxx, c255.xxxx
              +       mulsc r2.___w, c27.y, r2.w
/*   61   */          max r2.___w, r2.wwww, c27.wwww
              +       subsc r0.__z_, c255.y, r1.x
/*   62   */          min r7.x___, r2.wwww, c255.yyyy
              +       subsc r2.___w, c255.y, r1.z
/*    4.1 */       exec
/*   63   */          mul r7._y__, r0.zzzz, r7.xxxx
              +       retain_prev r1._
/*   64   */          mul r7._yzw, r7.xxyy, c24.xxzy
              +       retain_prev r1._
/*   65   */          mul r7.x___, r7.yyyy, r0.zzzz
              +       retain_prev r1._
/*   66   */          mul r0.x_zw, r7.xzzw, r0.xxxx
              +       retain_prev r1._
/*   67   */          mul r0.x_zw, r0.xwwz, r2.wwww
              +       retain_prev r1._
/*   68   */          mul r7.xyz_, r0.xzww, c27.zzzz
              +       retain_prev r1._
/*    5.0 */       cjmp !b129, L22
/*    5.1 */       exec
/*   69   */          mul r13, r3.wzyx, c42.wzyx
              +       retain_prev r1._
/*   70   */          add r12.xyz_, -r2.xyzz, c29.xyzz
              +       retain_prev r1._
/*   71   */          dp3 r12.___w, r12.zxyy, r12.zxyy
              +       retain_prev r1._
/*   72   */          max4 r0.x___, r13.zxwy
              +       rsq r1.x___, r_abs[12].w
/*   73   */          mul r12, r12, r1.xxxx
              +       retain_prev r1._
/*   74   */          dp3 r2.___w, r5.xyzz, r12.zxyy
              +       retain_prev r1._
/*    6.0 */       exec
/*   75   */          dp3 r1.__z_, r12.zxyy, -c30.zxyy
              +       retain_prev r1._
/*   76   */          add r1.x___, r12.wwww, -c28.wwww
              +       retain_prev r1._
/*   77   */          add r1.__z_, r1.zzzz, -c31.xxxx
              +       mulsc_sat r0.__z_, c29.w, r1.x
/*   78   */          max r0.___w, r2.wwww, c255.xxxx
              +       mulsc r2.___w, c31.y, r1.z
/*   79   */          max r6.___w, r2.wwww, c31.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   80   */          min r12.x___, r6.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*    6.1 */       exec
/*   81   */          mul r12._y__, r0.xxxx, r12.xxxx
              +       retain_prev r1._
/*   82   */          mul r12.xy_w, r12.yyxx, c28.zyxx
              +       retain_prev r1._
/*   83   */          mul r12.__z_, r12.wwww, r0.xxxx
              +       retain_prev r1._
/*   84   */          mul r0.x_zw, r12.xyyz, r0.wwww
              +       retain_prev r1._
/*   85   */          mul r0.x_zw, r0.wzzx, r2.wwww
              +       retain_prev r1._
/*   86   */          mad r7.xyz_, r0.xzww, c31.zzzz, r7.xyzz
              +       retain_prev r1._
/*    7.0 */       cjmp !b130, L22
/*    7.1 */       exec
/*   87   */          mul r13, r3, c43
              +       retain_prev r1._
/*   88   */          add r12.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   89   */          dp3 r12.___w, r12.xzyy, r12.xzyy
              +       retain_prev r1._
/*   90   */          max4 r0.x___, r13.ywxz
              +       rsq r1.x___, r_abs[12].w
/*   91   */          mul r12, r12, r1.xxxx
              +       retain_prev r1._
/*   92   */          dp3 r2.___w, r5.xyzz, r12.xzyy
              +       retain_prev r1._
/*    8.0 */       exec
/*   93   */          dp3 r1.__z_, r12.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   94   */          add r1.x___, r12.wwww, -c32.wwww
              +       retain_prev r1._
/*   95   */          add r1.__z_, r1.zzzz, -c35.xxxx
              +       mulsc_sat r0.__z_, c33.w, r1.x
/*   96   */          max r0.___w, r2.wwww, c255.xxxx
              +       mulsc r2.___w, c35.y, r1.z
/*   97   */          max r6.___w, r2.wwww, c35.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   98   */          min r12.x___, r6.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*    8.1 */       exec
/*   99   */          mul r12._y__, r0.xxxx, r12.xxxx
              +       retain_prev r1._
/*  100   */          mul r12.xy_w, r12.yyxx, c32.zyxx
              +       retain_prev r1._
/*  101   */          mul r12.__z_, r12.wwww, r0.xxxx
              +       retain_prev r1._
/*  102   */          mul r0.x_zw, r12.xyyz, r0.wwww
              +       retain_prev r1._
/*  103   */          mul r0.x_zw, r0.wzzx, r2.wwww
              +       retain_prev r1._
/*  104   */          mad r7.xyz_, r0.xzww, c35.zzzz, r7.xyzz
              +       retain_prev r1._
/*    9.0 */       cjmp !b131, L22
/*    9.1 */       exec
/*  105   */          mul r13, r3.wzyx, c44.wzyx
              +       retain_prev r1._
/*  106   */          add r12.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*  107   */          dp3 r12.___w, r12.zxyy, r12.zxyy
              +       retain_prev r1._
/*  108   */          max4 r0.x___, r13.zxwy
              +       rsq r1.x___, r_abs[12].w
/*  109   */          mul r12, r12, r1.xxxx
              +       retain_prev r1._
/*  110   */          dp3 r2.___w, r5.xyzz, r12.zxyy
              +       retain_prev r1._
/*   10.0 */       exec
/*  111   */          dp3 r1.__z_, r12.zxyy, -c38.zxyy
              +       retain_prev r1._
/*  112   */          add r1.x___, r12.wwww, -c36.wwww
              +       retain_prev r1._
/*  113   */          add r1.__z_, r1.zzzz, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*  114   */          max r0.___w, r2.wwww, c255.xxxx
              +       mulsc r2.___w, c39.y, r1.z
/*  115   */          max r6.___w, r2.wwww, c39.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  116   */          min r12.x___, r6.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*   10.1 */       exec
/*  117   */          mul r12._y__, r0.xxxx, r12.xxxx
              +       retain_prev r1._
/*  118   */          mul r12.xy_w, r12.yyxx, c36.zyxx
              +       retain_prev r1._
/*  119   */          mul r12.__z_, r12.wwww, r0.xxxx
              +       retain_prev r1._
/*  120   */          mul r0.x_zw, r12.xyyz, r0.wwww
              +       retain_prev r1._
/*  121   */          mul r0.x_zw, r0.wzzx, r2.wwww
              +       retain_prev r1._
/*  122   */          mad r7.xyz_, r0.xzww, c39.zzzz, r7.xyzz
              +       retain_prev r1._
                label L22
/*   11.0 */       cjmp !b132, L34
/*   11.1 */       exec
/*  123   */          add r13.xyz_, -r2.zyxx, c9.zyxx
              +       retain_prev r1._
/*  124   */          dp3 r13.___w, r13.xzyy, r13.xzyy
              +       retain_prev r1._
/*  125   */          mul r12, r3.wzyx, c45.wzyx
              +       rsq r1.x___, r_abs[13].w
/*  126   */          mul r13, r13, r1.xxxx
              +       retain_prev r1._
/*  127   */          add r1.x___, r13.wwww, -c8.wwww
              +       retain_prev r1._
/*  128   */          dp3 r2.___w, r13.xzyy, r5.xyzz
              +       mulsc_sat r0.x___, c9.w, r1.x
/*   12.0 */       exec
/*  129   */          max4 r0.__z_, r12.zxwy
              +       maxs r13.x___, r2.ww
/*  130   */          add r0.x_z_, -r0.xzzz, c255.yyyy
              +       maxs r13._y__, c255.xx
/*  131   */          mul r12.xyz_, r0.xxxx, c8.zyxx
              +       maxs r2.___w, r13.xy
/*  132   */          mul r12.xyz_, r12.xyzz, r2.wwww
              +       retain_prev r1._
/*  133   */          mad r7.xyz_, r12.zyxx, r0.zzzz, r7.xyzz
              +       retain_prev r1._
/*   12.1 */       cjmp !b133, L34
/*   13.0 */       exec
/*  134   */          add r13.xyz_, -r2.xyzz, c11.xyzz
              +       retain_prev r1._
/*  135   */          dp3 r13.___w, r13.zxyy, r13.zxyy
              +       retain_prev r1._
/*  136   */          mul r12, r3, c46
              +       rsq r1.x___, r_abs[13].w
/*  137   */          mul r13, r13, r1.xxxx
              +       retain_prev r1._
/*  138   */          add r1.x___, r13.wwww, -c10.wwww
              +       retain_prev r1._
/*  139   */          dp3 r2.___w, r13.zxyy, r5.xyzz
              +       mulsc_sat r0.x___, c11.w, r1.x
/*   13.1 */       exec
/*  140   */          max4 r0.__z_, r12.ywxz
              +       maxs r13.x___, r2.ww
/*  141   */          add r0.x_z_, -r0.xzzz, c255.yyyy
              +       maxs r13._y__, c255.xx
/*  142   */          mul r12.xyz_, r0.xxxx, c10.zyxx
              +       maxs r2.___w, r13.xy
/*  143   */          mul r12.xyz_, r12.xyzz, r2.wwww
              +       retain_prev r1._
/*  144   */          mad r7.xyz_, r12.zyxx, r0.zzzz, r7.xyzz
              +       retain_prev r1._
/*   14.0 */       cjmp !b134, L34
/*   14.1 */       exec
/*  145   */          add r13.xyz_, -r2.zyxx, c13.zyxx
              +       retain_prev r1._
/*  146   */          dp3 r13.___w, r13.xzyy, r13.xzyy
              +       retain_prev r1._
/*  147   */          mul r12, r3.wzyx, c47.wzyx
              +       rsq r1.x___, r_abs[13].w
/*  148   */          mul r13, r13, r1.xxxx
              +       retain_prev r1._
/*  149   */          add r1.x___, r13.wwww, -c12.wwww
              +       retain_prev r1._
/*  150   */          dp3 r2.___w, r13.xzyy, r5.xyzz
              +       mulsc_sat r0.x___, c13.w, r1.x
/*   15.0 */       exec
/*  151   */          max4 r0.__z_, r12.zxwy
              +       maxs r13.x___, r2.ww
/*  152   */          add r0.x_z_, -r0.xzzz, c255.yyyy
              +       maxs r13._y__, c255.xx
/*  153   */          mul r12.xyz_, r0.xxxx, c12.zyxx
              +       maxs r2.___w, r13.xy
/*  154   */          mul r12.xyz_, r12.xyzz, r2.wwww
              +       retain_prev r1._
/*  155   */          mad r7.xyz_, r12.zyxx, r0.zzzz, r7.xyzz
              +       retain_prev r1._
/*   15.1 */       cjmp !b135, L34
/*   16.0 */       exec
/*  156   */          add r12.xyz_, -r2.xyzz, c15.xyzz
              +       retain_prev r1._
/*  157   */          dp3 r12.___w, r12.zxyy, r12.zxyy
              +       retain_prev r1._
/*  158   */          mul r3, r3, c48
              +       rsq r1.x___, r_abs[12].w
/*  159   */          mul r12, r12, r1.xxxx
              +       retain_prev r1._
/*  160   */          add r1.x___, r12.wwww, -c14.wwww
              +       retain_prev r1._
/*  161   */          dp3 r2.___w, r12.zxyy, r5.xyzz
              +       mulsc_sat r0.x___, c15.w, r1.x
/*   16.1 */       exec
/*  162   */          max4 r0.__z_, r3.ywxz
              +       maxs r12.x___, r2.ww
/*  163   */          add r0.x_z_, -r0.xzzz, c255.yyyy
              +       maxs r12._y__, c255.xx
/*  164   */          mul r3.xyz_, r0.xxxx, c14.zyxx
              +       maxs r2.___w, r12.xy
/*  165   */          mul r3.xyz_, r3.xyzz, r2.wwww
              +       retain_prev r1._
/*  166   */          mad r7.xyz_, r3.zyxx, r0.zzzz, r7.xyzz
              +       retain_prev r1._
                label L34
/*   17.0 */       exec
/*  167   */          mul r12, r5.xxzy, r5.yxxz
              +       retain_prev r1._
/*  168   */          dp3 r1.x___, r9.xzyy, r4.zxyy
              +       retain_prev r1._
/*  169   */          dp3 r1.__z_, r8.xzyy, r4.zxyy
              +       retain_prev r1._
/*  170   */          mul r0.x_z_, r5.yzzz, r5.yzzz
              +       retain_prev r1._
/*  171   */          dp3 r1._y__, r11.xzyy, r4.zxyy
              +       subs r2.___w, r0.xz
/*  172   */          dp4 r0.x___, r12.xywz, c19.wzxy
              +       addsc r3.x___, c16.w, r1.y
/*   17.1 */       exec    // PredicateClean=false
/*  173   */          dp4 r0.__z_, r12.xywz, c21.wzxy
              +       addsc r3._y__, c18.w, r1.z
/*  174   */          dp4 r0.___w, r12.xywz, c20.wzxy
              +       addsc r3.__z_, c17.w, r1.x
/*  175   */          add r1.xyz_, r3.zxyy, r0.wxzz
              +       setp_gt r1._, c_abs[57].x
/*  176   */          mad r1.xyz_, r2.wwww, c22.xzyy, r1.yzxx
              +       retain_prev r1._
/*  177   */          mad r0.x_zw, r7.zyyx, r1.wwww, r1.yzzx
              +       retain_prev r1._
/*   18.0 */  (p0) exec
/*  178   */     (p0) mul r3.xyz_, r0.xzww, c60.xxxx
              +  (p0) retain_prev r1._
/*  179   */     (p0) mul r1.xyz_, r0.xzww, c61.xxxx
              +  (p0) retain_prev r1._
/*  180   */     (p0) mul r1.xyz_, r1.xyzz, c59.xxxx
              +  (p0) retain_prev r1._
/*  181   */     (p0) mad r0.x_zw, r3.xyyz, c58.xxxx, r1.xyyz
              +  (p0) retain_prev r1._
/*   18.1 */       exec
/*  182   */          mul r0, r10.zyxw, r0.wzxy
              +       retain_prev r1._
/*   19.0 */       cjmp !b136, L42
/*   19.1 */       exec
/*  183   */          mad r1.___w, r4.wwww, c54.yyyy, c54.zzzz
              +       retain_prev r1._
/*  184   */          add r1.x___, r4.wwww, -c51.xxxx
              +       rsq r1._y__, r_abs[5].w
/*  185   */          mul r3.xyz_, r6.xyzz, r1.yyyy
              +       retain_prev r1._
/*  186   */          cndeq r2, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  187   */          dp4 r1._y__, c52.zxyw, r2
              +       retain_prev r1._
/*  188   */          dp3 r1.__z_, r3.xzyy, c52.zxyy
              +       retain_prev r1._
/*   20.0 */       exec
/*  189   */          add r2.xyz_, -r0.xyzz, c53.xyzz
              +       mulsc r2.___w, c51.z, r1.x
/*  190   */          min r3.xy__, r1.yzzz, c255.xzzz
              +       mulsc r1.x___, c51.w, r1.y
/*  191   */          max r1.__z_, r2.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  192   */          max r1._, r1, r1
              +       mulsc r1.x___, c54.x, r1.y
/*  193   */          mad r1.x___, r1.xxxx, r3.xxxx, r1.wwww
              +       retain_prev r1._
/*  194   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*   20.1 */       exec
/*  195   */          min r1.x___, r1.xxxx, c53.wwww
              +       retain_prev r1._
/*  196   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*  197   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L42
/*   21.0 */       exece
/*  198   */          mul r0.xyz_, r0.zyxx, c3.xxxx
              +       retain_prev r1._
/*  199   */          max oC0, r0.zyxw, r0.zyxw
/*   21.1 */       cnop
