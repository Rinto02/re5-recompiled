/*    0.0 */       exec
/*    5   */          dp3 r0.___w, r0.zxyy, r0.zxyy
/*    6   */          sgt r1, -r_abs[0].xxxx, c254.yyyy
              +       rsq r2.___w, r_abs[0].w
/*    7   */          mul r3.xyz_, r2.wwww, c0.zxyy
/*    8   */          mul r2.xyz_, r3.zxyy, r0.zxyy
/*    9   */          mad r2.xyz_, r3.xyzz, r0.yzxx, -r2.xyzz
/*   10   */          dp3 r0.___w, r2.zxyy, r2.zxyy
/*    0.1 */       exec
/*   11   */          mul r3.xyz_, r2.wwww, r0.xyzz
              +       rsq r0.x___, r_abs[0].w
/*   12   */          mul r4.xyz_, r2.xyzz, r0.xxxx
/*   13   */          mul r0.xyz_, r4.xyzz, c254.xxxx
              +       maxs r2.___w, c3.xx
/*   14   */          mad r0.xyz_, -r0.xyzz, c1.xxxx, r3.xyzz
/*    1.0 */       loop i31, L7
                label L3
/*    1.1 */       exec
/*   15   */          maxs r2._y__, r0.yy
/*   16   */          max r2.__z_, r0.zzzz, r0.zzzz
              +       maxs r2.x___, r0.xx
/*   17   */          cube r0, r2.zzxy, r2.yxzz
/*   18   */          max r5.__z_, r0.wwww, r0.wwww
              +       rcp r3.___w, r_abs[0].z
/*   19   */          mad r5.xy__, r0.yxxx, r3.wwww, c254.zzzz
/*   20   */          setTexLOD r2.w
/*    2.0 */       exec
/*   21   */          tfetchCube r5, r5.xyz, tf0, UseComputedLOD=false, UseRegisterLOD=true
/*   22   */          serialize
                      mad r0.xyz_, r4.xyzz, c1.xxxx, r2.xyzz
/*   23   */          dp3 r0.___w, r2.zxyy, r2.zxyy
/*   24   */          rsq r0.___w, r_abs[0].w
/*   25   */          mul r2.xyz_, r0.wwww, r2.zyxx
/*   26   */          dp3 r0.___w, r2.xzyy, r3.zxyy
/*    2.1 */       exec
/*   27   */          max r2.x___, r5.wwww, c254.wwww
              +       log r0.___w, r_abs[0].w
/*   28   */          mul r0.___w, r0.wwww, c2.xxxx
              +       rcp r2.x___, r2.x
/*   29   */          mul r2.xyz_, r2.xxxx, r5.xyzz
              +       exp r5.___w, r0.w
/*   30   */          mul r5.xyz_, r2.zyxx, r5.wwww
/*   31   */          add r1, r5.zxyw, r1
/*    3.0 */       endloop i31, L3
                label L7
/*    3.1 */       alloc colors
/*    4.0 */       exec
/*   32   */          rcp r0.x___, r1.w
/*   33   */          mul r0.xyz_, r1.xyzz, r0.xxxx
/*   34   */          max r0.___w, r0.zzzz, c255.xxxx
              +       maxs r1.x___, r0.xy
/*   35   */          max r0.___w, r1.xxxx, r0.wwww
/*   36   */          rcp r0.___w, r0.w
/*   37   */          mul r0.xyz_, r0.xzyy, r0.wwww
/*    4.1 */       exece
/*   38   */          max oC0, r0, r0
