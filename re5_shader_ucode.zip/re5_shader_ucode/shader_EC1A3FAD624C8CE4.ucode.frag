/*    0.0 */       exec    // PredicateClean=false
/*    8   */          sgt r2._y__, c1.xxxx, r0.wwww
              +       sgts r2.x___, -r_abs[0].x
/*    9   */          setp_ne_push r8.x___, c255.yyyy, r2.yyyy
              +       sgts r2._y__, -r_abs[0].x
/*    0.1 */ (!p0) jmp L13
/*    1.0 */       exec    // PredicateClean=false
/*   10   */     (p0) dp3 r2.x___, r0.zxyy, r0.zxyy
/*   11   */     (p0) rsq r2.x___, r_abs[2].x
/*   12   */     (p0) mul r2.x_zw, r2.xxxx, -c23.xyyz
/*   13   */     (p0) dp3 r2.x___, r2.wxzz, r0.zxyy
/*   14   */          setp_gt_push r8.x___, r8.xxxx, r2.xxxx
/*    1.1 */ (!p0) jmp L12
/*    2.0 */  (p0) exec
/*   15   */     (p0) rcp r0.x___, r1.w
/*   16   */     (p0) mul r2.xyz_, r0.xxxx, r1.yzxx
/*   17   */     (p0) tfetch2D r9.x___, r2.zx, tf0, OffsetX=-2, OffsetY=1
/*   18   */     (p0) tfetch2D r9.___x, r2.zx, tf0, OffsetX=1, OffsetY=1
/*   19   */     (p0) tfetch2D r9.__x_, r2.zx, tf0, OffsetY=1
/*   20   */     (p0) tfetch2D r9._x__, r2.zx, tf0, OffsetX=-1, OffsetY=1
/*    2.1 */  (p0) exec
/*   21   */     (p0) tfetch2D r10.x___, r2.zx, tf0, OffsetX=-2
/*   22   */     (p0) tfetch2D r10.___x, r2.zx, tf0, OffsetX=1
/*   23   */     (p0) tfetch2D r10.__x_, r2.zx, tf0
/*   24   */     (p0) tfetch2D r10._x__, r2.zx, tf0, OffsetX=-1
/*   25   */     (p0) tfetch2D r5.x___, r2.zx, tf0, OffsetX=-2, OffsetY=-1
/*   26   */     (p0) tfetch2D r5.___x, r2.zx, tf0, OffsetX=1, OffsetY=-1
/*    3.0 */  (p0) exec
/*   27   */     (p0) tfetch2D r5.__x_, r2.zx, tf0, OffsetY=-1
/*   28   */     (p0) tfetch2D r5._x__, r2.zx, tf0, OffsetX=-1, OffsetY=-1
/*   29   */     (p0) tfetch2D r6.x___, r2.zx, tf0, OffsetX=-2, OffsetY=-2
/*   30   */     (p0) tfetch2D r6.___x, r2.zx, tf0, OffsetX=1, OffsetY=-2
/*   31   */     (p0) tfetch2D r6.__x_, r2.zx, tf0, OffsetY=-2
/*   32   */     (p0) tfetch2D r6._x__, r2.zx, tf0, OffsetX=-1, OffsetY=-2
/*    3.1 */       exec    // PredicateClean=false
/*   33   */          serialize
                 (p0) subsc r0._y__, c255.x, r2.y
/*   34   */     (p0) sge r3, r6, r0.yyyy
/*   35   */     (p0) sge r4, r5, r0.yyyy
/*   36   */     (p0) sge r2, r10, r0.yyyy
/*   37   */     (p0) sge r7, r9, r0.yyyy
              +  (p0) mulsc r0.x___, c0.y, r0.x
/*   38   */          setp_gt_push r8.x___, r8.xxxx, c3.xxxx
/*    4.0 */  (p0) exec
/*   39   */     (p0) add r7, -r0.yyyy, r9
/*   40   */     (p0) add r2, -r0.yyyy, r10
/*   41   */     (p0) add r4, -r0.yyyy, r5
/*   42   */     (p0) add r3, -r0.yyyy, r6
/*   43   */     (p0) mul_sat r3, r3, c3.xxxx
/*   44   */     (p0) mul_sat r4, r4, c3.xxxx
/*    4.1 */       exec    // PredicateClean=false
/*   45   */     (p0) mul_sat r2, r2, c3.xxxx
/*   46   */     (p0) mul_sat r7, r7, c3.xxxx
/*   47   */          setp_pop r8.x___, r8.x
/*   48   */     (p0) mad_sat r5.__z_, r0.wwww, c2.xxxx, c2.yyyy
/*   49   */     (p0) mul r0.xy__, r0.xxxx, r1.xyyy
/*   50   */     (p0) add r1, r2, r4
/*    5.0 */  (p0) exec
/*   51   */     (p0) frc r5.xy__, r0.yxxx
/*   52   */     (p0) add r0.xy__, -r5.xzzz, c255.xxxx
/*   53   */     (p0) mad r1, r0.xxxx, r3, r1
/*   54   */     (p0) mad r1, r5.xxxx, r7, r1
/*   55   */     (p0) dp3 r0.__z_, r1.zxyy, c255.xxxx
              +  (p0) subs r0.___w, r1.wx
/*   56   */     (p0) mad r0.x___, r0.wwww, r5.yyyy, r0.zzzz
/*    5.1 */  (p0) exec
/*   57   */     (p0) mulsc r0.__z_, c255.z, r0.x
/*   58   */     (p0) mul r2._y__, r0.zzzz, r0.yyyy
                label L12
/*    6.0 */       exec    // PredicateClean=false
/*   59   */          setp_pop r8.x___, r8.x
/*   60   */     (p0) maxs r2.x___, r2.yy
                label L13
/*    6.1 */       alloc colors
/*    7.0 */       exece
/*   61   */          mul oC0, r2.xxxx, c4.xxxx
/*    7.1 */       cnop
