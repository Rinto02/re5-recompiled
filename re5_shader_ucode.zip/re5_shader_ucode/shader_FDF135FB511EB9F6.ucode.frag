/*    0.0 */       exec
/*    2   */          max r1, r1, c0.xyxy
/*    3   */          max r0, r0, c0.xyxy
/*    4   */          min r2, r0, c1.xyxy
/*    5   */          min r1, r1, c1.xyxy
/*    6   */          tfetch2D r0, r1.zw, tf0
/*    7   */          tfetch2D r1, r1.xy, tf0
/*    0.1 */       exec
/*    8   */          tfetch2D r3, r2.xy, tf0
/*    9   */          tfetch2D r2, r2.zw, tf0
/*    1.0 */       alloc colors
/*    1.1 */       exece
/*   10   */          add r2, r3, r2
/*   11   */          add r1, r2, r1
/*   12   */          add r0, r1, r0
/*   13   */          mul oC0, r0, c255.xxxx
