/*    0.0 */       exec
/*    3   */          vfetch_full r1.xy01, r0.x, vf0, DataFormat=FMT_32_32_FLOAT, Stride=5, Signed=true, NumFormat=integer, PrefetchCount=5
/*    4   */          vfetch_mini r0.xyz_, Offset=2, DataFormat=FMT_32_32_32_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    5   */          max oPos, r1, r1
/*    1.1 */       alloc interpolators
/*    2.0 */       exece
/*    6   */          max o0.xyz_, r0.xyzz, r0.xyzz
/*    2.1 */       cnop
