/*    0.0 */       exec
/*   31   */          tfetch2D r5, r1.xy, tf0
/*   32   */          serialize
                      max r1._, r1, r1
              +       rcp r2.___w, r0.w
/*   33   */          mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r5.ww
/*   34   */          mad r0.xy__, r2.wwww, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   35   */          mul r0.xy__, r3.zwww, r0.yxxx
              +       subsc r2.___w, -c1.x, -r1.y
/*   36   */          kill_gt r1._, c255.xxxx, r2.wwww
              +       retain_prev r1._
/*    0.1 */       exec
/*   37   */          tfetch2D r8.xyz_, r3.xy, tf5
/*   38   */          tfetch2D r0, r0.xy, tf7
/*   39   */          serialize
                      sgt r10.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       maxs r3.___w, c15.xx
/*   40   */          add r3.xyz_, r2.xyzz, -c23.xyzz
              +       sgts r15._y__, -r_abs[1].x
/*   41   */          dp3 r2.___w, r4.zxyy, r4.zxyy
              +       sgts r15.__z_, -r_abs[1].x
/*   42   */          mul r13.xyz_, r5.xyzz, c13.xyzz
              +       sgts r15.x___, -r_abs[1].x
/*    1.0 */       exec
/*   43   */          mul r7, r0.wzyx, c5.wzyx
              +       rsq r2.___w, r_abs[2].w
/*   44   */          dp3 r0.x___, r3.zxyy, r3.zxyy
              +       mulsc r5.__z_, c16.x, r2.w
/*   45   */          mul r14.xyz_, r2.wwww, c18.xyzz
              +       mulsc r5._y__, c16.y, r2.w
/*   46   */          mul r6.xyz_, r2.wwww, r4.zyxx
              +       mulsc r5.x___, c16.z, r2.w
/*   47   */          min r7, r7, c7.xxxx
              +       rsq r0._y__, r_abs[0].x
/*   48   */          mul r12.xyz_, r3.zyxx, r0.yyyy
              +       mulsc r11.__z_, c17.z, r2.w
/*    1.1 */       exec
/*   49   */          max r7, r7.wzyx, c8.xxxx
              +       mulsc r11._y__, c17.y, r2.w
/*   50   */          max r0._yz_, r7.yyxx, r7.wwzz
              +       mulsc r11.x___, c17.x, r2.w
/*   51   */          max r3.__z_, r0.zzzz, r0.yyyy
              +       sqrt r3._y__, r_abs[0].x
/*    2.0 */       cjmp !b128, L36
/*    2.1 */       exec
/*   52   */          sgt r0.__z_, c62.zzzz, c255.wwww
              +       retain_prev r1._
/*   53   */          add r9.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   54   */          mul r10, r7.wzyx, c48.wzyx
              +       retain_prev r1._
/*   55   */          dp3 r0.x___, r9.xzyy, r9.xzyy
              +       retain_prev r1._
/*   56   */          max4 r1.x___, r10.zxwy
              +       retain_prev r1._
/*   57   */          add r1._y__, -r1.xxxx, c255.yyyy
              +       rsq r1.x___, r_abs[0].x
/*    3.0 */       exec
/*   58   */          mul r9.xy_w, r9.xyzz, r1.xxxx
              +       retain_prev r1._
/*   59   */          dp3 r9.__z_, r6.xzyy, r9.xwyy
              +       retain_prev r1._
/*   60   */          dp3 r0._y__, r9.xwyy, -c34.zxyy
              +       retain_prev r1._
/*   61   */          add r9.xy_w, r9.wyxx, -r12.zyxx
              +       retain_prev r1._
/*   62   */          dp3 r2.___w, r9.wxyy, r9.wxyy
              +       maxs r1._, r0.xx
/*   63   */          add r0.x___, r0.yyyy, -c35.xxxx
              +       muls_prev r1.x___, r1.x
/*    3.1 */       exec
/*   64   */          mul r0.___w, r0.xxxx, c35.yyyy
              +       subsc r0.x___, -c32.w, -r1.x
/*   65   */          max r0.___w, r0.wwww, c35.wwww
              +       rsq r2.___w, r_abs[2].w
/*   66   */          mul r10.xyz_, r9.wyxx, r2.wwww
              +       mulsc_sat r2.___w, c33.w, r0.x
/*   67   */          min r9.x___, r0.wwww, c255.yyyy
              +       subsc r3.x___, c255.y, r2.w
/*   68   */          dp3 r9._y__, r6.xzyy, r10.xzyy
              +       maxs r1._, r3.xx
/*   69   */          max r0.x__w, r9.yzzz, c255.xxxx
              +       muls_prev r9._y__, r9.x
/*    4.0 */       exec    // PredicateClean=false
/*   70   */          mul r10.xyz_, r9.xyyy, c32.xzyy
              +       log r2.___w, r_abs[0].x
/*   71   */          mul r10.___w, r10.xxxx, r3.xxxx
              +       mulsc r2.___w, c14.z, r2.w
/*   72   */          mul r9.xyz_, r10.yzww, r0.wwww
              +       exp r2.___w, r2.w
/*   73   */          mul r10.xyz_, r10.wzyy, r2.wwww
              +       setp_ne r1._, r0.z
/*    4.1 */  (p0) exec
/*   74   */     (p0) max r1._, r1, r1
              +  (p0) maxs r15.___w, c255.yy
/*   75   */     (p0) mul r0.x_zw, r1.xxxx, c34.xyyz
              +  (p0) rcp r2.___w, c62.z
/*   76   */     (p0) mad r0.xyz_, r0.xzww, r0.yyyy, c33.xyzz
              +  (p0) retain_prev r1._
/*   77   */     (p0) add r15.xyz_, -r0.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*   78   */     (p0) dp4 r0.x___, c66.zxyw, r15.zxyw
              +  (p0) muls_prev r1.x___, r2.w
/*   79   */     (p0) dp4 r0._y__, c67.zxyw, r15.zxyw
              +  (p0) mulsc r2.___w, c62.w, r1.x
/*    5.0 */  (p0) exec
/*   80   */     (p0) mul r0.xy__, r0.xyyy, c254.xxxx
              +  (p0) rcp r2.___w, r2.w
/*   81   */     (p0) mul r0.xy__, r0.xyyy, r2.wwww
              +  (p0) retain_prev r1._
/*   82   */     (p0) add r0.__z_, r0.xxxx, c254.xxxx
              +  (p0) subsc r0.___w, c254.x, r0.y
/*   83   */     (p0) tfetch2D r0.xyz_, r0.zw, tf1
/*   84   */          serialize
                 (p0) mul r9.xyz_, r9.xyzz, r0.zyxx
              +  (p0) retain_prev r1._
/*   85   */     (p0) mul r10.xyz_, r10.xyzz, r0.xyzz
              +  (p0) retain_prev r1._
/*    5.1 */       exec
/*   86   */          max r1._, r1, r1
              +       mulsc r2.___w, c35.z, r1.y
/*   87   */          mul r15.xyz_, r2.wwww, r9.zxyy
              +       retain_prev r1._
/*   88   */          mul r10.xyz_, r1.yyyy, r10.zyxx
              +       retain_prev r1._
/*    6.0 */       cjmp !b129, L36
/*    6.1 */       exec
/*   89   */          sgt r4.___w, c63.zzzz, c255.wwww
              +       retain_prev r1._
/*   90   */          add r0._yzw, -r2.xxyz, c37.xxyz
              +       retain_prev r1._
/*   91   */          mul r9, r7, c49
              +       retain_prev r1._
/*   92   */          dp3 r1._y__, r0.wyzz, r0.wyzz
              +       retain_prev r1._
/*   93   */          max4 r1.x___, r9.ywxz
              +       retain_prev r1._
/*   94   */          add r0.x___, -r1.xxxx, c255.yyyy
              +       rsq r1.x___, r_abs[1].y
/*    7.0 */       exec
/*   95   */          mul r9.xyz_, r0.yzww, r1.xxxx
              +       retain_prev r1._
/*   96   */          dp3 r0.__z_, r6.xzyy, r9.zxyy
              +       retain_prev r1._
/*   97   */          dp3 r3.x___, r9.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   98   */          add r9.xyz_, r9.xyzz, -r12.zyxx
              +       retain_prev r1._
/*   99   */          dp3 r2.___w, r9.zxyy, r9.zxyy
              +       maxs r1._, r1.yy
/*  100   */          add r1._y__, r3.xxxx, -c39.xxxx
              +       muls_prev r1.x___, r1.x
/*    7.1 */       exec
/*  101   */          mul r0._y__, r1.yyyy, c39.yyyy
              +       subsc r1._y__, -c36.w, -r1.x
/*  102   */          max r0._y__, r0.yyyy, c39.wwww
              +       rsq r2.___w, r_abs[2].w
/*  103   */          mul r9._yzw, r9.xxyz, r2.wwww
              +       mulsc_sat r2.___w, c37.w, r1.y
/*  104   */          min r9.x___, r0.yyyy, c255.yyyy
              +       subsc r2.___w, c255.y, r2.w
/*  105   */          dp3 r0._y__, r6.xzyy, r9.wyzz
              +       maxs r1._, r2.ww
/*  106   */          max r0._yz_, r0.yyzz, c255.xxxx
              +       muls_prev r9._y__, r9.x
/*    8.0 */       exec    // PredicateClean=false
/*  107   */          mul r16.xyz_, r9.xyyy, c36.xzyy
              +       log r1._y__, r_abs[0].y
/*  108   */          mul r16.___w, r16.xxxx, r2.wwww
              +       mulsc r2.___w, c14.z, r1.y
/*  109   */          mul r9.xyz_, r16.yzww, r0.zzzz
              +       exp r2.___w, r2.w
/*  110   */          mul r0._yzw, r16.wwzy, r2.wwww
              +       setp_ne r1._, r4.w
/*    8.1 */  (p0) exec
/*  111   */     (p0) max r1._, r1, r1
              +  (p0) maxs r17.___w, c255.yy
/*  112   */     (p0) mul r16.xyz_, r1.xxxx, c38.xyzz
              +  (p0) rcp r1._y__, c63.z
/*  113   */     (p0) mad r16.xyz_, r16.xyzz, r3.xxxx, c37.xyzz
              +  (p0) retain_prev r1._
/*  114   */     (p0) add r17.xyz_, -r16.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  115   */     (p0) dp4 r16.x___, c68.zxyw, r17.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  116   */     (p0) dp4 r16._y__, c69.zxyw, r17.zxyw
              +  (p0) mulsc r1.x___, c63.w, r1.x
/*    9.0 */  (p0) exec
/*  117   */     (p0) mul r16.xy__, r16.xyyy, c254.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  118   */     (p0) mul r1.xy__, r16.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*  119   */     (p0) add r16.x___, r1.xxxx, c254.xxxx
              +  (p0) subsc r16._y__, c254.x, r1.y
/*  120   */     (p0) tfetch2D r16.xyz_, r16.xy, tf2
/*  121   */          serialize
                 (p0) mul r9.xyz_, r9.xyzz, r16.zyxx
              +  (p0) retain_prev r1._
/*  122   */     (p0) mul r0._yzw, r0.yyzw, r16.xxyz
              +  (p0) retain_prev r1._
/*    9.1 */       exec
/*  123   */          max r1._, r1, r1
              +       mulsc r2.___w, c39.z, r0.x
/*  124   */          mad r15.xyz_, r2.wwww, r9.zxyy, r15.xyzz
              +       retain_prev r1._
/*  125   */          mad r10.xyz_, r0.xxxx, r0.wzyy, r10.xyzz
              +       retain_prev r1._
/*   10.0 */       cjmp !b130, L36
/*   10.1 */       exec
/*  126   */          sgt r4.___w, c64.zzzz, c255.wwww
              +       retain_prev r1._
/*  127   */          add r0._yzw, -r2.xxyz, c41.xxyz
              +       retain_prev r1._
/*  128   */          mul r9, r7, c50
              +       retain_prev r1._
/*  129   */          dp3 r1._y__, r0.wyzz, r0.wyzz
              +       retain_prev r1._
/*  130   */          max4 r1.x___, r9.ywxz
              +       retain_prev r1._
/*  131   */          add r0.x___, -r1.xxxx, c255.yyyy
              +       rsq r1.x___, r_abs[1].y
/*   11.0 */       exec
/*  132   */          mul r9.xyz_, r0.yzww, r1.xxxx
              +       retain_prev r1._
/*  133   */          dp3 r0.__z_, r6.xzyy, r9.zxyy
              +       retain_prev r1._
/*  134   */          dp3 r3.x___, r9.zxyy, -c42.zxyy
              +       retain_prev r1._
/*  135   */          add r9.xyz_, r9.xyzz, -r12.zyxx
              +       retain_prev r1._
/*  136   */          dp3 r2.___w, r9.zxyy, r9.zxyy
              +       maxs r1._, r1.yy
/*  137   */          add r1._y__, r3.xxxx, -c43.xxxx
              +       muls_prev r1.x___, r1.x
/*   11.1 */       exec
/*  138   */          mul r0._y__, r1.yyyy, c43.yyyy
              +       subsc r1._y__, -c40.w, -r1.x
/*  139   */          max r0._y__, r0.yyyy, c43.wwww
              +       rsq r2.___w, r_abs[2].w
/*  140   */          mul r9._yzw, r9.xxyz, r2.wwww
              +       mulsc_sat r2.___w, c41.w, r1.y
/*  141   */          min r9.x___, r0.yyyy, c255.yyyy
              +       subsc r2.___w, c255.y, r2.w
/*  142   */          dp3 r0._y__, r6.xzyy, r9.wyzz
              +       maxs r1._, r2.ww
/*  143   */          max r0._yz_, r0.yyzz, c255.xxxx
              +       muls_prev r9._y__, r9.x
/*   12.0 */       exec    // PredicateClean=false
/*  144   */          mul r16.xyz_, r9.xyyy, c40.xzyy
              +       log r1._y__, r_abs[0].y
/*  145   */          mul r16.___w, r16.xxxx, r2.wwww
              +       mulsc r2.___w, c14.z, r1.y
/*  146   */          mul r9.xyz_, r16.yzww, r0.zzzz
              +       exp r2.___w, r2.w
/*  147   */          mul r0._yzw, r16.wwzy, r2.wwww
              +       setp_ne r1._, r4.w
/*   12.1 */  (p0) exec
/*  148   */     (p0) max r1._, r1, r1
              +  (p0) maxs r17.___w, c255.yy
/*  149   */     (p0) mul r16.xyz_, r1.xxxx, c42.xyzz
              +  (p0) rcp r1._y__, c64.z
/*  150   */     (p0) mad r16.xyz_, r16.xyzz, r3.xxxx, c41.xyzz
              +  (p0) retain_prev r1._
/*  151   */     (p0) add r17.xyz_, -r16.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  152   */     (p0) dp4 r16.x___, c70.zxyw, r17.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  153   */     (p0) dp4 r16._y__, c71.zxyw, r17.zxyw
              +  (p0) mulsc r1.x___, c64.w, r1.x
/*   13.0 */  (p0) exec
/*  154   */     (p0) mul r16.xy__, r16.xyyy, c254.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  155   */     (p0) mul r1.xy__, r16.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*  156   */     (p0) add r16.x___, r1.xxxx, c254.xxxx
              +  (p0) subsc r16._y__, c254.x, r1.y
/*  157   */     (p0) tfetch2D r16.xyz_, r16.xy, tf3
/*  158   */          serialize
                 (p0) mul r9.xyz_, r9.xyzz, r16.zyxx
              +  (p0) retain_prev r1._
/*  159   */     (p0) mul r0._yzw, r0.yyzw, r16.xxyz
              +  (p0) retain_prev r1._
/*   13.1 */       exec
/*  160   */          max r1._, r1, r1
              +       mulsc r2.___w, c43.z, r0.x
/*  161   */          mad r15.xyz_, r2.wwww, r9.zxyy, r15.xyzz
              +       retain_prev r1._
/*  162   */          mad r10.xyz_, r0.xxxx, r0.wzyy, r10.xyzz
              +       retain_prev r1._
/*   14.0 */       cjmp !b131, L36
/*   14.1 */       exec
/*  163   */          sgt r4.___w, c65.zzzz, c255.wwww
              +       retain_prev r1._
/*  164   */          add r0._yzw, -r2.xxyz, c45.xxyz
              +       retain_prev r1._
/*  165   */          mul r9, r7, c51
              +       retain_prev r1._
/*  166   */          dp3 r1._y__, r0.wyzz, r0.wyzz
              +       retain_prev r1._
/*  167   */          max4 r1.x___, r9.ywxz
              +       retain_prev r1._
/*  168   */          add r0.x___, -r1.xxxx, c255.yyyy
              +       rsq r1.x___, r_abs[1].y
/*   15.0 */       exec
/*  169   */          mul r9.xyz_, r0.yzww, r1.xxxx
              +       retain_prev r1._
/*  170   */          dp3 r0.__z_, r6.xzyy, r9.zxyy
              +       retain_prev r1._
/*  171   */          dp3 r3.x___, r9.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  172   */          add r9.xyz_, r9.xyzz, -r12.zyxx
              +       retain_prev r1._
/*  173   */          dp3 r2.___w, r9.zxyy, r9.zxyy
              +       maxs r1._, r1.yy
/*  174   */          add r1._y__, r3.xxxx, -c47.xxxx
              +       muls_prev r1.x___, r1.x
/*   15.1 */       exec
/*  175   */          mul r0._y__, r1.yyyy, c47.yyyy
              +       subsc r1._y__, -c44.w, -r1.x
/*  176   */          max r0._y__, r0.yyyy, c47.wwww
              +       rsq r2.___w, r_abs[2].w
/*  177   */          mul r9._yzw, r9.xxyz, r2.wwww
              +       mulsc_sat r2.___w, c45.w, r1.y
/*  178   */          min r9.x___, r0.yyyy, c255.yyyy
              +       subsc r2.___w, c255.y, r2.w
/*  179   */          dp3 r0._y__, r6.xzyy, r9.wyzz
              +       maxs r1._, r2.ww
/*  180   */          max r0._yz_, r0.yyzz, c255.xxxx
              +       muls_prev r9._y__, r9.x
/*   16.0 */       exec    // PredicateClean=false
/*  181   */          mul r16.xyz_, r9.xyyy, c44.xzyy
              +       log r1._y__, r_abs[0].y
/*  182   */          mul r16.___w, r16.xxxx, r2.wwww
              +       mulsc r2.___w, c14.z, r1.y
/*  183   */          mul r9.xyz_, r16.yzww, r0.zzzz
              +       exp r2.___w, r2.w
/*  184   */          mul r0._yzw, r16.wwzy, r2.wwww
              +       setp_ne r1._, r4.w
/*   16.1 */  (p0) exec
/*  185   */     (p0) max r1._, r1, r1
              +  (p0) maxs r17.___w, c255.yy
/*  186   */     (p0) mul r16.xyz_, r1.xxxx, c46.xyzz
              +  (p0) rcp r1._y__, c65.z
/*  187   */     (p0) mad r16.xyz_, r16.xyzz, r3.xxxx, c45.xyzz
              +  (p0) retain_prev r1._
/*  188   */     (p0) add r17.xyz_, -r16.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  189   */     (p0) dp4 r16.x___, c72.zxyw, r17.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  190   */     (p0) dp4 r16._y__, c73.zxyw, r17.zxyw
              +  (p0) mulsc r1.x___, c65.w, r1.x
/*   17.0 */  (p0) exec
/*  191   */     (p0) mul r16.xy__, r16.xyyy, c254.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  192   */     (p0) mul r1.xy__, r16.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*  193   */     (p0) add r16.x___, r1.xxxx, c254.xxxx
              +  (p0) subsc r16._y__, c254.x, r1.y
/*  194   */     (p0) tfetch2D r16.xyz_, r16.xy, tf4
/*  195   */          serialize
                 (p0) mul r9.xyz_, r9.xyzz, r16.zyxx
              +  (p0) retain_prev r1._
/*  196   */     (p0) mul r0._yzw, r0.yyzw, r16.xxyz
              +  (p0) retain_prev r1._
/*   17.1 */       exec
/*  197   */          max r1._, r1, r1
              +       mulsc r2.___w, c47.z, r0.x
/*  198   */          mad r15.xyz_, r2.wwww, r9.zxyy, r15.xyzz
              +       retain_prev r1._
/*  199   */          mad r10.xyz_, r0.xxxx, r0.wzyy, r10.xyzz
              +       retain_prev r1._
                label L36
/*   18.0 */       cjmp !b132, L48
/*   18.1 */       exec
/*  200   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  201   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  202   */          mul r9, r7.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  203   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  204   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  205   */          dp3 r2.___w, r0.xzyy, r6.xzyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   19.0 */       exec
/*  206   */          max4 r0._y__, r9.zxwy
              +       maxs r0.__z_, r2.ww
/*  207   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  208   */          mul r9.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  209   */          mul r9.xyz_, r9.xyzz, r2.wwww
              +       retain_prev r1._
/*  210   */          mad r15.xyz_, r9.zxyy, r0.yyyy, r15.xyzz
              +       retain_prev r1._
/*   19.1 */       cjmp !b133, L48
/*   20.0 */       exec
/*  211   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  212   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  213   */          mul r9, r7, c53
              +       rsq r1.x___, r_abs[0].w
/*  214   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  215   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  216   */          dp3 r2.___w, r0.zxyy, r6.xzyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   20.1 */       exec
/*  217   */          max4 r0._y__, r9.ywxz
              +       maxs r0.__z_, r2.ww
/*  218   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  219   */          mul r9.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  220   */          mul r9.xyz_, r9.xyzz, r2.wwww
              +       retain_prev r1._
/*  221   */          mad r15.xyz_, r9.zxyy, r0.yyyy, r15.xyzz
              +       retain_prev r1._
/*   21.0 */       cjmp !b134, L48
/*   21.1 */       exec
/*  222   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  223   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  224   */          mul r9, r7.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  225   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  226   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  227   */          dp3 r2.___w, r0.xzyy, r6.xzyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   22.0 */       exec
/*  228   */          max4 r0._y__, r9.zxwy
              +       maxs r0.__z_, r2.ww
/*  229   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  230   */          mul r9.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  231   */          mul r9.xyz_, r9.xyzz, r2.wwww
              +       retain_prev r1._
/*  232   */          mad r15.xyz_, r9.zxyy, r0.yyyy, r15.xyzz
              +       retain_prev r1._
/*   22.1 */       cjmp !b135, L48
/*   23.0 */       exec
/*  233   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  234   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  235   */          mul r7, r7, c55
              +       rsq r1.x___, r_abs[0].w
/*  236   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  237   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  238   */          dp3 r2.___w, r0.zxyy, r6.xzyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   23.1 */       exec
/*  239   */          max4 r0._y__, r7.ywxz
              +       maxs r0.__z_, r2.ww
/*  240   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  241   */          mul r7.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  242   */          mul r7.xyz_, r7.xyzz, r2.wwww
              +       retain_prev r1._
/*  243   */          mad r15.xyz_, r7.zxyy, r0.yyyy, r15.xyzz
              +       retain_prev r1._
                label L48
/*   24.0 */       exec
/*  244   */          mul r7, r6.zyxx, r6.yxxz
              +       retain_prev r1._
/*  245   */          dp3 r1.x___, r14.zxyy, r4.zxyy
              +       retain_prev r1._
/*  246   */          dp3 r0.x___, r11.zxyy, r4.zxyy
              +       retain_prev r1._
/*  247   */          mul r0._yz_, r6.zzyy, r6.zzyy
              +       retain_prev r1._
/*  248   */          dp3 r1._y__, r5.xzyy, r4.zxyy
              +       subs r2.___w, r0.yz
/*  249   */          dp4 r0._y__, r7.wzxy, c19.wzxy
              +       addsc r4.x___, c16.w, r1.y
/*   24.1 */       exec    // PredicateClean=false
/*  250   */          dp4 r0.__z_, r7.wzxy, c20.wzxy
              +       addsc r4._y__, c17.w, r0.x
/*  251   */          dp4 r0.___w, r7.wzxy, c21.wzxy
              +       addsc r4.__z_, c18.w, r1.x
/*  252   */          add r0.xyz_, r4.zxyy, r0.wyzz
              +       setp_gt r1._, c_abs[56].x
/*  253   */          mad r0.xyz_, r2.wwww, c22.xyzz, r0.yzxx
              +       retain_prev r1._
/*  254   */          mad r4.xyz_, r15.xzyy, r1.wwww, r0.xyzz
              +       retain_prev r1._
/*   25.0 */  (p0) exec
/*  255   */     (p0) mul r7.xyz_, r4.zyxx, c59.xxxx
              +  (p0) retain_prev r1._
/*  256   */     (p0) mul r0.xyz_, r4.zyxx, c60.xxxx
              +  (p0) retain_prev r1._
/*  257   */     (p0) mul r0.xyz_, r0.xyzz, c58.xxxx
              +  (p0) retain_prev r1._
/*  258   */     (p0) mad r4.xyz_, r7.zyxx, c57.xxxx, r0.zyxx
              +  (p0) retain_prev r1._
/*   25.1 */       exec
/*  259   */          dp3 r7._y__, r12.xzyy, r6.xzyy
              +       retain_prev r1._
/*  260   */          max r1._, r1, r1
              +       adds r1.x___, r7.yy
/*  261   */          mad r0.xyz_, -r6.xyzz, r1.xxxx, r12.xyzz
              +       retain_prev r1._
/*  262   */          cube r0, r0.xxzy, r0.yzxx
              +       retain_prev r1._
/*  263   */          max r6.__z_, r0.wwww, r0.wwww
              +       rcp r1.x___, r_abs[0].z
/*  264   */          mad r6.xy__, r0.yxxx, r1.xxxx, c254.yyyy
              +       retain_prev r1._
/*   26.0 */       exec
/*  265   */          setTexLOD r3.w
/*  266   */          tfetchCube r6, r6.xyz, tf6, UseComputedLOD=false, UseRegisterLOD=true
/*   26.1 */       alloc colors
/*   27.0 */       exec
/*  267   */          max r1.x___, r6.wwww, c254.zzzz
              +       mulsc r7.x___, c6.x, r3.z
/*  268   */          add r0.xy__, -r7.xyyy, c255.yyyy
              +       rcp r1.x___, r1.x
/*  269   */          mul r3.x_zw, r1.xxxx, r6.xyyz
              +       retain_prev r1._
/*  270   */          mul r6.xyz_, r3.wzxx, r0.xxxx
              +       muls r1.x___, r_abs[0].yy
/*  271   */          max r1._, r1, r1
              +       muls r1.x___, r1.xx
/*  272   */          mul r6.___w, r1.xxxx, r_abs[0].yyyy
              +       retain_prev r1._
/*   27.1 */       exec    // PredicateClean=false
/*  273   */          mad r0.xyz_, r6.zyxx, c14.wwww, r10.zyxx
              +       retain_prev r1._
/*  274   */          mad_sat r1.x___, r6.wwww, c14.xxxx, c14.yyyy
              +       retain_prev r1._
/*  275   */          max r1._, r1, r1
              +       subsc r1.x___, c255.y, r1.x
/*  276   */          mul r1.x___, r1.xxxx, r1.wwww
              +       setp_ne r1._, c56.x
/*  277   */     (p0) mul r0.xyz_, r0.xyzz, c61.xxxx
              +  (p0) retain_prev r1._
/*  278   */          mul r1.xy_w, r1.xxxx, r8.xyzz
              +       maxs r1._, r5.ww
/*   28.0 */       exec
/*  279   */          mul r0.xyz_, r1.xyww, r0.xyzz
              +       muls_prev r1.___w, r1.z
/*  280   */          mad r0.xyz_, r13.xyzz, r4.xyzz, r0.xyzz
              +       retain_prev r1._
/*   28.1 */       cjmp !b136, L61
/*   29.0 */       exec
/*  281   */          mad r2.___w, r3.yyyy, c12.yyyy, c12.zzzz
              +       retain_prev r1._
/*  282   */          dp3 r1.__z_, r12.xzyy, c10.zxyy
              +       retain_prev r1._
/*  283   */          cndeq r4, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  284   */          dp4 r1._y__, c10.zxyw, r4
              +       subsc r1.x___, -c9.x, -r3.y
/*  285   */          add r2.xyz_, -r0.xyzz, c11.xyzz
              +       mulsc r0.___w, c9.z, r1.x
/*  286   */          min r3.xy__, r1.yzzz, c255.xzzz
              +       mulsc r1.x___, c9.w, r1.y
/*   29.1 */       exec
/*  287   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  288   */          max r1._, r1, r1
              +       mulsc r1.x___, c12.x, r1.y
/*  289   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  290   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  291   */          min r1.x___, r1.xxxx, c11.wwww
              +       retain_prev r1._
/*  292   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*   30.0 */       exec
/*  293   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L61
/*   30.1 */       exece
/*  294   */          mul r1.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  295   */          max oC0, r1, r1
