/*    0.0 */       exec
/*    3   */          vfetch_full r1.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=3
/*    4   */          vfetch_mini r0._x__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    5   */          mad r1.xyz_, r1.xyzz, c215.xyzz, c4.xyzz
/*    6   */          mulsc r0.x___, c255.x, r0.y
/*    7   */          sge r1.___w, r_abs[0].xxxx, c255.yyyy
              +       maxas r0._, r0.xx
/*    8   */          dp4 r0.x___, c[23+a0].zxyw, r1.zxyw
/*    9   */          dp4 r0._y__, c[24+a0].zxyw, r1.zxyw
/*   10   */          dp4 r0.__z_, c[25+a0].zxyw, r1.zxyw
              +       sges r0.___w, r_abs[0].x
/*    1.1 */       exec
/*   11   */          mad r0.xyz_, c6.xyzz, c5.xxxx, r0.xyzz
/*   12   */          dp4 oPos.x___, c0.zxyw, r0.zxyw
/*   13   */          dp4 oPos._y__, c1.zxyw, r0.zxyw
/*   14   */          dp4 oPos.__z_, c2.zxyw, r0.zxyw
/*   15   */          dp4 oPos.___w, c3.zxyw, r0.zxyw
/*    2.0 */       alloc interpolators
/*    2.1 */       exece
