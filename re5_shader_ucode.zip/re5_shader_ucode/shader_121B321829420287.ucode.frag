/*    0.0 */       exec
/*   26   */          sgt r10.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       rcp r2.___w, r4.w
/*   27   */          mad r3.__zw, r2.wwww, r4.xxxy, c5.xxxy
              +       retain_prev r1._
/*   28   */          mul r3.__zw, r3.zzzw, c6.xxxy
              +       retain_prev r1._
/*   29   */          tfetch2D r8.yxzw, r1.xy, tf0
/*   30   */          tfetch2D r3.__x_, r3.zw, tf5
/*   31   */          serialize
                      add r3.___w, c2.zzzz, c255.yyyy
              +       rcp r5.___w, r0.w
/*    0.1 */       exec
/*   32   */          mad r2.___w, r2.wwww, r4.zzzz, c2.zzzz
              +       retain_prev r1._
/*   33   */          mad r0._yz_, r5.wwww, r0.yyxx, c5.yyxx
              +       retain_prev r1._
/*   34   */          add r0.x___, r3.wwww, -r3.zzzz
              +       retain_prev r1._
/*   35   */          mul r3.__zw, c7.zzzw, c6.xxxy
              +       rcp r0.x___, r0.x
/*   36   */          mul r0.__zw, r3.zzzw, r0.zzzy
              +       rcp r0._y__, r2.w
/*   37   */          mul r0.xy__, r0.xyyy, c2.wwww
              +       retain_prev r1._
/*    1.0 */       exec
/*   38   */          add r0.x___, r0.xxxx, -r0.yyyy
              +       rcp r2.___w, c59.x
/*   39   */          mul r2.___w, r_abs[0].xxxx, r2.wwww
              +       retain_prev r1._
/*   40   */          min r4.x___, r2.wwww, c255.yyyy
              +       retain_prev r1._
/*   41   */          mad r2.___w, r4.xxxx, r8.wwww, -c4.xxxx
              +       retain_prev r1._
/*   42   */          kill_gt r1._, c255.xxxx, r2.wwww
              +       retain_prev r1._
/*   43   */          tfetch2D r12.xyz_, r3.xy, tf2
/*    1.1 */       exec
/*   44   */          tfetch2D r0.xy__, r3.xy, tf1
/*   45   */          tfetch2D r11, r0.zw, tf4
/*   46   */          serialize
                      sgt r9.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       retain_prev r1._
/*   47   */          mul r3.___w, r8.wwww, r1.zzzz
              +       maxs r5.___w, c58.xx
/*   48   */          add r3.xyz_, r2.xyzz, -c23.xyzz
              +       maxs r1.x___, r8.zz
/*   49   */          mul r13, r11.wzyx, c40.wzyx
              +       mulsc r11.__z_, c56.z, r1.x
/*    2.0 */       exec
/*   50   */          dp3 r1._y__, r3.zxyy, r3.zxyy
              +       mulsc r11._y__, c56.y, r8.x
/*   51   */          mad r0.x__w, r0.yxxx, c254.xxxx, c255.wwww
              +       retain_prev r1._
/*   52   */          dp2add r2.___w, -r0.xwww, r0.xwww, c255.yyyy
              +       retain_prev r1._
/*   53   */          min r13, r13, c50.xxxx
              +       rsq r0._y__, r_abs[1].y
/*   54   */          mul r3.xyz_, r3.zyxx, r0.yyyy
              +       mulsc r11.x___, c56.x, r8.y
/*   55   */          max r8, r13.wzyx, c51.xxxx
              +       sqrt r2.___w, r_abs[2].w
/*    2.1 */       exec
/*   56   */          mul r4._yzw, r2.wwww, r7.xxyz
              +       maxs r2.___w, r8.yw
/*   57   */          mad r0.xyz_, r0.xxxx, r6.zyxx, r4.wzyy
              +       retain_prev r1._
/*   58   */          mad r0._yzw, r0.wwww, r5.xxzy, r0.zzxy
              +       retain_prev r1._
/*   59   */          dp3 r0.x___, r0.zyww, r0.zyww
              +       maxs r4._y__, r8.xz
/*   60   */          max r2.___w, r4.yyyy, r2.wwww
              +       rsq r0.x___, r_abs[0].x
/*   61   */          mul r4._yzw, r0.yywz, r0.xxxx
              +       sqrt r1._y__, r_abs[1].y
/*    3.0 */       cjmp !b128, L26
/*    3.1 */       exec
/*   62   */          mul r0, r8.wzyx, c41.wzyx
              +       retain_prev r1._
/*   63   */          add r6.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*   64   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   65   */          max4 r0.__z_, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   66   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   67   */          dp3 r0.___w, r4.wyzz, r6.xzyy
              +       retain_prev r1._
/*    4.0 */       exec
/*   68   */          add r5.xyz_, r6.zyxx, -r3.zyxx
              +       retain_prev r1._
/*   69   */          dp3 r1.__z_, r6.xzyy, -c26.zxyy
              +       retain_prev r1._
/*   70   */          add r1.x___, r6.wwww, -c24.wwww
              +       retain_prev r1._
/*   71   */          add r1.__z_, r1.zzzz, -c27.xxxx
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   72   */          dp3 r0._y__, r5.zxyy, r5.zxyy
              +       mulsc r1.x___, c27.y, r1.z
/*   73   */          max r1.x___, r1.xxxx, c27.wwww
              +       rsq r0._y__, r_abs[0].y
/*    4.1 */       exec
/*   74   */          mul r6.xyz_, r5.zyxx, r0.yyyy
              +       subsc r5.x___, c255.y, r0.x
/*   75   */          min r5._y__, r1.xxxx, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*   76   */          dp3 r0._y__, r4.wyzz, r6.xzyy
              +       maxs r1._, r5.xx
/*   77   */          max r0.__zw, r0.wwwy, c255.xxxx
              +       muls_prev r5.__z_, r5.y
/*   78   */          mul r6._yzw, r5.yyzz, c24.xxzy
              +       log r1.x___, r_abs[0].w
/*   79   */          max r1._, r1, r1
              +       mulsc r0._y__, c57.z, r1.x
/*    5.0 */       exec
/*   80   */          mul r6.x___, r6.yyyy, r5.xxxx
              +       exp r0._y__, r0.y
/*   81   */          mul r5.xy__, r6.zwww, r0.yyyy
              +       retain_prev r1._
/*   82   */          mul r9.xy__, r5.xyyy, r0.xxxx
              +       retain_prev r1._
/*   83   */          mul r6, r6.xxzw, r0.yzzz
              +       retain_prev r1._
/*   84   */          mul r0._yzw, r6.yywz, r0.xxxx
              +       maxs r1._, r6.xx
/*   85   */          mul r10.xyz_, r0.ywzz, c27.zzzz
              +       muls_prev r9.__z_, r0.x
/*    5.1 */       cjmp !b129, L26
/*    6.0 */       exec
/*   86   */          mul r0, r8.wzyx, c42.wzyx
              +       retain_prev r1._
/*   87   */          add r6.xyz_, -r2.xyzz, c29.xyzz
              +       retain_prev r1._
/*   88   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*   89   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   90   */          mul r7, r6, r1.xxxx
              +       retain_prev r1._
/*   91   */          dp3 r5.__z_, r4.wyzz, r7.zxyy
              +       retain_prev r1._
/*    6.1 */       exec
/*   92   */          add r6.xyz_, r7.xyzz, -r3.zyxx
              +       retain_prev r1._
/*   93   */          dp3 r1.__z_, r7.zxyy, -c30.zxyy
              +       retain_prev r1._
/*   94   */          add r1.x___, r7.wwww, -c28.wwww
              +       retain_prev r1._
/*   95   */          add r1.__z_, r1.zzzz, -c31.xxxx
              +       mulsc_sat r0.__z_, c29.w, r1.x
/*   96   */          dp3 r0._y__, r6.zxyy, r6.zxyy
              +       mulsc r1.x___, c31.y, r1.z
/*   97   */          max r1.x___, r1.xxxx, c31.wwww
              +       rsq r0._y__, r_abs[0].y
/*    7.0 */       exec
/*   98   */          mul r6.xyz_, r6.zyxx, r0.yyyy
              +       subsc r0._y__, c255.y, r0.x
/*   99   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0.___w, c255.y, r0.z
/*  100   */          dp3 r5._y__, r4.wyzz, r6.xzyy
              +       maxs r1._, r0.ww
/*  101   */          max r0.x_z_, r5.yzzz, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*  102   */          mul r6.xy_w, r5.yyxx, c28.zyxx
              +       log r1.x___, r_abs[0].x
/*  103   */          mul r6.__z_, r6.wwww, r0.wwww
              +       mulsc r5.x___, c57.z, r1.x
/*    7.1 */       exec
/*  104   */          mul r0.x_zw, r6.xyyz, r0.zzzz
              +       exp r5.x___, r5.x
/*  105   */          mul r5.xyz_, r6.xyzz, r5.xxxx
              +       retain_prev r1._
/*  106   */          mad r9.xyz_, r5.xyzz, r0.yyyy, r9.xyzz
              +       retain_prev r1._
/*  107   */          mul r0.xyz_, r0.wzxx, r0.yyyy
              +       retain_prev r1._
/*  108   */          mad r10.xyz_, r0.xzyy, c31.zzzz, r10.xyzz
              +       retain_prev r1._
/*    8.0 */       cjmp !b130, L26
/*    8.1 */       exec
/*  109   */          mul r0, r8, c43
              +       retain_prev r1._
/*  110   */          add r6.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*  111   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*  112   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[6].w
/*  113   */          mul r7, r6, r1.xxxx
              +       retain_prev r1._
/*  114   */          dp3 r5.__z_, r4.wyzz, r7.xzyy
              +       retain_prev r1._
/*    9.0 */       exec
/*  115   */          add r6.xyz_, r7.zyxx, -r3.zyxx
              +       retain_prev r1._
/*  116   */          dp3 r1.__z_, r7.xzyy, -c34.zxyy
              +       retain_prev r1._
/*  117   */          add r1.x___, r7.wwww, -c32.wwww
              +       retain_prev r1._
/*  118   */          add r1.__z_, r1.zzzz, -c35.xxxx
              +       mulsc_sat r0.__z_, c33.w, r1.x
/*  119   */          dp3 r0._y__, r6.zxyy, r6.zxyy
              +       mulsc r1.x___, c35.y, r1.z
/*  120   */          max r1.x___, r1.xxxx, c35.wwww
              +       rsq r0._y__, r_abs[0].y
/*    9.1 */       exec
/*  121   */          mul r6.xyz_, r6.xyzz, r0.yyyy
              +       subsc r0._y__, c255.y, r0.x
/*  122   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0.___w, c255.y, r0.z
/*  123   */          dp3 r5._y__, r4.wyzz, r6.zxyy
              +       maxs r1._, r0.ww
/*  124   */          max r0.x_z_, r5.yzzz, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*  125   */          mul r6.xy_w, r5.yyxx, c32.zyxx
              +       log r1.x___, r_abs[0].x
/*  126   */          mul r6.__z_, r6.wwww, r0.wwww
              +       mulsc r5.x___, c57.z, r1.x
/*   10.0 */       exec
/*  127   */          mul r0.x_zw, r6.xyyz, r0.zzzz
              +       exp r5.x___, r5.x
/*  128   */          mul r5.xyz_, r6.xyzz, r5.xxxx
              +       retain_prev r1._
/*  129   */          mad r9.xyz_, r5.xyzz, r0.yyyy, r9.xyzz
              +       retain_prev r1._
/*  130   */          mul r0.xyz_, r0.wzxx, r0.yyyy
              +       retain_prev r1._
/*  131   */          mad r10.xyz_, r0.xzyy, c35.zzzz, r10.xyzz
              +       retain_prev r1._
/*   10.1 */       cjmp !b131, L26
/*   11.0 */       exec
/*  132   */          mul r0, r8.wzyx, c44.wzyx
              +       retain_prev r1._
/*  133   */          add r6.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*  134   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*  135   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*  136   */          mul r7, r6, r1.xxxx
              +       retain_prev r1._
/*  137   */          dp3 r5.__z_, r4.wyzz, r7.zxyy
              +       retain_prev r1._
/*   11.1 */       exec
/*  138   */          add r6.xyz_, r7.xyzz, -r3.zyxx
              +       retain_prev r1._
/*  139   */          dp3 r1.__z_, r7.zxyy, -c38.zxyy
              +       retain_prev r1._
/*  140   */          add r1.x___, r7.wwww, -c36.wwww
              +       retain_prev r1._
/*  141   */          add r1.__z_, r1.zzzz, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*  142   */          dp3 r0._y__, r6.zxyy, r6.zxyy
              +       mulsc r1.x___, c39.y, r1.z
/*  143   */          max r1.x___, r1.xxxx, c39.wwww
              +       rsq r0._y__, r_abs[0].y
/*   12.0 */       exec
/*  144   */          mul r6.xyz_, r6.zyxx, r0.yyyy
              +       subsc r0._y__, c255.y, r0.x
/*  145   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0.___w, c255.y, r0.z
/*  146   */          dp3 r5._y__, r4.wyzz, r6.xzyy
              +       maxs r1._, r0.ww
/*  147   */          max r0.x_z_, r5.yzzz, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*  148   */          mul r6.xy_w, r5.yyxx, c36.zyxx
              +       log r1.x___, r_abs[0].x
/*  149   */          mul r6.__z_, r6.wwww, r0.wwww
              +       mulsc r5.x___, c57.z, r1.x
/*   12.1 */       exec
/*  150   */          mul r0.x_zw, r6.xyyz, r0.zzzz
              +       exp r5.x___, r5.x
/*  151   */          mul r5.xyz_, r6.xyzz, r5.xxxx
              +       retain_prev r1._
/*  152   */          mad r9.xyz_, r5.xyzz, r0.yyyy, r9.xyzz
              +       retain_prev r1._
/*  153   */          mul r0.xyz_, r0.wzxx, r0.yyyy
              +       retain_prev r1._
/*  154   */          mad r10.xyz_, r0.xzyy, c39.zzzz, r10.xyzz
              +       retain_prev r1._
                label L26
/*   13.0 */       cjmp !b132, L38
/*   13.1 */       exec
/*  155   */          add r0.xyz_, -r2.zyxx, c9.zyxx
              +       retain_prev r1._
/*  156   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  157   */          mul r6, r8.wzyx, c45.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  158   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  159   */          add r1.x___, r0.wwww, -c8.wwww
              +       retain_prev r1._
/*  160   */          dp3 r0.__z_, r0.xzyy, r4.wyzz
              +       mulsc_sat r0.x___, c9.w, r1.x
/*   14.0 */       exec
/*  161   */          max4 r0._y__, r6.zxwy
              +       maxs r0.__z_, r0.zz
/*  162   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  163   */          mul r5.xyz_, r0.xxxx, c8.zyxx
              +       maxs r0.__z_, r0.zw
/*  164   */          mul r5.xyz_, r5.xyzz, r0.zzzz
              +       retain_prev r1._
/*  165   */          mad r10.xyz_, r5.zxyy, r0.yyyy, r10.xyzz
              +       retain_prev r1._
/*   14.1 */       cjmp !b133, L38
/*   15.0 */       exec
/*  166   */          add r0.xyz_, -r2.xyzz, c11.xyzz
              +       retain_prev r1._
/*  167   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  168   */          mul r6, r8, c46
              +       rsq r1.x___, r_abs[0].w
/*  169   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  170   */          add r1.x___, r0.wwww, -c10.wwww
              +       retain_prev r1._
/*  171   */          dp3 r0.__z_, r0.zxyy, r4.wyzz
              +       mulsc_sat r0.x___, c11.w, r1.x
/*   15.1 */       exec
/*  172   */          max4 r0._y__, r6.ywxz
              +       maxs r0.__z_, r0.zz
/*  173   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  174   */          mul r5.xyz_, r0.xxxx, c10.zyxx
              +       maxs r0.__z_, r0.zw
/*  175   */          mul r5.xyz_, r5.xyzz, r0.zzzz
              +       retain_prev r1._
/*  176   */          mad r10.xyz_, r5.zxyy, r0.yyyy, r10.xyzz
              +       retain_prev r1._
/*   16.0 */       cjmp !b134, L38
/*   16.1 */       exec
/*  177   */          add r0.xyz_, -r2.zyxx, c13.zyxx
              +       retain_prev r1._
/*  178   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  179   */          mul r6, r8.wzyx, c47.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  180   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  181   */          add r1.x___, r0.wwww, -c12.wwww
              +       retain_prev r1._
/*  182   */          dp3 r0.__z_, r0.xzyy, r4.wyzz
              +       mulsc_sat r0.x___, c13.w, r1.x
/*   17.0 */       exec
/*  183   */          max4 r0._y__, r6.zxwy
              +       maxs r0.__z_, r0.zz
/*  184   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  185   */          mul r5.xyz_, r0.xxxx, c12.zyxx
              +       maxs r0.__z_, r0.zw
/*  186   */          mul r5.xyz_, r5.xyzz, r0.zzzz
              +       retain_prev r1._
/*  187   */          mad r10.xyz_, r5.zxyy, r0.yyyy, r10.xyzz
              +       retain_prev r1._
/*   17.1 */       cjmp !b135, L38
/*   18.0 */       exec
/*  188   */          add r0.xyz_, -r2.xyzz, c15.xyzz
              +       retain_prev r1._
/*  189   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  190   */          mul r6, r8, c48
              +       rsq r1.x___, r_abs[0].w
/*  191   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  192   */          add r1.x___, r0.wwww, -c14.wwww
              +       retain_prev r1._
/*  193   */          dp3 r0.__z_, r0.zxyy, r4.wyzz
              +       mulsc_sat r0.x___, c15.w, r1.x
/*   18.1 */       exec
/*  194   */          max4 r0._y__, r6.ywxz
              +       maxs r0.__z_, r0.zz
/*  195   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  196   */          mul r5.xyz_, r0.xxxx, c14.zyxx
              +       maxs r0.__z_, r0.zw
/*  197   */          mul r5.xyz_, r5.xyzz, r0.zzzz
              +       retain_prev r1._
/*  198   */          mad r10.xyz_, r5.zxyy, r0.yyyy, r10.xyzz
              +       retain_prev r1._
                label L38
/*   19.0 */       exec
/*  199   */          mul r7, r4.yzww, r4.zwwy
              +       retain_prev r1._
/*  200   */          cndeq r0, c255.xxxy, r4.wyzz, c255.yyyy
              +       retain_prev r1._
/*  201   */          dp4 r5.x___, c16.zxyw, r0
              +       retain_prev r1._
/*  202   */          dp4 r5._y__, c18.zxyw, r0
              +       retain_prev r1._
/*  203   */          dp4 r5.__z_, c17.zxyw, r0
              +       retain_prev r1._
/*  204   */          dp4 r0.x___, r7.wzxy, c19.wzxy
              +       muls r6.x___, r4.yy
/*   19.1 */       exec    // PredicateClean=false
/*  205   */          dp4 r0._y__, r7.wzxy, c21.wzxy
              +       muls r6._y__, r4.zz
/*  206   */          dp4 r0.__z_, r7.wzxy, c20.wzxy
              +       subs r0.___w, r6.xy
/*  207   */          add r0.xyz_, r5.zxyy, r0.zxyy
              +       setp_gt r1._, c_abs[60].x
/*  208   */          mad r0.xyz_, r0.wwww, c22.xyzz, r0.yxzz
              +       retain_prev r1._
/*  209   */          mad r5.xyz_, r10.xzyy, r1.wwww, r0.xyzz
              +       retain_prev r1._
/*   20.0 */  (p0) exec
/*  210   */     (p0) mul r6.xyz_, r5.zyxx, c63.xxxx
              +  (p0) retain_prev r1._
/*  211   */     (p0) mul r0.xyz_, r5.zyxx, c64.xxxx
              +  (p0) retain_prev r1._
/*  212   */     (p0) mul r0.xyz_, r0.xyzz, c62.xxxx
              +  (p0) retain_prev r1._
/*  213   */     (p0) mad r5.xyz_, r6.zyxx, c61.xxxx, r0.zyxx
              +  (p0) retain_prev r1._
/*   20.1 */       exec
/*  214   */          dp3 r1.__z_, r3.xzyy, r4.wyzz
              +       retain_prev r1._
/*  215   */          max r1._, r1, r1
              +       adds r1.x___, r1.zz
/*  216   */          mad r0.xyz_, -r4.yzww, r1.xxxx, r3.zyxx
              +       retain_prev r1._
/*  217   */          cube r0, r0.zzxy, r0.yxzz
              +       retain_prev r1._
/*  218   */          max r4.___w, r0.wwww, r0.wwww
              +       rcp r1.x___, r_abs[0].z
/*  219   */          mad r4._yz_, r0.yyxx, r1.xxxx, c254.yyyy
              +       retain_prev r1._
/*   21.0 */       exec
/*  220   */          setTexLOD r5.w
/*  221   */          tfetchCube r0, r4.yzw, tf3, UseComputedLOD=false, UseRegisterLOD=true
/*   21.1 */       alloc colors
/*   22.0 */       exec
/*  222   */          max r4._y__, r0.wwww, c254.zzzz
              +       mulsc r1.x___, c49.x, r2.w
/*  223   */          add r1.x_z_, -r1.xzzz, c255.yyyy
              +       rcp r2.___w, r4.y
/*  224   */          mul r0.xyz_, r2.wwww, r0.xyzz
              +       retain_prev r1._
/*  225   */          mul r6.xyz_, r0.zyxx, r1.xxxx
              +       muls r2.___w, r_abs[1].zz
/*  226   */          max r1._, r1, r1
              +       muls r2.___w, r2.ww
/*  227   */          mul r6.___w, r2.wwww, r_abs[1].zzzz
              +       retain_prev r1._
/*   22.1 */       exec    // PredicateClean=false
/*  228   */          mad r0.xyz_, r6.zyxx, c57.wwww, r9.zyxx
              +       retain_prev r1._
/*  229   */          mad_sat r1.x___, r6.wwww, c57.xxxx, c57.yyyy
              +       retain_prev r1._
/*  230   */          max r1._, r1, r1
              +       subsc r1.x___, c255.y, r1.x
/*  231   */          mul r1.x___, r1.xxxx, r1.wwww
              +       setp_ne r1._, c60.x
/*  232   */     (p0) mul r0.xyz_, r0.xyzz, c65.xxxx
              +  (p0) retain_prev r1._
/*  233   */          mul r1.x_zw, r1.xxxx, r12.xyyz
              +       maxs r1._, r3.ww
/*   23.0 */       exec
/*  234   */          mul r0.xyz_, r1.xzww, r0.xyzz
              +       muls_prev r1.___w, r4.x
/*  235   */          mad r0.xyz_, r11.xyzz, r5.xyzz, r0.xyzz
              +       retain_prev r1._
/*   23.1 */       cjmp !b136, L51
/*   24.0 */       exec
/*  236   */          mad r2.___w, r1.yyyy, c55.yyyy, c55.zzzz
              +       retain_prev r1._
/*  237   */          dp3 r1.__z_, r3.xzyy, c53.zxyy
              +       retain_prev r1._
/*  238   */          cndeq r3, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  239   */          dp4 r1.x___, c53.zxyw, r3
              +       subsc r1._y__, -c52.x, -r1.y
/*  240   */          add r2.xyz_, -r0.xyzz, c54.xyzz
              +       mulsc r0.___w, c52.z, r1.y
/*  241   */          min r3.xy__, r1.xzzz, c255.xzzz
              +       mulsc r1.x___, c52.w, r1.x
/*   24.1 */       exec
/*  242   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  243   */          max r1._, r1, r1
              +       mulsc r1.x___, c55.x, r1.y
/*  244   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  245   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  246   */          min r1.x___, r1.xxxx, c54.wwww
              +       retain_prev r1._
/*  247   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*   25.0 */       exec
/*  248   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L51
/*   25.1 */       exece
/*  249   */          mul r1.xyz_, r0.xyzz, c3.xxxx
              +       retain_prev r1._
/*  250   */          max oC0, r1, r1
