/*    0.0 */       exec
/*    2   */          tfetch2D r1, r1.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    3   */          mul r1.xyz_, r1.xyzz, c23.xxxx
              +       maxs r0._, r1.ww
/*    4   */          mul oC0.xyz_, r1.xyzz, r0.xyzz
              +       muls_prev oC0.___w, r0.w
/*    1.1 */       cnop
