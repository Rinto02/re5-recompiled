/*    0.0 */       exec    // PredicateClean=false
/*   18   */          sgt r4.x___, c1.zzzz, r0.wwww
/*   19   */          setp_ne_push r9.x___, c255.yyyy, r4.xxxx
              +       sgts r4.x___, -r_abs[0].x
/*    0.1 */ (!p0) jmp L33
/*    1.0 */       exec    // PredicateClean=false
/*   20   */     (p0) dp3 r4._y__, r0.zxyy, r0.zxyy
/*   21   */     (p0) sgt r4.x___, c1.xxxx, r0.wwww
              +  (p0) rsq r4._y__, r_abs[4].y
/*   22   */     (p0) mul r4._yzw, r4.yyyy, -c23.xxyz
/*   23   */     (p0) dp3 r0.__z_, r4.wyzz, r0.zxyy
/*   24   */          setp_ne_push r9.x___, r9.xxxx, r4.xxxx
/*    1.1 */ (!p0) jmp L11
/*    2.0 */  (p0) exec
/*   25   */     (p0) rcp r0.x___, r1.w
/*   26   */     (p0) mul r2.xyz_, r0.xxxx, r1.yzxx
/*   27   */     (p0) tfetch2D r8.x___, r2.zx, tf0, OffsetX=-2, OffsetY=1
/*   28   */     (p0) tfetch2D r8.___x, r2.zx, tf0, OffsetX=1, OffsetY=1
/*   29   */     (p0) tfetch2D r8.__x_, r2.zx, tf0, OffsetY=1
/*   30   */     (p0) tfetch2D r8._x__, r2.zx, tf0, OffsetX=-1, OffsetY=1
/*    2.1 */  (p0) exec
/*   31   */     (p0) tfetch2D r10.x___, r2.zx, tf0, OffsetX=-2
/*   32   */     (p0) tfetch2D r10.___x, r2.zx, tf0, OffsetX=1
/*   33   */     (p0) tfetch2D r10.__x_, r2.zx, tf0
/*   34   */     (p0) tfetch2D r10._x__, r2.zx, tf0, OffsetX=-1
/*   35   */     (p0) tfetch2D r5.x___, r2.zx, tf0, OffsetX=-2, OffsetY=-1
/*   36   */     (p0) tfetch2D r5.___x, r2.zx, tf0, OffsetX=1, OffsetY=-1
/*    3.0 */  (p0) exec
/*   37   */     (p0) tfetch2D r5.__x_, r2.zx, tf0, OffsetY=-1
/*   38   */     (p0) tfetch2D r5._x__, r2.zx, tf0, OffsetX=-1, OffsetY=-1
/*   39   */     (p0) tfetch2D r6.x___, r2.zx, tf0, OffsetX=-2, OffsetY=-2
/*   40   */     (p0) tfetch2D r6.___x, r2.zx, tf0, OffsetX=1, OffsetY=-2
/*   41   */     (p0) tfetch2D r6.__x_, r2.zx, tf0, OffsetY=-2
/*   42   */     (p0) tfetch2D r6._x__, r2.zx, tf0, OffsetX=-1, OffsetY=-2
/*    3.1 */       exec    // PredicateClean=false
/*   43   */          serialize
                 (p0) subsc r0._y__, c255.x, r2.y
/*   44   */     (p0) sge r3, r6, r0.yyyy
/*   45   */     (p0) sge r4, r5, r0.yyyy
/*   46   */     (p0) sge r2, r10, r0.yyyy
/*   47   */     (p0) sge r7, r8, r0.yyyy
              +  (p0) mulsc r0.x___, c0.y, r0.x
/*   48   */          setp_gt_push r9.x___, r9.xxxx, c4.xxxx
/*    4.0 */  (p0) exec
/*   49   */     (p0) add r7, -r0.yyyy, r8
/*   50   */     (p0) add r2, -r0.yyyy, r10
/*   51   */     (p0) add r4, -r0.yyyy, r5
/*   52   */     (p0) add r3, -r0.yyyy, r6
/*   53   */     (p0) mul_sat r3, r3, c4.xxxx
/*   54   */     (p0) mul_sat r4, r4, c4.xxxx
/*    4.1 */       exec    // PredicateClean=false
/*   55   */     (p0) mul_sat r2, r2, c4.xxxx
/*   56   */     (p0) mul_sat r7, r7, c4.xxxx
/*   57   */          setp_pop r9.x___, r9.x
/*   58   */     (p0) mul r0.xy__, r0.xxxx, r1.xyyy
/*   59   */     (p0) frc r0.xy__, r0.xyyy
/*   60   */     (p0) add r1, r2, r4
              +  (p0) subsc r0.___w, c255.x, r0.y
/*    5.0 */  (p0) exec
/*   61   */     (p0) mad r1, r0.wwww, r3, r1
/*   62   */     (p0) mad r1, r0.yyyy, r7, r1
/*   63   */     (p0) dp3 r0.___w, r1.zxyy, c255.xxxx
              +  (p0) subs r1.x___, r1.wx
/*   64   */     (p0) mad r0.x___, r1.xxxx, r0.xxxx, r0.wwww
/*   65   */     (p0) mul r0.___w, r0.xxxx, c255.zzzz
              +  (p0) maxs r0.x___, c255.xx
                label L11
/*    5.1 */       exec    // PredicateClean=false
/*   66   */          setp_inv r9.x___, r9.x
/*    6.0 */ (!p0) jmp L32
/*    6.1 */       exec    // PredicateClean=false
/*   67   */     (p0) sgt r1.x___, c1.yyyy, r0.wwww
/*   68   */          setp_ne_push r9.x___, r9.xxxx, r1.xxxx
/*    7.0 */ (!p0) jmp L22
/*    7.1 */  (p0) exec
/*   69   */     (p0) rcp r0.x___, r2.w
/*   70   */     (p0) mul r1.xyz_, r0.xxxx, r2.yzxx
/*   71   */     (p0) tfetch2D r10.x___, r1.zx, tf1, OffsetX=-2, OffsetY=1
/*   72   */     (p0) tfetch2D r10.___x, r1.zx, tf1, OffsetX=1, OffsetY=1
/*   73   */     (p0) tfetch2D r10.__x_, r1.zx, tf1, OffsetY=1
/*   74   */     (p0) tfetch2D r10._x__, r1.zx, tf1, OffsetX=-1, OffsetY=1
/*    8.0 */  (p0) exec
/*   75   */     (p0) tfetch2D r4.x___, r1.zx, tf1, OffsetX=-2
/*   76   */     (p0) tfetch2D r4.___x, r1.zx, tf1, OffsetX=1
/*   77   */     (p0) tfetch2D r4.__x_, r1.zx, tf1
/*   78   */     (p0) tfetch2D r4._x__, r1.zx, tf1, OffsetX=-1
/*   79   */     (p0) tfetch2D r5.x___, r1.zx, tf1, OffsetX=-2, OffsetY=-1
/*   80   */     (p0) tfetch2D r5.___x, r1.zx, tf1, OffsetX=1, OffsetY=-1
/*    8.1 */  (p0) exec
/*   81   */     (p0) tfetch2D r5.__x_, r1.zx, tf1, OffsetY=-1
/*   82   */     (p0) tfetch2D r5._x__, r1.zx, tf1, OffsetX=-1, OffsetY=-1
/*   83   */     (p0) tfetch2D r6.x___, r1.zx, tf1, OffsetX=-2, OffsetY=-2
/*   84   */     (p0) tfetch2D r6.___x, r1.zx, tf1, OffsetX=1, OffsetY=-2
/*   85   */     (p0) tfetch2D r6.__x_, r1.zx, tf1, OffsetY=-2
/*   86   */     (p0) tfetch2D r6._x__, r1.zx, tf1, OffsetX=-1, OffsetY=-2
/*    9.0 */       exec    // PredicateClean=false
/*   87   */          serialize
                 (p0) subsc r0._y__, c255.x, r1.y
/*   88   */     (p0) sge r1, r6, r0.yyyy
/*   89   */     (p0) sge r3, r5, r0.yyyy
/*   90   */     (p0) sge r7, r4, r0.yyyy
/*   91   */     (p0) sge r8, r10, r0.yyyy
              +  (p0) mulsc r0.x___, c0.y, r0.x
/*   92   */          setp_gt_push r9.x___, r9.xxxx, c4.xxxx
/*    9.1 */  (p0) exec
/*   93   */     (p0) add r8, -r0.yyyy, r10
/*   94   */     (p0) add r4, -r0.yyyy, r4
/*   95   */     (p0) add r3, -r0.yyyy, r5
/*   96   */     (p0) add r1, -r0.yyyy, r6
/*   97   */     (p0) mul_sat r1, r1, c4.xxxx
/*   98   */     (p0) mul_sat r3, r3, c4.xxxx
/*   10.0 */       exec    // PredicateClean=false
/*   99   */     (p0) mul_sat r7, r4, c4.xxxx
/*  100   */     (p0) mul_sat r8, r8, c4.xxxx
/*  101   */          setp_pop r9.x___, r9.x
/*  102   */     (p0) mul r0.xy__, r0.xxxx, r2.xyyy
/*  103   */     (p0) frc r0.xy__, r0.xyyy
/*  104   */     (p0) add r2, r7, r3
              +  (p0) subsc r0.___w, c255.x, r0.y
/*   10.1 */  (p0) exec
/*  105   */     (p0) mad r1, r0.wwww, r1, r2
/*  106   */     (p0) mad r1, r0.yyyy, r8, r1
/*  107   */     (p0) dp3 r0.___w, r1.zxyy, c255.xxxx
              +  (p0) subs r1.x___, r1.wx
/*  108   */     (p0) mad r0.x___, r1.xxxx, r0.xxxx, r0.wwww
/*  109   */     (p0) mul r0.___w, r0.xxxx, c255.zzzz
              +  (p0) maxs r0.x___, c255.xx
                label L22
/*   11.0 */       exec    // PredicateClean=false
/*  110   */          setp_inv r9.x___, r9.x
/*   11.1 */ (!p0) jmp L31
/*   12.0 */  (p0) exec
/*  111   */     (p0) rcp r0.x___, r3.w
/*  112   */     (p0) mul r1.xyz_, r0.xxxx, r3.yzxx
/*  113   */     (p0) tfetch2D r10.x___, r1.zx, tf2, OffsetX=-2, OffsetY=1
/*  114   */     (p0) tfetch2D r10.___x, r1.zx, tf2, OffsetX=1, OffsetY=1
/*  115   */     (p0) tfetch2D r10.__x_, r1.zx, tf2, OffsetY=1
/*  116   */     (p0) tfetch2D r10._x__, r1.zx, tf2, OffsetX=-1, OffsetY=1
/*   12.1 */  (p0) exec
/*  117   */     (p0) tfetch2D r4.x___, r1.zx, tf2, OffsetX=-2
/*  118   */     (p0) tfetch2D r4.___x, r1.zx, tf2, OffsetX=1
/*  119   */     (p0) tfetch2D r4.__x_, r1.zx, tf2
/*  120   */     (p0) tfetch2D r4._x__, r1.zx, tf2, OffsetX=-1
/*  121   */     (p0) tfetch2D r5.x___, r1.zx, tf2, OffsetX=-2, OffsetY=-1
/*  122   */     (p0) tfetch2D r5.___x, r1.zx, tf2, OffsetX=1, OffsetY=-1
/*   13.0 */  (p0) exec
/*  123   */     (p0) tfetch2D r5.__x_, r1.zx, tf2, OffsetY=-1
/*  124   */     (p0) tfetch2D r5._x__, r1.zx, tf2, OffsetX=-1, OffsetY=-1
/*  125   */     (p0) tfetch2D r6.x___, r1.zx, tf2, OffsetX=-2, OffsetY=-2
/*  126   */     (p0) tfetch2D r6.___x, r1.zx, tf2, OffsetX=1, OffsetY=-2
/*  127   */     (p0) tfetch2D r6.__x_, r1.zx, tf2, OffsetY=-2
/*  128   */     (p0) tfetch2D r6._x__, r1.zx, tf2, OffsetX=-1, OffsetY=-2
/*   13.1 */       exec    // PredicateClean=false
/*  129   */          serialize
                 (p0) subsc r0._y__, c255.x, r1.y
/*  130   */     (p0) sge r2, r6, r0.yyyy
/*  131   */     (p0) sge r8, r5, r0.yyyy
/*  132   */     (p0) sge r1, r4, r0.yyyy
/*  133   */     (p0) sge r7, r10, r0.yyyy
              +  (p0) mulsc r0.x___, c0.y, r0.x
/*  134   */          setp_gt_push r9.x___, r9.xxxx, c4.xxxx
/*   14.0 */  (p0) exec
/*  135   */     (p0) add r7, -r0.yyyy, r10
/*  136   */     (p0) add r1, -r0.yyyy, r4
/*  137   */     (p0) add r4, -r0.yyyy, r5
/*  138   */     (p0) add r2, -r0.yyyy, r6
/*  139   */     (p0) mul_sat r2, r2, c4.xxxx
/*  140   */     (p0) mul_sat r8, r4, c4.xxxx
/*   14.1 */       exec    // PredicateClean=false
/*  141   */     (p0) mul_sat r1, r1, c4.xxxx
/*  142   */     (p0) mul_sat r7, r7, c4.xxxx
/*  143   */          setp_pop r9.x___, r9.x
/*  144   */     (p0) mad_sat r0._y__, r0.wwww, c2.xxxx, c2.yyyy
/*  145   */     (p0) mul r0.x__w, r0.xxxx, r3.xyyy
/*  146   */     (p0) frc r0.x__w, r0.xwww
/*   15.0 */  (p0) exec
/*  147   */     (p0) add r1, r1, r8
              +  (p0) subsc r3.x___, c255.x, r0.w
/*  148   */     (p0) mad r1, r3.xxxx, r2, r1
/*  149   */     (p0) mad r1, r0.wwww, r7.yxwz, r1.yxwz
/*  150   */     (p0) dp3 r1.x___, r1.wyxx, c255.xxxx
              +  (p0) subs r1._y__, r1.zy
/*  151   */     (p0) mad r0.x___, r1.yyyy, r0.xxxx, r1.xxxx
/*  152   */     (p0) mul r0.___w, r0.xxxx, c255.zzzz
              +  (p0) subsc r0.x___, c255.x, r0.y
                label L31
/*   15.1 */       exec    // PredicateClean=false
/*  153   */          setp_pop r9.x___, r9.x
                label L32
/*   16.0 */       exec    // PredicateClean=false
/*  154   */          setp_pop r9.x___, r9.x
/*  155   */     (p0) mulsc_sat r0._y__, c3.x, r0.z
/*  156   */     (p0) subsc r0._y__, c255.x, r0.y
/*  157   */     (p0) max r0._y__, r0.yyyy, r0.wwww
/*  158   */     (p0) mul r4.x___, r0.yyyy, r0.xxxx
                label L33
/*   16.1 */       alloc colors
/*   17.0 */       exece
/*  159   */          max oC0, r4.xxxx, r4.xxxx
/*   17.1 */       cnop
