/*    0.0 */       exec
/*    6   */          vfetch_full r3.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer
/*    7   */          serialize
                      max r1, c28, c28
/*    8   */          max r0, c29, c29
/*    9   */          max r2, c30.zyxw, c30.zyxw
/*   10   */          cndeq r3, c255.zzzx, r3.zxyy, c255.xxxx
/*   11   */          dp4 r1.x___, r1.zxyw, r3
/*    0.1 */       exec
/*   12   */          dp4 r1._y__, r0.zxyw, r3
/*   13   */          dp4 r1.__z_, r2.xzyw, r3
/*    1.0 */       cjmp !b0, L7
/*    1.1 */       exec
/*   14   */          cndeq r0, c255.zzzx, r1.zxyy, c255.xxxx
/*   15   */          dp4 r1.x___, c0.zxyw, r0
/*   16   */          dp4 r1._y__, c1.zxyw, r0
/*   17   */          dp4 r1.__z_, c2.zxyw, r0
/*   18   */          dp2add r0.__z_, r1.xyyy, r1.xyyy, c255.zzzz
/*   19   */          dp3 r0.x___, r1.zxyy, r1.zxyy
/*    2.0 */       exec
/*   20   */          sqrt r0._y__, r_abs[0].x
/*   21   */          mad r0.x___, r0.yyyy, c27.xxxx, c27.yyyy
/*   22   */          add r0.___w, -r1.zzzz, r0.yyyy
/*   23   */          mul r2.xy__, r1.xyyy, r0.yyyy
/*   24   */          mul r2.xy__, r2.yxxx, r0.wwww
              +       rcp r0.__z_, r0.z
/*   25   */          mul r0.__zw, r2.yyyx, r0.zzzz
/*    2.1 */       exec
/*   26   */          cndge r0.xy__, r1.zzzz, r0.xyyy, c255.xyyy
/*    3.0 */       jmp L8
                label L7
/*    3.1 */       exec
/*   27   */          cndeq r1, c255.zzzx, r1.zxyy, c255.xxxx
/*   28   */          dp4 r0.__z_, c23.zxyw, r1
/*   29   */          dp4 r0.___w, c24.zxyw, r1
/*   30   */          dp4 r0.x___, c25.zxyw, r1
/*   31   */          dp4 r0._y__, c26.zxyw, r1
                label L8
/*    4.0 */       alloc position
/*    4.1 */       exec
/*   32   */          max oPos, r0.zwxy, r0.zwxy
/*    5.0 */       alloc interpolators
/*    5.1 */       exece
