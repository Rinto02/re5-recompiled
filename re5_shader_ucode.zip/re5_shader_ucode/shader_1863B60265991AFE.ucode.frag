/*    0.0 */       exec
/*    2   */          tfetch2D r0.xyz_, r0.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exec
/*    3   */          mul r0.xyz_, r0.xyzz, c49.xxxx
/*    4   */          mul r1.xyz_, r0.xyzz, c48.yyyy
/*    5   */          maxs r0.x___, r1.xy
/*    6   */          max r0._y__, r0.xxxx, r1.zzzz
/*    7   */          subsc r0.x___, -c50.x, -r0.y
/*    8   */          max r0.x_z_, r0.xxxx, c255.yxxx
/*    1.1 */       exece
/*    9   */          mul r0._y__, r0.yyyy, r0.xxxx
/*   10   */          rcp r0.x___, r0.y
/*   11   */          mul r0.x___, r0.zzzz, r0.xxxx
/*   12   */          mul oC0.xyz1, r1.xyzz, r0.xxxx
