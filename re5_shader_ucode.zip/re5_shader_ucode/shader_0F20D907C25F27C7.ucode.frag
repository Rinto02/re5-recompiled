/*    0.0 */       alloc colors
/*    0.1 */       exece
/*    1   */          max oC0._001, r0, r0
              +       sgts oC0.x___, -r_abs[0].x
