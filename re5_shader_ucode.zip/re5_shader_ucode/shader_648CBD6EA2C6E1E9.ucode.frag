/*    0.0 */       exec
/*    2   */          tfetch2D r1, r1.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    3   */          add r2.x___, -c0.wwww, c255.xxxx
/*    4   */          max r2._y__, r1.wwww, c0.wwww
/*    5   */          mul r2._yzw, r2.yyyy, c0.xxyz
              +       maxs r2.x___, r2.xx
/*    6   */          mul r1.xyz_, r2.yzww, r1.xyzz
              +       maxs r2._y__, r1.ww
/*    7   */          mul r1.xyz_, r1.xyzz, c23.wwww
              +       maxs r1.___w, r2.xy
/*    8   */          mul oC0, r1, r0
/*    1.1 */       cnop
