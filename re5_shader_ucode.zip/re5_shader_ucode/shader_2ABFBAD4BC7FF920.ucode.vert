/*    0.0 */       exec
/*    3   */          vfetch_full r1.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    4   */          vfetch_mini r0._x__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    5   */          vfetch_mini r0.y_x_, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    6   */          mad r2.xyz_, r1.xyzz, c215.xyzz, c4.xyzz
/*    7   */          mulsc r0._y__, c255.x, r0.y
/*    8   */          sge r2.___w, r_abs[0].xxxx, c255.yyyy
              +       maxas r0._, r0.yy
/*    9   */          dp4 r1.x___, c[23+a0].zxyw, r2.zxyw
/*   10   */          dp4 r1._y__, c[24+a0].zxyw, r2.zxyw
/*   11   */          dp4 r1.__z_, c[25+a0].zxyw, r2.zxyw
              +       sges r1.___w, r_abs[0].x
/*    1.1 */       exec
/*   12   */          mad r1.xyz_, c7.xyzz, c6.xxxx, r1.xyzz
/*   13   */          dp4 oPos.x___, c0.zxyw, r1.zxyw
/*   14   */          dp4 oPos._y__, c1.zxyw, r1.zxyw
/*   15   */          dp4 oPos.__z_, c2.zxyw, r1.zxyw
/*   16   */          dp4 oPos.___w, c3.zxyw, r1.zxyw
/*    2.0 */       alloc interpolators
/*    2.1 */       exece
/*   17   */          add o0.xy__, r0.xzzz, c5.xyyy
