/*    0.0 */       exec
/*    2   */          tfetch2D r1, r0.xy, tf0
/*    3   */          tfetch2D r0.x___, r0.xy, tf1
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    4   */          subsc r0.x___, c255.y, r0.x
/*    5   */          max oC0, r1, r1
/*    6   */          subsc r0.x___, c255.y, r0.x
/*    7   */          mad_sat oDepth.x___, -r0.xxxx, c255.xxxx, r0.xxxx
/*    1.1 */       cnop
