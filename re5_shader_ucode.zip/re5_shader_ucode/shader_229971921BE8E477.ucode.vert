/*    0.0 */       exec
/*    9   */          vfetch_full r2.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*   10   */          vfetch_mini r1.xy__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   11   */          vfetch_mini r0.__x_, Offset=3, DataFormat=FMT_8_8_8_8
/*   12   */          vfetch_mini r4.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   13   */          vfetch_mini r6, Offset=5, DataFormat=FMT_8_8_8_8, Signed=true
/*   14   */          vfetch_mini r0.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       exec
/*   15   */          serialize
                      mad r3.xyz_, r2.xyzz, c3.xyzz, c4.xyzz
/*   16   */          mul r7.xy__, r1.xyyy, c255.wwww
/*   17   */          add r0.___w, -r0.zzzz, c255.xxxx
              +       maxas r0._, r7.yy
/*   18   */          mul r5, r0.wwww, c[30+a0]
/*   19   */          mul r2, r0.wwww, c[29+a0]
/*   20   */          mul r1, r0.wwww, c[28+a0]
              +       maxas r0._, r7.xx
/*    1.0 */       exec
/*   21   */          mad r1, r0.zzzz, c[28+a0], r1
/*   22   */          mad r2, r0.zzzz, c[29+a0], r2
/*   23   */          mad r5, r0.zzzz, c[30+a0], r5
/*   24   */          cndeq r7, c255.zzzx, r3.zxyy, c255.xxxx
/*   25   */          dp4 r3.x___, r1.zxyw, r7
/*   26   */          dp4 r3._y__, r2.zxyw, r7
/*    1.1 */       exec
/*   27   */          dp4 r3.__z_, r5.zxyw, r7
/*    2.0 */       cjmp !b0, L9
/*    2.1 */       exec
/*   28   */          cndeq r7, c255.zzzx, r3.zxyy, c255.xxxx
/*   29   */          dp4 r8.x___, c0.zxyw, r7
/*   30   */          dp4 r8._y__, c1.zxyw, r7
/*   31   */          dp4 r8.__z_, c2.zxyw, r7
/*   32   */          dp2add r3.___w, r8.xyyy, r8.xyyy, c255.zzzz
/*   33   */          dp3 r0.__z_, r8.zxyy, r8.zxyy
/*    3.0 */       exec
/*   34   */          sqrt r0.___w, r_abs[0].z
/*   35   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   36   */          add r4.___w, -r8.zzzz, r0.wwww
/*   37   */          mul r7.xy__, r8.xyyy, r0.wwww
/*   38   */          mul r7.xy__, r7.yxxx, r4.wwww
              +       rcp r3.___w, r3.w
/*   39   */          mul r7.xy__, r7.yxxx, r3.wwww
/*    3.1 */       exec
/*   40   */          cndge r7.__zw, r8.zzzz, r0.zzzw, c255.xxxy
/*    4.0 */       jmp L10
                label L9
/*    4.1 */       exec
/*   41   */          cndeq r8, c255.zzzx, r3.zxyy, c255.xxxx
/*   42   */          dp4 r7.x___, c23.zxyw, r8
/*   43   */          dp4 r7._y__, c24.zxyw, r8
/*   44   */          dp4 r7.__z_, c25.zxyw, r8
/*   45   */          dp4 r7.___w, c26.zxyw, r8
                label L10
/*    5.0 */       alloc position
/*    5.1 */       exec
/*   46   */          mad r7.__z_, -r7.wwww, c9.xxxx, r7.zzzz
/*   47   */          max oPos, r7, r7
/*    6.0 */       alloc interpolators
/*    6.1 */       exec
/*   48   */          dp3 r8.x___, r6.zxyy, r2.zxyy
/*   49   */          dp3 r8._y__, r6.zxyy, r5.zxyy
/*   50   */          dp3 r8.__z_, r6.zxyy, r1.zxyy
/*   51   */          dp3 r9.x___, r4.zxyy, r1.zxyy
/*   52   */          dp3 r9._y__, r4.zxyy, r2.zxyy
/*   53   */          dp3 r9.__z_, r4.zxyy, r5.zxyy
/*    7.0 */       exec
/*   54   */          add r6.xy__, r0.xyyy, c7.xyyy
              +       maxs r6.__z_, c5.xx
/*   55   */          add o3.xy__, r0.xyyy, c8.xyyy
/*   56   */          max o2.xyz_, r3.xyzz, r3.xyzz
/*   57   */          max o1, r6, r6
/*   58   */          max o0, r7, r7
/*   59   */          dp3 r0._y__, r9.zxyy, r9.zxyy
/*    7.1 */       exec
/*   60   */          dp3 r0.x___, r8.yzxx, r8.yzxx
              +       rsq r0._y__, r_abs[0].y
/*   61   */          mul r1.xyz_, r9.xyzz, r0.yyyy
              +       rsq r0.x___, r_abs[0].x
/*   62   */          mul o4.xyz_, r8.zxyy, r0.xxxx
/*   63   */          mul o6.xyz_, r9.xyzz, r0.yyyy
/*   64   */          mul r2.xyz_, r8.xyzz, r0.xxxx
/*   65   */          mul r0.xyz_, r2.yzxx, r1.yzxx
/*    8.0 */       exece
/*   66   */          mad r0._yzw, r2.xxyz, r1.zzxy, -r0.xxyz
/*   67   */          dp3 r0.x___, r0.wyzz, r0.wyzz
/*   68   */          rsq r0.x___, r_abs[0].x
/*   69   */          mul r0.xyz_, r0.yzww, r0.xxxx
/*   70   */          mul o5.xyz_, r0.xyzz, c6.zzzz
/*    8.1 */       cnop
