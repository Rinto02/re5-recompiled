/*    0.0 */       exec
/*   14   */          vfetch_full r9.wxy_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=5
/*   15   */          vfetch_mini r1, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   16   */          vfetch_mini r7, Offset=3, DataFormat=FMT_8_8_8_8
/*   17   */          vfetch_mini r5.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   18   */          serialize
                      mul r4.xy__, r1.xyyy, c255.zzzz
/*   19   */          maxas r0._, r4.yy
/*    0.1 */       exec    // PredicateClean=false
/*   20   */          mul r0, r7.yyyy, c[37+a0]
/*   21   */          mul r3, r7.yyyy, c[36+a0]
              +       setp_gt r0._, r7.z
/*   22   */          mul r2, r7.yyyy, c[35+a0]
              +       maxas r0._, r4.xx
/*   23   */          mad r2.xyz_, r7.xxxx, c[35+a0].xyzz, r2.xyzz
/*   24   */          mad r10.x___, r7.xxxx, c[35+a0].wwww, r2.wwww
/*   25   */          mad r8.xyz_, r7.xxxx, c[36+a0].xyzz, r3.xyzz
/*    1.0 */       exec
/*   26   */          mad r10._y__, r7.xxxx, c[36+a0].wwww, r3.wwww
/*   27   */          mad r6.xyz_, r7.xxxx, c[37+a0].xyzz, r0.xyzz
/*   28   */          mad r10.__z_, r7.xxxx, c[37+a0].wwww, r0.wwww
/*    1.1 */  (p0) exec
/*   29   */     (p0) mul r11.xy__, r1.zwww, c255.zzzz
/*   30   */     (p0) maxas r0._, r11.yy
/*   31   */     (p0) mul r4, r7.wwww, c[35+a0]
/*   32   */     (p0) mul r3, r7.wwww, c[36+a0]
/*   33   */     (p0) mul r0, r7.wwww, c[37+a0]
              +  (p0) maxas r0._, r11.xx
/*   34   */     (p0) mad r0, r7.zzzz, c[37+a0], r0
/*    2.0 */  (p0) exec
/*   35   */     (p0) mad r3, r7.zzzz, c[36+a0], r3
/*   36   */     (p0) mad r4, r7.zzzz, c[35+a0], r4
/*   37   */     (p0) add r10._y__, r3.wwww, r10.yyyy
              +  (p0) maxs r0._, r4.ww
/*   38   */     (p0) add r2.xyz_, r4.xyzz, r2.xyzz
              +  (p0) adds_prev r10.x___, r10.x
/*   39   */     (p0) add r8.xyz_, r3.xyzz, r8.xyzz
              +  (p0) maxs r0._, r0.ww
/*   40   */     (p0) add r6.xyz_, r0.xyzz, r6.xyzz
              +  (p0) adds_prev r10.__z_, r10.z
/*    2.1 */       exec
/*   41   */          add r11, r1, c4.xxxx
/*   42   */          mul r3._yz_, r11.xxyy, c4.zzzz
              +       maxs r3.x___, c4.yy
/*   43   */          tfetch2D r12, r3.yx, tf16, UseComputedLOD=false, OffsetX=2
/*   44   */          tfetch2D r13, r3.yx, tf16, UseComputedLOD=false, OffsetX=1
/*   45   */          tfetch2D r1, r3.yx, tf16, UseComputedLOD=false
/*   46   */          tfetch2D r0, r3.zx, tf16, UseComputedLOD=false
/*    3.0 */       exec
/*   47   */          tfetch2D r4, r3.zx, tf16, UseComputedLOD=false, OffsetX=1
/*   48   */          tfetch2D r3, r3.zx, tf16, UseComputedLOD=false, OffsetX=2
/*   49   */          serialize
                      mul r3, r7.yyyy, r3
/*   50   */          mul r4, r7.yyyy, r4
/*   51   */          mul r0, r7.yyyy, r0
/*   52   */          mad r0.xyz_, r7.xxxx, r1.xyzz, r0.xyzz
/*    3.1 */       exec    // PredicateClean=false
/*   53   */          mad r1.x___, r7.xxxx, r1.wwww, r0.wwww
/*   54   */          mad r4.xyz_, r7.xxxx, r13.xyzz, r4.xyzz
/*   55   */          mad r1.__z_, r7.xxxx, r13.wwww, r4.wwww
/*   56   */          mad r3.xyz_, r7.xxxx, r12.xyzz, r3.xyzz
/*   57   */          mad r1._y__, r7.xxxx, r12.wwww, r3.wwww
/*   58   */          mul r11._yz_, r11.zzww, c4.zzzz
              +       setp_gt r0._, r7.z
/*    4.0 */  (p0) exec
/*   59   */     (p0) maxs r11.x___, c4.yy
/*   60   */     (p0) tfetch2D r14, r11.yx, tf16, UseComputedLOD=false
/*   61   */     (p0) tfetch2D r15, r11.yx, tf16, UseComputedLOD=false, OffsetX=1
/*   62   */     (p0) tfetch2D r16, r11.yx, tf16, UseComputedLOD=false, OffsetX=2
/*   63   */     (p0) tfetch2D r17, r11.zx, tf16, UseComputedLOD=false, OffsetX=2
/*   64   */     (p0) tfetch2D r12, r11.zx, tf16, UseComputedLOD=false, OffsetX=1
/*    4.1 */  (p0) exec
/*   65   */     (p0) tfetch2D r11, r11.zx, tf16, UseComputedLOD=false
/*   66   */          serialize
                 (p0) mul r13, r7.wwww, r11
/*   67   */     (p0) mul r12, r7.wwww, r12
/*   68   */     (p0) mul r11, r7.wwww, r17
/*   69   */     (p0) mad r11, r7.zzzz, r16, r11
/*   70   */     (p0) mad r12, r7.zzzz, r15, r12
/*    5.0 */  (p0) exec
/*   71   */     (p0) mad r7, r7.zzzz, r14, r13
/*   72   */     (p0) add r1.__z_, r12.wwww, r1.zzzz
              +  (p0) maxs r0._, r7.ww
/*   73   */     (p0) add r0.xyz_, r7.xyzz, r0.xyzz
              +  (p0) adds_prev r1.x___, r1.x
/*   74   */     (p0) add r4.xyz_, r12.xyzz, r4.xyzz
              +  (p0) maxs r0._, r11.ww
/*   75   */     (p0) add r3.xyz_, r11.xyzz, r3.xyzz
              +  (p0) adds_prev r1._y__, r1.y
/*    5.1 */       exec
/*   76   */          dp3 r7.x___, r5.zxyy, r2.zxyy
/*   77   */          dp3 r7._y__, r5.zxyy, r8.zxyy
/*   78   */          dp3 r7.__z_, r5.zxyy, r6.zxyy
/*   79   */          mad r9.xyz_, r9.xyzz, c227.zyxx, c3.zyxx
/*   80   */          dp3 r5.x___, r9.xzyy, r0.zxyy
/*   81   */          dp3 r5._y__, r9.xzyy, r3.zxyy
/*    6.0 */       exec
/*   82   */          dp3 r5.__z_, r9.xzyy, r4.zxyy
/*   83   */          dp3 r0.x___, r9.xzyy, r2.zxyy
/*   84   */          dp3 r0._y__, r9.xzyy, r8.zxyy
/*   85   */          dp3 r0.__z_, r9.xzyy, r6.zxyy
/*   86   */          dp3 r2._y__, r7.zxyy, c1.zxyy
/*   87   */          dp3 r2.__z_, r7.zxyy, c2.zxyy
/*    6.1 */       exec
/*   88   */          add r0.xyz_, r0.xyzz, r10.xyzz
/*   89   */          add r3.xyz_, r5.xyzz, r1.xyzz
              +       sges r3.___w, r_abs[0].x
/*   90   */          dp4 r1.x___, c27.zxyw, r3.yxzw
/*   91   */          dp4 r1._y__, c29.zxyw, r3.yxzw
/*   92   */          dp4 r1.___w, c28.zxyw, r3.yxzw
              +       sges r0.___w, r_abs[0].x
/*   93   */          dp4 r4.x___, c0.zxyw, r0.zxyw
/*    7.0 */       exec
/*   94   */          dp4 r4.__z_, c1.zxyw, r0.zxyw
/*   95   */          dp4 r4._y__, c2.zxyw, r0.zxyw
              +       sges r4.___w, r_abs[0].x
/*   96   */          mad r1.__z_, -r4.yyyy, c5.xxxx, -c5.wwww
/*   97   */          dp4 r3.x___, c23.zxyw, r4.yxzw
/*   98   */          dp4 r3._y__, c24.zxyw, r4.yxzw
/*   99   */          dp4 r0._y__, c25.zxyw, r4.yxzw
/*    7.1 */       exec
/*  100   */          dp4 r3.__z_, c26.zxyw, r4.yxzw
/*  101   */          add r0.x_zw, r4.xzzy, -r1.xwwy
/*  102   */          dp3 r0.x___, r0.wxzz, r0.wxzz
/*  103   */          add r1.xy_w, r1.xyww, -r4.xyzz
              +       rsq r0.x___, r_abs[0].x
/*  104   */          dp3 r2.x___, r7.zxyy, c0.zxyy
              +       mulsc r0.x___, c5.y, r0.x
/*  105   */          min r0.x___, r0.xxxx, c255.wwww
/*    8.0 */       exec
/*  106   */          mad r0.x_zw, r1.xyyw, r0.xxxx, r4.xyyz
/*  107   */          add r0.x_zw, -r0.xzzw, r4.xyyz
/*  108   */          mul r0.x_zw, r0.xwwz, c5.zzzz
/*  109   */          add r5.xyz_, r4.xzyy, -r0.xzww
              +       sges r5.___w, r_abs[0].x
/*  110   */          dp4 r1.x___, c30.zxyw, r5.zxyw
/*  111   */          dp4 r1._y__, c31.zxyw, r5.zxyw
              +       maxs r4.x___, r1.zz
/*    8.1 */       exec
/*  112   */          dp4 r1.___w, c32.zxyw, r5.zxyw
              +       maxs r4._y__, c255.ww
/*  113   */          dp4 r1.__z_, c33.zxyw, r5.zxyw
              +       mins r3.___w, r4.xy
/*    9.0 */       cjmp b0, L22
/*    9.1 */       exec
/*  114   */          rcp r0.x___, r3.z
/*  115   */          mad r0._y__, -r0.xxxx, c255.xxxx, r0.yyyy
/*  116   */          dp2add r0.x___, r2.xyyy, r2.xyyy, c255.yyyy
/*  117   */          max r0.___w, r3.zzzz, r3.zzzz
              +       rsq r0.x___, r_abs[0].x
/*  118   */          mul r0.x_z_, r2.xyyy, r0.xxxx
/*  119   */          mul r0.x_z_, r0.zxxx, c34.wzzz
/*   10.0 */       exec
/*  120   */          mad r0.x_z_, r0.zxxx, r3.zzzz, r3.xyyy
/*   10.1 */       jmp L23
                label L22
/*   11.0 */       exec
/*  121   */          dp3 r2.x___, r0.wxzz, r2.zxyy
/*  122   */          cndgt r0.x_zw, r2.xxxx, r3.xyyz, r1.xyyz
/*  123   */          cndgt r0._y__, r2.xxxx, r0.yyyy, r1.wwww
                label L23
/*   11.1 */       alloc position
/*   12.0 */       exec
/*  124   */          max oPos, r0.xzyw, r0.xzyw
/*   12.1 */       alloc interpolators
/*   13.0 */       exece
/*  125   */          max o0, r3.xywz, r3.xywz
/*  126   */          max o1, r1.xywz, r1.xywz
/*   13.1 */       cnop
