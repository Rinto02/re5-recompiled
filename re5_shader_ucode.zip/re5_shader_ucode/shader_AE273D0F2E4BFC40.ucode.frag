/*    0.0 */       exec
/*   18   */          tfetch2D r9._w__, r4.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exec    // PredicateClean=false
/*   19   */          sgt r4.x___, c2.zzzz, r0.wwww
/*   20   */          setp_ne_push r9.x___, c255.yyyy, r4.xxxx
/*   21   */          add r4.x___, r9.yyyy, -c23.xxxx
              +       sgts r4._y__, -r_abs[0].x
/*   22   */          kill_gt r0._, c255.yyyy, r4.xxxx
              +       sgts r4.x___, -r_abs[0].x
/*    1.1 */ (!p0) jmp L35
/*    2.0 */       exec    // PredicateClean=false
/*   23   */     (p0) dp3 r4._y__, r0.zxyy, r0.zxyy
/*   24   */     (p0) sgt r4.x___, c2.xxxx, r0.wwww
              +  (p0) rsq r4._y__, r_abs[4].y
/*   25   */     (p0) mul r4._yzw, r4.yyyy, -c0.xxyz
/*   26   */     (p0) dp3 r0._y__, r4.wyzz, r0.zxyy
/*   27   */          setp_ne_push r9.x___, r9.xxxx, r4.xxxx
/*    2.1 */ (!p0) jmp L13
/*    3.0 */  (p0) exec
/*   28   */     (p0) rcp r0.x___, r1.w
/*   29   */     (p0) mul r2.xyz_, r0.xxxx, r1.yzxx
/*   30   */     (p0) tfetch2D r8.x___, r2.zx, tf1, OffsetX=-2, OffsetY=1
/*   31   */     (p0) tfetch2D r8.___x, r2.zx, tf1, OffsetX=1, OffsetY=1
/*   32   */     (p0) tfetch2D r8.__x_, r2.zx, tf1, OffsetY=1
/*   33   */     (p0) tfetch2D r8._x__, r2.zx, tf1, OffsetX=-1, OffsetY=1
/*    3.1 */  (p0) exec
/*   34   */     (p0) tfetch2D r10.x___, r2.zx, tf1, OffsetX=-2
/*   35   */     (p0) tfetch2D r10.___x, r2.zx, tf1, OffsetX=1
/*   36   */     (p0) tfetch2D r10.__x_, r2.zx, tf1
/*   37   */     (p0) tfetch2D r10._x__, r2.zx, tf1, OffsetX=-1
/*   38   */     (p0) tfetch2D r5.x___, r2.zx, tf1, OffsetX=-2, OffsetY=-1
/*   39   */     (p0) tfetch2D r5.___x, r2.zx, tf1, OffsetX=1, OffsetY=-1
/*    4.0 */  (p0) exec
/*   40   */     (p0) tfetch2D r5.__x_, r2.zx, tf1, OffsetY=-1
/*   41   */     (p0) tfetch2D r5._x__, r2.zx, tf1, OffsetX=-1, OffsetY=-1
/*   42   */     (p0) tfetch2D r6.x___, r2.zx, tf1, OffsetX=-2, OffsetY=-2
/*   43   */     (p0) tfetch2D r6.___x, r2.zx, tf1, OffsetX=1, OffsetY=-2
/*   44   */     (p0) tfetch2D r6.__x_, r2.zx, tf1, OffsetY=-2
/*   45   */     (p0) tfetch2D r6._x__, r2.zx, tf1, OffsetX=-1, OffsetY=-2
/*    4.1 */       exec    // PredicateClean=false
/*   46   */          serialize
                 (p0) subsc r0.__z_, c255.x, r2.y
/*   47   */     (p0) sge r3, r6, r0.zzzz
/*   48   */     (p0) sge r4, r5, r0.zzzz
/*   49   */     (p0) sge r2, r10, r0.zzzz
/*   50   */     (p0) sge r7, r8, r0.zzzz
              +  (p0) mulsc r0.x___, c1.y, r0.x
/*   51   */          setp_gt_push r9.x___, r9.xxxx, c5.xxxx
/*    5.0 */  (p0) exec
/*   52   */     (p0) add r7, -r0.zzzz, r8
/*   53   */     (p0) add r2, -r0.zzzz, r10
/*   54   */     (p0) add r4, -r0.zzzz, r5
/*   55   */     (p0) add r3, -r0.zzzz, r6
/*   56   */     (p0) mul_sat r3, r3, c5.xxxx
/*   57   */     (p0) mul_sat r4, r4, c5.xxxx
/*    5.1 */       exec    // PredicateClean=false
/*   58   */     (p0) mul_sat r2, r2, c5.xxxx
/*   59   */     (p0) mul_sat r7, r7, c5.xxxx
/*   60   */          setp_pop r9.x___, r9.x
/*   61   */     (p0) mul r0.x_z_, r0.xxxx, r1.xyyy
/*   62   */     (p0) frc r0.x_z_, r0.xzzz
/*   63   */     (p0) add r1, r2, r4
              +  (p0) subsc r0.___w, c255.x, r0.z
/*    6.0 */  (p0) exec
/*   64   */     (p0) mad r1, r0.wwww, r3, r1
/*   65   */     (p0) mad r1, r0.zzzz, r7, r1
/*   66   */     (p0) dp3 r0.___w, r1.zxyy, c255.xxxx
              +  (p0) subs r1.x___, r1.wx
/*   67   */     (p0) mad r0.x___, r1.xxxx, r0.xxxx, r0.wwww
/*   68   */     (p0) mul r0.___w, r0.xxxx, c255.zzzz
              +  (p0) maxs r0.x___, c255.xx
                label L13
/*    6.1 */       exec    // PredicateClean=false
/*   69   */          setp_inv r9.x___, r9.x
/*    7.0 */ (!p0) jmp L34
/*    7.1 */       exec    // PredicateClean=false
/*   70   */     (p0) sgt r1.x___, c2.yyyy, r0.wwww
/*   71   */          setp_ne_push r9.x___, r9.xxxx, r1.xxxx
/*    8.0 */ (!p0) jmp L24
/*    8.1 */  (p0) exec
/*   72   */     (p0) rcp r0.x___, r2.w
/*   73   */     (p0) mul r1.xyz_, r0.xxxx, r2.yzxx
/*   74   */     (p0) tfetch2D r10.x___, r1.zx, tf2, OffsetX=-2, OffsetY=1
/*   75   */     (p0) tfetch2D r10.___x, r1.zx, tf2, OffsetX=1, OffsetY=1
/*   76   */     (p0) tfetch2D r10.__x_, r1.zx, tf2, OffsetY=1
/*   77   */     (p0) tfetch2D r10._x__, r1.zx, tf2, OffsetX=-1, OffsetY=1
/*    9.0 */  (p0) exec
/*   78   */     (p0) tfetch2D r4.x___, r1.zx, tf2, OffsetX=-2
/*   79   */     (p0) tfetch2D r4.___x, r1.zx, tf2, OffsetX=1
/*   80   */     (p0) tfetch2D r4.__x_, r1.zx, tf2
/*   81   */     (p0) tfetch2D r4._x__, r1.zx, tf2, OffsetX=-1
/*   82   */     (p0) tfetch2D r5.x___, r1.zx, tf2, OffsetX=-2, OffsetY=-1
/*   83   */     (p0) tfetch2D r5.___x, r1.zx, tf2, OffsetX=1, OffsetY=-1
/*    9.1 */  (p0) exec
/*   84   */     (p0) tfetch2D r5.__x_, r1.zx, tf2, OffsetY=-1
/*   85   */     (p0) tfetch2D r5._x__, r1.zx, tf2, OffsetX=-1, OffsetY=-1
/*   86   */     (p0) tfetch2D r6.x___, r1.zx, tf2, OffsetX=-2, OffsetY=-2
/*   87   */     (p0) tfetch2D r6.___x, r1.zx, tf2, OffsetX=1, OffsetY=-2
/*   88   */     (p0) tfetch2D r6.__x_, r1.zx, tf2, OffsetY=-2
/*   89   */     (p0) tfetch2D r6._x__, r1.zx, tf2, OffsetX=-1, OffsetY=-2
/*   10.0 */       exec    // PredicateClean=false
/*   90   */          serialize
                 (p0) subsc r0.__z_, c255.x, r1.y
/*   91   */     (p0) sge r1, r6, r0.zzzz
/*   92   */     (p0) sge r3, r5, r0.zzzz
/*   93   */     (p0) sge r7, r4, r0.zzzz
/*   94   */     (p0) sge r8, r10, r0.zzzz
              +  (p0) mulsc r0.x___, c1.y, r0.x
/*   95   */          setp_gt_push r9.x___, r9.xxxx, c5.xxxx
/*   10.1 */  (p0) exec
/*   96   */     (p0) add r8, -r0.zzzz, r10
/*   97   */     (p0) add r4, -r0.zzzz, r4
/*   98   */     (p0) add r3, -r0.zzzz, r5
/*   99   */     (p0) add r1, -r0.zzzz, r6
/*  100   */     (p0) mul_sat r1, r1, c5.xxxx
/*  101   */     (p0) mul_sat r3, r3, c5.xxxx
/*   11.0 */       exec    // PredicateClean=false
/*  102   */     (p0) mul_sat r7, r4, c5.xxxx
/*  103   */     (p0) mul_sat r8, r8, c5.xxxx
/*  104   */          setp_pop r9.x___, r9.x
/*  105   */     (p0) mul r0.x_z_, r0.xxxx, r2.xyyy
/*  106   */     (p0) frc r0.x_z_, r0.xzzz
/*  107   */     (p0) add r2, r7, r3
              +  (p0) subsc r0.___w, c255.x, r0.z
/*   11.1 */  (p0) exec
/*  108   */     (p0) mad r1, r0.wwww, r1, r2
/*  109   */     (p0) mad r1, r0.zzzz, r8, r1
/*  110   */     (p0) dp3 r0.___w, r1.zxyy, c255.xxxx
              +  (p0) subs r1.x___, r1.wx
/*  111   */     (p0) mad r0.x___, r1.xxxx, r0.xxxx, r0.wwww
/*  112   */     (p0) mul r0.___w, r0.xxxx, c255.zzzz
              +  (p0) maxs r0.x___, c255.xx
                label L24
/*   12.0 */       exec    // PredicateClean=false
/*  113   */          setp_inv r9.x___, r9.x
/*   12.1 */ (!p0) jmp L33
/*   13.0 */  (p0) exec
/*  114   */     (p0) rcp r0.x___, r3.w
/*  115   */     (p0) mul r1.xyz_, r0.xxxx, r3.yzxx
/*  116   */     (p0) tfetch2D r10.x___, r1.zx, tf3, OffsetX=-2, OffsetY=1
/*  117   */     (p0) tfetch2D r10.___x, r1.zx, tf3, OffsetX=1, OffsetY=1
/*  118   */     (p0) tfetch2D r10.__x_, r1.zx, tf3, OffsetY=1
/*  119   */     (p0) tfetch2D r10._x__, r1.zx, tf3, OffsetX=-1, OffsetY=1
/*   13.1 */  (p0) exec
/*  120   */     (p0) tfetch2D r4.x___, r1.zx, tf3, OffsetX=-2
/*  121   */     (p0) tfetch2D r4.___x, r1.zx, tf3, OffsetX=1
/*  122   */     (p0) tfetch2D r4.__x_, r1.zx, tf3
/*  123   */     (p0) tfetch2D r4._x__, r1.zx, tf3, OffsetX=-1
/*  124   */     (p0) tfetch2D r5.x___, r1.zx, tf3, OffsetX=-2, OffsetY=-1
/*  125   */     (p0) tfetch2D r5.___x, r1.zx, tf3, OffsetX=1, OffsetY=-1
/*   14.0 */  (p0) exec
/*  126   */     (p0) tfetch2D r5.__x_, r1.zx, tf3, OffsetY=-1
/*  127   */     (p0) tfetch2D r5._x__, r1.zx, tf3, OffsetX=-1, OffsetY=-1
/*  128   */     (p0) tfetch2D r6.x___, r1.zx, tf3, OffsetX=-2, OffsetY=-2
/*  129   */     (p0) tfetch2D r6.___x, r1.zx, tf3, OffsetX=1, OffsetY=-2
/*  130   */     (p0) tfetch2D r6.__x_, r1.zx, tf3, OffsetY=-2
/*  131   */     (p0) tfetch2D r6._x__, r1.zx, tf3, OffsetX=-1, OffsetY=-2
/*   14.1 */       exec    // PredicateClean=false
/*  132   */          serialize
                 (p0) subsc r0.__z_, c255.x, r1.y
/*  133   */     (p0) sge r2, r6, r0.zzzz
/*  134   */     (p0) sge r8, r5, r0.zzzz
/*  135   */     (p0) sge r1, r4, r0.zzzz
/*  136   */     (p0) sge r7, r10, r0.zzzz
              +  (p0) mulsc r0.x___, c1.y, r0.x
/*  137   */          setp_gt_push r9.x___, r9.xxxx, c5.xxxx
/*   15.0 */  (p0) exec
/*  138   */     (p0) add r7, -r0.zzzz, r10
/*  139   */     (p0) add r1, -r0.zzzz, r4
/*  140   */     (p0) add r4, -r0.zzzz, r5
/*  141   */     (p0) add r2, -r0.zzzz, r6
/*  142   */     (p0) mul_sat r2, r2, c5.xxxx
/*  143   */     (p0) mul_sat r8, r4, c5.xxxx
/*   15.1 */       exec    // PredicateClean=false
/*  144   */     (p0) mul_sat r1, r1, c5.xxxx
/*  145   */     (p0) mul_sat r7, r7, c5.xxxx
/*  146   */          setp_pop r9.x___, r9.x
/*  147   */     (p0) mad_sat r0.__z_, r0.wwww, c3.xxxx, c3.yyyy
/*  148   */     (p0) mul r0.x__w, r0.xxxx, r3.xyyy
/*  149   */     (p0) frc r0.x__w, r0.xwww
/*   16.0 */  (p0) exec
/*  150   */     (p0) add r1, r1, r8
              +  (p0) subsc r3.x___, c255.x, r0.w
/*  151   */     (p0) mad r1, r3.xxxx, r2, r1
/*  152   */     (p0) mad r1, r0.wwww, r7.yxwz, r1.yxwz
/*  153   */     (p0) dp3 r1.x___, r1.wyxx, c255.xxxx
              +  (p0) subs r1._y__, r1.zy
/*  154   */     (p0) mad r0.x___, r1.yyyy, r0.xxxx, r1.xxxx
/*  155   */     (p0) mul r0.___w, r0.xxxx, c255.zzzz
              +  (p0) subsc r0.x___, c255.x, r0.z
                label L33
/*   16.1 */       exec    // PredicateClean=false
/*  156   */          setp_pop r9.x___, r9.x
                label L34
/*   17.0 */       exec    // PredicateClean=false
/*  157   */          setp_pop r9.x___, r9.x
/*  158   */     (p0) mulsc_sat r0._y__, c4.x, r0.y
/*  159   */     (p0) subsc r0._y__, c255.x, r0.y
/*  160   */     (p0) max r0._y__, r0.yyyy, r0.wwww
/*  161   */     (p0) mul r4.x___, r0.yyyy, r0.xxxx
              +  (p0) maxs r4._y__, r9.yy
                label L35
/*   17.1 */       exece
/*  162   */          max oC0, r4.xxxy, r4.xxxy
