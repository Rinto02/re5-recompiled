/*    0.0 */       exec
/*   21   */          vfetch_full r10.zyx1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*   22   */          vfetch_mini r12, Offset=3, DataFormat=FMT_8_8_8_8
/*   23   */          vfetch_mini r1.wxzy, Offset=4, DataFormat=FMT_16_16_16_16, Signed=true
/*   24   */          vfetch_mini r9.zywx, Offset=6, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   25   */          vfetch_mini r0.zyxw, Offset=7, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   26   */          serialize
                      max r7.xyz_, c255.zwww, c255.zwww
/*    0.1 */       exec
/*   27   */          max r8.xyz_, c255.wzww, c255.wzww
/*   28   */          max r2.xyz_, c255.wwzz, c255.wwzz
/*   29   */          max r5.xyz_, c255.wzww, c255.wzww
              +       maxs r13.x___, c255.zz
/*   30   */          max r4.xyz_, c255.wwzz, c255.wwzz
              +       maxs r13._y__, c255.ww
/*   31   */          add r11.xyz_, r10.xyzz, -c30.zyxx
              +       maxs r1.x___, r1.xx
/*   32   */          dp3 r2.___w, r11.xzyy, r11.xzyy
              +       mulsc r1.x___, c251.w, r1.x
/*    1.0 */       exec
/*   33   */          dp4 r1.x___, r1.xxxx, c8.wzxy
              +       rsq r2.___w, r_abs[2].w
/*   34   */          mul r3.xyz_, r11.zyxx, r2.wwww
              +       maxs r13.__z_, c255.ww
/*    1.1 */       cjmp !b1, L11
/*    2.0 */       exec
/*   35   */          dp4 r11.x___, r10.wxzy, c26.wzxy
/*   36   */          dp4 r11._y__, r10.wxzy, c27.wzxy
              +       mulsc r6._y__, c251.z, r1.y
/*   37   */          dp4 r2.___w, r10.wxzy, c29.wzxy
              +       mulsc r6.x___, c251.z, r1.w
/*   38   */          dp4 r2.x___, r10.wxzy, c28.wzxy
              +       rcp r2._y__, r2.w
/*   39   */          mad r11.__z_, r1.xxxx, r2.yyyy, r2.xxxx
/*    2.1 */       cjmp !b2, L9
/*    3.0 */       exec
/*   40   */          add r2.xyz_, r9.xyww, c251.xxxx
/*   41   */          add r4.xyz_, r0.xyzz, c251.xxxx
/*   42   */          mul r7.xyz_, r4.zyxx, c250.yyyy
/*   43   */          mul r4.xyz_, r2.zyxx, c250.yyyy
/*   44   */          mul r2.xyz_, r7.yxzz, r4.xzyy
/*   45   */          mad r5.xyz_, r7.xzyy, r4.yxzz, -r2.xyzz
/*    3.1 */       exec
/*   46   */          dp3 r2.x___, r5.xzyy, r5.xzyy
/*   47   */          max r9.xy_w, r10.yzxx, r10.yzxx
              +       rsq r2.x___, r_abs[2].x
/*   48   */          mul r2.xyz_, r5.xyzz, r2.xxxx
/*   49   */          cndgt r5.xyz_, r9.zzzz, -r2.zyxx, r2.zyxx
/*    4.0 */       jmp L10
                label L9
/*    4.1 */       exec
/*   50   */          sgt r9.xy_w, -r_abs[0].xxxx, c255.wwww
                label L10
/*    5.0 */       jmp L23
                label L11
/*    5.1 */       exec
/*   51   */          mul r4.xy__, r1.ywww, c252.xxxx
              +       addsc r0._y__, c251.x, r0.y
/*   52   */          mul r6.xy__, r4.yxxx, c7.xyyy
              +       addsc r0.__z_, c251.x, r0.z
/*    6.0 */       cjmp !b2, L17
/*    6.1 */       exec
/*   53   */          add r2.___w, r9.xxxx, -c252.xxxx
              +       subsc r0.x___, -c252.w, -r0.x
/*   54   */          mad r3.___w, r9.zzzz, c254.wwww, r2.wwww
/*   55   */          mul r5.xy__, r0.yzzz, c252.yyyy
              +       mulsc r5.__z_, c252.y, r0.x
/*   56   */          mul r4.xyz_, r5.zxyy, r11.zxyy
/*   57   */          mad r5.xyz_, r5.zyxx, r11.yxzz, -r4.yxzz
/*   58   */          dp3 r2.___w, r5.zxyy, r5.zxyy
/*    7.0 */       exec
/*   59   */          mul r4.xy__, r3.wwww, c253.xyyy
              +       rsq r2.___w, r_abs[2].w
/*   60   */          mul r5.xyz_, r5.zyxx, r2.wwww
/*   61   */          mul r5.xyz_, r5.zxyy, c253.xyyy
/*   62   */          mad r10.xyz_, r5.yzxx, r4.xxyy, r10.xyzz
/*   63   */          dp4 r3.___w, r10.wxzy, c28.wzxy
              +       sgts r9._y__, -r_abs[0].x
/*   64   */          dp4 r11.x___, r10.wxzy, c26.wzxy
              +       sgts r9.x___, -r_abs[0].x
/*    7.1 */       exec
/*   65   */          dp4 r2.___w, r10.wxzy, c29.wzxy
              +       sgts r9.___w, -r_abs[0].x
/*   66   */          dp4 r11._y__, r10.wxzy, c27.wzxy
              +       rcp r4.x___, r2.w
/*   67   */          mad r11.__z_, r1.xxxx, r4.xxxx, r3.wwww
/*    8.0 */       jmp L22
                label L17
/*    8.1 */       exec
/*   68   */          mad r2.x_z_, r9.yxxx, c254.wzzz, r9.wzzz
/*   69   */          mul r4.x_z_, r2.xxxx, c254.yxxx
/*   70   */          mul r4._y__, -r4.zzzz, c251.yyyy
              +       mulsc r5.x___, c255.x, r0.y
/*   71   */          add r2._y_w, r4.xxyy, c252.zzzz
              +       mulsc r5._y__, c255.x, r0.z
/*   72   */          frc r2._y_w, r2.yyww
              +       mulsc r5.__z_, c255.y, r0.x
/*   73   */          mad r2.xy__, r2.ywww, c250.zzzz, c250.xxxx
/*    9.0 */       exec
/*   74   */          mul r4._yz_, r5.xxyy, r2.zzzz
              +       cos r2.__z_, r2.x
/*   75   */          mul r4.x___, r4.zzzz, r5.zzzz
              +       sin r2.___w, r2.x
/*   76   */          mul r4, r4.xxyy, r2.wzzw
/*   77   */          subs r7.x___, r4.yw
/*   78   */          add r7.__z_, r4.xxxx, r4.zzzz
              +       cos r7._y__, r2.y
/*   79   */          mul r5.xyz_, r7.xyzz, c1.xxyy
/*    9.1 */       exec
/*   80   */          mul r4.xy_w, r7.yxzz, c2.xxyy
/*   81   */          mul r7.xyz_, r7.xyzz, c0.xxyy
              +       sin r2._y__, r2.y
/*   82   */          mad r2.__z_, -r2.yyyy, c0.yyyy, r7.yyyy
/*   83   */          mad r2.x___, -r2.yyyy, c2.yyyy, r4.xxxx
/*   84   */          mad r2._y__, -r2.yyyy, c1.yyyy, r5.yyyy
/*   85   */          add r4.x___, r7.zzzz, r7.xxxx
              +       adds r4.__z_, r5.zx
/*   10.0 */       exec
/*   86   */          mul r13.xyz_, r3.zyxx, c253.zzzz
              +       adds r4._y__, r4.wy
/*   87   */          add r9.xy_w, r4.zxyy, r10.yzxx
/*   88   */          mul r4.xyz_, r13.yzxx, r2.xyzz
              +       sges r9.__z_, r_abs[0].x
/*   89   */          mad r4._yzw, r13.yyzx, r2.zzxy, -r4.yyzx
/*   90   */          dp4 r3.___w, c28.zxyw, r9.wyxz
/*   91   */          dp4 r11.x___, c26.zxyw, r9.wyxz
/*   10.1 */       exec
/*   92   */          dp4 r11._y__, c27.zxyw, r9.wyxz
/*   93   */          dp3 r4.x___, r4.ywzz, r4.ywzz
/*   94   */          dp4 r2.___w, c29.zxyw, r9.wyxz
              +       rsq r4.x___, r_abs[4].x
/*   95   */          mul r8.xyz_, r4.yzww, r4.xxxx
              +       rcp r4.x___, r2.w
/*   96   */          mad r11.__z_, r1.xxxx, r4.xxxx, r3.wwww
                label L22
/*   11.0 */       exec
/*   97   */          max r5.xyz_, r8.zyxx, r8.zyxx
/*   98   */          max r7.xyz_, r2.zyxx, r2.zyxx
/*   99   */          max r4.xyz_, r13.zyxx, r13.zyxx
                label L23
/*   11.1 */       exec
/*  100   */          mul r0._y__, r1.zzzz, c252.wwww
              +       rcp r0.x___, r2.w
/*  101   */          mad r0.x___, r0.xxxx, r11.zzzz, c25.zzzz
/*  102   */          mul r12.xyz_, r0.yyyy, r12.xyzz
              +       rcp r0.x___, r0.x
/*  103   */          mul r2.__z_, r0.xxxx, c25.wwww
              +       mulsc r6.___w, c5.x, r0.w
/*   12.0 */       cjmp !b4, L26
/*   12.1 */       exec
/*  104   */          dp4 r0._y__, r10.wxzy, c6.wzxy
/*  105   */          subsc r0.x___, -c9.x, -r0.y
/*  106   */          mulsc_sat r0.x___, c9.y, r0.x
/*  107   */          mul r12.___w, r0.xxxx, r12.wwww
                label L26
/*   13.0 */       cjmp !b0, L30
/*   13.1 */       exec
/*  108   */          add r0.xyz_, r10.xyzz, -c30.zyxx
/*  109   */          dp3 r0.x___, r0.xzyy, r0.xzyy
/*  110   */          max r1.xyz_, c3.xyzz, c3.xyzz
              +       sqrt r0._y__, r_abs[0].x
/*  111   */          subsc r0.x___, -c31.x, -r0.y
/*  112   */          mulsc r0.x___, c31.z, r0.x
/*  113   */          min r0.x___, r0.xxxx, c3.wwww
/*   14.0 */       exec
/*  114   */          max r1.___w, r0.xxxx, c255.wwww
/*   14.1 */       jmp L31
                label L30
/*   15.0 */       exec
/*  115   */          sgt r1, -r_abs[0].xxxx, c255.wwww
                label L31
/*   15.1 */       cjmp !b3, L34
/*   16.0 */       exec
/*  116   */          sgt r0.x___, c253.wwww, r12.wwww
/*  117   */          cndeq r11.___w, r0.xxxx, r2.wwww, c253.zzzz
/*   16.1 */       jmp L35
                label L34
/*   17.0 */       exec
/*  118   */          maxs r11.___w, r2.ww
                label L35
/*   17.1 */       alloc position
/*   18.0 */       exec
/*  119   */          max oPos, r11, r11
/*   18.1 */       alloc interpolators
/*   19.0 */       exec
/*  120   */          dp3 r0.x___, r3.zxyy, r4.zxyy
/*  121   */          add r0.x___, -r0.xxxx, c255.zzzz
              +       maxs r2.x___, r11.xx
/*  122   */          max o2.xyz_, r7.xyzz, r7.xyzz
/*  123   */          max o3.xyz_, r5.xyzz, r5.xyzz
/*  124   */          max o4.xyz_, r4.xyzz, r4.xyzz
/*  125   */          max o5.xyz_, r9.yxww, r9.yxww
/*   19.1 */       exec
/*  126   */          max o0, r12.zyxw, r12.zyxw
/*  127   */          max o7, r1, r1
/*  128   */          mul r0._y__, r_abs[0].xxxx, r_abs[0].xxxx
              +       maxs r2._y__, r11.yy
/*  129   */          max o6, r2, r2
/*  130   */          muls r0._y__, r0.yy
/*  131   */          mul r0.x___, r0.yyyy, r_abs[0].xxxx
/*   20.0 */       exece
/*  132   */          mad_sat r0.x___, r0.xxxx, c4.xxxx, c4.yyyy
/*  133   */          subsc r6.__z_, c255.z, r0.x
/*  134   */          max o1, r6, r6
/*   20.1 */       cnop
