/*    0.0 */       exec
/*    8   */          vfetch_full r2.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*    9   */          vfetch_mini r6.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*   10   */          vfetch_mini r8, Offset=4, DataFormat=FMT_8_8_8_8, Signed=true
/*   11   */          vfetch_mini r0._yx_, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   12   */          vfetch_mini r1.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   13   */          vfetch_mini r0.y__x, Offset=7, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       exec
/*   14   */          serialize
                      max r7, c28, c28
/*   15   */          max r3, c29, c29
/*   16   */          max r5, c30, c30
/*   17   */          cndeq r4, c255.zzzx, r2.zxyy, c255.xxxx
/*   18   */          dp4 r2.x___, r7.zxyw, r4
/*   19   */          dp4 r2._y__, r3.zxyw, r4
/*    1.0 */       exec
/*   20   */          dp4 r2.__z_, r5.zxyw, r4
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   21   */          cndeq r4, c255.zzzx, r2.zxyy, c255.xxxx
/*   22   */          dp4 r9.x___, c0.zxyw, r4
/*   23   */          dp4 r9._y__, c1.zxyw, r4
/*   24   */          dp4 r9.__z_, c2.zxyw, r4
/*   25   */          dp2add r2.___w, r9.xyyy, r9.xyyy, c255.zzzz
/*   26   */          dp3 r1.__z_, r9.zxyy, r9.zxyy
/*    2.1 */       exec
/*   27   */          sqrt r1.___w, r_abs[1].z
/*   28   */          mad r1.__z_, r1.wwww, c27.xxxx, c27.yyyy
/*   29   */          add r4.x___, -r9.zzzz, r1.wwww
/*   30   */          mul r4._yz_, r9.xxyy, r1.wwww
/*   31   */          mul r4.xy__, r4.zyyy, r4.xxxx
              +       rcp r2.___w, r2.w
/*   32   */          mul r4.xy__, r4.yxxx, r2.wwww
/*    3.0 */       exec
/*   33   */          cndge r4.__zw, r9.zzzz, r1.zzzw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   34   */          cndeq r9, c255.zzzx, r2.zxyy, c255.xxxx
/*   35   */          dp4 r4.x___, c23.zxyw, r9
/*   36   */          dp4 r4._y__, c24.zxyw, r9
/*   37   */          dp4 r4.__z_, c25.zxyw, r9
/*   38   */          dp4 r4.___w, c26.zxyw, r9
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   39   */          mad r4.__z_, -r4.wwww, c6.xxxx, r4.zzzz
/*   40   */          max oPos, r4, r4
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   41   */          dp3 r9.x___, r6.zxyy, r3.zxyy
/*   42   */          dp3 r9._y__, r6.zxyy, r7.zxyy
/*   43   */          dp3 r9.__z_, r6.zxyy, r5.zxyy
              +       maxs r6.x___, r8.xx
/*   44   */          max r6._y__, r8.yyyy, r8.yyyy
              +       maxs r6.__z_, r8.zz
/*   45   */          dp3 r5.__z_, r6.zxyy, r5.zxyy
              +       maxs r8.__z_, c31.xx
/*   46   */          dp3 r5._y__, r6.zxyy, r3.zxyy
              +       addsc r8.x___, c4.x, r0.y
/*    6.1 */       exec
/*   47   */          dp3 r5.x___, r6.zxyy, r7.zxyy
              +       addsc r8._y__, c4.y, r0.z
/*   48   */          add o3.xy__, r1.xyyy, c5.xyyy
/*   49   */          max o4.xy__, r0.xwww, r0.xwww
/*   50   */          max o2.xyz_, r2.xyzz, r2.xyzz
/*   51   */          max o5.xyz_, r5.xyzz, r5.xyzz
/*   52   */          max o7.xyz_, r9.yxzz, r9.yxzz
/*    7.0 */       exec
/*   53   */          max o1, r8, r8
/*   54   */          max o0, r4, r4
/*   55   */          mul r1.xy__, r5.xxxx, r9.zxxx
/*   56   */          mul r0, r5.yzyz, r9.zxyy
/*   57   */          add r0.__z_, r1.yyyy, -r0.zzzz
/*   58   */          add r0.___w, r0.wwww, -r1.xxxx
              +       subs r0._y__, r0.xy
/*    7.1 */       exece
/*   59   */          dp3 r0.x___, r0.zyww, r0.zyww
/*   60   */          rsq r0.x___, r_abs[0].x
/*   61   */          mul r0.xyz_, r0.yzww, r0.xxxx
/*   62   */          mul o6.xyz_, r0.xzyy, c3.zzzz
