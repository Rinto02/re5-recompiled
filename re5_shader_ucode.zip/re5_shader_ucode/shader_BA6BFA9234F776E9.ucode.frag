/*    0.0 */       exec
/*    4   */          tfetch2D r6.xy__, r1.xy, tf2
/*    5   */          serialize
                      add r5.xyz_, r5.xyzz, -c23.xyzz
/*    6   */          mad r6.xy__, r6.xyyy, c254.yyyy, c254.zzzz
/*    7   */          dp2add r2.___w, -r6.yxxx, r6.yxxx, c254.xxxx
/*    8   */          dp3 r3.___w, r5.zxyy, r5.zxyy
              +       sqrt r2.___w, r_abs[2].w
/*    9   */          mul r4.xyz_, r2.wwww, r4.xyzz
/*    0.1 */       exec
/*   10   */          mad r3.xyz_, r6.yyyy, r3.xyzz, r4.xyzz
/*   11   */          mad r3.xyz_, r6.xxxx, r2.xzyy, r3.xzyy
/*   12   */          dp3 r2.___w, r3.yxzz, r3.yxzz
              +       rsq r2.x___, r_abs[3].w
/*   13   */          mul r2.xyz_, r5.xyzz, r2.xxxx
              +       rsq r2.___w, r_abs[2].w
/*   14   */          mul r6.xyz_, r3.xzyy, r2.wwww
/*   15   */          dp3 r3.x___, r2.zxyy, r6.zxyy
/*    1.0 */       exec
/*   16   */          mul r8, r6.xyzz, r6.yzzx
              +       maxs r6.___w, c254.xx
/*   17   */          dp4 r3._y__, c18.zxyw, r6.zxyw
/*   18   */          dp4 r3.__z_, r8.wzxy, c21.wzxy
/*   19   */          add r3.__zw, r3.yyyx, r3.zzzx
/*   20   */          mad r2.xyz_, -r6.xyzz, r3.wwww, r2.xyzz
/*   21   */          cube r2, r2.zzxy, r2.yxzz
/*    1.1 */       exec
/*   22   */          max r4.__z_, r2.wwww, r2.wwww
              +       rcp r3.x___, r_abs[2].z
/*   23   */          mad r4.xy__, r2.yxxx, r3.xxxx, c254.wwww
/*   24   */          tfetch2D r5.xyz_, r1.xy, tf3
/*   25   */          tfetchCube r9, r4.xyz, tf0, UseComputedLOD=false
/*   26   */          tfetch2D r2, r1.xy, tf1
/*    2.0 */       alloc colors
/*    2.1 */       exec
/*   27   */          max r3.x___, r9.wwww, c255.xxxx
/*   28   */          mul r4.xyz_, r2.xyzz, r0.xyzz
/*   29   */          mul r5.xyz_, r5.xyzz, r1.zzzz
              +       rcp r1.x___, r3.x
/*   30   */          mul r1.xyz_, r1.xxxx, r9.xyzz
/*   31   */          mul r1.xyz_, r5.xzyy, r1.xzyy
/*   32   */          dp4 r5.__z_, c16.zxyw, r6.zxyw
/*    3.0 */       exec
/*   33   */          dp4 r5.___w, c17.zxyw, r6.zxyw
/*   34   */          dp4 r3.x___, r8.wzxy, c19.wzxy
              +       muls r5.x___, r6.xx
/*   35   */          dp4 r3._y__, r8.wzxy, c20.wzxy
              +       muls r5._y__, r6.yy
/*   36   */          add r3.xy__, r5.zwww, r3.xyyy
              +       subs r1.___w, r5.xy
/*   37   */          mad r3.xyz_, r1.wwww, c22.xyzz, r3.xyzz
/*   38   */          mad r1.xyz_, r4.xyzz, r3.xyzz, r1.xzyy
/*    3.1 */       exece
/*   39   */          add r2.xyz_, -r1.xyzz, r7.xyzz
              +       maxs r0._, r2.ww
/*   40   */          mad r1.xyz_, r2.xzyy, r7.wwww, r1.xzyy
/*   41   */          mul oC0.xyz_, r1.xzyy, c0.xxxx
              +       muls_prev oC0.___w, r0.w
