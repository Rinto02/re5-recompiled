/*    0.0 */       exec
/*    3   */          vfetch_full r1.xyz1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=6
/*    4   */          vfetch_mini r0.xy__, Offset=4, DataFormat=FMT_32_32_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    5   */          max oPos, r1, r1
/*    1.1 */       alloc interpolators
/*    2.0 */       exece
/*    6   */          max o0.xy__, r0.xyyy, r0.xyyy
/*    7   */          max o1.xy__, r1.xyyy, r1.xyyy
/*    2.1 */       cnop
