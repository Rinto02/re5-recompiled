/*    0.0 */       exec
/*    9   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*   10   */          vfetch_mini r3.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   11   */          vfetch_mini r2, Offset=3, DataFormat=FMT_8_8_8_8
/*   12   */          vfetch_mini r8.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   13   */          vfetch_mini r1.___w, Offset=5, DataFormat=FMT_8_8_8_8, Signed=true
/*   14   */          vfetch_mini r4.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       exec    // PredicateClean=false
/*   15   */          serialize
                      mul r1.xy__, r3.zwww, c255.wwww
/*   16   */          maxas r0._, r1.yy
/*   17   */          mul r5, r2.yyyy, c[30+a0]
/*   18   */          mul r7, r2.yyyy, c[29+a0]
              +       setp_gt r0._, r2.z
/*   19   */          mul r6, r2.yyyy, c[28+a0]
              +       maxas r0._, r1.xx
/*   20   */          mad r6, r2.xxxx, c[28+a0], r6
/*    1.0 */       exec
/*   21   */          mad r7, r2.xxxx, c[29+a0], r7
/*   22   */          mad r5, r2.xxxx, c[30+a0], r5
/*    1.1 */  (p0) exec
/*   23   */     (p0) mul r1.xy__, r3.xyyy, c255.wwww
/*   24   */     (p0) maxas r0._, r1.yy
/*   25   */     (p0) mad r3, r2.wwww, c[30+a0], r5
/*   26   */     (p0) mad r5, r2.wwww, c[29+a0], r7
/*   27   */     (p0) mad r6, r2.wwww, c[28+a0], r6
/*   28   */     (p0) maxas r0._, r1.xx
/*    2.0 */  (p0) exec
/*   29   */     (p0) mad r6, r2.zzzz, c[28+a0], r6
/*   30   */     (p0) mad r7, r2.zzzz, c[29+a0], r5
/*   31   */     (p0) mad r5, r2.zzzz, c[30+a0], r3
/*    2.1 */       exec
/*   32   */          mad r0.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*   33   */          cndeq r2, c255.zzzx, r0.zxyy, c255.xxxx
/*   34   */          dp4 r0.x___, r6.zxyw, r2
/*   35   */          dp4 r0._y__, r7.zxyw, r2
/*   36   */          dp4 r0.__z_, r5.zxyw, r2
/*    3.0 */       cjmp !b0, L11
/*    3.1 */       exec
/*   37   */          cndeq r2, c255.zzzx, r0.zxyy, c255.xxxx
/*   38   */          dp4 r3.x___, c0.zxyw, r2
/*   39   */          dp4 r3._y__, c1.zxyw, r2
/*   40   */          dp4 r3.__z_, c2.zxyw, r2
/*   41   */          dp2add r0.___w, r3.xyyy, r3.xyyy, c255.zzzz
/*   42   */          dp3 r1.x___, r3.zxyy, r3.zxyy
/*    4.0 */       exec
/*   43   */          sqrt r1._y__, r_abs[1].x
/*   44   */          mad r1.x___, r1.yyyy, c27.xxxx, c27.yyyy
/*   45   */          add r1.__z_, -r3.zzzz, r1.yyyy
/*   46   */          mul r2.xy__, r3.xyyy, r1.yyyy
/*   47   */          mul r2.xy__, r2.yxxx, r1.zzzz
              +       rcp r0.___w, r0.w
/*   48   */          mul r2.xy__, r2.yxxx, r0.wwww
/*    4.1 */       exec
/*   49   */          cndge r2.__zw, r3.zzzz, r1.xxxy, c255.xxxy
/*    5.0 */       jmp L12
                label L11
/*    5.1 */       exec
/*   50   */          cndeq r3, c255.zzzx, r0.zxyy, c255.xxxx
/*   51   */          dp4 r2.x___, c23.zxyw, r3
/*   52   */          dp4 r2._y__, c24.zxyw, r3
/*   53   */          dp4 r2.__z_, c25.zxyw, r3
/*   54   */          dp4 r2.___w, c26.zxyw, r3
                label L12
/*    6.0 */       alloc position
/*    6.1 */       exec
/*   55   */          mad r2.__z_, -r2.wwww, c8.xxxx, r2.zzzz
/*   56   */          max oPos, r2, r2
/*    7.0 */       alloc interpolators
/*    7.1 */       exec
/*   57   */          dp3 r3.x___, r8.zxyy, r6.zxyy
/*   58   */          dp3 r3._y__, r8.zxyy, r7.zxyy
/*   59   */          dp3 r3.__z_, r8.zxyy, r5.zxyy
/*   60   */          add r1.xy__, r4.xyyy, c6.xyyy
              +       maxs r1.__z_, c5.xx
/*   61   */          add o3.xy__, r4.xyyy, c7.xyyy
/*   62   */          max o2.xyz_, r0.xyzz, r0.xyzz
/*    8.0 */       exece
/*   63   */          max o1, r1, r1
/*   64   */          max o0, r2, r2
/*   65   */          dp3 r0.x___, r3.zxyy, r3.zxyy
/*   66   */          rsq r0.x___, r_abs[0].x
/*   67   */          mul o4.xyz_, r3.xyzz, r0.xxxx
/*    8.1 */       cnop
