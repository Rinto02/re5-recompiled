/*    0.0 */       exec
/*    9   */          vfetch_full r3.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=5
/*   10   */          vfetch_mini r0._x__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   11   */          vfetch_mini r1.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   12   */          serialize
                      sge r3.___w, r_abs[0].xxxx, c255.xxxx
              +       addsc r0.x___, c4.x, r0.y
/*   13   */          mul r0.__z_, r0.xxxx, c4.zzzz
              +       maxs r0.x___, c4.yy
/*   14   */          tfetch2D r4, r0.zx, tf16, UseComputedLOD=false, OffsetX=1
/*    0.1 */       exec
/*   15   */          tfetch2D r5, r0.zx, tf16, UseComputedLOD=false, OffsetX=2
/*   16   */          tfetch2D r2, r0.zx, tf16, UseComputedLOD=false
/*   17   */          serialize
                      mad r3.xyz_, r3.zyxx, c227.zyxx, c3.zyxx
/*   18   */          dp4 r2.x___, r2.zxyw, r3.xzyw
/*   19   */          dp4 r2._y__, r5.zxyw, r3.xzyw
              +       mulsc r0.x___, c255.w, r0.y
/*   20   */          dp4 r2.__z_, r4.zxyw, r3.xzyw
              +       maxas r0._, r0.xx
/*    1.0 */       exec
/*   21   */          dp4 r0.x___, c[35+a0].zxyw, r3.xzyw
/*   22   */          dp4 r0._y__, c[36+a0].zxyw, r3.xzyw
/*   23   */          dp4 r0.__z_, c[37+a0].zxyw, r3.xzyw
/*   24   */          dp3 r4.x___, r1.zxyy, c[35+a0].zxyy
/*   25   */          dp3 r4._y__, r1.zxyy, c[36+a0].zxyy
/*   26   */          dp3 r4.__z_, r1.zxyy, c[37+a0].zxyy
              +       sges r2.___w, r_abs[0].x
/*    1.1 */       exec
/*   27   */          dp4 r1._y__, c27.zxyw, r2.yxzw
/*   28   */          dp4 r1.__z_, c29.zxyw, r2.yxzw
/*   29   */          dp4 r1.___w, c28.zxyw, r2.yxzw
/*   30   */          dp3 r2.x___, r4.zxyy, c1.zxyy
/*   31   */          dp3 r2.__z_, r4.zxyy, c2.zxyy
              +       sges r0.___w, r_abs[0].x
/*   32   */          dp4 r3.x___, c0.zxyw, r0.zxyw
/*    2.0 */       exec
/*   33   */          dp4 r3.__z_, c1.zxyw, r0.zxyw
/*   34   */          dp4 r3._y__, c2.zxyw, r0.zxyw
              +       sges r3.___w, r_abs[0].x
/*   35   */          mad r2.___w, -r3.yyyy, c5.xxxx, -c5.wwww
/*   36   */          dp4 r0._y__, c23.zxyw, r3.yxzw
/*   37   */          dp4 r0.__z_, c24.zxyw, r3.yxzw
/*   38   */          dp4 r1.x___, c25.zxyw, r3.yxzw
/*    2.1 */       exec
/*   39   */          dp4 r0.___w, c26.zxyw, r3.yxzw
/*   40   */          add r5.xyz_, r3.xzyy, -r1.ywzz
/*   41   */          dp3 r0.x___, r5.zxyy, r5.zxyy
/*   42   */          add r1._yzw, r1.yyzw, -r3.xxyz
              +       rsq r0.x___, r_abs[0].x
/*   43   */          dp3 r2._y__, r4.zxyy, c0.zxyy
              +       mulsc r0.x___, c5.y, r0.x
/*   44   */          min r0.x___, r0.xxxx, c255.yyyy
/*    3.0 */       exec
/*   45   */          mad r1._yzw, r1.yyzw, r0.xxxx, r3.xxyz
/*   46   */          add r1._yzw, -r1.yyzw, r3.xxyz
/*   47   */          mul r1._yzw, r1.zzwy, c5.zzzz
/*   48   */          add r5.xyz_, r3.xzyy, -r1.wzyy
              +       sges r5.___w, r_abs[0].x
/*   49   */          dp4 r3.x___, c30.zxyw, r5.zxyw
/*   50   */          dp4 r3._y__, c31.zxyw, r5.zxyw
              +       maxs r4.x___, r2.ww
/*    3.1 */       exec
/*   51   */          dp4 r3.___w, c32.zxyw, r5.zxyw
              +       maxs r4._y__, c255.yy
/*   52   */          dp4 r3.__z_, c33.zxyw, r5.zxyw
              +       mins r0.x___, r4.xy
/*    4.0 */       cjmp !b0, L11
/*    4.1 */       exec
/*   53   */          dp3 r2.x___, r1.ywzz, r2.zyxx
/*   54   */          cndgt r1._yzw, r2.xxxx, r0.yyzw, r3.xxyz
/*   55   */          cndgt r1.x___, r2.xxxx, r1.xxxx, r3.wwww
/*    5.0 */       jmp L13
                label L11
/*    5.1 */       exec
/*   56   */          rcp r1._y__, r0.w
/*   57   */          mad r1.x___, -r1.yyyy, c255.zzzz, r1.xxxx
/*   58   */          dp2add r1._y__, r2.yxxx, r2.yxxx, c255.xxxx
/*   59   */          max r1.___w, r0.wwww, r0.wwww
              +       rsq r1._y__, r_abs[1].y
/*   60   */          mul r1._yz_, r2.xxyy, r1.yyyy
/*   61   */          mul r1._yz_, r1.yyzz, c34.wwzz
/*    6.0 */       exec
/*   62   */          mad r1._yz_, r1.zzyy, r0.wwww, r0.yyzz
                label L13
/*    6.1 */       alloc position
/*    7.0 */       exec
/*   63   */          max oPos, r1.yzxw, r1.yzxw
/*    7.1 */       alloc interpolators
/*    8.0 */       exece
/*   64   */          max o0, r0.yzxw, r0.yzxw
/*   65   */          max o1, r3.xywz, r3.xywz
/*    8.1 */       cnop
