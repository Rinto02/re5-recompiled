/*    0.0 */       exec
/*    6   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=3
/*    7   */          vfetch_mini r0.x___, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    8   */          serialize
                      mad r2.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*    9   */          mulsc r0.x___, c255.w, r0.x
/*   10   */          maxas r0._, r0.xx
/*   11   */          max r0, c[28+a0], c[28+a0]
/*    0.1 */       exec
/*   12   */          max r3, c[29+a0], c[29+a0]
/*   13   */          max r1, c[30+a0].zyxw, c[30+a0].zyxw
/*   14   */          cndeq r2, c255.zzzx, r2.zxyy, c255.xxxx
/*   15   */          dp4 r0.x___, r0.zxyw, r2
/*   16   */          dp4 r0._y__, r3.zxyw, r2
/*   17   */          dp4 r0.__z_, r1.xzyw, r2
/*    1.0 */       cjmp !b0, L7
/*    1.1 */       exec
/*   18   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   19   */          dp4 r1.x___, c0.zxyw, r0
/*   20   */          dp4 r1._y__, c1.zxyw, r0
/*   21   */          dp4 r1.__z_, c2.zxyw, r0
/*   22   */          dp2add r0.x___, r1.xyyy, r1.xyyy, c255.zzzz
/*   23   */          dp3 r0._y__, r1.zxyy, r1.zxyy
/*    2.0 */       exec
/*   24   */          sqrt r0.___w, r_abs[0].y
/*   25   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   26   */          add r0._y__, -r1.zzzz, r0.wwww
/*   27   */          mul r2.xy__, r1.xyyy, r0.wwww
/*   28   */          mul r2.xy__, r2.yxxx, r0.yyyy
              +       rcp r0.x___, r0.x
/*   29   */          mul r0.xy__, r2.yxxx, r0.xxxx
/*    2.1 */       exec
/*   30   */          cndge r0.__zw, r1.zzzz, r0.zzzw, c255.xxxy
/*    3.0 */       jmp L8
                label L7
/*    3.1 */       exec
/*   31   */          cndeq r1, c255.zzzx, r0.zxyy, c255.xxxx
/*   32   */          dp4 r0.x___, c23.zxyw, r1
/*   33   */          dp4 r0._y__, c24.zxyw, r1
/*   34   */          dp4 r0.__z_, c25.zxyw, r1
/*   35   */          dp4 r0.___w, c26.zxyw, r1
                label L8
/*    4.0 */       alloc position
/*    4.1 */       exec
/*   36   */          max oPos, r0, r0
/*    5.0 */       alloc interpolators
/*    5.1 */       exece
