/*    0.0 */       exec
/*    8   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=5
/*    9   */          vfetch_mini r3.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   10   */          vfetch_mini r0.x___, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   11   */          serialize
                      mad r0._yzw, r0.yyzw, c3.xxyz, c4.xxyz
/*   12   */          mulsc r0.x___, c255.w, r0.x
/*   13   */          maxas r0._, r0.xx
/*    0.1 */       exec
/*   14   */          max r4, c[28+a0], c[28+a0]
/*   15   */          max r2, c[29+a0], c[29+a0]
/*   16   */          max r5, c[30+a0], c[30+a0]
/*   17   */          cndeq r0, c255.zzzx, r0.wyzz, c255.xxxx
/*   18   */          dp4 r1.x___, r4.zxyw, r0
/*   19   */          dp4 r1._y__, r2.zxyw, r0
/*    1.0 */       exec
/*   20   */          dp4 r1.__z_, r5.zxyw, r0
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   21   */          cndeq r0, c255.zzzx, r1.zxyy, c255.xxxx
/*   22   */          dp4 r6.x___, c0.zxyw, r0
/*   23   */          dp4 r6._y__, c1.zxyw, r0
/*   24   */          dp4 r6.__z_, c2.zxyw, r0
/*   25   */          dp2add r0.x___, r6.xyyy, r6.xyyy, c255.zzzz
/*   26   */          dp3 r0._y__, r6.zxyy, r6.zxyy
/*    2.1 */       exec
/*   27   */          sqrt r0.___w, r_abs[0].y
/*   28   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   29   */          add r0._y__, -r6.zzzz, r0.wwww
/*   30   */          mul r7.xy__, r6.xyyy, r0.wwww
/*   31   */          mul r7.xy__, r7.yxxx, r0.yyyy
              +       rcp r0.x___, r0.x
/*   32   */          mul r0.xy__, r7.yxxx, r0.xxxx
/*    3.0 */       exec
/*   33   */          cndge r0.__zw, r6.zzzz, r0.zzzw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   34   */          cndeq r6, c255.zzzx, r1.zxyy, c255.xxxx
/*   35   */          dp4 r0.x___, c23.zxyw, r6
/*   36   */          dp4 r0._y__, c24.zxyw, r6
/*   37   */          dp4 r0.__z_, c25.zxyw, r6
/*   38   */          dp4 r0.___w, c26.zxyw, r6
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   39   */          max oPos, r0, r0
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   40   */          dp3 r2._y__, r3.zxyy, r2.zxyy
/*   41   */          dp3 r2.__z_, r3.zxyy, r5.zxyy
/*   42   */          dp3 r0.x___, r1.zxyy, c2.zxyy
/*   43   */          dp3 r2.x___, r3.zxyy, r4.zxyy
              +       addsc r0.___w, -c2.w, -r0.x
/*   44   */          mad r1.xyz_, -r0.wwww, c5.xyzz, r1.xyzz
/*   45   */          dp3 r0.x___, r2.zxyy, r2.zxyy
/*    6.1 */       exec
/*   46   */          sge r1.___w, r_abs[0].xxxx, c255.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   47   */          dp4 o1.x___, c220.zxyw, r1.zxyw
/*   48   */          dp4 o1._y__, c221.zxyw, r1.zxyw
/*   49   */          dp4 o1.__z_, c222.zxyw, r1.zxyw
/*   50   */          dp4 o1.___w, c223.zxyw, r1.zxyw
/*   51   */          mul r0.xyz_, r2.xyzz, r0.xxxx
/*    7.0 */       exece
/*   52   */          max o0, r0, r0
/*    7.1 */       cnop
