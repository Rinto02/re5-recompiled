/*    0.0 */       exec
/*    2   */          tfetch2D r0.x___, r0.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    3   */          add r0._y__, c50.zzzz, c255.xxxx
/*    4   */          add r0.x___, r0.yyyy, -r0.xxxx
/*    5   */          mul r0._y__, c51.xxxx, c50.wwww
              +       rcp r0.x___, r0.x
/*    6   */          mul oC0.000w, r0.yyyy, r0.xxxx
/*    1.1 */       cnop
