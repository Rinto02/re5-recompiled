/*    0.0 */       exec
/*   10   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*   11   */          vfetch_mini r7.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   12   */          vfetch_mini r1, Offset=3, DataFormat=FMT_8_8_8_8
/*   13   */          vfetch_mini r6.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   14   */          vfetch_mini r2.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   15   */          serialize
                      mul r2.__zw, r7.zzzw, c255.wwww
/*    0.1 */       exec    // PredicateClean=false
/*   16   */          maxas r0._, r2.ww
/*   17   */          mul r3, r1.yyyy, c[30+a0]
/*   18   */          mul r5, r1.yyyy, c[29+a0]
              +       setp_gt r0._, r1.z
/*   19   */          mul r4, r1.yyyy, c[28+a0]
              +       maxas r0._, r2.zz
/*   20   */          mad r4, r1.xxxx, c[28+a0], r4
/*   21   */          mad r5, r1.xxxx, c[29+a0], r5
/*    1.0 */       exec
/*   22   */          mad r3, r1.xxxx, c[30+a0], r3
/*    1.1 */  (p0) exec
/*   23   */     (p0) mul r1.xy__, r7.xyyy, c255.wwww
/*   24   */     (p0) maxas r0._, r1.yy
/*   25   */     (p0) mad r3, r1.wwww, c[30+a0], r3
/*   26   */     (p0) mad r5, r1.wwww, c[29+a0], r5
/*   27   */     (p0) mad r4, r1.wwww, c[28+a0], r4
/*   28   */     (p0) maxas r0._, r1.xx
/*    2.0 */  (p0) exec
/*   29   */     (p0) mad r4, r1.zzzz, c[28+a0], r4
/*   30   */     (p0) mad r5, r1.zzzz, c[29+a0], r5
/*   31   */     (p0) mad r3, r1.zzzz, c[30+a0], r3
/*    2.1 */       exec
/*   32   */          mad r0.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*   33   */          cndeq r1, c255.zzzx, r0.zxyy, c255.xxxx
/*   34   */          dp4 r0._y__, r4.zxyw, r1
/*   35   */          dp4 r0.__z_, r5.zxyw, r1
/*   36   */          dp4 r0.___w, r3.zxyw, r1
/*    3.0 */       cjmp !b0, L11
/*    3.1 */       exec
/*   37   */          cndeq r1, c255.zzzx, r0.wyzz, c255.xxxx
/*   38   */          dp4 r7.x___, c0.zxyw, r1
/*   39   */          dp4 r7._y__, c1.zxyw, r1
/*   40   */          dp4 r7.__z_, c2.zxyw, r1
/*   41   */          dp2add r0.x___, r7.xyyy, r7.xyyy, c255.zzzz
/*   42   */          dp3 r1.x___, r7.zxyy, r7.zxyy
/*    4.0 */       exec
/*   43   */          sqrt r1.___w, r_abs[1].x
/*   44   */          mad r1.__z_, r1.wwww, c27.xxxx, c27.yyyy
/*   45   */          add r1.x___, -r7.zzzz, r1.wwww
/*   46   */          mul r2.__zw, r7.xxxy, r1.wwww
/*   47   */          mul r1.xy__, r2.wzzz, r1.xxxx
              +       rcp r0.x___, r0.x
/*   48   */          mul r1.xy__, r1.yxxx, r0.xxxx
/*    4.1 */       exec
/*   49   */          cndge r1.__zw, r7.zzzz, r1.zzzw, c255.xxxy
/*    5.0 */       jmp L12
                label L11
/*    5.1 */       exec
/*   50   */          cndeq r7, c255.zzzx, r0.wyzz, c255.xxxx
/*   51   */          dp4 r1.x___, c23.zxyw, r7
/*   52   */          dp4 r1._y__, c24.zxyw, r7
/*   53   */          dp4 r1.__z_, c25.zxyw, r7
/*   54   */          dp4 r1.___w, c26.zxyw, r7
                label L12
/*    6.0 */       alloc position
/*    6.1 */       exec
/*   55   */          max oPos, r1, r1
/*    7.0 */       alloc interpolators
/*    7.1 */       exec
/*   56   */          dp3 r1.x___, r6.zxyy, r4.zxyy
/*   57   */          dp3 r1._y__, r6.zxyy, r5.zxyy
/*   58   */          dp3 r0.x___, r0.wyzz, c2.zxyy
/*   59   */          dp3 r1.__z_, r6.zxyy, r3.zxyy
              +       addsc r1.___w, -c2.w, -r0.x
/*   60   */          add o4.xy__, r2.xyyy, c5.xyyy
/*   61   */          mad r2.xyz_, -r1.wwww, c6.xyzz, r0.yzww
/*    8.0 */       exec
/*   62   */          dp3 r0.x___, r1.zxyy, r1.zxyy
/*   63   */          sge r2.___w, r_abs[0].xxxx, c255.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   64   */          dp4 o1.x___, c220.zxyw, r2.zxyw
/*   65   */          dp4 o1._y__, c221.zxyw, r2.zxyw
/*   66   */          dp4 o1.__z_, c222.zxyw, r2.zxyw
/*   67   */          dp4 o1.___w, c223.zxyw, r2.zxyw
/*    8.1 */       exec
/*   68   */          dp4 o2.x___, c224.zxyw, r2.zxyw
/*   69   */          dp4 o2._y__, c225.zxyw, r2.zxyw
/*   70   */          dp4 o2.__z_, c226.zxyw, r2.zxyw
/*   71   */          dp4 o2.___w, c227.zxyw, r2.zxyw
/*   72   */          dp4 o3.x___, c228.zxyw, r2.zxyw
/*   73   */          dp4 o3._y__, c229.zxyw, r2.zxyw
/*    9.0 */       exece
/*   74   */          dp4 o3.__z_, c230.zxyw, r2.zxyw
/*   75   */          dp4 o3.___w, c231.zxyw, r2.zxyw
/*   76   */          mul r1.xyz_, r1.xyzz, r0.xxxx
/*   77   */          max o0, r1, r1
/*    9.1 */       cnop
