/*    0.0 */       exec
/*    3   */          vfetch_full r2.xyz1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=6
/*    4   */          vfetch_mini r0.yx__, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    5   */          dp4 r1.x___, c4.zxyw, r2.zxyw
/*    6   */          dp4 r1._y__, c5.zxyw, r2.zxyw
/*    7   */          dp4 r1.__z_, c6.zxyw, r2.zxyw
              +       sges r1.___w, r_abs[0].x
/*    8   */          mad r1.xyz_, c8.xyzz, c7.xxxx, r1.xyzz
/*    9   */          dp4 oPos.x___, c0.zxyw, r1.zxyw
/*   10   */          dp4 oPos._y__, c1.zxyw, r1.zxyw
/*    1.1 */       exec
/*   11   */          dp4 oPos.__z_, c2.zxyw, r1.zxyw
/*   12   */          dp4 oPos.___w, c3.zxyw, r1.zxyw
/*    2.0 */       alloc interpolators
/*    2.1 */       exece
/*   13   */          add o0.xy__, r0.xyyy, c23.xyyy
