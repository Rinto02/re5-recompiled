/*    0.0 */       exec
/*   15   */          vfetch_full r5.zyx1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*   16   */          vfetch_mini r3, Offset=3, DataFormat=FMT_8_8_8_8
/*   17   */          vfetch_mini r1.xywz, Offset=4, DataFormat=FMT_16_16_16_16, Signed=true
/*   18   */          vfetch_mini r2.yzwx, Offset=6, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   19   */          vfetch_mini r0.zyxw, Offset=7, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   20   */          serialize
                      mulsc r1.__z_, c252.y, r1.z
/*    0.1 */       exec
/*   21   */          dp4 r1.__z_, r1.zzzz, c7.wzxy
/*    1.0 */       cjmp !b1, L5
/*    1.1 */       exec
/*   22   */          dp4 r2.__z_, r5.wxzy, c28.wzxy
/*   23   */          dp4 r2.x___, r5.wxzy, c26.wzxy
              +       mulsc r4._y__, c253.w, r1.x
/*   24   */          dp4 r1.x___, r5.wxzy, c29.wzxy
              +       mulsc r4.x___, c253.w, r1.y
/*   25   */          dp4 r2._y__, r5.wxzy, c27.wzxy
              +       rcp r2.___w, r1.x
/*   26   */          mad r2.__z_, r1.zzzz, r2.wwww, r2.zzzz
/*    2.0 */       jmp L15
                label L5
/*    2.1 */       exec
/*   27   */          mul r4.xy__, r1.xyyy, c252.xxxx
              +       addsc r0._y__, c254.x, r0.y
/*   28   */          mul r4.xy__, r4.yxxx, c6.xyyy
              +       addsc r0.__z_, c254.x, r0.z
/*    3.0 */       cjmp !b2, L11
/*    3.1 */       exec
/*   29   */          subsc r1.x___, -c252.x, -r2.y
/*   30   */          mad r2.x___, r2.zzzz, c255.yyyy, r1.xxxx
/*   31   */          mul r7.xy__, r0.yzzz, c254.wwww
              +       subsc r0.x___, -c253.z, -r0.x
/*   32   */          add r6.xyz_, r5.xyzz, -c30.zyxx
              +       mulsc r7.__z_, c254.w, r0.x
/*   33   */          mul r2._yzw, r7.xxzy, r6.xxzy
/*   34   */          mad r6.xyz_, r7.zyxx, r6.yxzz, -r2.yzww
/*    4.0 */       exec
/*   35   */          dp3 r1.x___, r6.zxyy, r6.zxyy
/*   36   */          mul r2.xy__, r2.xxxx, c255.zwww
              +       rsq r1.x___, r_abs[1].x
/*   37   */          mul r6.xyz_, r6.zyxx, r1.xxxx
/*   38   */          mul r6.xyz_, r6.zxyy, c255.zwww
/*   39   */          mad r5.xyz_, r6.yzxx, r2.xxyy, r5.xyzz
/*   40   */          dp4 r2.__z_, r5.wxzy, c28.wzxy
/*    4.1 */       exec
/*   41   */          dp4 r2.x___, r5.wxzy, c26.wzxy
/*   42   */          dp4 r1.x___, r5.wxzy, c29.wzxy
/*   43   */          dp4 r2._y__, r5.wxzy, c27.wzxy
              +       rcp r2.___w, r1.x
/*   44   */          mad r2.__z_, r1.zzzz, r2.wwww, r2.zzzz
/*    5.0 */       jmp L15
                label L11
/*    5.1 */       exec
/*   45   */          mad r2.xy__, r2.yxxx, c255.xyyy, r2.zwww
/*   46   */          mad r1.x___, r2.yyyy, c253.yyyy, c251.xxxx
/*   47   */          frc r1.x___, r1.xxxx
              +       mulsc r6.x___, c251.y, r0.x
/*   48   */          mad r1.x___, r1.xxxx, c252.wwww, c251.zzzz
/*   49   */          mul r2.__zw, r0.yyyz, c252.zzzz
              +       cos r6._y__, r1.x
/*   50   */          mul r2.xy__, r2.zwww, r2.xxxx
              +       sin r6.__z_, r1.x
/*    6.0 */       exec
/*   51   */          mul r2.xyz_, r2.xxyy, r6.yzxx
/*   52   */          mul r4.__zw, r2.zzzz, r6.yyyz
/*   53   */          add r2.__z_, r4.zzzz, -r2.yyyy
/*   54   */          add r2.___w, r4.wwww, r2.xxxx
/*   55   */          dp2add r2.x___, r2.wzzz, c0.yxxx, c253.xxxx
/*   56   */          dp2add r2._y__, r2.wzzz, c2.yxxx, c253.xxxx
/*    6.1 */       exec
/*   57   */          dp2add r2.__z_, r2.wzzz, c1.yxxx, c253.xxxx
/*   58   */          add r6.xyz_, r5.zxyy, r2.xyzz
              +       sges r6.___w, r_abs[0].x
/*   59   */          dp4 r2.__z_, c28.zxyw, r6.yxzw
/*   60   */          dp4 r2.x___, c26.zxyw, r6.yxzw
/*   61   */          dp4 r1.x___, c29.zxyw, r6.yxzw
/*   62   */          dp4 r2._y__, c27.zxyw, r6.yxzw
              +       rcp r2.___w, r1.x
/*    7.0 */       exec
/*   63   */          mad r2.__z_, r1.zzzz, r2.wwww, r2.zzzz
                label L15
/*    7.1 */       exec
/*   64   */          mul r0._y__, r1.wwww, c253.zzzz
              +       rcp r0.x___, r1.x
/*   65   */          mad r0.x___, r0.xxxx, r2.zzzz, c25.zzzz
/*   66   */          mul r3.xyz_, r0.yyyy, r3.xyzz
              +       rcp r0.x___, r0.x
/*   67   */          mul r1.___w, r0.xxxx, c25.wwww
              +       mulsc r0.__z_, c4.x, r0.w
/*    8.0 */       cjmp !b4, L18
/*    8.1 */       exec
/*   68   */          dp4 r0._y__, r5.wxzy, c5.wzxy
/*   69   */          subsc r0.x___, -c8.x, -r0.y
/*   70   */          mulsc_sat r0.x___, c8.y, r0.x
/*   71   */          mul r3.___w, r0.xxxx, r3.wwww
                label L18
/*    9.0 */       cjmp !b0, L21
/*    9.1 */       exec
/*   72   */          add r0.xy_w, r5.xyzz, -c30.zyxx
/*   73   */          dp3 r0.x___, r0.xwyy, r0.xwyy
/*   74   */          sqrt r0._y__, r_abs[0].x
/*   75   */          subsc r0.x___, -c31.x, -r0.y
/*   76   */          mulsc r0.x___, c31.z, r0.x
/*   77   */          min r0.x___, r0.xxxx, c3.wwww
/*   10.0 */       exec
/*   78   */          mulsc r0.x___, c31.y, r0.x
/*   79   */          max r0.x___, r0.xxxx, c253.xxxx
/*   80   */          subsc r0.x___, c255.w, r0.x
/*   81   */          mul r3.___w, r0.xxxx, r3.wwww
/*   82   */          mul r3.xyz_, r3.xyzz, r0.xxxx
                label L21
/*   10.1 */       cjmp !b3, L24
/*   11.0 */       exec
/*   83   */          sgt r0.x___, c254.zzzz, r3.wwww
/*   84   */          cndeq r2.___w, r0.xxxx, r1.xxxx, c254.yyyy
/*   11.1 */       jmp L25
                label L24
/*   12.0 */       exec
/*   85   */          maxs r2.___w, r1.xx
                label L25
/*   12.1 */       alloc position
/*   13.0 */       exec
/*   86   */          max oPos, r2, r2
/*   13.1 */       alloc interpolators
/*   14.0 */       exece
/*   87   */          max r1._yz_, r2.xxyy, r2.xxyy
              +       rcp r4.__z_, r0.z
/*   88   */          max o3._000, r0, r0
              +       sgts o3.x___, -r_abs[0].x
/*   89   */          max o1.xy0w, r4.xyzz, r4.xyzz
/*   90   */          max o0, r3.zyxw, r3.zyxw
/*   91   */          max o2, r1.yzwx, r1.yzwx
/*   14.1 */       cnop
