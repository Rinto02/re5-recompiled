/*    0.0 */       exec
/*    2   */          tfetch2D r1.xyz_, r0.xy, tf2
/*    3   */          tfetch2D r2.xyz_, r0.xy, tf0
/*    4   */          tfetch2D r0.xyz_, r0.xy, tf1
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    5   */          add r0.xyz_, r2.xyzz, r0.xyzz
/*    6   */          add oC0.xyz1, r0.xyzz, r1.xyzz
/*    1.1 */       cnop
