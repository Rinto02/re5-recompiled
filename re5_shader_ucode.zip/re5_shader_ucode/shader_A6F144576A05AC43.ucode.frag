/*    0.0 */       exec
/*   25   */          tfetch2D r7.yxzw, r1.xy, tf0
/*   26   */          serialize
                      mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r7.ww
/*   27   */          sgt r11.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       rcp r1.x___, r0.w
/*   28   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   29   */          mul r0.__zw, r3.zzzw, r0.yyyx
              +       subsc r1.x___, -c1.x, -r1.y
/*   30   */          kill_gt r1._, c255.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   31   */          tfetch2D r12.xyz_, r3.xy, tf2
/*   32   */          tfetch2D r0.xy__, r3.xy, tf1
/*   33   */          tfetch2D r9, r0.zw, tf4
/*   34   */          serialize
                      sgt r8.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       maxs r3.x___, c15.xx
/*   35   */          add r3._yzw, r2.xxyz, -c23.xxyz
              +       maxs r1.x___, r7.zz
/*   36   */          mul r9, r9.wzyx, c5.wzyx
              +       mulsc r7.__z_, c13.z, r1.x
/*    1.0 */       exec
/*   37   */          dp3 r2.___w, r3.wyzz, r3.wyzz
              +       mulsc r7.x___, c13.y, r7.x
/*   38   */          mad r0.x__w, r0.yxxx, c254.xxxx, c255.wwww
              +       retain_prev r1._
/*   39   */          dp2add r0._y__, -r0.xwww, r0.xwww, c255.yyyy
              +       retain_prev r1._
/*   40   */          min r10, r9, c7.xxxx
              +       rsq r0.__z_, r_abs[2].w
/*   41   */          mul r9.xyz_, r3.wzyy, r0.zzzz
              +       mulsc r7._y__, c13.x, r7.y
/*   42   */          max r10, r10.wzyx, c8.xxxx
              +       sqrt r0._y__, r_abs[0].y
/*    1.1 */       exec
/*   43   */          mul r6.xyz_, r0.yyyy, r6.xyzz
              +       maxs r3._y__, r10.yw
/*   44   */          mad r0.xyz_, r0.xxxx, r5.zyxx, r6.zyxx
              +       retain_prev r1._
/*   45   */          mad r0._yzw, r0.wwww, r4.xxzy, r0.zzxy
              +       retain_prev r1._
/*   46   */          dp3 r0.x___, r0.zyww, r0.zyww
              +       maxs r3.__z_, r10.xz
/*   47   */          max r3.__z_, r3.zzzz, r3.yyyy
              +       rsq r0.x___, r_abs[0].x
/*   48   */          mul r5.xyz_, r0.ywzz, r0.xxxx
              +       sqrt r3._y__, r_abs[2].w
/*    2.0 */       cjmp !b128, L24
/*    2.1 */       exec
/*   49   */          dp3 r0._y__, r5.zxyy, -r9.xzyy
              +       retain_prev r1._
/*   50   */          mul r4, r10.wzyx, c48.wzyx
              +       retain_prev r1._
/*   51   */          add r6.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   52   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   53   */          max4 r4.__z_, r4.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   54   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*    3.0 */       exec
/*   55   */          dp3 r1._y__, r6.xzyy, -c34.zxyy
              +       maxs r1.x___, r6.ww
/*   56   */          dp3 r0.x___, r5.zxyy, r6.xzyy
              +       subsc r2.___w, -c35.x, -r1.y
/*   57   */          max r4.x__w, r0.yxxx, c255.xxxx
              +       mulsc r1._y__, c35.y, r2.w
/*   58   */          max r1._y__, r1.yyyy, c35.wwww
              +       subsc r1.x___, -c32.w, -r1.x
/*   59   */          min r6.x___, r1.yyyy, c255.yyyy
              +       mulsc_sat r4._y__, c33.w, r1.x
/*   60   */          add r0.xyz_, -r4.zxyy, c255.yyyy
              +       retain_prev r1._
/*    3.1 */       exec
/*   61   */          mul r6._y__, r0.zzzz, r6.xxxx
              +       log r1.x___, r_abs[0].y
/*   62   */          mul r6._yzw, r6.xxyy, c32.xxzy
              +       retain_prev r1._
/*   63   */          mul r6.x___, r6.yyyy, r0.zzzz
              +       mulsc r1._y__, c14.z, r1.x
/*   64   */          mul r4.xyz_, r6.xzww, r4.wwww
              +       exp r1._y__, r1.y
/*   65   */          mul r6.xyz_, r6.zwxx, r1.yyyy
              +       retain_prev r1._
/*   66   */          mul r11.xyz_, r6.xyzz, r0.xxxx
              +       retain_prev r1._
/*    4.0 */       exec
/*   67   */          mul r0.xyz_, r4.xzyy, r0.xxxx
              +       retain_prev r1._
/*   68   */          mul r8.xyz_, r0.xzyy, c35.zzzz
              +       retain_prev r1._
/*    4.1 */       cjmp !b129, L24
/*    5.0 */       exec
/*   69   */          mul r0, r10.wzyx, c49.wzyx
              +       retain_prev r1._
/*   70   */          add r4.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   71   */          dp3 r4.___w, r4.zxyy, r4.zxyy
              +       retain_prev r1._
/*   72   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[4].w
/*   73   */          mul r4, r4, r1.xxxx
              +       retain_prev r1._
/*   74   */          dp3 r0._y__, r5.zxyy, r4.zxyy
              +       retain_prev r1._
/*    5.1 */       exec
/*   75   */          dp3 r2.___w, r4.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   76   */          add r1.x___, r4.wwww, -c36.wwww
              +       retain_prev r1._
/*   77   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   78   */          max r0._y__, r0.yyyy, c255.xxxx
              +       mulsc r2.___w, c39.y, r2.w
/*   79   */          max r0.___w, r2.wwww, c39.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   80   */          min r4.x___, r0.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*    6.0 */       exec
/*   81   */          mul r4._y__, r0.xxxx, r4.xxxx
              +       retain_prev r1._
/*   82   */          mul r4.xy_w, r4.yyxx, c36.zyxx
              +       retain_prev r1._
/*   83   */          mul r4.__z_, r4.wwww, r0.xxxx
              +       retain_prev r1._
/*   84   */          mul r0.xyz_, r4.xyzz, r0.yyyy
              +       retain_prev r1._
/*   85   */          mul r4.xyz_, r4.xyzz, r1.yyyy
              +       retain_prev r1._
/*   86   */          mad r11.xyz_, r4.xyzz, r2.wwww, r11.xyzz
              +       retain_prev r1._
/*    6.1 */       exec
/*   87   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   88   */          mad r8.xyz_, r0.xzyy, c39.zzzz, r8.xyzz
              +       retain_prev r1._
/*    7.0 */       cjmp !b130, L24
/*    7.1 */       exec
/*   89   */          mul r0, r10, c50
              +       retain_prev r1._
/*   90   */          add r4.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   91   */          dp3 r4.___w, r4.xzyy, r4.xzyy
              +       retain_prev r1._
/*   92   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[4].w
/*   93   */          mul r4, r4, r1.xxxx
              +       retain_prev r1._
/*   94   */          dp3 r0._y__, r5.zxyy, r4.xzyy
              +       retain_prev r1._
/*    8.0 */       exec
/*   95   */          dp3 r2.___w, r4.xzyy, -c42.zxyy
              +       retain_prev r1._
/*   96   */          add r1.x___, r4.wwww, -c40.wwww
              +       retain_prev r1._
/*   97   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*   98   */          max r0._y__, r0.yyyy, c255.xxxx
              +       mulsc r2.___w, c43.y, r2.w
/*   99   */          max r0.___w, r2.wwww, c43.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  100   */          min r4.x___, r0.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*    8.1 */       exec
/*  101   */          mul r4._y__, r0.xxxx, r4.xxxx
              +       retain_prev r1._
/*  102   */          mul r4.xy_w, r4.yyxx, c40.zyxx
              +       retain_prev r1._
/*  103   */          mul r4.__z_, r4.wwww, r0.xxxx
              +       retain_prev r1._
/*  104   */          mul r0.xyz_, r4.xyzz, r0.yyyy
              +       retain_prev r1._
/*  105   */          mul r4.xyz_, r4.xyzz, r1.yyyy
              +       retain_prev r1._
/*  106   */          mad r11.xyz_, r4.xyzz, r2.wwww, r11.xyzz
              +       retain_prev r1._
/*    9.0 */       exec
/*  107   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  108   */          mad r8.xyz_, r0.xzyy, c43.zzzz, r8.xyzz
              +       retain_prev r1._
/*    9.1 */       cjmp !b131, L24
/*   10.0 */       exec
/*  109   */          mul r0, r10.wzyx, c51.wzyx
              +       retain_prev r1._
/*  110   */          add r4.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*  111   */          dp3 r4.___w, r4.zxyy, r4.zxyy
              +       retain_prev r1._
/*  112   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[4].w
/*  113   */          mul r4, r4, r1.xxxx
              +       retain_prev r1._
/*  114   */          dp3 r0._y__, r5.zxyy, r4.zxyy
              +       retain_prev r1._
/*   10.1 */       exec
/*  115   */          dp3 r2.___w, r4.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  116   */          add r1.x___, r4.wwww, -c44.wwww
              +       retain_prev r1._
/*  117   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  118   */          max r0._y__, r0.yyyy, c255.xxxx
              +       mulsc r2.___w, c47.y, r2.w
/*  119   */          max r0.___w, r2.wwww, c47.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  120   */          min r4.x___, r0.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*   11.0 */       exec
/*  121   */          mul r4._y__, r0.xxxx, r4.xxxx
              +       retain_prev r1._
/*  122   */          mul r4.xy_w, r4.yyxx, c44.zyxx
              +       retain_prev r1._
/*  123   */          mul r4.__z_, r4.wwww, r0.xxxx
              +       retain_prev r1._
/*  124   */          mul r0.xyz_, r4.xyzz, r0.yyyy
              +       retain_prev r1._
/*  125   */          mul r4.xyz_, r4.xyzz, r1.yyyy
              +       retain_prev r1._
/*  126   */          mad r11.xyz_, r4.xyzz, r2.wwww, r11.xyzz
              +       retain_prev r1._
/*   11.1 */       exec
/*  127   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  128   */          mad r8.xyz_, r0.xzyy, c47.zzzz, r8.xyzz
              +       retain_prev r1._
                label L24
/*   12.0 */       cjmp !b132, L36
/*   12.1 */       exec
/*  129   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  130   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  131   */          mul r4, r10.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  132   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  133   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  134   */          dp3 r2.___w, r0.xzyy, r5.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   13.0 */       exec
/*  135   */          max4 r0._y__, r4.zxwy
              +       maxs r0.__z_, r2.ww
/*  136   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  137   */          mul r4.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  138   */          mul r4.xyz_, r4.xyzz, r2.wwww
              +       retain_prev r1._
/*  139   */          mad r8.xyz_, r4.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   13.1 */       cjmp !b133, L36
/*   14.0 */       exec
/*  140   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  141   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  142   */          mul r4, r10, c53
              +       rsq r1.x___, r_abs[0].w
/*  143   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  144   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  145   */          dp3 r2.___w, r0.zxyy, r5.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   14.1 */       exec
/*  146   */          max4 r0._y__, r4.ywxz
              +       maxs r0.__z_, r2.ww
/*  147   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  148   */          mul r4.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  149   */          mul r4.xyz_, r4.xyzz, r2.wwww
              +       retain_prev r1._
/*  150   */          mad r8.xyz_, r4.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   15.0 */       cjmp !b134, L36
/*   15.1 */       exec
/*  151   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  152   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  153   */          mul r4, r10.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  154   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  155   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  156   */          dp3 r2.___w, r0.xzyy, r5.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   16.0 */       exec
/*  157   */          max4 r0._y__, r4.zxwy
              +       maxs r0.__z_, r2.ww
/*  158   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  159   */          mul r4.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  160   */          mul r4.xyz_, r4.xyzz, r2.wwww
              +       retain_prev r1._
/*  161   */          mad r8.xyz_, r4.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   16.1 */       cjmp !b135, L36
/*   17.0 */       exec
/*  162   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  163   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  164   */          mul r4, r10, c55
              +       rsq r1.x___, r_abs[0].w
/*  165   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  166   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  167   */          dp3 r2.___w, r0.zxyy, r5.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   17.1 */       exec
/*  168   */          max4 r0._y__, r4.ywxz
              +       maxs r0.__z_, r2.ww
/*  169   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  170   */          mul r4.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  171   */          mul r4.xyz_, r4.xyzz, r2.wwww
              +       retain_prev r1._
/*  172   */          mad r8.xyz_, r4.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
                label L36
/*   18.0 */       exec
/*  173   */          mul r10, r5.xyzz, r5.yzzx
              +       retain_prev r1._
/*  174   */          cndeq r0, c255.xxxy, r5.zxyy, c255.yyyy
              +       retain_prev r1._
/*  175   */          dp4 r4.x___, c16.zxyw, r0
              +       retain_prev r1._
/*  176   */          dp4 r4._y__, c18.zxyw, r0
              +       retain_prev r1._
/*  177   */          dp4 r4.__z_, c17.zxyw, r0
              +       retain_prev r1._
/*  178   */          dp4 r0.x___, r10.wzxy, c19.wzxy
              +       muls r6.x___, r5.xx
/*   18.1 */       exec    // PredicateClean=false
/*  179   */          dp4 r0._y__, r10.wzxy, c21.wzxy
              +       muls r6._y__, r5.yy
/*  180   */          dp4 r0.__z_, r10.wzxy, c20.wzxy
              +       subs r2.___w, r6.xy
/*  181   */          add r0.xyz_, r4.zxyy, r0.zxyy
              +       setp_gt r1._, c_abs[56].x
/*  182   */          mad r0.xyz_, r2.wwww, c22.xyzz, r0.yxzz
              +       retain_prev r1._
/*  183   */          mad r4.xyz_, r8.xzyy, r1.wwww, r0.xyzz
              +       retain_prev r1._
/*   19.0 */  (p0) exec
/*  184   */     (p0) mul r6.xyz_, r4.zyxx, c59.xxxx
              +  (p0) retain_prev r1._
/*  185   */     (p0) mul r0.xyz_, r4.zyxx, c60.xxxx
              +  (p0) retain_prev r1._
/*  186   */     (p0) mul r0.xyz_, r0.xyzz, c58.xxxx
              +  (p0) retain_prev r1._
/*  187   */     (p0) mad r4.xyz_, r6.zyxx, c57.xxxx, r0.zyxx
              +  (p0) retain_prev r1._
/*   19.1 */       exec
/*  188   */          dp3 r6._y__, r9.xzyy, r5.zxyy
              +       retain_prev r1._
/*  189   */          max r1._, r1, r1
              +       adds r1.x___, r6.yy
/*  190   */          mad r0.xyz_, -r5.xyzz, r1.xxxx, r9.zyxx
              +       retain_prev r1._
/*  191   */          cube r0, r0.zzxy, r0.yxzz
              +       retain_prev r1._
/*  192   */          max r5.__z_, r0.wwww, r0.wwww
              +       rcp r1.x___, r_abs[0].z
/*  193   */          mad r5.xy__, r0.yxxx, r1.xxxx, c254.yyyy
              +       retain_prev r1._
/*   20.0 */       exec
/*  194   */          setTexLOD r3.x
/*  195   */          tfetchCube r5, r5.xyz, tf3, UseComputedLOD=false, UseRegisterLOD=true
/*   20.1 */       alloc colors
/*   21.0 */       exec
/*  196   */          max r1.x___, r5.wwww, c254.zzzz
              +       mulsc r6.x___, c6.x, r3.z
/*  197   */          add r0.xy__, -r6.xyyy, c255.yyyy
              +       rcp r1.x___, r1.x
/*  198   */          mul r3.x_zw, r1.xxxx, r5.xyyz
              +       retain_prev r1._
/*  199   */          mul r5.xyz_, r3.wzxx, r0.xxxx
              +       muls r1.x___, r_abs[0].yy
/*  200   */          max r1._, r1, r1
              +       muls r1.x___, r1.xx
/*  201   */          mul r5.___w, r1.xxxx, r_abs[0].yyyy
              +       retain_prev r1._
/*   21.1 */       exec    // PredicateClean=false
/*  202   */          mad r0.xyz_, r5.zyxx, c14.wwww, r11.zyxx
              +       retain_prev r1._
/*  203   */          mad_sat r1.x___, r5.wwww, c14.xxxx, c14.yyyy
              +       retain_prev r1._
/*  204   */          max r1._, r1, r1
              +       subsc r1.x___, c255.y, r1.x
/*  205   */          mul r1.x___, r1.xxxx, r1.wwww
              +       setp_ne r1._, c56.x
/*  206   */     (p0) mul r0.xyz_, r0.xyzz, c61.xxxx
              +  (p0) retain_prev r1._
/*  207   */          mul r1.xy_w, r1.xxxx, r12.xyzz
              +       maxs r1._, r7.ww
/*   22.0 */       exec
/*  208   */          mul r0.xyz_, r1.xyww, r0.xyzz
              +       muls_prev r1.___w, r1.z
/*  209   */          mad r0.xyz_, r7.yxzz, r4.xyzz, r0.xyzz
              +       retain_prev r1._
/*   22.1 */       cjmp !b136, L49
/*   23.0 */       exec
/*  210   */          mad r2.___w, r3.yyyy, c12.yyyy, c12.zzzz
              +       retain_prev r1._
/*  211   */          dp3 r1.__z_, r9.xzyy, c10.zxyy
              +       retain_prev r1._
/*  212   */          cndeq r4, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  213   */          dp4 r1._y__, c10.zxyw, r4
              +       subsc r1.x___, -c9.x, -r3.y
/*  214   */          add r2.xyz_, -r0.xyzz, c11.xyzz
              +       mulsc r0.___w, c9.z, r1.x
/*  215   */          min r3.xy__, r1.yzzz, c255.xzzz
              +       mulsc r1.x___, c9.w, r1.y
/*   23.1 */       exec
/*  216   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  217   */          max r1._, r1, r1
              +       mulsc r1.x___, c12.x, r1.y
/*  218   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  219   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  220   */          min r1.x___, r1.xxxx, c11.wwww
              +       retain_prev r1._
/*  221   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*   24.0 */       exec
/*  222   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L49
/*   24.1 */       exece
/*  223   */          mul r1.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  224   */          max oC0, r1, r1
