/*    0.0 */       exec
/*   11   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=8
/*   12   */          vfetch_mini r3, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   13   */          vfetch_mini r8, Offset=3, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   14   */          vfetch_mini r9, Offset=4, DataFormat=FMT_8_8_8_8
/*   15   */          vfetch_mini r2, Offset=5, DataFormat=FMT_8_8_8_8
/*   16   */          vfetch_mini r5.xyz_, Offset=6, DataFormat=FMT_2_10_10_10, Signed=true
/*    0.1 */       exec    // PredicateClean=false
/*   17   */          vfetch_mini r1.yx__, Offset=7, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   18   */          vfetch_full r7, r0.x, vf1, Offset=1, DataFormat=FMT_8_8_8_8, Stride=2, Signed=true
/*   19   */          serialize
                      mul r10, r3, c255.wwww
/*   20   */          maxas r0._, r10.ww
/*   21   */          mul r6, r9.wwww, c[30+a0]
/*   22   */          mul r3, r9.wwww, c[29+a0]
              +       setp_gt r0._, r2.x
/*    1.0 */       exec
/*   23   */          mul r4, r9.wwww, c[28+a0]
              +       maxas r0._, r10.zz
/*   24   */          mad r4, r9.zzzz, c[28+a0].wyzx, r4.wyzx
/*   25   */          mad r3, r9.zzzz, c[29+a0].wyzx, r3.wyzx
/*   26   */          mad r6, r9.zzzz, c[30+a0].wyzx, r6.wyzx
/*   27   */          maxas r0._, r10.yy
/*   28   */          mad r6, r9.yyyy, c[30+a0].wzxy, r6.xzwy
/*    1.1 */       exec
/*   29   */          mad r3, r9.yyyy, c[29+a0].wzxy, r3.xzwy
/*   30   */          mad r4, r9.yyyy, c[28+a0].wzxy, r4.xzwy
/*   31   */          maxas r0._, r10.xx
/*   32   */          mad r4, r9.xxxx, c[28+a0], r4.zwyx
/*   33   */          mad r3, r9.xxxx, c[29+a0], r3.zwyx
/*   34   */          mad r6, r9.xxxx, c[30+a0], r6.zwyx
/*    2.0 */  (p0) exec
/*   35   */     (p0) mul r8, r8, c255.wwww
/*   36   */     (p0) maxas r0._, r8.ww
/*   37   */     (p0) mad r6, r2.wwww, c[30+a0].xywz, r6.xywz
/*   38   */     (p0) mad r3, r2.wwww, c[29+a0].xywz, r3.xywz
/*   39   */     (p0) mad r4, r2.wwww, c[28+a0].xywz, r4.xywz
/*   40   */     (p0) maxas r0._, r8.zz
/*    2.1 */  (p0) exec
/*   41   */     (p0) mad r4, r2.zzzz, c[28+a0].wxzy, r4.zxwy
/*   42   */     (p0) mad r3, r2.zzzz, c[29+a0].wxzy, r3.zxwy
/*   43   */     (p0) mad r6, r2.zzzz, c[30+a0].wxzy, r6.zxwy
/*   44   */     (p0) maxas r0._, r8.yy
/*   45   */     (p0) mad r6, r2.yyyy, c[30+a0].wzyx, r6.xzwy
/*   46   */     (p0) mad r3, r2.yyyy, c[29+a0].wzyx, r3.xzwy
/*    3.0 */  (p0) exec
/*   47   */     (p0) mad r4, r2.yyyy, c[28+a0].wzyx, r4.xzwy
/*   48   */     (p0) maxas r0._, r8.xx
/*   49   */     (p0) mad r4, r2.xxxx, c[28+a0], r4.wzyx
/*   50   */     (p0) mad r3, r2.xxxx, c[29+a0], r3.wzyx
/*   51   */     (p0) mad r6, r2.xxxx, c[30+a0], r6.wzyx
/*    3.1 */       exec
/*   52   */          mad r0.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*   53   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   54   */          dp4 r2.x___, r4.zxyw, r0
/*   55   */          dp4 r2._y__, r3.zxyw, r0
/*   56   */          dp4 r2.__z_, r6.zxyw, r0
/*    4.0 */       cjmp !b0, L13
/*    4.1 */       exec
/*   57   */          cndeq r0, c255.zzzx, r2.zxyy, c255.xxxx
/*   58   */          dp4 r8.x___, c0.zxyw, r0
/*   59   */          dp4 r8._y__, c1.zxyw, r0
/*   60   */          dp4 r8.__z_, c2.zxyw, r0
/*   61   */          dp2add r0.x___, r8.xyyy, r8.xyyy, c255.zzzz
/*   62   */          dp3 r0._y__, r8.zxyy, r8.zxyy
/*    5.0 */       exec
/*   63   */          sqrt r0.___w, r_abs[0].y
/*   64   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   65   */          add r0._y__, -r8.zzzz, r0.wwww
/*   66   */          mul r1.__zw, r8.xxxy, r0.wwww
/*   67   */          mul r1.__zw, r1.wwwz, r0.yyyy
              +       rcp r0.x___, r0.x
/*   68   */          mul r0.xy__, r1.wzzz, r0.xxxx
/*    5.1 */       exec
/*   69   */          cndge r0.__zw, r8.zzzz, r0.zzzw, c255.xxxy
/*    6.0 */       jmp L14
                label L13
/*    6.1 */       exec
/*   70   */          cndeq r8, c255.zzzx, r2.zxyy, c255.xxxx
/*   71   */          dp4 r0.x___, c23.zxyw, r8
/*   72   */          dp4 r0._y__, c24.zxyw, r8
/*   73   */          dp4 r0.__z_, c25.zxyw, r8
/*   74   */          dp4 r0.___w, c26.zxyw, r8
                label L14
/*    7.0 */       alloc position
/*    7.1 */       exec
/*   75   */          mad r0.__z_, -r0.wwww, c9.xxxx, r0.zzzz
/*   76   */          max oPos, r0, r0
/*    8.0 */       alloc interpolators
/*    8.1 */       exec
/*   77   */          dp3 r8.x___, r7.zxyy, r3.zxyy
/*   78   */          dp3 r8._y__, r7.zxyy, r6.zxyy
/*   79   */          dp3 r8.__z_, r7.zxyy, r4.zxyy
/*   80   */          dp3 r4.x___, r5.zxyy, r4.zxyy
/*   81   */          dp3 r4._y__, r5.zxyy, r3.zxyy
/*   82   */          dp3 r4.__z_, r5.zxyy, r6.zxyy
/*    9.0 */       exec
/*   83   */          add r7.xy__, r1.xyyy, c7.xyyy
              +       maxs r7.__z_, c5.xx
/*   84   */          add o3.xy__, r1.xyyy, c8.xyyy
/*   85   */          max o2.xyz_, r2.xyzz, r2.xyzz
/*   86   */          max o1, r7, r7
/*   87   */          max o0, r0, r0
/*   88   */          dp3 r0._y__, r4.zxyy, r4.zxyy
/*    9.1 */       exec
/*   89   */          dp3 r0.x___, r8.yzxx, r8.yzxx
              +       rsq r0._y__, r_abs[0].y
/*   90   */          mul r1.xyz_, r4.xyzz, r0.yyyy
              +       rsq r0.x___, r_abs[0].x
/*   91   */          mul o4.xyz_, r8.zxyy, r0.xxxx
/*   92   */          mul o6.xyz_, r4.xyzz, r0.yyyy
/*   93   */          mul r2.xyz_, r8.xyzz, r0.xxxx
/*   94   */          mul r0.xyz_, r2.yzxx, r1.yzxx
/*   10.0 */       exece
/*   95   */          mad r0._yzw, r2.xxyz, r1.zzxy, -r0.xxyz
/*   96   */          dp3 r0.x___, r0.wyzz, r0.wyzz
/*   97   */          rsq r0.x___, r_abs[0].x
/*   98   */          mul r0.xyz_, r0.yzww, r0.xxxx
/*   99   */          mul o5.xyz_, r0.xyzz, c6.zzzz
/*   10.1 */       cnop
