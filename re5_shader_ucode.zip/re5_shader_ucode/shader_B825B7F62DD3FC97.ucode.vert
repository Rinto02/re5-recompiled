/*    0.0 */       exec
/*    4   */          vfetch_full r1.xyz1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=6
/*    5   */          vfetch_mini r0.xy__, Offset=4, DataFormat=FMT_32_32_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    6   */          max oPos, r1, r1
/*    1.1 */       alloc interpolators
/*    2.0 */       exec
/*    7   */          add r5._y__, c51.xxxx, c50.xxxx
/*    8   */          mad r1.xy__, c51.xxxx, c254.xyyy, c50.xxxx
/*    9   */          mad r5.x_z_, c51.xxxx, c254.wzzz, c50.xxxx
/*   10   */          add r3.xy__, r0.xyyy, -c52.xyyy
              +       adds r0.x___, c51.xx
/*   11   */          mul r2.xy__, r3.xyyy, c50.xxxx
              +       mulsc r0.x___, c255.w, r0.x
/*   12   */          mul r0._yzw, c51.xxxx, c255.zzxy
              +       maxs r0._, r3.xx
/*    2.1 */       exec
/*   13   */          mad r4, r3.xyxy, r1.xxyy, c52.xyxy
/*   14   */          mad r1, r3.xyxy, r5.xxyy, c52.xyxy
/*   15   */          add r0, r0.zwxy, c50.xxxx
              +       muls_prev r2.__z_, r5.z
/*   16   */          max r1, r1, c48.xyxy
              +       maxs r0._, r3.yy
/*   17   */          max r4, r4, c48.xyxy
              +       muls_prev r2.___w, r5.z
/*   18   */          add r2, r2, c52.xyxy
/*    3.0 */       exec
/*   19   */          min o2, r4, c49.xyxy
/*   20   */          min o4, r1, c49.xyxy
/*   21   */          mad r1, r3.xyxy, r0.zzww, c52.xyxy
/*   22   */          mad r0, r3.xyxy, r0.xxyy, c52.xyxy
/*   23   */          max r0, r0, c48.xyxy
/*   24   */          max r1, r1, c48.xyxy
/*    3.1 */       exece
/*   25   */          max r2, r2, c48.xyxy
/*   26   */          min o0, r2, c49.xyxy
/*   27   */          min o1, r1, c49.xyxy
/*   28   */          min o3, r0, c49.xyxy
