/*    0.0 */       exec
/*   32   */          tfetch2D r7.yxzw, r1.xy, tf0
/*   33   */          serialize
                      mul r8.xy__, r3.xyyy, c14.yyyy
              +       rcp r1.x___, r0.w
/*   34   */          mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r7.ww
/*   35   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   36   */          mul r3.__zw, r3.zzzw, r0.yyyx
              +       subsc r1.x___, -c1.x, -r1.y
/*   37   */          kill_gt r1._, c254.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   38   */          tfetch2D r10.xyz_, r3.xy, tf6
/*   39   */          tfetch2D r0.xy__, r8.xy, tf9
/*   40   */          tfetch2D r0.__xy, r3.xy, tf5
/*   41   */          tfetch2D r8, r3.zw, tf8
/*   42   */          serialize
                      sgt r9.xyz_, -r_abs[1].xxxx, c254.xxxx
              +       maxs r3.___w, c56.xx
/*   43   */          add r3.xyz_, r2.xyzz, -c23.xyzz
              +       sgts r12._y__, -r_abs[1].x
/*    1.0 */       exec
/*   44   */          mul r8, r8.wzyx, c5.wzyx
              +       sgts r12.__z_, -r_abs[1].x
/*   45   */          dp3 r2.___w, r3.zxyy, r3.zxyy
              +       sgts r12.x___, -r_abs[1].x
/*   46   */          mad r0, r0.xywz, c255.xxxx, c253.yyyy
              +       retain_prev r1._
/*   47   */          min r8, r8, c7.xxxx
              +       rsq r1.x___, r_abs[2].w
/*   48   */          mul r11.xyz_, r3.zyxx, r1.xxxx
              +       maxs r1.x___, r7.zz
/*   49   */          max r8, r8.wzyx, c8.xxxx
              +       mulsc r6.___w, c13.z, r1.x
/*    1.1 */       exec
/*   50   */          mad r0.x__w, r0.yxxx, c14.xxxx, r0.zwww
              +       retain_prev r1._
/*   51   */          dp2add r0._y__, -r0.xwww, r0.xwww, c254.yyyy
              +       retain_prev r1._
/*   52   */          max r3.xy__, r8.yxxx, r8.wzzz
              +       sqrt r0._y__, r_abs[0].y
/*   53   */          mul r13.xyz_, r0.yyyy, r6.xyzz
              +       mulsc r6._y__, c13.y, r7.x
/*   54   */          mad r0.xyz_, r0.xxxx, r5.zyxx, r13.zyxx
              +       retain_prev r1._
/*   55   */          mad r0._yzw, r0.wwww, r4.xxzy, r0.zzxy
              +       retain_prev r1._
/*    2.0 */       exec
/*   56   */          dp3 r0.x___, r0.zyww, r0.zyww
              +       mulsc r6.x___, c13.x, r7.y
/*   57   */          max r3.__z_, r3.yyyy, r3.xxxx
              +       rsq r0.x___, r_abs[0].x
/*   58   */          mul r4.xyz_, r0.ywzz, r0.xxxx
              +       sqrt r3._y__, r_abs[2].w
/*    2.1 */       cjmp !b128, L37
/*    3.0 */       exec
/*   59   */          sgt r4.___w, c63.zzzz, c254.wwww
              +       retain_prev r1._
/*   60   */          add r0._yzw, -r2.zzyx, c33.zzyx
              +       retain_prev r1._
/*   61   */          mul r5, r8.wzyx, c48.wzyx
              +       retain_prev r1._
/*   62   */          dp3 r1._y__, r0.ywzz, r0.ywzz
              +       retain_prev r1._
/*   63   */          max4 r1.x___, r5.zxwy
              +       retain_prev r1._
/*   64   */          add r0.x___, -r1.xxxx, c254.yyyy
              +       rsq r1.x___, r_abs[1].y
/*    3.1 */       exec
/*   65   */          mul r5.xyz_, r0.yzww, r1.xxxx
              +       retain_prev r1._
/*   66   */          dp3 r0.__z_, r4.zxyy, r5.xzyy
              +       retain_prev r1._
/*   67   */          dp3 r3.x___, r5.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   68   */          add r5.xyz_, r5.zyxx, -r11.zyxx
              +       retain_prev r1._
/*   69   */          dp3 r2.___w, r5.zxyy, r5.zxyy
              +       maxs r1._, r1.yy
/*   70   */          add r1._y__, r3.xxxx, -c35.xxxx
              +       muls_prev r1.x___, r1.x
/*    4.0 */       exec
/*   71   */          mul r0._y__, r1.yyyy, c35.yyyy
              +       subsc r1._y__, -c32.w, -r1.x
/*   72   */          max r0._y__, r0.yyyy, c35.wwww
              +       rsq r2.___w, r_abs[2].w
/*   73   */          mul r5._yzw, r5.zzyx, r2.wwww
              +       mulsc_sat r2.___w, c33.w, r1.y
/*   74   */          min r5.x___, r0.yyyy, c254.yyyy
              +       subsc r2.___w, c254.y, r2.w
/*   75   */          dp3 r0._y__, r4.zxyy, r5.ywzz
              +       maxs r1._, r2.ww
/*   76   */          max r0._yz_, r0.yyzz, c254.xxxx
              +       muls_prev r5._y__, r5.x
/*    4.1 */       exec    // PredicateClean=false
/*   77   */          mul r5.xyz_, r5.xyyy, c32.xzyy
              +       log r1._y__, r_abs[0].y
/*   78   */          mul r5.___w, r5.xxxx, r2.wwww
              +       mulsc r2.___w, c15.z, r1.y
/*   79   */          mul r0._yzw, r5.yyzw, r0.zzzz
              +       exp r2.___w, r2.w
/*   80   */          mul r5.xyz_, r5.wzyy, r2.wwww
              +       setp_ne r1._, r4.w
/*    5.0 */  (p0) exec
/*   81   */     (p0) max r1._, r1, r1
              +  (p0) maxs r12.___w, c254.yy
/*   82   */     (p0) mul r9.xyz_, r1.xxxx, c34.xyzz
              +  (p0) rcp r1._y__, c63.z
/*   83   */     (p0) mad r9.xyz_, r9.xyzz, r3.xxxx, c33.xyzz
              +  (p0) retain_prev r1._
/*   84   */     (p0) add r12.xyz_, -r9.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*   85   */     (p0) dp4 r9.x___, c67.zxyw, r12.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*   86   */     (p0) dp4 r9._y__, c68.zxyw, r12.zxyw
              +  (p0) mulsc r1.x___, c63.w, r1.x
/*    5.1 */  (p0) exec
/*   87   */     (p0) mul r9.xy__, r9.xyyy, c253.xxxx
              +  (p0) rcp r1.x___, r1.x
/*   88   */     (p0) mul r1.xy__, r9.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*   89   */     (p0) add r9.x___, r1.xxxx, c253.xxxx
              +  (p0) subsc r9._y__, c253.x, r1.y
/*   90   */     (p0) tfetch2D r9.xyz_, r9.xy, tf1
/*   91   */          serialize
                 (p0) mul r0._yzw, r0.yyzw, r9.zzyx
              +  (p0) retain_prev r1._
/*   92   */     (p0) mul r5.xyz_, r5.xyzz, r9.xyzz
              +  (p0) retain_prev r1._
/*    6.0 */       exec
/*   93   */          max r1._, r1, r1
              +       mulsc r2.___w, c35.z, r0.x
/*   94   */          mul r12.xyz_, r2.wwww, r0.wyzz
              +       retain_prev r1._
/*   95   */          mul r9.xyz_, r0.xxxx, r5.zyxx
              +       retain_prev r1._
/*    6.1 */       cjmp !b129, L37
/*    7.0 */       exec
/*   96   */          sgt r0.__z_, c64.zzzz, c254.wwww
              +       retain_prev r1._
/*   97   */          add r5.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   98   */          mul r13, r8, c49
              +       retain_prev r1._
/*   99   */          dp3 r1._y__, r5.zxyy, r5.zxyy
              +       retain_prev r1._
/*  100   */          max4 r1.x___, r13.ywxz
              +       retain_prev r1._
/*  101   */          add r0.x___, -r1.xxxx, c254.yyyy
              +       rsq r1.x___, r_abs[1].y
/*    7.1 */       exec
/*  102   */          mul r5.xy_w, r5.xyzz, r1.xxxx
              +       retain_prev r1._
/*  103   */          dp3 r5.__z_, r4.zxyy, r5.wxyy
              +       retain_prev r1._
/*  104   */          dp3 r0._y__, r5.wxyy, -c38.zxyy
              +       retain_prev r1._
/*  105   */          add r5.xy_w, r5.xyww, -r11.zyxx
              +       retain_prev r1._
/*  106   */          dp3 r2.___w, r5.wxyy, r5.wxyy
              +       maxs r1._, r1.yy
/*  107   */          add r1._y__, r0.yyyy, -c39.xxxx
              +       muls_prev r1.x___, r1.x
/*    8.0 */       exec
/*  108   */          mul r0.___w, r1.yyyy, c39.yyyy
              +       subsc r1._y__, -c36.w, -r1.x
/*  109   */          max r0.___w, r0.wwww, c39.wwww
              +       rsq r2.___w, r_abs[2].w
/*  110   */          mul r7.xyz_, r5.xyww, r2.wwww
              +       mulsc_sat r2.___w, c37.w, r1.y
/*  111   */          min r5.x___, r0.wwww, c254.yyyy
              +       subsc r2.___w, c254.y, r2.w
/*  112   */          dp3 r5._y__, r4.zxyy, r7.zxyy
              +       maxs r1._, r2.ww
/*  113   */          max r7.xy__, r5.yzzz, c254.xxxx
              +       muls_prev r5._y__, r5.x
/*    8.1 */       exec    // PredicateClean=false
/*  114   */          mul r5.xyz_, r5.xyyy, c36.xzyy
              +       log r1._y__, r_abs[7].x
/*  115   */          mul r5.___w, r5.xxxx, r2.wwww
              +       mulsc r2.___w, c15.z, r1.y
/*  116   */          mul r7.xyz_, r5.yzww, r7.yyyy
              +       exp r2.___w, r2.w
/*  117   */          mul r5.xyz_, r5.wzyy, r2.wwww
              +       setp_ne r1._, r0.z
/*    9.0 */  (p0) exec
/*  118   */     (p0) max r1._, r1, r1
              +  (p0) maxs r13.___w, c254.yy
/*  119   */     (p0) mul r13.xyz_, r1.xxxx, c38.xyzz
              +  (p0) rcp r1._y__, c64.z
/*  120   */     (p0) mad r0._yzw, r13.xxyz, r0.yyyy, c37.xxyz
              +  (p0) retain_prev r1._
/*  121   */     (p0) add r13.xyz_, -r0.yzww, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  122   */     (p0) dp4 r0._y__, c69.zxyw, r13.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  123   */     (p0) dp4 r0.__z_, c70.zxyw, r13.zxyw
              +  (p0) mulsc r1.x___, c64.w, r1.x
/*    9.1 */  (p0) exec
/*  124   */     (p0) mul r0._yz_, r0.yyzz, c253.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  125   */     (p0) mul r1.xy__, r0.yzzz, r1.xxxx
              +  (p0) retain_prev r1._
/*  126   */     (p0) add r0._y__, r1.xxxx, c253.xxxx
              +  (p0) subsc r0.__z_, c253.x, r1.y
/*  127   */     (p0) tfetch2D r0._xyz, r0.yz, tf2
/*  128   */          serialize
                 (p0) mul r7.xyz_, r7.xyzz, r0.wzyy
              +  (p0) retain_prev r1._
/*  129   */     (p0) mul r5.xyz_, r5.xyzz, r0.yzww
              +  (p0) retain_prev r1._
/*   10.0 */       exec
/*  130   */          max r1._, r1, r1
              +       mulsc r2.___w, c39.z, r0.x
/*  131   */          mad r12.xyz_, r2.wwww, r7.zxyy, r12.xyzz
              +       retain_prev r1._
/*  132   */          mad r9.xyz_, r0.xxxx, r5.zyxx, r9.xyzz
              +       retain_prev r1._
/*   10.1 */       cjmp !b130, L37
/*   11.0 */       exec
/*  133   */          sgt r4.___w, c65.zzzz, c254.wwww
              +       retain_prev r1._
/*  134   */          add r0._yzw, -r2.xxyz, c41.xxyz
              +       retain_prev r1._
/*  135   */          mul r5, r8, c50
              +       retain_prev r1._
/*  136   */          dp3 r1._y__, r0.wyzz, r0.wyzz
              +       retain_prev r1._
/*  137   */          max4 r1.x___, r5.ywxz
              +       retain_prev r1._
/*  138   */          add r0.x___, -r1.xxxx, c254.yyyy
              +       rsq r1.x___, r_abs[1].y
/*   11.1 */       exec
/*  139   */          mul r5.xyz_, r0.yzww, r1.xxxx
              +       retain_prev r1._
/*  140   */          dp3 r0.__z_, r4.zxyy, r5.zxyy
              +       retain_prev r1._
/*  141   */          dp3 r3.x___, r5.zxyy, -c42.zxyy
              +       retain_prev r1._
/*  142   */          add r5.xyz_, r5.xyzz, -r11.zyxx
              +       retain_prev r1._
/*  143   */          dp3 r2.___w, r5.zxyy, r5.zxyy
              +       maxs r1._, r1.yy
/*  144   */          add r1._y__, r3.xxxx, -c43.xxxx
              +       muls_prev r1.x___, r1.x
/*   12.0 */       exec
/*  145   */          mul r0._y__, r1.yyyy, c43.yyyy
              +       subsc r1._y__, -c40.w, -r1.x
/*  146   */          max r0._y__, r0.yyyy, c43.wwww
              +       rsq r2.___w, r_abs[2].w
/*  147   */          mul r5._yzw, r5.xxyz, r2.wwww
              +       mulsc_sat r2.___w, c41.w, r1.y
/*  148   */          min r5.x___, r0.yyyy, c254.yyyy
              +       subsc r2.___w, c254.y, r2.w
/*  149   */          dp3 r0._y__, r4.zxyy, r5.wyzz
              +       maxs r1._, r2.ww
/*  150   */          max r0._yz_, r0.yyzz, c254.xxxx
              +       muls_prev r5._y__, r5.x
/*   12.1 */       exec    // PredicateClean=false
/*  151   */          mul r5.xyz_, r5.xyyy, c40.xzyy
              +       log r1._y__, r_abs[0].y
/*  152   */          mul r5.___w, r5.xxxx, r2.wwww
              +       mulsc r2.___w, c15.z, r1.y
/*  153   */          mul r0._yzw, r5.yyzw, r0.zzzz
              +       exp r2.___w, r2.w
/*  154   */          mul r5.xyz_, r5.wzyy, r2.wwww
              +       setp_ne r1._, r4.w
/*   13.0 */  (p0) exec
/*  155   */     (p0) max r1._, r1, r1
              +  (p0) maxs r14.___w, c254.yy
/*  156   */     (p0) mul r13.xyz_, r1.xxxx, c42.xyzz
              +  (p0) rcp r1._y__, c65.z
/*  157   */     (p0) mad r13.xyz_, r13.xyzz, r3.xxxx, c41.xyzz
              +  (p0) retain_prev r1._
/*  158   */     (p0) add r14.xyz_, -r13.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  159   */     (p0) dp4 r13.x___, c71.zxyw, r14.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  160   */     (p0) dp4 r13._y__, c72.zxyw, r14.zxyw
              +  (p0) mulsc r1.x___, c65.w, r1.x
/*   13.1 */  (p0) exec
/*  161   */     (p0) mul r13.xy__, r13.xyyy, c253.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  162   */     (p0) mul r1.xy__, r13.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*  163   */     (p0) add r13.x___, r1.xxxx, c253.xxxx
              +  (p0) subsc r13._y__, c253.x, r1.y
/*  164   */     (p0) tfetch2D r13.xyz_, r13.xy, tf3
/*  165   */          serialize
                 (p0) mul r0._yzw, r0.yyzw, r13.zzyx
              +  (p0) retain_prev r1._
/*  166   */     (p0) mul r5.xyz_, r5.xyzz, r13.xyzz
              +  (p0) retain_prev r1._
/*   14.0 */       exec
/*  167   */          max r1._, r1, r1
              +       mulsc r2.___w, c43.z, r0.x
/*  168   */          mad r12.xyz_, r2.wwww, r0.wyzz, r12.xyzz
              +       retain_prev r1._
/*  169   */          mad r9.xyz_, r0.xxxx, r5.zyxx, r9.xyzz
              +       retain_prev r1._
/*   14.1 */       cjmp !b131, L37
/*   15.0 */       exec
/*  170   */          sgt r4.___w, c66.zzzz, c254.wwww
              +       retain_prev r1._
/*  171   */          add r0._yzw, -r2.xxyz, c45.xxyz
              +       retain_prev r1._
/*  172   */          mul r5, r8, c51
              +       retain_prev r1._
/*  173   */          dp3 r1._y__, r0.wyzz, r0.wyzz
              +       retain_prev r1._
/*  174   */          max4 r1.x___, r5.ywxz
              +       retain_prev r1._
/*  175   */          add r0.x___, -r1.xxxx, c254.yyyy
              +       rsq r1.x___, r_abs[1].y
/*   15.1 */       exec
/*  176   */          mul r5.xyz_, r0.yzww, r1.xxxx
              +       retain_prev r1._
/*  177   */          dp3 r0.__z_, r4.zxyy, r5.zxyy
              +       retain_prev r1._
/*  178   */          dp3 r3.x___, r5.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  179   */          add r5.xyz_, r5.xyzz, -r11.zyxx
              +       retain_prev r1._
/*  180   */          dp3 r2.___w, r5.zxyy, r5.zxyy
              +       maxs r1._, r1.yy
/*  181   */          add r1._y__, r3.xxxx, -c47.xxxx
              +       muls_prev r1.x___, r1.x
/*   16.0 */       exec
/*  182   */          mul r0._y__, r1.yyyy, c47.yyyy
              +       subsc r1._y__, -c44.w, -r1.x
/*  183   */          max r0._y__, r0.yyyy, c47.wwww
              +       rsq r2.___w, r_abs[2].w
/*  184   */          mul r5._yzw, r5.xxyz, r2.wwww
              +       mulsc_sat r2.___w, c45.w, r1.y
/*  185   */          min r5.x___, r0.yyyy, c254.yyyy
              +       subsc r2.___w, c254.y, r2.w
/*  186   */          dp3 r0._y__, r4.zxyy, r5.wyzz
              +       maxs r1._, r2.ww
/*  187   */          max r0._yz_, r0.yyzz, c254.xxxx
              +       muls_prev r5._y__, r5.x
/*   16.1 */       exec    // PredicateClean=false
/*  188   */          mul r13.xyz_, r5.xyyy, c44.xzyy
              +       log r1._y__, r_abs[0].y
/*  189   */          mul r13.___w, r13.xxxx, r2.wwww
              +       mulsc r2.___w, c15.z, r1.y
/*  190   */          mul r5.xyz_, r13.yzww, r0.zzzz
              +       exp r2.___w, r2.w
/*  191   */          mul r0._yzw, r13.wwzy, r2.wwww
              +       setp_ne r1._, r4.w
/*   17.0 */  (p0) exec
/*  192   */     (p0) max r1._, r1, r1
              +  (p0) maxs r14.___w, c254.yy
/*  193   */     (p0) mul r13.xyz_, r1.xxxx, c46.xyzz
              +  (p0) rcp r1._y__, c66.z
/*  194   */     (p0) mad r13.xyz_, r13.xyzz, r3.xxxx, c45.xyzz
              +  (p0) retain_prev r1._
/*  195   */     (p0) add r14.xyz_, -r13.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  196   */     (p0) dp4 r13.x___, c73.zxyw, r14.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  197   */     (p0) dp4 r13._y__, c74.zxyw, r14.zxyw
              +  (p0) mulsc r1.x___, c66.w, r1.x
/*   17.1 */  (p0) exec
/*  198   */     (p0) mul r13.xy__, r13.xyyy, c253.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  199   */     (p0) mul r1.xy__, r13.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*  200   */     (p0) add r13.x___, r1.xxxx, c253.xxxx
              +  (p0) subsc r13._y__, c253.x, r1.y
/*  201   */     (p0) tfetch2D r13.xyz_, r13.xy, tf4
/*  202   */          serialize
                 (p0) mul r5.xyz_, r5.xyzz, r13.zyxx
              +  (p0) retain_prev r1._
/*  203   */     (p0) mul r0._yzw, r0.yyzw, r13.xxyz
              +  (p0) retain_prev r1._
/*   18.0 */       exec
/*  204   */          max r1._, r1, r1
              +       mulsc r2.___w, c47.z, r0.x
/*  205   */          mad r12.xyz_, r2.wwww, r5.zxyy, r12.xyzz
              +       retain_prev r1._
/*  206   */          mad r9.xyz_, r0.xxxx, r0.wzyy, r9.xyzz
              +       retain_prev r1._
                label L37
/*   18.1 */       cjmp !b132, L49
/*   19.0 */       exec
/*  207   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  208   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  209   */          mul r5, r8.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  210   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  211   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  212   */          dp3 r2.___w, r0.xzyy, r4.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   19.1 */       exec
/*  213   */          max4 r0._y__, r5.zxwy
              +       maxs r0.__z_, r2.ww
/*  214   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  215   */          mul r5.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  216   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  217   */          mad r12.xyz_, r5.zxyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
/*   20.0 */       cjmp !b133, L49
/*   20.1 */       exec
/*  218   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  219   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  220   */          mul r5, r8, c53
              +       rsq r1.x___, r_abs[0].w
/*  221   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  222   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  223   */          dp3 r2.___w, r0.zxyy, r4.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   21.0 */       exec
/*  224   */          max4 r0._y__, r5.ywxz
              +       maxs r0.__z_, r2.ww
/*  225   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  226   */          mul r5.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  227   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  228   */          mad r12.xyz_, r5.zxyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
/*   21.1 */       cjmp !b134, L49
/*   22.0 */       exec
/*  229   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  230   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  231   */          mul r5, r8.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  232   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  233   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  234   */          dp3 r2.___w, r0.xzyy, r4.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   22.1 */       exec
/*  235   */          max4 r0._y__, r5.zxwy
              +       maxs r0.__z_, r2.ww
/*  236   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  237   */          mul r5.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  238   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  239   */          mad r12.xyz_, r5.zxyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
/*   23.0 */       cjmp !b135, L49
/*   23.1 */       exec
/*  240   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  241   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  242   */          mul r5, r8, c55
              +       rsq r1.x___, r_abs[0].w
/*  243   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  244   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  245   */          dp3 r2.___w, r0.zxyy, r4.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   24.0 */       exec
/*  246   */          max4 r0._y__, r5.ywxz
              +       maxs r0.__z_, r2.ww
/*  247   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  248   */          mul r5.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  249   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  250   */          mad r12.xyz_, r5.zxyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
                label L49
/*   24.1 */       exec
/*  251   */          mul r13, r4.xyzz, r4.yzzx
              +       retain_prev r1._
/*  252   */          cndeq r0, c254.xxxy, r4.zxyy, c254.yyyy
              +       retain_prev r1._
/*  253   */          dp4 r5.x___, c16.zxyw, r0
              +       retain_prev r1._
/*  254   */          dp4 r5._y__, c18.zxyw, r0
              +       retain_prev r1._
/*  255   */          dp4 r5.__z_, c17.zxyw, r0
              +       retain_prev r1._
/*  256   */          dp4 r0.x___, r13.wzxy, c19.wzxy
              +       muls r8.x___, r4.xx
/*   25.0 */       exec    // PredicateClean=false
/*  257   */          dp4 r0._y__, r13.wzxy, c21.wzxy
              +       muls r8._y__, r4.yy
/*  258   */          dp4 r0.__z_, r13.wzxy, c20.wzxy
              +       subs r2.___w, r8.xy
/*  259   */          add r0.xyz_, r5.zxyy, r0.zxyy
              +       setp_gt r1._, c_abs[57].x
/*  260   */          mad r0.xyz_, r2.wwww, c22.xyzz, r0.yxzz
              +       retain_prev r1._
/*  261   */          mad r5.xyz_, r12.xzyy, r1.wwww, r0.xyzz
              +       retain_prev r1._
/*   25.1 */  (p0) exec
/*  262   */     (p0) mul r8.xyz_, r5.zyxx, c60.xxxx
              +  (p0) retain_prev r1._
/*  263   */     (p0) mul r0.xyz_, r5.zyxx, c61.xxxx
              +  (p0) retain_prev r1._
/*  264   */     (p0) mul r0.xyz_, r0.xyzz, c59.xxxx
              +  (p0) retain_prev r1._
/*  265   */     (p0) mad r5.xyz_, r8.zyxx, c58.xxxx, r0.zyxx
              +  (p0) retain_prev r1._
/*   26.0 */       exec
/*  266   */          dp3 r8._y__, r11.xzyy, r4.zxyy
              +       retain_prev r1._
/*  267   */          max r1._, r1, r1
              +       adds r1.x___, r8.yy
/*  268   */          mad r0.xyz_, -r4.xyzz, r1.xxxx, r11.zyxx
              +       retain_prev r1._
/*  269   */          cube r0, r0.zzxy, r0.yxzz
              +       retain_prev r1._
/*  270   */          max r4.__z_, r0.wwww, r0.wwww
              +       rcp r1.x___, r_abs[0].z
/*  271   */          mad r4.xy__, r0.yxxx, r1.xxxx, c253.zzzz
              +       retain_prev r1._
/*   26.1 */       exec
/*  272   */          setTexLOD r3.w
/*  273   */          tfetchCube r4, r4.xyz, tf7, UseComputedLOD=false, UseRegisterLOD=true
/*   27.0 */       alloc colors
/*   27.1 */       exec
/*  274   */          max r1.x___, r4.wwww, c253.wwww
              +       mulsc r8.x___, c6.x, r3.z
/*  275   */          add r0.xy__, -r8.xyyy, c254.yyyy
              +       rcp r1.x___, r1.x
/*  276   */          mul r3.x_zw, r1.xxxx, r4.xyyz
              +       retain_prev r1._
/*  277   */          mul r4.xyz_, r3.wzxx, r0.xxxx
              +       muls r1.x___, r_abs[0].yy
/*  278   */          max r1._, r1, r1
              +       muls r1.x___, r1.xx
/*  279   */          mul r4.___w, r1.xxxx, r_abs[0].yyyy
              +       retain_prev r1._
/*   28.0 */       exec    // PredicateClean=false
/*  280   */          mad r0.xyz_, r4.zyxx, c15.wwww, r9.zyxx
              +       retain_prev r1._
/*  281   */          mad_sat r1.x___, r4.wwww, c15.xxxx, c15.yyyy
              +       retain_prev r1._
/*  282   */          max r1._, r1, r1
              +       subsc r1.x___, c254.y, r1.x
/*  283   */          mul r1.x___, r1.xxxx, r1.wwww
              +       setp_ne r1._, c57.x
/*  284   */     (p0) mul r0.xyz_, r0.xyzz, c62.xxxx
              +  (p0) retain_prev r1._
/*  285   */          mul r1.xy_w, r1.xxxx, r10.xyzz
              +       maxs r1._, r7.ww
/*   28.1 */       exec
/*  286   */          mul r0.xyz_, r1.xyww, r0.xyzz
              +       muls_prev r1.___w, r1.z
/*  287   */          mad r0.xyz_, r6.xyww, r5.xyzz, r0.xyzz
              +       retain_prev r1._
/*   29.0 */       cjmp !b136, L62
/*   29.1 */       exec
/*  288   */          mad r2.___w, r3.yyyy, c12.yyyy, c12.zzzz
              +       retain_prev r1._
/*  289   */          dp3 r1.__z_, r11.xzyy, c10.zxyy
              +       retain_prev r1._
/*  290   */          cndeq r4, c254.xxxy, r2.zxyy, c254.yyyy
              +       retain_prev r1._
/*  291   */          dp4 r1._y__, c10.zxyw, r4
              +       subsc r1.x___, -c9.x, -r3.y
/*  292   */          add r2.xyz_, -r0.xyzz, c11.xyzz
              +       mulsc r0.___w, c9.z, r1.x
/*  293   */          min r3.xy__, r1.yzzz, c254.xzzz
              +       mulsc r1.x___, c9.w, r1.y
/*   30.0 */       exec
/*  294   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  295   */          max r1._, r1, r1
              +       mulsc r1.x___, c12.x, r1.y
/*  296   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  297   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  298   */          min r1.x___, r1.xxxx, c11.wwww
              +       retain_prev r1._
/*  299   */          max r1.x___, r1.xxxx, c254.xxxx
              +       retain_prev r1._
/*   30.1 */       exec
/*  300   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L62
/*   31.0 */       exece
/*  301   */          mul r1.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  302   */          max oC0, r1, r1
/*   31.1 */       cnop
