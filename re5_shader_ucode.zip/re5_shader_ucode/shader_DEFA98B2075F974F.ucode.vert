/*    0.0 */       exec
/*    3   */          vfetch_full r1.xyz1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    4   */          dp4 r0.x___, c4.zxyw, r1.zxyw
/*    5   */          dp4 r0._y__, c5.zxyw, r1.zxyw
/*    6   */          dp4 r0.__z_, c6.zxyw, r1.zxyw
              +       sges r0.___w, r_abs[0].x
/*    7   */          mad r0.xyz_, c7.xyzz, c23.xxxx, r0.xyzz
/*    8   */          dp4 oPos.x___, c0.zxyw, r0.zxyw
/*    9   */          dp4 oPos._y__, c1.zxyw, r0.zxyw
/*    1.1 */       exec
/*   10   */          dp4 oPos.__z_, c2.zxyw, r0.zxyw
/*   11   */          dp4 oPos.___w, c3.zxyw, r0.zxyw
/*    2.0 */       alloc interpolators
/*    2.1 */       exece
