/*    0.0 */       exec
/*    6   */          vfetch_full r3.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=6
/*    7   */          vfetch_mini r6.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    8   */          vfetch_mini r5, Offset=3, DataFormat=FMT_8_8_8_8
/*    9   */          vfetch_mini r1.__yx, Offset=5, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   10   */          serialize
                      mul r1.xy__, r6.zwww, c255.xxxx
/*   11   */          maxas r0._, r1.yy
/*    0.1 */       exec    // PredicateClean=false
/*   12   */          mul r4, r5.yyyy, c[25+a0]
/*   13   */          mul r0, r5.yyyy, c[24+a0]
              +       setp_gt r0._, r5.z
/*   14   */          mul r2, r5.yyyy, c[23+a0]
              +       maxas r0._, r1.xx
/*   15   */          mad r2.xyz_, r5.xxxx, c[23+a0].xyzz, r2.xyzz
/*   16   */          mad r1.x___, r5.xxxx, c[23+a0].wwww, r2.wwww
/*   17   */          mad r0, r5.xxxx, c[24+a0], r0
/*    1.0 */       exec
/*   18   */          mad r4.xyz_, r5.xxxx, c[25+a0].xyzz, r4.xyzz
/*   19   */          mad r1._y__, r5.xxxx, c[25+a0].wwww, r4.wwww
/*    1.1 */  (p0) exec
/*   20   */     (p0) mul r5.xy__, r6.xyyy, c255.xxxx
/*   21   */     (p0) maxas r0._, r5.yy
/*   22   */     (p0) mul r7, r5.wwww, c[23+a0]
/*   23   */     (p0) mad r0, r5.wwww, c[24+a0], r0
/*   24   */     (p0) mul r6, r5.wwww, c[25+a0]
              +  (p0) maxas r0._, r5.xx
/*   25   */     (p0) mad r0, r5.zzzz, c[24+a0], r0
/*    2.0 */  (p0) exec
/*   26   */     (p0) mad r6, r5.zzzz, c[25+a0], r6
/*   27   */     (p0) mad r5, r5.zzzz, c[23+a0], r7
/*   28   */     (p0) add r1.x___, r5.wwww, r1.xxxx
/*   29   */     (p0) add r2.xyz_, r5.xyzz, r2.xyzz
              +  (p0) maxs r0._, r6.ww
/*   30   */     (p0) add r4.xyz_, r6.xyzz, r4.xyzz
              +  (p0) adds_prev r1._y__, r1.y
/*    2.1 */       exec
/*   31   */          mul r1.__zw, r1.zzzw, c5.yyyx
/*   32   */          tfetch2D r5.xyz_, r1.wz, tf16, UseComputedLOD=false
/*    3.0 */       alloc position
/*    3.1 */       exec
/*   33   */          mad r3.xyz_, r3.xyzz, c215.xyzz, c4.xyzz
/*   34   */          add r3.xyz_, r3.xyzz, r5.xyzz
/*   35   */          dp3 r1.__z_, r3.zxyy, r2.zxyy
/*   36   */          dp3 r1.___w, r3.zxyy, r4.zxyy
              +       sges r3.___w, r_abs[0].x
/*   37   */          dp4 r0._y__, r0.zxyw, r3.zxyw
/*   38   */          add r0.x_z_, r1.zwww, r1.xyyy
              +       sges r0.___w, r_abs[0].x
/*    4.0 */       exec
/*   39   */          mad r0.xyz_, c7.xyzz, c6.xxxx, r0.xyzz
/*   40   */          dp4 oPos.x___, c0.zxyw, r0.zxyw
/*   41   */          dp4 oPos._y__, c1.zxyw, r0.zxyw
/*   42   */          dp4 oPos.__z_, c2.zxyw, r0.zxyw
/*   43   */          dp4 oPos.___w, c3.zxyw, r0.zxyw
/*    4.1 */       alloc interpolators
/*    5.0 */       exece
/*    5.1 */       cnop
