/*    0.0 */       exec
/*    2   */          tfetch2D r1, r1.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    3   */          mul r1.xyz_, r1.xyzz, r0.xyzz
/*    4   */          add r2.xyz_, -r1.xyzz, r3.xyzz
              +       maxs r0._, r1.ww
/*    5   */          mad r1.xyz_, r2.xyzz, r3.wwww, r1.xyzz
/*    6   */          mul oC0.xyz_, r1.xyzz, c23.xxxx
              +       muls_prev oC0.___w, r0.w
/*    1.1 */       cnop
