/*    0.0 */       exec
/*    2   */          tfetch2D r1.xyz_, r1.xy, tf1
/*    3   */          tfetch2D r0._x__, r0.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    4   */          subsc r0.x___, c255.x, r0.y
/*    5   */          max oC0.xyz_, r1.xyzz, r1.xyzz
/*    6   */          sgt r0._y__, r0.xxxx, c48.xxxx
/*    7   */          cndeq oC0.___w, r0.yyyy, r0.xxxx, c255.xxxx
/*    1.1 */       cnop
