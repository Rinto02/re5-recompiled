/*    0.0 */       exec
/*    7   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    8   */          vfetch_mini r1.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    9   */          vfetch_mini r0.x___, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   10   */          serialize
                      mad r3.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*   11   */          mulsc r0.x___, c255.w, r0.x
/*   12   */          maxas r0._, r0.xx
/*    0.1 */       exec
/*   13   */          max r0, c[28+a0], c[28+a0]
/*   14   */          max r4, c[29+a0], c[29+a0]
/*   15   */          max r2, c[30+a0].zyxw, c[30+a0].zyxw
/*   16   */          cndeq r3, c255.zzzx, r3.zxyy, c255.xxxx
/*   17   */          dp4 r0.x___, r0.zxyw, r3
/*   18   */          dp4 r0._y__, r4.zxyw, r3
/*    1.0 */       exec
/*   19   */          dp4 r0.__z_, r2.xzyw, r3
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   20   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   21   */          dp4 r2.x___, c0.zxyw, r0
/*   22   */          dp4 r2._y__, c1.zxyw, r0
/*   23   */          dp4 r2.__z_, c2.zxyw, r0
/*   24   */          dp2add r0.x___, r2.xyyy, r2.xyyy, c255.zzzz
/*   25   */          dp3 r0._y__, r2.zxyy, r2.zxyy
/*    2.1 */       exec
/*   26   */          sqrt r0.___w, r_abs[0].y
/*   27   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   28   */          add r0._y__, -r2.zzzz, r0.wwww
/*   29   */          mul r1.__zw, r2.xxxy, r0.wwww
/*   30   */          mul r1.__zw, r1.wwwz, r0.yyyy
              +       rcp r0.x___, r0.x
/*   31   */          mul r0.xy__, r1.wzzz, r0.xxxx
/*    3.0 */       exec
/*   32   */          cndge r0.__zw, r2.zzzz, r0.zzzw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   33   */          cndeq r2, c255.zzzx, r0.zxyy, c255.xxxx
/*   34   */          dp4 r0.x___, c23.zxyw, r2
/*   35   */          dp4 r0._y__, c24.zxyw, r2
/*   36   */          dp4 r0.__z_, c25.zxyw, r2
/*   37   */          dp4 r0.___w, c26.zxyw, r2
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   38   */          max oPos, r0, r0
/*    5.1 */       alloc interpolators
/*    6.0 */       exece
/*   39   */          add o0.xy__, r1.xyyy, c5.xyyy
/*    6.1 */       cnop
