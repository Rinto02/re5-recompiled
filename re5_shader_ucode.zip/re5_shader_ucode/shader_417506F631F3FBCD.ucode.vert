/*    0.0 */       exec
/*    7   */          vfetch_full r2.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*    8   */          vfetch_mini r7.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*    9   */          vfetch_mini r5.__w_, Offset=4, DataFormat=FMT_8_8_8_8, Signed=true
/*   10   */          vfetch_mini r5.yx__, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   11   */          vfetch_mini r0.zwyx, Offset=7, DataFormat=FMT_8_8_8_8
/*   12   */          serialize
                      max r3, c28, c28
/*    0.1 */       exec
/*   13   */          max r6, c29, c29
/*   14   */          max r1, c30, c30
/*   15   */          cndeq r2, c255.zzzx, r2.zxyy, c255.xxxx
/*   16   */          dp4 r4.x___, r3.zxyw, r2
/*   17   */          dp4 r4._y__, r6.zxyw, r2
/*   18   */          dp4 r4.__z_, r1.zxyw, r2
/*    1.0 */       cjmp !b0, L7
/*    1.1 */       exec
/*   19   */          cndeq r2, c255.zzzx, r4.zxyy, c255.xxxx
/*   20   */          dp4 r8.x___, c0.zxyw, r2
/*   21   */          dp4 r8._y__, c1.zxyw, r2
/*   22   */          dp4 r8.__z_, c2.zxyw, r2
/*   23   */          dp2add r2.x___, r8.xyyy, r8.xyyy, c255.zzzz
/*   24   */          dp3 r2._y__, r8.zxyy, r8.zxyy
/*    2.0 */       exec
/*   25   */          sqrt r2.___w, r_abs[2].y
/*   26   */          mad r2.__z_, r2.wwww, c27.xxxx, c27.yyyy
/*   27   */          add r2._y__, -r8.zzzz, r2.wwww
/*   28   */          mul r9.xy__, r8.xyyy, r2.wwww
/*   29   */          mul r9.xy__, r9.yxxx, r2.yyyy
              +       rcp r2.x___, r2.x
/*   30   */          mul r2.xy__, r9.yxxx, r2.xxxx
/*    2.1 */       exec
/*   31   */          cndge r2.__zw, r8.zzzz, r2.zzzw, c255.xxxy
/*    3.0 */       jmp L8
                label L7
/*    3.1 */       exec
/*   32   */          cndeq r8, c255.zzzx, r4.zxyy, c255.xxxx
/*   33   */          dp4 r2.x___, c23.zxyw, r8
/*   34   */          dp4 r2._y__, c24.zxyw, r8
/*   35   */          dp4 r2.__z_, c25.zxyw, r8
/*   36   */          dp4 r2.___w, c26.zxyw, r8
                label L8
/*    4.0 */       alloc position
/*    4.1 */       exec
/*   37   */          mad r2.__z_, -r2.wwww, c4.xxxx, r2.zzzz
/*   38   */          max oPos, r2, r2
/*    5.0 */       alloc interpolators
/*    5.1 */       exec
/*   39   */          add r5.xy__, r5.xyyy, c3.xyyy
              +       mulsc r5.___w, c31.x, r0.y
/*   40   */          dp3 o3.x___, r7.zxyy, r3.zxyy
/*   41   */          dp3 o3._y__, r7.zxyy, r6.zxyy
/*   42   */          dp3 o3.__z_, r7.zxyy, r1.zxyy
/*   43   */          max o2.xyz_, r4.xyzz, r4.xyzz
/*   44   */          max o1, r5.xywz, r5.xywz
/*    6.0 */       exece
/*   45   */          max o0, r2, r2
/*   46   */          max o4, r0.xzwy, r0.xzwy
/*    6.1 */       cnop
