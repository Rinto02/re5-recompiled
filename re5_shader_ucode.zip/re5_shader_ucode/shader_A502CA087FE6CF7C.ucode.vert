/*    0.0 */       exec
/*    7   */          vfetch_full r4.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*    8   */          vfetch_mini r7.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*    9   */          vfetch_mini r8.___w, Offset=4, DataFormat=FMT_8_8_8_8, Signed=true
/*   10   */          vfetch_mini r2.__yx, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   11   */          vfetch_mini r2.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   12   */          vfetch_mini r1.zyxw, Offset=7, DataFormat=FMT_8_8_8_8
/*    0.1 */       exec
/*   13   */          serialize
                      max r0, c28, c28
/*   14   */          max r6, c29, c29
/*   15   */          max r3, c30, c30
/*   16   */          cndeq r4, c255.zzzx, r4.zxyy, c255.xxxx
/*   17   */          dp4 r5.x___, r0.zxyw, r4
/*   18   */          dp4 r5._y__, r6.zxyw, r4
/*    1.0 */       exec
/*   19   */          dp4 r5.__z_, r3.zxyw, r4
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   20   */          cndeq r4, c255.zzzx, r5.zxyy, c255.xxxx
/*   21   */          dp4 r8.x___, c0.zxyw, r4
/*   22   */          dp4 r8._y__, c1.zxyw, r4
/*   23   */          dp4 r8.__z_, c2.zxyw, r4
/*   24   */          dp2add r4.x___, r8.xyyy, r8.xyyy, c255.zzzz
/*   25   */          dp3 r4._y__, r8.zxyy, r8.zxyy
/*    2.1 */       exec
/*   26   */          sqrt r4.___w, r_abs[4].y
/*   27   */          mad r4.__z_, r4.wwww, c27.xxxx, c27.yyyy
/*   28   */          add r4._y__, -r8.zzzz, r4.wwww
/*   29   */          mul r9.xy__, r8.xyyy, r4.wwww
/*   30   */          mul r9.xy__, r9.yxxx, r4.yyyy
              +       rcp r4.x___, r4.x
/*   31   */          mul r4.xy__, r9.yxxx, r4.xxxx
/*    3.0 */       exec
/*   32   */          cndge r4.__zw, r8.zzzz, r4.zzzw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   33   */          cndeq r9, c255.zzzx, r5.zxyy, c255.xxxx
/*   34   */          dp4 r4.x___, c23.zxyw, r9
/*   35   */          dp4 r4._y__, c24.zxyw, r9
/*   36   */          dp4 r4.__z_, c25.zxyw, r9
/*   37   */          dp4 r4.___w, c26.zxyw, r9
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   38   */          mad r4.__z_, -r4.wwww, c5.xxxx, r4.zzzz
/*   39   */          max oPos, r4, r4
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   40   */          maxs r8.__z_, c31.xx
/*   41   */          add r8.xy__, r2.zwww, c3.xyyy
              +       rcp r0.___w, r1.w
/*   42   */          dp3 o5.x___, r7.zxyy, r0.zxyy
/*   43   */          dp3 o5._y__, r7.zxyy, r6.zxyy
/*   44   */          dp3 o5.__z_, r7.zxyy, r3.zxyy
/*   45   */          add o4.xy00, r2.xyyy, c4.zwww
/*    6.1 */       exece
/*   46   */          max o2.xyz_, r5.xyzz, r5.xyzz
/*   47   */          max o1, r8, r8
/*   48   */          max o0, r4, r4
/*   49   */          mul o3.xyz_, r0.wwww, r1.xyzz
