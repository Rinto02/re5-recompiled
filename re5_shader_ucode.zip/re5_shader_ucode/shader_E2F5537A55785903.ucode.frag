/*    0.0 */       exec
/*   12   */          max r2, c255, c255
/*   13   */          tfetch2D r3, r2.ww, tf1
/*   14   */          tfetch2D r20, r2.yx, tf0
/*   15   */          serialize
                      dp3 r1.___w, r20.zxyy, c254.xyzz
              +       maxs r0.x___, r3.ww
/*   16   */          subsc r1.x___, -c255.z, -r0.x
/*   17   */          tfetch2D r8, r2.wz, tf1
/*    0.1 */       exec
/*   18   */          tfetch2D r17, r2.xx, tf1
/*   19   */          serialize
                      dp3 r9.x___, r17.zxyy, c254.xyzz
              +       maxs r0.x___, r8.ww
/*   20   */          tfetch2D r10, r2.xw, tf0
/*   21   */          serialize
                      dp3 r10.x___, r10.zxyy, c254.xyzz
              +       subsc r7.__z_, -c255.z, -r0.x
/*   22   */          tfetch2D r12, r2.yx, tf1
/*   23   */          serialize
                      dp3 r9.___w, r12.zxyy, c254.xyzz
              +       maxs r0.x___, r10.ww
/*    1.0 */       exec
/*   24   */          tfetch2D r15, r2.wy, tf1
/*   25   */          serialize
                      dp3 r10.__z_, r15.zxyy, c254.xyzz
              +       subsc r7._y__, -c255.z, -r0.x
/*   26   */          tfetch2D r13, r2.yy, tf1
/*   27   */          serialize
                      dp3 r14.x___, r13.zxyy, c254.xyzz
              +       maxs r0.x___, r15.ww
/*   28   */          tfetch2D r16, r2.yz, tf1
/*   29   */          tfetch2D r6, r2.yy, tf0
/*    1.1 */       exec
/*   30   */          serialize
                      dp3 r14._y__, r6.zxyy, c254.xyzz
              +       subsc r4.x___, -c255.z, -r0.x
/*   31   */          add r21._y__, r6.wwww, -c255.zzzz
              +       maxs r0.x___, r16.ww
/*   32   */          tfetch2D r19, r2.zz, tf0
/*   33   */          tfetch2D r5, r2.zx, tf1
/*   34   */          serialize
                      dp3 r14.__z_, r5.zxyy, c254.xyzz
              +       subsc r9.__z_, -c255.z, -r0.x
/*   35   */          add r21.__z_, r5.wwww, -c255.zzzz
              +       maxs r0.x___, r19.ww
/*    2.0 */       exec
/*   36   */          tfetch2D r25, r2.xy, tf1
/*   37   */          serialize
                      dp3 r4._y__, r25.zxyy, c254.xyzz
              +       subsc r9._y__, -c255.z, -r0.x
/*   38   */          maxs r0.x___, r25.ww
/*   39   */          tfetch2D r22, r2.zx, tf0
/*   40   */          serialize
                      subsc r11.x___, -c255.z, -r0.x
/*   41   */          dp3 r14.___w, r22.zxyy, c254.xyzz
              +       maxs r0.x___, r12.ww
/*    2.1 */       exec
/*   42   */          tfetch2D r26, r2.yw, tf1
/*   43   */          tfetch2D r24.xywz, r2.xx, tf0
/*   44   */          serialize
                      dp3 r1.__z_, r24.wxyy, c254.xyzz
              +       subsc r18.__z_, -c255.z, -r0.x
/*   45   */          maxs r0.x___, r24.zz
/*   46   */          tfetch2D r27.xwyz, r2.yw, tf0
/*   47   */          serialize
                      subsc r18._y__, -c255.z, -r0.x
/*    3.0 */       exec
/*   48   */          dp3 r12._y__, r27.wxzz, c254.xyzz
              +       maxs r0.x___, r13.ww
/*   49   */          tfetch2D r13, r2.xz, tf1
/*   50   */          tfetch2D r23, r2.xz, tf0
/*   51   */          serialize
                      subsc r21.x___, -c255.z, -r0.x
/*   52   */          dp3 r12.__z_, r13.zxyy, c254.xyzz
              +       maxs r0.x___, r13.ww
/*   53   */          add r13.x___, r26.wwww, -c255.zzzz
              +       subsc r13.__z_, -c255.z, -r0.x
/*    3.1 */       exec
/*   54   */          dp3 r12.___w, r23.zxyy, c254.xyzz
              +       maxs r0.x___, r27.yy
/*   55   */          add r13.___w, r23.wwww, -c255.zzzz
              +       subsc r13._y__, -c255.z, -r0.x
/*   56   */          maxs r0.x___, r22.ww
/*   57   */          sgt r6, -r13, r13
              +       subsc r21.___w, -c255.z, -r0.x
/*   58   */          sgt r5, r21, -r21
/*   59   */          sgt r0, -r21, r21
/*    4.0 */       exec
/*   60   */          add r5, r5, -r0
              +       maxs r0.x___, r20.ww
/*   61   */          add r18.x___, r17.wwww, -c255.zzzz
              +       subsc r18.___w, -c255.z, -r0.x
/*   62   */          sgt r17, r18, -r18
/*   63   */          sgt r0, -r18, r18
/*   64   */          add r23, r17, -r0
/*   65   */          mul r20, r14, r5
/*    4.1 */       exec
/*   66   */          tfetch2D r14, r2.wy, tf0
/*   67   */          tfetch2D r21, r2.zy, tf0
/*   68   */          tfetch2D r17, r2.wx, tf1
/*   69   */          tfetch2D r18, r2.xy, tf0
/*   70   */          tfetch2D r22, r2.wx, tf0
/*   71   */          tfetch2D r5, r2.ww, tf0
/*    5.0 */       exec
/*   72   */          serialize
                      dp3 r4.__z_, r17.zxyy, c254.xyzz
/*   73   */          dp3 r7.x___, r18.zxyy, c254.xyzz
/*   74   */          dp3 r7.___w, r22.zxyy, c254.xyzz
/*   75   */          dp2add r1.__z_, r1.zwww, r23.ywww, r20.wwww
/*   76   */          dp2add r0.___w, r9.xwww, r23.xzzz, r20.zzzz
/*   77   */          dp3 r0._y__, r14.zxyy, c254.xyzz
              +       maxs r0.x___, r22.ww
/*    5.1 */       exec
/*   78   */          add r11.__z_, r17.wwww, -c255.zzzz
              +       subsc r11.___w, -c255.z, -r0.x
/*   79   */          dp3 r0.__z_, r21.zxyy, c254.xyzz
              +       subsc r11._y__, -c255.z, -r18.w
/*   80   */          tfetch2D r18, r2.yz, tf0
/*   81   */          serialize
                      sgt r17, r11, -r11
              +       maxs r0.x___, r18.ww
/*   82   */          sgt r11, -r11, r11
              +       subsc r9.___w, -c255.z, -r0.x
/*   83   */          add r11, r17, -r11
/*    6.0 */       exec
/*   84   */          dp2add r1.___w, r7.wxxx, r11.wyyy, r1.zzzz
/*   85   */          dp2add r1.__z_, r4.zyyy, r11.zxxx, r0.wwww
/*   86   */          tfetch2D r17, r2.zz, tf1
/*   87   */          serialize
                      dp3 r0.___w, r18.zxyy, c254.xyzz
              +       subsc r9.x___, -c255.z, -r17.w
/*   88   */          sgt r11, r9, -r9
              +       maxs r0.x___, r21.ww
/*   89   */          subsc r4._y__, -c255.z, -r14.w
/*    6.1 */       exec
/*   90   */          tfetch2D r14, r2.zy, tf1
/*   91   */          serialize
                      sgt r9, -r9.zwxy, r9.zwxy
              +       subsc r4.___w, -c255.z, -r0.x
/*   92   */          add r9, r11, -r9.zwxy
              +       subsc r4.__z_, -c255.z, -r14.w
/*   93   */          sgt r21, r4, -r4
/*   94   */          sgt r4, -r4, r4
/*   95   */          dp3 r10.___w, r14.zxyy, c254.xyzz
              +       maxs r0._, r21.yy
/*    7.0 */       exec
/*   96   */          sgt r22, r13, -r13
              +       adds_prev r13._y__, -r4.y
/*   97   */          add r6, r22, -r6
              +       maxs r0._, r21.xx
/*   98   */          adds_prev r13.x___, -r4.x
/*   99   */          maxs r0._, r21.zz
/*  100   */          adds_prev r13.__z_, -r4.z
/*  101   */          dp3 r12.x___, r26.zxyy, c254.xyzz
              +       maxs r0._, r21.ww
/*    7.1 */       exec
/*  102   */          add r7.x__w, r1.zwww, r20.xyyy
              +       adds_prev r13.___w, -r4.w
/*  103   */          dp2add r0.__z_, r0.zyyy, r13.wyyy, r7.wwww
/*  104   */          tfetch2D r4, r2.wz, tf0
/*  105   */          serialize
                      dp3 r10._y__, r4.zxyy, c254.xyzz
/*  106   */          dp3 r0._y__, r19.zxyy, c254.xyzz
/*  107   */          dp3 r1.__z_, r17.zxyy, c254.xyzz
/*    8.0 */       exec
/*  108   */          dp3 r1.___w, r16.zxyy, c254.xyzz
/*  109   */          dp2add r0.x___, r10.wzzz, r13.zxxx, r7.xxxx
/*  110   */          mul r6, r12, r6
/*  111   */          add r0.x_z_, r0.xzzz, r6.zwww
/*  112   */          dp2add r0._y__, r0.wyyy, r9.wyyy, r0.zzzz
/*  113   */          dp2add r0.__z_, r1.wzzz, r9.zxxx, r0.xxxx
/*    8.1 */       exec
/*  114   */          tfetch2D r9, r2.xw, tf1
/*  115   */          serialize
                      add r1._y__, r5.wwww, -c255.zzzz
              +       maxs r0.x___, r4.ww
/*  116   */          add r7.x___, r9.wwww, -c255.zzzz
              +       subsc r7.___w, -c255.z, -r0.x
/*  117   */          tfetch2D r4, r2.zw, tf0
/*  118   */          serialize
                      sgt r11, r7, -r7
              +       maxs r0.x___, r4.ww
/*  119   */          sgt r7, -r7, r7
              +       subsc r1.___w, -c255.z, -r0.x
/*    9.0 */       exec
/*  120   */          add r7, r11, -r7
/*  121   */          dp2add r0._y__, r10.yxxx, r7.wyyy, r0.yyyy
/*  122   */          dp3 r0.x___, r9.zxyy, c254.xyzz
/*  123   */          dp3 r0.___w, r8.zxyy, c254.xyzz
/*  124   */          dp2add r0.x___, r0.wxxx, r7.zxxx, r0.zzzz
/*  125   */          tfetch2D r2, r2.zw, tf1
/*    9.1 */       alloc colors
/*   10.0 */       exec
/*  126   */          dp3 r0.___w, r4.zxyy, c254.xyzz
              +       subsc r1.__z_, -c255.z, -r2.w
/*  127   */          sgt r7, r1, -r1
/*  128   */          sgt r1, -r1, r1
/*  129   */          add r1, r7, -r1
/*  130   */          add r0.x_z_, r0.xyyy, r6.xyyy
/*  131   */          dp3 r2._y__, r2.zxyy, c254.xyzz
/*   10.1 */       exec
/*  132   */          dp3 r0._y__, r5.zxyy, c254.xyzz
/*  133   */          dp2add r0._y__, r0.wyyy, r1.wyyy, r0.zzzz
/*  134   */          dp3 r2.x___, r3.zxyy, c254.xyzz
/*  135   */          dp2add r0.x___, r2.yxxx, r1.zxxx, r0.xxxx
/*  136   */          mul r0.x_z_, -r0.yxxx, c254.wwww
/*  137   */          exp r0._y__, r0.z
/*   11.0 */       exece
/*  138   */          exp r0.x___, r0.x
/*  139   */          add r0._y__, r0.yyyy, -r0.xxxx
/*  140   */          mad oC0.x111, r0.yyyy, c0.xxxx, r0.xxxx
/*   11.1 */       cnop
