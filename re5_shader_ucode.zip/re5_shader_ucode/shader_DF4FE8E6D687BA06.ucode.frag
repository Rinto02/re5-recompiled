/*    0.0 */       exec
/*   24   */          tfetch2D r9.yxzw, r1.xy, tf0
/*   25   */          tfetch2D r2.___x, r5.xy, tf6
/*   26   */          serialize
                      mul r4.__zw, c4.zzzw, c3.xxxy
              +       rcp r1.x___, r0.w
/*   27   */          mad r1.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   28   */          mul r3.__z_, r9.wwww, r2.wwww
              +       retain_prev r1._
/*   29   */          mul r1.xy__, r4.zwww, r1.yxxx
              +       subsc r2.___w, -c1.x, -r3.z
/*    0.1 */       exec
/*   30   */          kill_gt r1._, c255.xxxx, r2.wwww
              +       retain_prev r1._
/*   31   */          tfetch2D r12.zyx_, r3.xy, tf2
/*   32   */          tfetch2D r3._x_y, r3.xy, tf1
/*   33   */          tfetch2D r0, r1.xy, tf5
/*   34   */          serialize
                      sgt r13.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       retain_prev r1._
/*   35   */          sgt r10.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       maxs r3.x___, c58.xx
/*    1.0 */       exec
/*   36   */          add r5.xyz_, r2.xyzz, -c23.xyzz
              +       maxs r1.x___, r9.zz
/*   37   */          mul r0, r0.wzyx, c5.wzyx
              +       mulsc r9.__z_, c15.z, r1.x
/*   38   */          dp3 r1._y__, r5.zxyy, r5.zxyy
              +       mulsc r9.x___, c15.y, r9.x
/*   39   */          mad r3._y_w, r3.wwyy, c254.xxxx, c254.yyyy
              +       retain_prev r1._
/*   40   */          dp2add r2.___w, -r3.ywww, r3.ywww, c255.yyyy
              +       retain_prev r1._
/*   41   */          min r0, r0, c9.xxxx
              +       rsq r4.__z_, r_abs[1].y
/*    1.1 */       exec
/*   42   */          mul r5.xyz_, r5.zyxx, r4.zzzz
              +       mulsc r9._y__, c15.x, r9.y
/*   43   */          max r11, r0.wzyx, c10.xxxx
              +       sqrt r2.___w, r_abs[2].w
/*   44   */          mul r0.xyz_, r2.wwww, r8.xyzz
              +       maxs r0.___w, r11.yw
/*   45   */          mad r0.xyz_, r3.yyyy, r7.zyxx, r0.zyxx
              +       retain_prev r1._
/*   46   */          mad r0.xyz_, r3.wwww, r6.xzyy, r0.zxyy
              +       retain_prev r1._
/*   47   */          dp3 r2.___w, r0.yxzz, r0.yxzz
              +       maxs r3._y__, r11.xz
/*    2.0 */       exec
/*   48   */          max r3._y__, r3.yyyy, r0.wwww
              +       rsq r2.___w, r_abs[2].w
/*   49   */          mul r6.xyz_, r0.yzxx, r2.wwww
              +       sqrt r1._y__, r_abs[1].y
/*    2.1 */       cjmp !b128, L25
/*    3.0 */       exec
/*   50   */          mul r0, r11.wzyx, c48.wzyx
              +       retain_prev r1._
/*   51   */          add r7.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   52   */          dp3 r7.___w, r7.xzyy, r7.xzyy
              +       retain_prev r1._
/*   53   */          max4 r0.__z_, r0.zxwy
              +       rsq r1.x___, r_abs[7].w
/*   54   */          mul r8, r7, r1.xxxx
              +       retain_prev r1._
/*   55   */          dp3 r7._y__, r6.xzyy, r8.xzyy
              +       retain_prev r1._
/*    3.1 */       exec
/*   56   */          add r7.x_zw, r8.zyyx, -r5.zyyx
              +       retain_prev r1._
/*   57   */          dp3 r2.___w, r8.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   58   */          add r1.x___, r8.wwww, -c32.wwww
              +       retain_prev r1._
/*   59   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   60   */          dp3 r0._y__, r7.wxzz, r7.wxzz
              +       mulsc r1.x___, c35.y, r2.w
/*   61   */          max r1.x___, r1.xxxx, c35.wwww
              +       rsq r2.___w, r_abs[0].y
/*    4.0 */       exec
/*   62   */          mul r7.x_zw, r7.wzzx, r2.wwww
              +       subsc r0.___w, c255.y, r0.x
/*   63   */          min r4.__z_, r1.xxxx, c255.yyyy
              +       subsc r2.___w, c255.y, r0.z
/*   64   */          dp3 r7.x___, r6.xzyy, r7.xwzz
              +       maxs r1._, r0.ww
/*   65   */          max r0._yz_, r7.yyxx, c255.xxxx
              +       muls_prev r4.___w, r4.z
/*   66   */          mul r7._yzw, r4.zzww, c32.xxzy
              +       log r1.x___, r_abs[0].z
/*   67   */          max r1._, r1, r1
              +       mulsc r0.x___, c57.z, r1.x
/*    4.1 */       exec
/*   68   */          mul r7.x___, r7.yyyy, r0.wwww
              +       exp r0.x___, r0.x
/*   69   */          mul r4.__zw, r7.zzzw, r0.xxxx
              +       retain_prev r1._
/*   70   */          mul r13.xy__, r4.zwww, r2.wwww
              +       retain_prev r1._
/*   71   */          mul r0, r7.xzwx, r0.yyyx
              +       retain_prev r1._
/*   72   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       maxs r1._, r0.ww
/*   73   */          mul r10.xyz_, r0.zxyy, c35.zzzz
              +       muls_prev r13.__z_, r2.w
/*    5.0 */       cjmp !b129, L25
/*    5.1 */       exec
/*   74   */          mul r0, r11.wzyx, c49.wzyx
              +       retain_prev r1._
/*   75   */          add r7.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   76   */          dp3 r7.___w, r7.zxyy, r7.zxyy
              +       retain_prev r1._
/*   77   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[7].w
/*   78   */          mul r8, r7, r1.xxxx
              +       retain_prev r1._
/*   79   */          dp3 r7._y__, r6.xzyy, r8.zxyy
              +       retain_prev r1._
/*    6.0 */       exec
/*   80   */          add r7.x_zw, r8.xyyz, -r5.zyyx
              +       retain_prev r1._
/*   81   */          dp3 r2.___w, r8.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   82   */          add r1.x___, r8.wwww, -c36.wwww
              +       retain_prev r1._
/*   83   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   84   */          dp3 r0._y__, r7.wxzz, r7.wxzz
              +       mulsc r1.x___, c39.y, r2.w
/*   85   */          max r1.x___, r1.xxxx, c39.wwww
              +       rsq r2.___w, r_abs[0].y
/*    6.1 */       exec
/*   86   */          mul r7.x_zw, r7.wzzx, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   87   */          min r4.__z_, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*   88   */          dp3 r7.x___, r6.xzyy, r7.xwzz
              +       maxs r1._, r0.yy
/*   89   */          max r0.x__w, r7.yxxx, c255.xxxx
              +       muls_prev r4.___w, r4.z
/*   90   */          mul r7.xy_w, r4.wwzz, c36.zyxx
              +       log r1.x___, r_abs[0].w
/*   91   */          mul r7.__z_, r7.wwww, r0.yyyy
              +       mulsc r0.___w, c57.z, r1.x
/*    7.0 */       exec
/*   92   */          mul r0.xyz_, r7.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*   93   */          mul r7.xyz_, r7.xyzz, r0.wwww
              +       retain_prev r1._
/*   94   */          mad r13.xyz_, r7.xyzz, r2.wwww, r13.xyzz
              +       retain_prev r1._
/*   95   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   96   */          mad r10.xyz_, r0.zxyy, c39.zzzz, r10.xyzz
              +       retain_prev r1._
/*    7.1 */       cjmp !b130, L25
/*    8.0 */       exec
/*   97   */          mul r0, r11, c50
              +       retain_prev r1._
/*   98   */          add r7.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   99   */          dp3 r7.___w, r7.xzyy, r7.xzyy
              +       retain_prev r1._
/*  100   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[7].w
/*  101   */          mul r8, r7, r1.xxxx
              +       retain_prev r1._
/*  102   */          dp3 r7._y__, r6.xzyy, r8.xzyy
              +       retain_prev r1._
/*    8.1 */       exec
/*  103   */          add r7.x_zw, r8.zyyx, -r5.zyyx
              +       retain_prev r1._
/*  104   */          dp3 r2.___w, r8.xzyy, -c42.zxyy
              +       retain_prev r1._
/*  105   */          add r1.x___, r8.wwww, -c40.wwww
              +       retain_prev r1._
/*  106   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*  107   */          dp3 r0._y__, r7.wxzz, r7.wxzz
              +       mulsc r1.x___, c43.y, r2.w
/*  108   */          max r1.x___, r1.xxxx, c43.wwww
              +       rsq r2.___w, r_abs[0].y
/*    9.0 */       exec
/*  109   */          mul r7.x_zw, r7.xzzw, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  110   */          min r4.__z_, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*  111   */          dp3 r7.x___, r6.xzyy, r7.wxzz
              +       maxs r1._, r0.yy
/*  112   */          max r0.x__w, r7.yxxx, c255.xxxx
              +       muls_prev r4.___w, r4.z
/*  113   */          mul r7.xy_w, r4.wwzz, c40.zyxx
              +       log r1.x___, r_abs[0].w
/*  114   */          mul r7.__z_, r7.wwww, r0.yyyy
              +       mulsc r0.___w, c57.z, r1.x
/*    9.1 */       exec
/*  115   */          mul r0.xyz_, r7.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  116   */          mul r7.xyz_, r7.xyzz, r0.wwww
              +       retain_prev r1._
/*  117   */          mad r13.xyz_, r7.xyzz, r2.wwww, r13.xyzz
              +       retain_prev r1._
/*  118   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  119   */          mad r10.xyz_, r0.zxyy, c43.zzzz, r10.xyzz
              +       retain_prev r1._
/*   10.0 */       cjmp !b131, L25
/*   10.1 */       exec
/*  120   */          mul r0, r11.wzyx, c51.wzyx
              +       retain_prev r1._
/*  121   */          add r7.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*  122   */          dp3 r7.___w, r7.zxyy, r7.zxyy
              +       retain_prev r1._
/*  123   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[7].w
/*  124   */          mul r8, r7, r1.xxxx
              +       retain_prev r1._
/*  125   */          dp3 r7._y__, r6.xzyy, r8.zxyy
              +       retain_prev r1._
/*   11.0 */       exec
/*  126   */          add r7.x_zw, r8.xyyz, -r5.zyyx
              +       retain_prev r1._
/*  127   */          dp3 r2.___w, r8.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  128   */          add r1.x___, r8.wwww, -c44.wwww
              +       retain_prev r1._
/*  129   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  130   */          dp3 r0._y__, r7.wxzz, r7.wxzz
              +       mulsc r1.x___, c47.y, r2.w
/*  131   */          max r1.x___, r1.xxxx, c47.wwww
              +       rsq r2.___w, r_abs[0].y
/*   11.1 */       exec
/*  132   */          mul r7.x_zw, r7.wzzx, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  133   */          min r4.__z_, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*  134   */          dp3 r7.x___, r6.xzyy, r7.xwzz
              +       maxs r1._, r0.yy
/*  135   */          max r0.x__w, r7.yxxx, c255.xxxx
              +       muls_prev r4.___w, r4.z
/*  136   */          mul r7.xy_w, r4.wwzz, c44.zyxx
              +       log r1.x___, r_abs[0].w
/*  137   */          mul r7.__z_, r7.wwww, r0.yyyy
              +       mulsc r0.___w, c57.z, r1.x
/*   12.0 */       exec
/*  138   */          mul r0.xyz_, r7.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  139   */          mul r7.xyz_, r7.xyzz, r0.wwww
              +       retain_prev r1._
/*  140   */          mad r13.xyz_, r7.xyzz, r2.wwww, r13.xyzz
              +       retain_prev r1._
/*  141   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  142   */          mad r10.xyz_, r0.zxyy, c47.zzzz, r10.xyzz
              +       retain_prev r1._
                label L25
/*   12.1 */       cjmp !b132, L37
/*   13.0 */       exec
/*  143   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  144   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  145   */          mul r7, r11.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  146   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  147   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  148   */          dp3 r2.___w, r0.xzyy, r6.xzyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   13.1 */       exec
/*  149   */          max4 r0._y__, r7.zxwy
              +       maxs r0.__z_, r2.ww
/*  150   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  151   */          mul r7.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  152   */          mul r7.xyz_, r7.xyzz, r2.wwww
              +       retain_prev r1._
/*  153   */          mad r10.xyz_, r7.xzyy, r0.yyyy, r10.xyzz
              +       retain_prev r1._
/*   14.0 */       cjmp !b133, L37
/*   14.1 */       exec
/*  154   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  155   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  156   */          mul r7, r11, c53
              +       rsq r1.x___, r_abs[0].w
/*  157   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  158   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  159   */          dp3 r2.___w, r0.zxyy, r6.xzyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   15.0 */       exec
/*  160   */          max4 r0._y__, r7.ywxz
              +       maxs r0.__z_, r2.ww
/*  161   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  162   */          mul r7.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  163   */          mul r7.xyz_, r7.xyzz, r2.wwww
              +       retain_prev r1._
/*  164   */          mad r10.xyz_, r7.xzyy, r0.yyyy, r10.xyzz
              +       retain_prev r1._
/*   15.1 */       cjmp !b134, L37
/*   16.0 */       exec
/*  165   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  166   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  167   */          mul r7, r11.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  168   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  169   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  170   */          dp3 r2.___w, r0.xzyy, r6.xzyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   16.1 */       exec
/*  171   */          max4 r0._y__, r7.zxwy
              +       maxs r0.__z_, r2.ww
/*  172   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  173   */          mul r7.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  174   */          mul r7.xyz_, r7.xyzz, r2.wwww
              +       retain_prev r1._
/*  175   */          mad r10.xyz_, r7.xzyy, r0.yyyy, r10.xyzz
              +       retain_prev r1._
/*   17.0 */       cjmp !b135, L37
/*   17.1 */       exec
/*  176   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  177   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  178   */          mul r7, r11, c55
              +       rsq r1.x___, r_abs[0].w
/*  179   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  180   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  181   */          dp3 r2.___w, r0.zxyy, r6.xzyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   18.0 */       exec
/*  182   */          max4 r0._y__, r7.ywxz
              +       maxs r0.__z_, r2.ww
/*  183   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  184   */          mul r7.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  185   */          mul r7.xyz_, r7.xyzz, r2.wwww
              +       retain_prev r1._
/*  186   */          mad r10.xyz_, r7.xzyy, r0.yyyy, r10.xyzz
              +       retain_prev r1._
                label L37
/*   18.1 */       exec
/*  187   */          dp3 r4.___w, r5.xzyy, r6.xzyy
              +       retain_prev r1._
/*  188   */          mul r7.x___, r3.yyyy, c6.xxxx
              +       adds r1.x___, r4.ww
/*  189   */          mad r0.xyz_, -r6.xyzz, r1.xxxx, r5.xyzz
              +       retain_prev r1._
/*  190   */          cube r0, r0.xxzy, r0.yzxx
              +       subsc r1.x___, -c255.y, -r1.w
/*  191   */          max r6.__z_, r0.wwww, r0.wwww
              +       rcp r2.___w, r_abs[0].z
/*  192   */          mul r0._yz_, r0.yyxx, r2.wwww
              +       mulsc r0.x___, c56.w, r1.x
/*   19.0 */       exec
/*  193   */          add r6.xy_w, r0.yzxx, c255.zzyy
              +       retain_prev r1._
/*  194   */          setTexLOD r3.x
/*  195   */          tfetchCube r8, r6.xyz, tf3, UseComputedLOD=false, UseRegisterLOD=true
/*  196   */          tfetch2D r0, r4.xy, tf4
/*   19.1 */       alloc colors
/*   20.0 */       exec
/*  197   */          mul r0.xyz_, r0.zxyy, r0.wwww
              +       mulsc r4.__z_, c8.x, r3.y
/*  198   */          max r1.x___, r8.wwww, c254.zzzz
              +       mulsc r3.x___, c59.z, r0.x
/*  199   */          add r4.x__w, -r4.zwww, c255.yyyy
              +       rcp r1.x___, r1.x
/*  200   */          mul r7._yzw, r1.xxxx, r8.xxyz
              +       mulsc r3._y__, c59.y, r0.z
/*  201   */          mul r4.xyz_, r7.wzyy, r4.xxxx
              +       muls r1.x___, r_abs[4].ww
/*  202   */          mul r1.x___, r1.xxxx, r1.xxxx
              +       mulsc r3.___w, c59.x, r0.y
/*   20.1 */       exec
/*  203   */          mul r4.___w, r1.xxxx, r_abs[4].wwww
              +       maxs r1._, r3.yy
/*  204   */          mad r0.xyz_, r4.xyzz, c57.wwww, r13.xyzz
              +       retain_prev r1._
/*  205   */          mad_sat r1.x___, r4.wwww, c57.xxxx, c57.yyyy
              +       retain_prev r1._
/*  206   */          mul r3.xy_w, r3.xwyy, r6.wwww
              +       muls_prev r7._y__, r1.w
/*  207   */          add r4.xyz_, -r3.xwyy, c7.zyxx
              +       subsc r4.___w, c255.y, r1.x
/*  208   */          mul r4, r7.xxxy, r4.xzyw
              +       retain_prev r1._
/*   21.0 */       exec
/*  209   */          add r3.xy_w, r3.xwyy, r4.xzyy
              +       retain_prev r1._
/*  210   */          mul r4.xyz_, r4.wwww, r12.xyzz
              +       maxs r1._, r3.zz
/*  211   */          mul r0.xyz_, r4.zyxx, r0.zyxx
              +       muls_prev r2.___w, r1.z
/*  212   */          mad r1.x_zw, r10.xyyz, r1.wwww, r3.xwwy
              +       retain_prev r1._
/*  213   */          mad r0.xyz_, r9.yxzz, r1.zwxx, r0.xyzz
              +       retain_prev r1._
/*   21.1 */       cjmp !b136, L47
/*   22.0 */       exec
/*  214   */          mad r1.___w, r1.yyyy, c14.yyyy, c14.zzzz
              +       retain_prev r1._
/*  215   */          dp3 r1.__z_, r5.xzyy, c12.zxyy
              +       retain_prev r1._
/*  216   */          cndeq r3, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  217   */          dp4 r1.x___, c12.zxyw, r3
              +       subsc r1._y__, -c11.x, -r1.y
/*  218   */          add r2.xyz_, -r0.xyzz, c13.xyzz
              +       mulsc r0.___w, c11.z, r1.y
/*  219   */          min r3.xy__, r1.xzzz, c255.xwww
              +       mulsc r1.x___, c11.w, r1.x
/*   22.1 */       exec
/*  220   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  221   */          max r1._, r1, r1
              +       mulsc r1.x___, c14.x, r1.y
/*  222   */          mad r1.x___, r1.xxxx, r3.xxxx, r1.wwww
              +       retain_prev r1._
/*  223   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  224   */          min r1.x___, r1.xxxx, c13.wwww
              +       retain_prev r1._
/*  225   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*   23.0 */       exec
/*  226   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L47
/*   23.1 */       exece
/*  227   */          mul r2.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  228   */          max oC0, r2, r2
