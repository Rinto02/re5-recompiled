/*    0.0 */       exec
/*   10   */          vfetch_full r3.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=6
/*   11   */          vfetch_mini r7.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   12   */          vfetch_mini r1, Offset=3, DataFormat=FMT_8_8_8_8
/*   13   */          vfetch_mini r6.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   14   */          vfetch_mini r2.xy__, Offset=5, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   15   */          serialize
                      mul r2.__zw, r7.zzzw, c255.wwww
/*    0.1 */       exec    // PredicateClean=false
/*   16   */          maxas r0._, r2.ww
/*   17   */          mul r0, r1.yyyy, c[30+a0]
/*   18   */          mul r5, r1.yyyy, c[29+a0]
              +       setp_gt r0._, r1.z
/*   19   */          mul r4, r1.yyyy, c[28+a0]
              +       maxas r0._, r2.zz
/*   20   */          mad r4, r1.xxxx, c[28+a0], r4
/*   21   */          mad r5, r1.xxxx, c[29+a0], r5
/*    1.0 */       exec
/*   22   */          mad r0, r1.xxxx, c[30+a0], r0
/*    1.1 */  (p0) exec
/*   23   */     (p0) mul r1.xy__, r7.xyyy, c255.wwww
/*   24   */     (p0) maxas r0._, r1.yy
/*   25   */     (p0) mad r0, r1.wwww, c[30+a0], r0
/*   26   */     (p0) mad r5, r1.wwww, c[29+a0], r5
/*   27   */     (p0) mad r4, r1.wwww, c[28+a0], r4
/*   28   */     (p0) maxas r0._, r1.xx
/*    2.0 */  (p0) exec
/*   29   */     (p0) mad r4, r1.zzzz, c[28+a0], r4
/*   30   */     (p0) mad r5, r1.zzzz, c[29+a0], r5
/*   31   */     (p0) mad r0, r1.zzzz, c[30+a0], r0
/*    2.1 */       exec
/*   32   */          mul r1.xy__, r2.xyyy, c5.xyyy
/*   33   */          tfetch2D r1.xyz_, r1.xy, tf16, UseComputedLOD=false
/*   34   */          serialize
                      mad r2.xyz_, r3.zyxx, c3.zyxx, c4.zyxx
/*   35   */          add r1.xyz_, r2.zyxx, r1.xyzz
/*   36   */          cndeq r2, c255.zzzx, r1.zxyy, c255.xxxx
/*   37   */          dp4 r1.x___, r4.zxyw, r2
/*    3.0 */       exec
/*   38   */          dp4 r1._y__, r5.zxyw, r2
/*   39   */          dp4 r1.__z_, r0.zxyw, r2
/*    3.1 */       cjmp !b0, L12
/*    4.0 */       exec
/*   40   */          cndeq r2, c255.zzzx, r1.zxyy, c255.xxxx
/*   41   */          dp4 r3.x___, c0.zxyw, r2
/*   42   */          dp4 r3._y__, c1.zxyw, r2
/*   43   */          dp4 r3.__z_, c2.zxyw, r2
/*   44   */          dp2add r1.___w, r3.xyyy, r3.xyyy, c255.zzzz
/*   45   */          dp3 r2.x___, r3.zxyy, r3.zxyy
/*    4.1 */       exec
/*   46   */          sqrt r2.___w, r_abs[2].x
/*   47   */          mad r2.__z_, r2.wwww, c27.xxxx, c27.yyyy
/*   48   */          add r2.x___, -r3.zzzz, r2.wwww
/*   49   */          mul r7.xy__, r3.xyyy, r2.wwww
/*   50   */          mul r2.xy__, r7.yxxx, r2.xxxx
              +       rcp r1.___w, r1.w
/*   51   */          mul r2.xy__, r2.yxxx, r1.wwww
/*    5.0 */       exec
/*   52   */          cndge r2.__zw, r3.zzzz, r2.zzzw, c255.xxxy
/*    5.1 */       jmp L13
                label L12
/*    6.0 */       exec
/*   53   */          cndeq r3, c255.zzzx, r1.zxyy, c255.xxxx
/*   54   */          dp4 r2.x___, c23.zxyw, r3
/*   55   */          dp4 r2._y__, c24.zxyw, r3
/*   56   */          dp4 r2.__z_, c25.zxyw, r3
/*   57   */          dp4 r2.___w, c26.zxyw, r3
                label L13
/*    6.1 */       alloc position
/*    7.0 */       exec
/*   58   */          max oPos, r2, r2
/*    7.1 */       alloc interpolators
/*    8.0 */       exec
/*   59   */          dp3 r2._y__, r6.zxyy, r5.zxyy
/*   60   */          dp3 r2.__z_, r6.zxyy, r0.zxyy
/*   61   */          dp3 r0.x___, r1.zxyy, c2.zxyy
/*   62   */          dp3 r2.x___, r6.zxyy, r4.zxyy
              +       addsc r0.___w, -c2.w, -r0.x
/*   63   */          mad r1.xyz_, -r0.wwww, c6.xyzz, r1.xyzz
/*   64   */          dp3 r0.x___, r2.zxyy, r2.zxyy
/*    8.1 */       exec
/*   65   */          sge r1.___w, r_abs[0].xxxx, c255.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   66   */          dp4 o1.x___, c220.zxyw, r1.zxyw
/*   67   */          dp4 o1._y__, c221.zxyw, r1.zxyw
/*   68   */          dp4 o1.__z_, c222.zxyw, r1.zxyw
/*   69   */          dp4 o1.___w, c223.zxyw, r1.zxyw
/*   70   */          mul r0.xyz_, r2.xyzz, r0.xxxx
/*    9.0 */       exece
/*   71   */          max o0, r0, r0
/*    9.1 */       cnop
