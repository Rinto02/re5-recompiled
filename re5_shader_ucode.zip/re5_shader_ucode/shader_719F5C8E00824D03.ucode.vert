/*    0.0 */       exec
/*   10   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*   11   */          vfetch_mini r3.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   12   */          vfetch_mini r2, Offset=3, DataFormat=FMT_8_8_8_8
/*   13   */          vfetch_mini r6.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   14   */          vfetch_mini r8, Offset=5, DataFormat=FMT_8_8_8_8, Signed=true
/*   15   */          vfetch_mini r1.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       exec    // PredicateClean=false
/*   16   */          serialize
                      mul r1.__zw, r3.zzzw, c255.wwww
/*   17   */          maxas r0._, r1.ww
/*   18   */          mul r7, r2.yyyy, c[30+a0]
/*   19   */          mul r4, r2.yyyy, c[29+a0]
              +       setp_gt r0._, r2.z
/*   20   */          mul r5, r2.yyyy, c[28+a0]
              +       maxas r0._, r1.zz
/*   21   */          mad r5, r2.xxxx, c[28+a0], r5
/*    1.0 */       exec
/*   22   */          mad r4, r2.xxxx, c[29+a0], r4
/*   23   */          mad r7, r2.xxxx, c[30+a0], r7
/*    1.1 */  (p0) exec
/*   24   */     (p0) mul r1.__zw, r3.xxxy, c255.wwww
/*   25   */     (p0) maxas r0._, r1.ww
/*   26   */     (p0) mad r3, r2.wwww, c[30+a0], r7
/*   27   */     (p0) mad r4, r2.wwww, c[29+a0], r4
/*   28   */     (p0) mad r5, r2.wwww, c[28+a0], r5
/*   29   */     (p0) maxas r0._, r1.zz
/*    2.0 */  (p0) exec
/*   30   */     (p0) mad r5, r2.zzzz, c[28+a0], r5
/*   31   */     (p0) mad r4, r2.zzzz, c[29+a0], r4
/*   32   */     (p0) mad r7, r2.zzzz, c[30+a0], r3
/*    2.1 */       exec
/*   33   */          mad r0.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*   34   */          cndeq r2, c255.zzzx, r0.zxyy, c255.xxxx
/*   35   */          dp4 r0.x___, r5.zxyw, r2
/*   36   */          dp4 r0._y__, r4.zxyw, r2
/*   37   */          dp4 r0.__z_, r7.zxyw, r2
/*    3.0 */       cjmp !b0, L11
/*    3.1 */       exec
/*   38   */          cndeq r2, c255.zzzx, r0.zxyy, c255.xxxx
/*   39   */          dp4 r3.x___, c0.zxyw, r2
/*   40   */          dp4 r3._y__, c1.zxyw, r2
/*   41   */          dp4 r3.__z_, c2.zxyw, r2
/*   42   */          dp2add r0.___w, r3.xyyy, r3.xyyy, c255.zzzz
/*   43   */          dp3 r1.__z_, r3.zxyy, r3.zxyy
/*    4.0 */       exec
/*   44   */          sqrt r1.___w, r_abs[1].z
/*   45   */          mad r1.__z_, r1.wwww, c27.xxxx, c27.yyyy
/*   46   */          add r2.x___, -r3.zzzz, r1.wwww
/*   47   */          mul r2._yz_, r3.xxyy, r1.wwww
/*   48   */          mul r2.xy__, r2.zyyy, r2.xxxx
              +       rcp r0.___w, r0.w
/*   49   */          mul r2.xy__, r2.yxxx, r0.wwww
/*    4.1 */       exec
/*   50   */          cndge r2.__zw, r3.zzzz, r1.zzzw, c255.xxxy
/*    5.0 */       jmp L12
                label L11
/*    5.1 */       exec
/*   51   */          cndeq r3, c255.zzzx, r0.zxyy, c255.xxxx
/*   52   */          dp4 r2.x___, c23.zxyw, r3
/*   53   */          dp4 r2._y__, c24.zxyw, r3
/*   54   */          dp4 r2.__z_, c25.zxyw, r3
/*   55   */          dp4 r2.___w, c26.zxyw, r3
                label L12
/*    6.0 */       alloc position
/*    6.1 */       exec
/*   56   */          mad r2.__z_, -r2.wwww, c9.xxxx, r2.zzzz
/*   57   */          max oPos, r2, r2
/*    7.0 */       alloc interpolators
/*    7.1 */       exec
/*   58   */          dp3 r3.x___, r8.zxyy, r4.zxyy
/*   59   */          dp3 r3._y__, r8.zxyy, r7.zxyy
/*   60   */          dp3 r3.__z_, r8.zxyy, r5.zxyy
/*   61   */          dp3 r5.x___, r6.zxyy, r5.zxyy
/*   62   */          dp3 r5._y__, r6.zxyy, r4.zxyy
/*   63   */          dp3 r5.__z_, r6.zxyy, r7.zxyy
/*    8.0 */       exec
/*   64   */          add r8.xy__, r1.xyyy, c7.xyyy
              +       maxs r8.__z_, c5.xx
/*   65   */          add o3.xy__, r1.xyyy, c8.xyyy
/*   66   */          max o2.xyz_, r0.xyzz, r0.xyzz
/*   67   */          max o1, r8, r8
/*   68   */          max o0, r2, r2
/*   69   */          dp3 r0._y__, r5.zxyy, r5.zxyy
/*    8.1 */       exec
/*   70   */          dp3 r0.x___, r3.yzxx, r3.yzxx
              +       rsq r0._y__, r_abs[0].y
/*   71   */          mul r1.xyz_, r5.xyzz, r0.yyyy
              +       rsq r0.x___, r_abs[0].x
/*   72   */          mul o4.xyz_, r3.zxyy, r0.xxxx
/*   73   */          mul o6.xyz_, r5.xyzz, r0.yyyy
/*   74   */          mul r2.xyz_, r3.xyzz, r0.xxxx
/*   75   */          mul r0.xyz_, r2.yzxx, r1.yzxx
/*    9.0 */       exece
/*   76   */          mad r0._yzw, r2.xxyz, r1.zzxy, -r0.xxyz
/*   77   */          dp3 r0.x___, r0.wyzz, r0.wyzz
/*   78   */          rsq r0.x___, r_abs[0].x
/*   79   */          mul r0.xyz_, r0.yzww, r0.xxxx
/*   80   */          mul o5.xyz_, r0.xyzz, c6.zzzz
/*    9.1 */       cnop
