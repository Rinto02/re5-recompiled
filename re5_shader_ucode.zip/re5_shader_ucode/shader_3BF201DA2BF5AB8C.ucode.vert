/*    0.0 */       exec
/*    7   */          vfetch_full r1.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    8   */          vfetch_mini r2.__x_, Offset=3, DataFormat=FMT_8_8_8_8
/*    9   */          vfetch_mini r2.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   10   */          vfetch_mini r0.xy__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   11   */          serialize
                      mad r4.xyz_, r1.xyzz, c3.xyzz, c4.xyzz
/*   12   */          mul r5.xy__, r0.xyyy, c255.wwww
/*    0.1 */       exec
/*   13   */          add r0.x___, -r2.zzzz, c255.xxxx
              +       maxas r0._, r5.yy
/*   14   */          mul r3, r0.xxxx, c[30+a0]
/*   15   */          mul r1, r0.xxxx, c[29+a0]
/*   16   */          mul r0, r0.xxxx, c[28+a0]
              +       maxas r0._, r5.xx
/*   17   */          mad r0, r2.zzzz, c[28+a0], r0
/*   18   */          mad r1, r2.zzzz, c[29+a0], r1
/*    1.0 */       exec
/*   19   */          mad r3, r2.zzzz, c[30+a0].zyxw, r3.zyxw
/*   20   */          cndeq r4, c255.zzzx, r4.zxyy, c255.xxxx
/*   21   */          dp4 r0.x___, r0.zxyw, r4
/*   22   */          dp4 r0._y__, r1.zxyw, r4
/*   23   */          dp4 r0.__z_, r3.xzyw, r4
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   24   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   25   */          dp4 r1.x___, c0.zxyw, r0
/*   26   */          dp4 r1._y__, c1.zxyw, r0
/*   27   */          dp4 r1.__z_, c2.zxyw, r0
/*   28   */          dp2add r0.__z_, r1.xyyy, r1.xyyy, c255.zzzz
/*   29   */          dp3 r0.x___, r1.zxyy, r1.zxyy
/*    2.1 */       exec
/*   30   */          sqrt r0._y__, r_abs[0].x
/*   31   */          mad r0.x___, r0.yyyy, c27.xxxx, c27.yyyy
/*   32   */          add r0.___w, -r1.zzzz, r0.yyyy
/*   33   */          mul r2.__zw, r1.xxxy, r0.yyyy
/*   34   */          mul r2.__zw, r2.wwwz, r0.wwww
              +       rcp r0.__z_, r0.z
/*   35   */          mul r0.__zw, r2.wwwz, r0.zzzz
/*    3.0 */       exec
/*   36   */          cndge r0.xy__, r1.zzzz, r0.xyyy, c255.xyyy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   37   */          cndeq r1, c255.zzzx, r0.zxyy, c255.xxxx
/*   38   */          dp4 r0.__z_, c23.zxyw, r1
/*   39   */          dp4 r0.___w, c24.zxyw, r1
/*   40   */          dp4 r0.x___, c25.zxyw, r1
/*   41   */          dp4 r0._y__, c26.zxyw, r1
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   42   */          max oPos, r0.zwxy, r0.zwxy
/*    5.1 */       alloc interpolators
/*    6.0 */       exece
/*   43   */          add o0.xy__, r2.xyyy, c5.xyyy
/*    6.1 */       cnop
