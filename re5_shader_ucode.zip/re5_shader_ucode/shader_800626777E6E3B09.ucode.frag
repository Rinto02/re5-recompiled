/*    0.0 */       exec
/*    2   */          tfetch2D r0, r0.xy, tf1, FetchValidOnly=false
/*    3   */          serialize
                      cndeq r1, c255.xxxy, r0.zxyy, c255.yyyy
/*    4   */          dp4 r2.x___, c49.zxyw, r1
/*    5   */          dp4 r2._y__, c50.zxyw, r1
/*    6   */          tfetch1D r0.__z_, r2.y, tf0
/*    7   */          tfetch1D r0._y__, r2.x, tf0
/*    0.1 */       exec
/*    8   */          serialize
                      dp4 r0.x___, c48.zxyw, r1
              +       maxs r0.___w, r0.ww
/*    9   */          tfetch1D r0.x___, r0.x, tf0
/*    1.0 */       alloc colors
/*    1.1 */       exece
/*   10   */          max oC0, r0, r0
