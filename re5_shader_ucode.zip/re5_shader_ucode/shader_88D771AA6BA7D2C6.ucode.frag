/*    0.0 */       exec
/*    8   */          tfetch2D r7._w__, r2.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exec    // PredicateClean=false
/*    9   */          sgt r2.x___, c2.xxxx, r0.wwww
              +       sgts r2.__z_, -r_abs[0].x
/*   10   */          setp_ne_push r7.x___, c255.yyyy, r2.xxxx
              +       sgts r2.___w, -r_abs[0].x
/*   11   */          add r2._y__, r7.yyyy, -c23.xxxx
              +       sgts r2.x___, -r_abs[0].x
/*   12   */          kill_gt r0._, c255.yyyy, r2.yyyy
              +       sgts r2._y__, -r_abs[0].x
/*    1.1 */ (!p0) jmp L15
/*    2.0 */       exec    // PredicateClean=false
/*   13   */     (p0) dp3 r2.x___, r0.zxyy, r0.zxyy
/*   14   */     (p0) rsq r2.x___, r_abs[2].x
/*   15   */     (p0) mul r3.xyz_, r2.xxxx, -c0.xyzz
/*   16   */     (p0) dp3 r2.x___, r3.zxyy, r0.zxyy
/*   17   */          setp_gt_push r7.x___, r7.xxxx, r2.xxxx
/*    2.1 */ (!p0) jmp L14
/*    3.0 */  (p0) exec
/*   18   */     (p0) rcp r0.x___, r1.w
/*   19   */     (p0) mul r2.xyz_, r0.xxxx, r1.yzxx
/*   20   */     (p0) tfetch2D r9.x___, r2.zx, tf1, OffsetX=-2, OffsetY=1
/*   21   */     (p0) tfetch2D r9.___x, r2.zx, tf1, OffsetX=1, OffsetY=1
/*   22   */     (p0) tfetch2D r9.__x_, r2.zx, tf1, OffsetY=1
/*   23   */     (p0) tfetch2D r9._x__, r2.zx, tf1, OffsetX=-1, OffsetY=1
/*    3.1 */  (p0) exec
/*   24   */     (p0) tfetch2D r10.x___, r2.zx, tf1, OffsetX=-2
/*   25   */     (p0) tfetch2D r10.___x, r2.zx, tf1, OffsetX=1
/*   26   */     (p0) tfetch2D r10.__x_, r2.zx, tf1
/*   27   */     (p0) tfetch2D r10._x__, r2.zx, tf1, OffsetX=-1
/*   28   */     (p0) tfetch2D r4.x___, r2.zx, tf1, OffsetX=-2, OffsetY=-1
/*   29   */     (p0) tfetch2D r4.___x, r2.zx, tf1, OffsetX=1, OffsetY=-1
/*    4.0 */  (p0) exec
/*   30   */     (p0) tfetch2D r4.__x_, r2.zx, tf1, OffsetY=-1
/*   31   */     (p0) tfetch2D r4._x__, r2.zx, tf1, OffsetX=-1, OffsetY=-1
/*   32   */     (p0) tfetch2D r5.x___, r2.zx, tf1, OffsetX=-2, OffsetY=-2
/*   33   */     (p0) tfetch2D r5.___x, r2.zx, tf1, OffsetX=1, OffsetY=-2
/*   34   */     (p0) tfetch2D r5.__x_, r2.zx, tf1, OffsetY=-2
/*   35   */     (p0) tfetch2D r5._x__, r2.zx, tf1, OffsetX=-1, OffsetY=-2
/*    4.1 */       exec    // PredicateClean=false
/*   36   */          serialize
                 (p0) subsc r0._y__, c255.x, r2.y
/*   37   */     (p0) sge r8, r5, r0.yyyy
/*   38   */     (p0) sge r3, r4, r0.yyyy
/*   39   */     (p0) sge r2, r10, r0.yyyy
/*   40   */     (p0) sge r6, r9, r0.yyyy
              +  (p0) mulsc r0.x___, c1.y, r0.x
/*   41   */          setp_gt_push r7.x___, r7.xxxx, c4.xxxx
/*    5.0 */  (p0) exec
/*   42   */     (p0) add r6, -r0.yyyy, r9
/*   43   */     (p0) add r2, -r0.yyyy, r10
/*   44   */     (p0) add r3, -r0.yyyy, r4
/*   45   */     (p0) add r4, -r0.yyyy, r5
/*   46   */     (p0) mul_sat r8, r4, c4.xxxx
/*   47   */     (p0) mul_sat r3, r3, c4.xxxx
/*    5.1 */       exec    // PredicateClean=false
/*   48   */     (p0) mul_sat r2, r2, c4.xxxx
/*   49   */     (p0) mul_sat r6, r6, c4.xxxx
/*   50   */          setp_pop r7.x___, r7.x
/*   51   */     (p0) mad_sat r4.__z_, r0.wwww, c3.xxxx, c3.yyyy
/*   52   */     (p0) mul r0.xy__, r0.xxxx, r1.xyyy
/*   53   */     (p0) add r1, r2, r3
/*    6.0 */  (p0) exec
/*   54   */     (p0) frc r4.xy__, r0.yxxx
/*   55   */     (p0) add r0.xy__, -r4.xzzz, c255.xxxx
/*   56   */     (p0) mad r1, r0.xxxx, r8, r1
/*   57   */     (p0) mad r1, r4.xxxx, r6, r1
/*   58   */     (p0) dp3 r0.__z_, r1.zxyy, c255.xxxx
              +  (p0) subs r0.___w, r1.wx
/*   59   */     (p0) mad r0.x___, r0.wwww, r4.yyyy, r0.zzzz
/*    6.1 */  (p0) exec
/*   60   */     (p0) mulsc r0.__z_, c255.z, r0.x
/*   61   */     (p0) mul r2.___w, r0.zzzz, r0.yyyy
              +  (p0) maxs r2.__z_, r7.yy
                label L14
/*    7.0 */       exec    // PredicateClean=false
/*   62   */          setp_pop r7.x___, r7.x
/*   63   */     (p0) max r2.xy__, r2.wzzz, r2.wzzz
                label L15
/*    7.1 */       exece
/*   64   */          mulsc r2._y__, c5.x, r2.y
/*   65   */          max oC0, r2.xxxy, r2.xxxy
