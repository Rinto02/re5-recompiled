/*    0.0 */       exec
/*   14   */          vfetch_full r7.wxy_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=6
/*   15   */          vfetch_mini r1, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   16   */          vfetch_mini r8, Offset=3, DataFormat=FMT_8_8_8_8
/*   17   */          vfetch_mini r5.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   18   */          vfetch_mini r10.yx__, Offset=5, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   19   */          serialize
                      mul r4.xy__, r1.xyyy, c255.zzzz
/*    0.1 */       exec    // PredicateClean=false
/*   20   */          maxas r0._, r4.yy
/*   21   */          mul r0, r8.yyyy, c[37+a0]
/*   22   */          mul r3, r8.yyyy, c[36+a0]
              +       setp_gt r0._, r8.z
/*   23   */          mul r2, r8.yyyy, c[35+a0]
              +       maxas r0._, r4.xx
/*   24   */          mad r2.xyz_, r8.xxxx, c[35+a0].xyzz, r2.xyzz
/*   25   */          mad r11.x___, r8.xxxx, c[35+a0].wwww, r2.wwww
/*    1.0 */       exec
/*   26   */          mad r9.xyz_, r8.xxxx, c[36+a0].xyzz, r3.xyzz
/*   27   */          mad r11._y__, r8.xxxx, c[36+a0].wwww, r3.wwww
/*   28   */          mad r6.xyz_, r8.xxxx, c[37+a0].xyzz, r0.xyzz
/*   29   */          mad r11.__z_, r8.xxxx, c[37+a0].wwww, r0.wwww
/*    1.1 */  (p0) exec
/*   30   */     (p0) mul r10.__zw, r1.zzzw, c255.zzzz
/*   31   */     (p0) maxas r0._, r10.ww
/*   32   */     (p0) mul r4, r8.wwww, c[35+a0]
/*   33   */     (p0) mul r3, r8.wwww, c[36+a0]
/*   34   */     (p0) mul r0, r8.wwww, c[37+a0]
              +  (p0) maxas r0._, r10.zz
/*   35   */     (p0) mad r0, r8.zzzz, c[37+a0], r0
/*    2.0 */  (p0) exec
/*   36   */     (p0) mad r3, r8.zzzz, c[36+a0], r3
/*   37   */     (p0) mad r4, r8.zzzz, c[35+a0], r4
/*   38   */     (p0) add r11._y__, r3.wwww, r11.yyyy
              +  (p0) maxs r0._, r4.ww
/*   39   */     (p0) add r2.xyz_, r4.xyzz, r2.xyzz
              +  (p0) adds_prev r11.x___, r11.x
/*   40   */     (p0) add r9.xyz_, r3.xyzz, r9.xyzz
              +  (p0) maxs r0._, r0.ww
/*   41   */     (p0) add r6.xyz_, r0.xyzz, r6.xyzz
              +  (p0) adds_prev r11.__z_, r11.z
/*    2.1 */       exec
/*   42   */          add r12, r1, c4.xxxx
/*   43   */          mul r3._yz_, r12.xxyy, c4.zzzz
              +       maxs r3.x___, c4.yy
/*   44   */          tfetch2D r13, r3.yx, tf16, UseComputedLOD=false, OffsetX=2
/*   45   */          tfetch2D r14, r3.yx, tf16, UseComputedLOD=false, OffsetX=1
/*   46   */          tfetch2D r1, r3.yx, tf16, UseComputedLOD=false
/*   47   */          tfetch2D r0, r3.zx, tf16, UseComputedLOD=false
/*    3.0 */       exec
/*   48   */          tfetch2D r4, r3.zx, tf16, UseComputedLOD=false, OffsetX=1
/*   49   */          tfetch2D r3, r3.zx, tf16, UseComputedLOD=false, OffsetX=2
/*   50   */          serialize
                      mul r3, r8.yyyy, r3
/*   51   */          mul r4, r8.yyyy, r4
/*   52   */          mul r0, r8.yyyy, r0
/*   53   */          mad r0.xyz_, r8.xxxx, r1.xyzz, r0.xyzz
/*    3.1 */       exec    // PredicateClean=false
/*   54   */          mad r1.x___, r8.xxxx, r1.wwww, r0.wwww
/*   55   */          mad r4.xyz_, r8.xxxx, r14.xyzz, r4.xyzz
/*   56   */          mad r1.__z_, r8.xxxx, r14.wwww, r4.wwww
/*   57   */          mad r3.xyz_, r8.xxxx, r13.xyzz, r3.xyzz
/*   58   */          mad r1._y__, r8.xxxx, r13.wwww, r3.wwww
/*   59   */          mul r12._yz_, r12.zzww, c4.zzzz
              +       setp_gt r0._, r8.z
/*    4.0 */  (p0) exec
/*   60   */     (p0) maxs r12.x___, c4.yy
/*   61   */     (p0) tfetch2D r15, r12.yx, tf16, UseComputedLOD=false
/*   62   */     (p0) tfetch2D r16, r12.yx, tf16, UseComputedLOD=false, OffsetX=1
/*   63   */     (p0) tfetch2D r17, r12.yx, tf16, UseComputedLOD=false, OffsetX=2
/*   64   */     (p0) tfetch2D r18, r12.zx, tf16, UseComputedLOD=false, OffsetX=2
/*   65   */     (p0) tfetch2D r13, r12.zx, tf16, UseComputedLOD=false, OffsetX=1
/*    4.1 */  (p0) exec
/*   66   */     (p0) tfetch2D r12, r12.zx, tf16, UseComputedLOD=false
/*   67   */          serialize
                 (p0) mul r14, r8.wwww, r12
/*   68   */     (p0) mul r13, r8.wwww, r13
/*   69   */     (p0) mul r12, r8.wwww, r18
/*   70   */     (p0) mad r12, r8.zzzz, r17, r12
/*   71   */     (p0) mad r13, r8.zzzz, r16, r13
/*    5.0 */  (p0) exec
/*   72   */     (p0) mad r8, r8.zzzz, r15, r14
/*   73   */     (p0) add r1.__z_, r13.wwww, r1.zzzz
              +  (p0) maxs r0._, r8.ww
/*   74   */     (p0) add r0.xyz_, r8.xyzz, r0.xyzz
              +  (p0) adds_prev r1.x___, r1.x
/*   75   */     (p0) add r4.xyz_, r13.xyzz, r4.xyzz
              +  (p0) maxs r0._, r12.ww
/*   76   */     (p0) add r3.xyz_, r12.xyzz, r3.xyzz
              +  (p0) adds_prev r1._y__, r1.y
/*    5.1 */       exec
/*   77   */          mul r8.xy__, r10.xyyy, c5.yxxx
/*   78   */          tfetch2D r10.xyz_, r8.yx, tf18, UseComputedLOD=false
/*   79   */          tfetch2D r8.xyz_, r8.yx, tf17, UseComputedLOD=false
/*   80   */          serialize
                      dp3 r12.x___, r5.zxyy, r2.zxyy
/*   81   */          dp3 r12._y__, r5.zxyy, r9.zxyy
/*   82   */          dp3 r12.__z_, r5.zxyy, r6.zxyy
/*    6.0 */       exec
/*   83   */          mad r7.xyz_, r7.yzxx, c227.yxzz, c3.yxzz
/*   84   */          add r10.xyz_, r7.yxzz, r10.xyzz
/*   85   */          dp3 r5.x___, r12.zxyy, c0.zxyy
              +       maxs r0._, r7.yy
/*   86   */          dp3 r5._y__, r12.zxyy, c1.zxyy
              +       adds_prev r8.x___, r8.x
/*   87   */          dp3 r5.__z_, r12.zxyy, c2.zxyy
              +       maxs r0._, r7.xx
/*   88   */          dp3 r7.x___, r10.zxyy, r0.zxyy
              +       adds_prev r8._y__, r8.y
/*    6.1 */       exec
/*   89   */          dp3 r7._y__, r10.zxyy, r3.zxyy
              +       maxs r0._, r7.zz
/*   90   */          dp3 r7.__z_, r10.zxyy, r4.zxyy
              +       adds_prev r8.__z_, r8.z
/*   91   */          dp3 r0.x___, r8.zxyy, r2.zxyy
/*   92   */          dp3 r0._y__, r8.zxyy, r9.zxyy
/*   93   */          dp3 r0.__z_, r8.zxyy, r6.zxyy
/*   94   */          add r0.xyz_, r0.xyzz, r11.xyzz
/*    7.0 */       exec
/*   95   */          add r2.xyz_, r7.xyzz, r1.xyzz
              +       sges r2.___w, r_abs[0].x
/*   96   */          dp4 r1.x___, c27.zxyw, r2.yxzw
/*   97   */          dp4 r1._y__, c29.zxyw, r2.yxzw
/*   98   */          dp4 r1.___w, c28.zxyw, r2.yxzw
              +       sges r0.___w, r_abs[0].x
/*   99   */          dp4 r3.x___, c0.zxyw, r0.zxyw
/*  100   */          dp4 r3.__z_, c1.zxyw, r0.zxyw
/*    7.1 */       exec
/*  101   */          dp4 r3._y__, c2.zxyw, r0.zxyw
              +       sges r3.___w, r_abs[0].x
/*  102   */          mad r1.__z_, -r3.yyyy, c6.xxxx, -c6.wwww
/*  103   */          dp4 r2._y__, c24.zxyw, r3.yxzw
/*  104   */          dp4 r0._y__, c25.zxyw, r3.yxzw
/*  105   */          dp4 r2.__z_, c26.zxyw, r3.yxzw
/*  106   */          add r0.x_zw, r3.xzzy, -r1.xwwy
/*    8.0 */       exec
/*  107   */          dp3 r0.x___, r0.wxzz, r0.wxzz
/*  108   */          add r1.xy_w, r1.xyww, -r3.xyzz
              +       rsq r0.x___, r_abs[0].x
/*  109   */          dp4 r2.x___, c23.zxyw, r3.yxzw
              +       mulsc r0.x___, c6.y, r0.x
/*  110   */          min r0.x___, r0.xxxx, c255.wwww
/*  111   */          mad r0.x_zw, r1.xyyw, r0.xxxx, r3.xyyz
/*  112   */          add r0.x_zw, -r0.xzzw, r3.xyyz
/*    8.1 */       exec
/*  113   */          mul r0.x_zw, r0.xwwz, c6.zzzz
/*  114   */          add r4.xyz_, r3.xzyy, -r0.xzww
              +       sges r4.___w, r_abs[0].x
/*  115   */          dp4 r1.x___, c30.zxyw, r4.zxyw
/*  116   */          dp4 r1._y__, c31.zxyw, r4.zxyw
              +       maxs r3.x___, r1.zz
/*  117   */          dp4 r1.___w, c32.zxyw, r4.zxyw
              +       maxs r3._y__, c255.ww
/*  118   */          dp4 r1.__z_, c33.zxyw, r4.zxyw
              +       mins r2.___w, r3.xy
/*    9.0 */       cjmp b0, L22
/*    9.1 */       exec
/*  119   */          rcp r0.x___, r2.z
/*  120   */          mad r0._y__, -r0.xxxx, c255.xxxx, r0.yyyy
/*  121   */          dp2add r0.x___, r5.xyyy, r5.xyyy, c255.yyyy
/*  122   */          max r0.___w, r2.zzzz, r2.zzzz
              +       rsq r0.x___, r_abs[0].x
/*  123   */          mul r0.x_z_, r5.xyyy, r0.xxxx
/*  124   */          mul r0.x_z_, r0.zxxx, c34.wzzz
/*   10.0 */       exec
/*  125   */          mad r0.x_z_, r0.zxxx, r2.zzzz, r2.xyyy
/*   10.1 */       jmp L23
                label L22
/*   11.0 */       exec
/*  126   */          dp3 r3.x___, r0.wxzz, r5.zxyy
/*  127   */          cndgt r0.x_zw, r3.xxxx, r2.xyyz, r1.xyyz
/*  128   */          cndgt r0._y__, r3.xxxx, r0.yyyy, r1.wwww
                label L23
/*   11.1 */       alloc position
/*   12.0 */       exec
/*  129   */          max oPos, r0.xzyw, r0.xzyw
/*   12.1 */       alloc interpolators
/*   13.0 */       exece
/*  130   */          max o0, r2.xywz, r2.xywz
/*  131   */          max o1, r1.xywz, r1.xywz
/*   13.1 */       cnop
