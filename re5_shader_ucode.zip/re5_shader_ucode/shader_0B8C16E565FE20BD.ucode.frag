/*    0.0 */       exec
/*    2   */          cube r0, r0.zzxy, r0.yxzz
              +       maxs r1.x___, c0.xx
/*    3   */          max r2.__z_, r0.wwww, r0.wwww
              +       rcp r1._y__, r_abs[0].z
/*    4   */          mad r2.xy__, r0.yxxx, r1.yyyy, c255.xxxx
/*    5   */          setTexLOD r1.x
/*    6   */          tfetchCube r1, r2.xyz, tf1, UseComputedLOD=false, UseRegisterLOD=true
/*    7   */          tfetchCube r0, r2.xyz, tf0, UseComputedLOD=false, UseRegisterLOD=true
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    8   */          add r1, r1, -r0
/*    9   */          mad oC0, r1, c1.xxxx, r0
/*    1.1 */       cnop
