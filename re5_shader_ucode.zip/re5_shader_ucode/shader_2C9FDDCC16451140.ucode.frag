/*    0.0 */       exec
/*    3   */          tfetch2D r1.xw_y, r1.xy, tf0, FetchValidOnly=false
/*    4   */          serialize
                      add r3, c3, c4.xxxx
              +       rcp r4.x___, r2.w
/*    5   */          mad r4.__zw, r4.xxxx, r2.xxxy, c1.xxxy
/*    6   */          add r5, c3, -c4.xxxx
              +       addsc r4.x___, c255.y, r1.x
/*    7   */          add r2, r3, -r5
              +       addsc r4._y__, c255.y, r1.w
/*    8   */          mul r4.xy__, r4.xyyy, r1.zzzz
              +       rcp r2.x___, r2.x
/*    0.1 */       exec
/*    9   */          mad r3.__zw, r4.zzzw, c2.xxxy, r4.xxxy
/*   10   */          max r3.xy__, r3.zwww, r3.xyyy
              +       rcp r2._y__, r2.y
/*   11   */          add r4, r3.zwzw, -r5
              +       rcp r2.__z_, r2.z
/*   12   */          min r3.__zw, r5.zzzw, r3.xxxy
              +       rcp r2.___w, r2.w
/*   13   */          mul_sat r4, r4, r2
/*   14   */          mad r2, -r4, c255.xxxx, c255.zzzz
/*    1.0 */       exec
/*   15   */          mul r4, r4, r4
/*   16   */          mul r3.xy__, r4.zwww, c4.xxxx
/*   17   */          mad r4.xy__, -r4.xyyy, r2.xyyy, c255.wwww
/*   18   */          mad r2.xy__, -r4.xyyy, c4.xxxx, r3.zwww
/*   19   */          mad r2.xy__, r3.xyyy, r2.zwww, r2.xyyy
/*   20   */          tfetch2D r2.xyz_, r2.xy, tf1
/*    1.1 */       alloc colors
/*    2.0 */       exece
/*   21   */          mul r2.xyz_, r2.xyzz, c0.xxxx
/*   22   */          mul r2.xyz_, r2.xyzz, c23.xxxx
              +       maxs r0._, r1.yy
/*   23   */          mul oC0.xyz_, r2.xyzz, r0.xyzz
              +       muls_prev oC0.___w, r0.w
/*    2.1 */       cnop
