/*    0.0 */       exec    // PredicateClean=false
/*    7   */          vfetch_full r6.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=6
/*    8   */          vfetch_mini r3, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    9   */          vfetch_mini r1, Offset=3, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   10   */          vfetch_mini r2, Offset=4, DataFormat=FMT_8_8_8_8
/*   11   */          vfetch_mini r4, Offset=5, DataFormat=FMT_8_8_8_8
/*   12   */          serialize
                      mul r7, r3, c255.xxxx
              +       setp_gt r0._, r4.x
/*    0.1 */       exec
/*   13   */          maxas r0._, r7.ww
/*   14   */          mul r3, r2.wwww, c[24+a0]
              +       maxas r0._, r7.zz
/*   15   */          mul r0, r2.zzzz, c[25+a0]
/*   16   */          mad r5, r2.zzzz, c[24+a0].wyzx, r3.wyzx
/*   17   */          mul r3, r2.zzzz, c[23+a0]
              +       maxas r0._, r7.yy
/*   18   */          mad r3, r2.yyyy, c[23+a0].wyxz, r3.wyxz
/*    1.0 */       exec
/*   19   */          mad r0, r2.yyyy, c[25+a0].wyxz, r0.wyxz
/*   20   */          mad r5, r2.yyyy, c[24+a0].wzxy, r5.xzwy
/*   21   */          maxas r0._, r7.xx
/*   22   */          mad r0, r2.xxxx, c[25+a0], r0.zywx
/*   23   */          mad r3, r2.xxxx, c[23+a0].wxyz, r3.xzyw
/*   24   */          mad r5, r2.xxxx, c[24+a0], r5.zwyx
/*    1.1 */       exec
/*   25   */          maxas r0._, r7.ww
/*   26   */          mad r3.x___, r2.wwww, c[23+a0].wwww, r3.xxxx
/*   27   */          mad r2.xyz_, r2.wwww, c[23+a0].xyzz, r3.yzww
/*   28   */          mad r3._y__, r2.wwww, c[25+a0].wwww, r0.wwww
/*   29   */          mad r0.xyz_, r2.wwww, c[25+a0].xyzz, r0.xyzz
/*    2.0 */  (p0) exec
/*   30   */     (p0) mul r8, r1, c255.xxxx
/*   31   */     (p0) maxas r0._, r8.ww
/*   32   */     (p0) mul r7, r4.wwww, c[23+a0].xzyw
/*   33   */     (p0) mad r5, r4.wwww, c[24+a0].xywz, r5.xywz
/*   34   */     (p0) mul r1, r4.wwww, c[25+a0].xzyw
              +  (p0) maxas r0._, r8.zz
/*   35   */     (p0) mad r5, r4.zzzz, c[24+a0].wxzy, r5.zxwy
/*    2.1 */  (p0) exec
/*   36   */     (p0) mad r1, r4.zzzz, c[25+a0].wyzx, r1.wzyx
/*   37   */     (p0) mad r7, r4.zzzz, c[23+a0].wyzx, r7.wzyx
/*   38   */     (p0) maxas r0._, r8.yy
/*   39   */     (p0) mad r7, r4.yyyy, c[23+a0].wzxy, r7.xzwy
/*   40   */     (p0) mad r1, r4.yyyy, c[25+a0].wzxy, r1.xzwy
/*   41   */     (p0) mad r5, r4.yyyy, c[24+a0].wzyx, r5.xzwy
/*    3.0 */  (p0) exec
/*   42   */          max r0._, c0, c0
/*   43   */     (p0) maxas r0._, r8.xx
/*   44   */     (p0) mad r5, r4.xxxx, c[24+a0], r5.wzyx
/*   45   */     (p0) mad r1, r4.xxxx, c[25+a0].xzyw, r1.zywx
/*   46   */     (p0) mad r4, r4.xxxx, c[23+a0].xzyw, r7.zywx
/*   47   */     (p0) add r3.x___, r4.wwww, r3.xxxx
/*    3.1 */  (p0) exec
/*   48   */     (p0) add r2.xyz_, r4.xzyy, r2.xyzz
              +  (p0) maxs r0._, r1.ww
/*   49   */     (p0) add r0.xyz_, r1.xzyy, r0.xyzz
              +  (p0) adds_prev r3._y__, r3.y
/*    4.0 */       alloc position
/*    4.1 */       exec
/*   50   */          mad r4.xyz_, r6.xyzz, c215.xyzz, c4.xyzz
/*   51   */          dp3 r1.x___, r4.zxyy, r2.zxyy
/*   52   */          dp3 r1._y__, r4.zxyy, r0.zxyy
              +       sges r4.___w, r_abs[0].x
/*   53   */          dp4 r0._y__, r5.zxyw, r4.zxyw
/*   54   */          add r0.x_z_, r1.xyyy, r3.xyyy
              +       sges r0.___w, r_abs[0].x
/*   55   */          mad r0.xyz_, c6.xyzz, c5.xxxx, r0.xyzz
/*    5.0 */       exec
/*   56   */          dp4 oPos.x___, c0.zxyw, r0.zxyw
/*   57   */          dp4 oPos._y__, c1.zxyw, r0.zxyw
/*   58   */          dp4 oPos.__z_, c2.zxyw, r0.zxyw
/*   59   */          dp4 oPos.___w, c3.zxyw, r0.zxyw
/*    5.1 */       alloc interpolators
/*    6.0 */       exece
/*    6.1 */       cnop
