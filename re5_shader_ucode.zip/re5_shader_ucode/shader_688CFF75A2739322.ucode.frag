/*    0.0 */       exec
/*   26   */          tfetch2D r7.yxzw, r1.xy, tf0
/*   27   */          serialize
                      mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r7.ww
/*   28   */          sgt r10.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       rcp r1.x___, r0.w
/*   29   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   30   */          mul r0.xy__, r3.zwww, r0.yxxx
              +       subsc r1.x___, -c1.x, -r1.y
/*   31   */          kill_gt r1._, c255.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   32   */          tfetch2D r11.xyz_, r3.xy, tf2
/*   33   */          tfetch2D r12.xy__, r3.xy, tf1
/*   34   */          tfetch2D r0, r0.xy, tf4
/*   35   */          serialize
                      sgt r9.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       maxs r3.___w, c15.xx
/*   36   */          add r8.xyz_, r2.xyzz, -c23.xyzz
              +       maxs r1.x___, r7.zz
/*   37   */          mul r0, r0.wzyx, c5.wzyx
              +       mulsc r7.__z_, c13.z, r1.x
/*    1.0 */       exec
/*   38   */          dp3 r1._y__, r8.zxyy, r8.zxyy
              +       mulsc r7.x___, c13.y, r7.x
/*   39   */          mad r13.xy__, r12.yxxx, c254.xxxx, c255.wwww
              +       retain_prev r1._
/*   40   */          dp2add r2.___w, -r13.xyyy, r13.xyyy, c255.yyyy
              +       retain_prev r1._
/*   41   */          min r0, r0, c7.xxxx
              +       rsq r3.__z_, r_abs[1].y
/*   42   */          mul r12.xyz_, r8.zyxx, r3.zzzz
              +       mulsc r7._y__, c13.x, r7.y
/*   43   */          max r8, r0.wzyx, c8.xxxx
              +       sqrt r2.___w, r_abs[2].w
/*    1.1 */       exec
/*   44   */          mul r0.xyz_, r2.wwww, r6.xyzz
              +       maxs r0.___w, r8.yw
/*   45   */          mad r0.xyz_, r13.xxxx, r5.zyxx, r0.zyxx
              +       retain_prev r1._
/*   46   */          mad r0.xyz_, r13.yyyy, r4.xzyy, r0.zxyy
              +       retain_prev r1._
/*   47   */          dp3 r2.___w, r0.yxzz, r0.yxzz
              +       maxs r3.__z_, r8.xz
/*   48   */          max r3.__z_, r3.zzzz, r0.wwww
              +       rsq r2.___w, r_abs[2].w
/*   49   */          mul r4.xyz_, r0.xzyy, r2.wwww
              +       sqrt r1._y__, r_abs[1].y
/*    2.0 */       cjmp !b128, L24
/*    2.1 */       exec
/*   50   */          mul r0, r8.wzyx, c48.wzyx
              +       retain_prev r1._
/*   51   */          add r5.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   52   */          dp3 r5.___w, r5.xzyy, r5.xzyy
              +       retain_prev r1._
/*   53   */          max4 r0.__z_, r0.zxwy
              +       rsq r1.x___, r_abs[5].w
/*   54   */          mul r6, r5, r1.xxxx
              +       retain_prev r1._
/*   55   */          dp3 r5.__z_, r4.zxyy, r6.xzyy
              +       retain_prev r1._
/*    3.0 */       exec
/*   56   */          add r5.xy_w, r6.zyxx, -r12.zyxx
              +       retain_prev r1._
/*   57   */          dp3 r2.___w, r6.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   58   */          add r1.x___, r6.wwww, -c32.wwww
              +       retain_prev r1._
/*   59   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   60   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c35.y, r2.w
/*   61   */          max r1.x___, r1.xxxx, c35.wwww
              +       rsq r2.___w, r_abs[0].y
/*    3.1 */       exec
/*   62   */          mul r6.xyz_, r5.wyxx, r2.wwww
              +       subsc r0.___w, c255.y, r0.x
/*   63   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r2.___w, c255.y, r0.z
/*   64   */          dp3 r5._y__, r4.zxyy, r6.xzyy
              +       maxs r1._, r0.ww
/*   65   */          max r0._yz_, r5.zzyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*   66   */          mul r5._yzw, r5.xxyy, c32.xxzy
              +       log r1.x___, r_abs[0].z
/*   67   */          max r1._, r1, r1
              +       mulsc r0.x___, c14.z, r1.x
/*    4.0 */       exec
/*   68   */          mul r5.x___, r5.yyyy, r0.wwww
              +       exp r0.x___, r0.x
/*   69   */          mul r6.xy__, r5.zwww, r0.xxxx
              +       retain_prev r1._
/*   70   */          mul r10.xy__, r6.xyyy, r2.wwww
              +       retain_prev r1._
/*   71   */          mul r0, r5.xzwx, r0.yyyx
              +       retain_prev r1._
/*   72   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       maxs r1._, r0.ww
/*   73   */          mul r9.xyz_, r0.xzyy, c35.zzzz
              +       muls_prev r10.__z_, r2.w
/*    4.1 */       cjmp !b129, L24
/*    5.0 */       exec
/*   74   */          mul r0, r8.wzyx, c49.wzyx
              +       retain_prev r1._
/*   75   */          add r5.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   76   */          dp3 r5.___w, r5.zxyy, r5.zxyy
              +       retain_prev r1._
/*   77   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[5].w
/*   78   */          mul r6, r5, r1.xxxx
              +       retain_prev r1._
/*   79   */          dp3 r5.__z_, r4.zxyy, r6.zxyy
              +       retain_prev r1._
/*    5.1 */       exec
/*   80   */          add r5.xy_w, r6.xyzz, -r12.zyxx
              +       retain_prev r1._
/*   81   */          dp3 r2.___w, r6.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   82   */          add r1.x___, r6.wwww, -c36.wwww
              +       retain_prev r1._
/*   83   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   84   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c39.y, r2.w
/*   85   */          max r1.x___, r1.xxxx, c39.wwww
              +       rsq r2.___w, r_abs[0].y
/*    6.0 */       exec
/*   86   */          mul r6.xyz_, r5.wyxx, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   87   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*   88   */          dp3 r5._y__, r4.zxyy, r6.xzyy
              +       maxs r1._, r0.yy
/*   89   */          max r0.x__w, r5.zyyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*   90   */          mul r5.xy_w, r5.yyxx, c36.zyxx
              +       log r1.x___, r_abs[0].w
/*   91   */          mul r5.__z_, r5.wwww, r0.yyyy
              +       mulsc r0.___w, c14.z, r1.x
/*    6.1 */       exec
/*   92   */          mul r0.xyz_, r5.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*   93   */          mul r5.xyz_, r5.xyzz, r0.wwww
              +       retain_prev r1._
/*   94   */          mad r10.xyz_, r5.xyzz, r2.wwww, r10.xyzz
              +       retain_prev r1._
/*   95   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   96   */          mad r9.xyz_, r0.xzyy, c39.zzzz, r9.xyzz
              +       retain_prev r1._
/*    7.0 */       cjmp !b130, L24
/*    7.1 */       exec
/*   97   */          mul r0, r8, c50
              +       retain_prev r1._
/*   98   */          add r5.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   99   */          dp3 r5.___w, r5.xzyy, r5.xzyy
              +       retain_prev r1._
/*  100   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[5].w
/*  101   */          mul r6, r5, r1.xxxx
              +       retain_prev r1._
/*  102   */          dp3 r5.__z_, r4.zxyy, r6.xzyy
              +       retain_prev r1._
/*    8.0 */       exec
/*  103   */          add r5.xy_w, r6.zyxx, -r12.zyxx
              +       retain_prev r1._
/*  104   */          dp3 r2.___w, r6.xzyy, -c42.zxyy
              +       retain_prev r1._
/*  105   */          add r1.x___, r6.wwww, -c40.wwww
              +       retain_prev r1._
/*  106   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*  107   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c43.y, r2.w
/*  108   */          max r1.x___, r1.xxxx, c43.wwww
              +       rsq r2.___w, r_abs[0].y
/*    8.1 */       exec
/*  109   */          mul r6.xyz_, r5.xyww, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  110   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*  111   */          dp3 r5._y__, r4.zxyy, r6.zxyy
              +       maxs r1._, r0.yy
/*  112   */          max r0.x__w, r5.zyyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*  113   */          mul r5.xy_w, r5.yyxx, c40.zyxx
              +       log r1.x___, r_abs[0].w
/*  114   */          mul r5.__z_, r5.wwww, r0.yyyy
              +       mulsc r0.___w, c14.z, r1.x
/*    9.0 */       exec
/*  115   */          mul r0.xyz_, r5.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  116   */          mul r5.xyz_, r5.xyzz, r0.wwww
              +       retain_prev r1._
/*  117   */          mad r10.xyz_, r5.xyzz, r2.wwww, r10.xyzz
              +       retain_prev r1._
/*  118   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  119   */          mad r9.xyz_, r0.xzyy, c43.zzzz, r9.xyzz
              +       retain_prev r1._
/*    9.1 */       cjmp !b131, L24
/*   10.0 */       exec
/*  120   */          mul r0, r8.wzyx, c51.wzyx
              +       retain_prev r1._
/*  121   */          add r5.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*  122   */          dp3 r5.___w, r5.zxyy, r5.zxyy
              +       retain_prev r1._
/*  123   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[5].w
/*  124   */          mul r6, r5, r1.xxxx
              +       retain_prev r1._
/*  125   */          dp3 r5.__z_, r4.zxyy, r6.zxyy
              +       retain_prev r1._
/*   10.1 */       exec
/*  126   */          add r5.xy_w, r6.xyzz, -r12.zyxx
              +       retain_prev r1._
/*  127   */          dp3 r2.___w, r6.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  128   */          add r1.x___, r6.wwww, -c44.wwww
              +       retain_prev r1._
/*  129   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  130   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c47.y, r2.w
/*  131   */          max r1.x___, r1.xxxx, c47.wwww
              +       rsq r2.___w, r_abs[0].y
/*   11.0 */       exec
/*  132   */          mul r6.xyz_, r5.wyxx, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  133   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*  134   */          dp3 r5._y__, r4.zxyy, r6.xzyy
              +       maxs r1._, r0.yy
/*  135   */          max r0.x__w, r5.zyyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*  136   */          mul r5.xy_w, r5.yyxx, c44.zyxx
              +       log r1.x___, r_abs[0].w
/*  137   */          mul r5.__z_, r5.wwww, r0.yyyy
              +       mulsc r0.___w, c14.z, r1.x
/*   11.1 */       exec
/*  138   */          mul r0.xyz_, r5.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  139   */          mul r5.xyz_, r5.xyzz, r0.wwww
              +       retain_prev r1._
/*  140   */          mad r10.xyz_, r5.xyzz, r2.wwww, r10.xyzz
              +       retain_prev r1._
/*  141   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  142   */          mad r9.xyz_, r0.xzyy, c47.zzzz, r9.xyzz
              +       retain_prev r1._
                label L24
/*   12.0 */       cjmp !b132, L36
/*   12.1 */       exec
/*  143   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  144   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  145   */          mul r5, r8.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  146   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  147   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  148   */          dp3 r2.___w, r0.xzyy, r4.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   13.0 */       exec
/*  149   */          max4 r0._y__, r5.zxwy
              +       maxs r0.__z_, r2.ww
/*  150   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  151   */          mul r5.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  152   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  153   */          mad r9.xyz_, r5.zxyy, r0.yyyy, r9.xyzz
              +       retain_prev r1._
/*   13.1 */       cjmp !b133, L36
/*   14.0 */       exec
/*  154   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  155   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  156   */          mul r5, r8, c53
              +       rsq r1.x___, r_abs[0].w
/*  157   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  158   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  159   */          dp3 r2.___w, r0.zxyy, r4.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   14.1 */       exec
/*  160   */          max4 r0._y__, r5.ywxz
              +       maxs r0.__z_, r2.ww
/*  161   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  162   */          mul r5.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  163   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  164   */          mad r9.xyz_, r5.zxyy, r0.yyyy, r9.xyzz
              +       retain_prev r1._
/*   15.0 */       cjmp !b134, L36
/*   15.1 */       exec
/*  165   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  166   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  167   */          mul r5, r8.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  168   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  169   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  170   */          dp3 r2.___w, r0.xzyy, r4.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   16.0 */       exec
/*  171   */          max4 r0._y__, r5.zxwy
              +       maxs r0.__z_, r2.ww
/*  172   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  173   */          mul r5.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  174   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  175   */          mad r9.xyz_, r5.zxyy, r0.yyyy, r9.xyzz
              +       retain_prev r1._
/*   16.1 */       cjmp !b135, L36
/*   17.0 */       exec
/*  176   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  177   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  178   */          mul r5, r8, c55
              +       rsq r1.x___, r_abs[0].w
/*  179   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  180   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  181   */          dp3 r2.___w, r0.zxyy, r4.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   17.1 */       exec
/*  182   */          max4 r0._y__, r5.ywxz
              +       maxs r0.__z_, r2.ww
/*  183   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  184   */          mul r5.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  185   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  186   */          mad r9.xyz_, r5.zxyy, r0.yyyy, r9.xyzz
              +       retain_prev r1._
                label L36
/*   18.0 */       exec
/*  187   */          tfetch2D r2.___x, r3.xy, tf5
/*  188   */          serialize
                      mul r6, r4.xyzz, r4.yzzx
              +       retain_prev r1._
/*  189   */          cndeq r0, c255.xxxy, r4.zxyy, c255.yyyy
              +       retain_prev r1._
/*  190   */          dp4 r5.x___, c16.zxyw, r0
              +       retain_prev r1._
/*  191   */          dp4 r5._y__, c18.zxyw, r0
              +       retain_prev r1._
/*  192   */          dp4 r5.__z_, c17.zxyw, r0
              +       retain_prev r1._
/*   18.1 */       exec    // PredicateClean=false
/*  193   */          dp4 r0.x___, r6.wzxy, c19.wzxy
              +       muls r3.x___, r4.xx
/*  194   */          dp4 r0._y__, r6.wzxy, c21.wzxy
              +       muls r3._y__, r4.yy
/*  195   */          dp4 r0.__z_, r6.wzxy, c20.wzxy
              +       subs r0.___w, r3.xy
/*  196   */          add r0.xyz_, r5.zxyy, r0.zxyy
              +       setp_gt r1._, c_abs[57].x
/*  197   */          mad r0.xyz_, r0.wwww, c22.xyzz, r0.yxzz
              +       retain_prev r1._
/*  198   */          mad r0.xyz_, r9.xyzz, r1.wwww, r0.xzyy
              +       retain_prev r1._
/*   19.0 */       exec
/*  199   */          mad r5.xyz_, r2.wwww, c56.xyzz, r0.xzyy
              +       retain_prev r1._
/*   19.1 */  (p0) exec
/*  200   */     (p0) mul r6.xyz_, r5.zyxx, c60.xxxx
              +  (p0) retain_prev r1._
/*  201   */     (p0) mul r0.xyz_, r5.zyxx, c61.xxxx
              +  (p0) retain_prev r1._
/*  202   */     (p0) mul r0.xyz_, r0.xyzz, c59.xxxx
              +  (p0) retain_prev r1._
/*  203   */     (p0) mad r5.xyz_, r6.zyxx, c58.xxxx, r0.zyxx
              +  (p0) retain_prev r1._
/*   20.0 */       exec
/*  204   */          dp3 r3._y__, r12.xzyy, r4.zxyy
              +       retain_prev r1._
/*  205   */          max r1._, r1, r1
              +       adds r1.x___, r3.yy
/*  206   */          mad r0.xyz_, -r4.xyzz, r1.xxxx, r12.zyxx
              +       retain_prev r1._
/*  207   */          cube r0, r0.zzxy, r0.yxzz
              +       retain_prev r1._
/*  208   */          max r4.__z_, r0.wwww, r0.wwww
              +       rcp r1.x___, r_abs[0].z
/*  209   */          mad r4.xy__, r0.yxxx, r1.xxxx, c254.yyyy
              +       retain_prev r1._
/*   20.1 */       exec
/*  210   */          setTexLOD r3.w
/*  211   */          tfetchCube r4, r4.xyz, tf3, UseComputedLOD=false, UseRegisterLOD=true
/*   21.0 */       alloc colors
/*   21.1 */       exec
/*  212   */          max r1.x___, r4.wwww, c254.zzzz
              +       mulsc r3.x___, c6.x, r3.z
/*  213   */          add r0.xy__, -r3.xyyy, c255.yyyy
              +       rcp r1.x___, r1.x
/*  214   */          mul r3.xyz_, r1.xxxx, r4.xyzz
              +       retain_prev r1._
/*  215   */          mul r3.xyz_, r3.zyxx, r0.xxxx
              +       muls r1.x___, r_abs[0].yy
/*  216   */          max r1._, r1, r1
              +       muls r1.x___, r1.xx
/*  217   */          mul r3.___w, r1.xxxx, r_abs[0].yyyy
              +       retain_prev r1._
/*   22.0 */       exec    // PredicateClean=false
/*  218   */          mad r0.xyz_, r3.zyxx, c14.wwww, r10.zyxx
              +       retain_prev r1._
/*  219   */          mad_sat r1.x___, r3.wwww, c14.xxxx, c14.yyyy
              +       retain_prev r1._
/*  220   */          max r1._, r1, r1
              +       subsc r1.x___, c255.y, r1.x
/*  221   */          mul r1.x___, r1.xxxx, r1.wwww
              +       setp_ne r1._, c57.x
/*  222   */     (p0) mul r0.xyz_, r0.xyzz, c62.xxxx
              +  (p0) retain_prev r1._
/*  223   */          mul r3.xyz_, r1.xxxx, r11.xyzz
              +       maxs r1._, r7.ww
/*   22.1 */       exec
/*  224   */          mul r0.xyz_, r3.xyzz, r0.xyzz
              +       muls_prev r1.___w, r1.z
/*  225   */          mad r0.xyz_, r7.yxzz, r5.xyzz, r0.xyzz
              +       retain_prev r1._
/*   23.0 */       cjmp !b136, L50
/*   23.1 */       exec
/*  226   */          mad r2.___w, r1.yyyy, c12.yyyy, c12.zzzz
              +       retain_prev r1._
/*  227   */          dp3 r1.__z_, r12.xzyy, c10.zxyy
              +       retain_prev r1._
/*  228   */          cndeq r3, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  229   */          dp4 r1.x___, c10.zxyw, r3
              +       subsc r1._y__, -c9.x, -r1.y
/*  230   */          add r2.xyz_, -r0.xyzz, c11.xyzz
              +       mulsc r0.___w, c9.z, r1.y
/*  231   */          min r3.xy__, r1.xzzz, c255.xzzz
              +       mulsc r1.x___, c9.w, r1.x
/*   24.0 */       exec
/*  232   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  233   */          max r1._, r1, r1
              +       mulsc r1.x___, c12.x, r1.y
/*  234   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  235   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  236   */          min r1.x___, r1.xxxx, c11.wwww
              +       retain_prev r1._
/*  237   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*   24.1 */       exec
/*  238   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L50
/*   25.0 */       exece
/*  239   */          mul r1.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  240   */          max oC0, r1, r1
/*   25.1 */       cnop
