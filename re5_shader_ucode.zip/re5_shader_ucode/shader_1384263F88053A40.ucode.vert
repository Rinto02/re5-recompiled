/*    0.0 */       exec
/*    9   */          vfetch_full r5.1zyx, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*   10   */          vfetch_mini r2, Offset=3, DataFormat=FMT_8_8_8_8
/*   11   */          vfetch_mini r0._zxy, Offset=4, DataFormat=FMT_16_16_16_16, Signed=true
/*   12   */          vfetch_mini r3.zywx, Offset=6, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   13   */          vfetch_mini r1.zyx_, Offset=7, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   14   */          serialize
                      add r4.xy__, c0.xyyy, c0.xyyy
/*    0.1 */       exec    // PredicateClean=false
/*   15   */          mul r0.x___, c3.xxxx, c4.xxxx
/*   16   */          add r4.__zw, c0.wwwz, c255.xxxy
              +       setp_gt r0._, r_abs[0].x
/*    1.0 */ (!p0) jmp L7
/*    1.1 */       exec
/*   17   */          add r6.xy__, r1.yzzz, c252.zzzz
/*   18   */          mad r1._yz_, r3.xxyy, c254.xxyy, r3.zzww
/*   19   */          mad r0.x___, r1.zzzz, c253.yyyy, c252.yyyy
/*   20   */          frc r6.__z_, r0.xxxx
              +       mulsc r3.x___, c252.w, r1.x
/*   21   */          mul r3._yzw, r6.zzxy, c255.wwzz
              +       mulsc r1.x___, c252.x, r0.z
/*   22   */          add r0.x___, r3.yyyy, c253.xxxx
              +       mulsc r1.___w, c252.x, r0.w
/*    2.0 */       exec
/*   23   */          mul r0.__zw, r1.wwwx, c1.xxxy
              +       cos r3._y__, r0.x
/*   24   */          mul r1.xy__, r3.zwww, r1.yyyy
              +       sin r3.__z_, r0.x
/*   25   */          mul r1.xyz_, r1.yxxx, r3.xyzz
/*   26   */          mul r3.xy__, r1.xxxx, r3.yzzz
/*   27   */          add r1.x___, r3.xxxx, -r1.zzzz
/*   28   */          add r1._y__, r3.yyyy, r1.yyyy
/*    2.1 */       exec
/*   29   */          add r1.xy__, r1.xyyy, r5.wzzz
/*   30   */          mad r1.xy__, r1.xyyy, r4.xyyy, r4.wzzz
/*    3.0 */       jmp L8
                label L7
/*    3.1 */       exec
/*   31   */          mul r0.__zw, r0.wwwz, c253.wwww
/*   32   */          mad r1.xy__, r4.xyyy, r5.wzzz, r4.wzzz
                label L8
/*    4.0 */       exec
/*   33   */          mulsc r0.x___, c253.z, r0.y
/*   34   */          mul r2.xyz_, r0.xxxx, r2.xyzz
/*    4.1 */       cjmp !b0, L11
/*    5.0 */       exec
/*   35   */          dp4 r0._y__, r5.xywz, c23.wzxy
/*   36   */          subsc r0.x___, -c2.x, -r0.y
/*   37   */          mulsc_sat r0.x___, c2.y, r0.x
/*   38   */          mul r2.___w, r0.xxxx, r2.wwww
                label L11
/*    5.1 */       exec    // PredicateClean=false
/*   39   */          sge r1.___w, r_abs[0].xxxx, c254.zzzz
              +       setp_ne r0._, c4.x
/*    6.0 */  (p0) exec
/*   40   */     (p0) sgt r0.x___, c254.wwww, r2.wwww
/*   41   */     (p0) cndeq r1.___w, r0.xxxx, c255.xxxx, c255.yyyy
/*    6.1 */       alloc position
/*    7.0 */       exec
/*   42   */          maxs r1.__z_, r5.yy
/*   43   */          max oPos, r1, r1
/*    7.1 */       alloc interpolators
/*    8.0 */       exece
/*   44   */          max o1.xy00, r0.zwww, r0.zwww
/*   45   */          max o0, r2.zyxw, r2.zyxw
/*    8.1 */       cnop
