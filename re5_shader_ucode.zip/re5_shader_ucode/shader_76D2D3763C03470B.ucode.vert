/*    0.0 */       exec
/*    8   */          vfetch_full r3.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=7
/*    9   */          vfetch_mini r5.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*   10   */          vfetch_mini r7, Offset=4, DataFormat=FMT_8_8_8_8, Signed=true
/*   11   */          vfetch_mini r0._yx_, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   12   */          vfetch_mini r0.y__x, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   13   */          serialize
                      max r6, c28, c28
/*    0.1 */       exec
/*   14   */          max r2, c29, c29
/*   15   */          max r1, c30, c30
/*   16   */          cndeq r3, c255.zzzx, r3.zxyy, c255.xxxx
/*   17   */          dp4 r4.x___, r6.zxyw, r3
/*   18   */          dp4 r4._y__, r2.zxyw, r3
/*   19   */          dp4 r4.__z_, r1.zxyw, r3
/*    1.0 */       cjmp !b0, L7
/*    1.1 */       exec
/*   20   */          cndeq r3, c255.zzzx, r4.zxyy, c255.xxxx
/*   21   */          dp4 r8.x___, c0.zxyw, r3
/*   22   */          dp4 r8._y__, c1.zxyw, r3
/*   23   */          dp4 r8.__z_, c2.zxyw, r3
/*   24   */          dp2add r3.x___, r8.xyyy, r8.xyyy, c255.zzzz
/*   25   */          dp3 r3._y__, r8.zxyy, r8.zxyy
/*    2.0 */       exec
/*   26   */          sqrt r3.___w, r_abs[3].y
/*   27   */          mad r3.__z_, r3.wwww, c27.xxxx, c27.yyyy
/*   28   */          add r3._y__, -r8.zzzz, r3.wwww
/*   29   */          mul r9.xy__, r8.xyyy, r3.wwww
/*   30   */          mul r9.xy__, r9.yxxx, r3.yyyy
              +       rcp r3.x___, r3.x
/*   31   */          mul r3.xy__, r9.yxxx, r3.xxxx
/*    2.1 */       exec
/*   32   */          cndge r3.__zw, r8.zzzz, r3.zzzw, c255.xxxy
/*    3.0 */       jmp L8
                label L7
/*    3.1 */       exec
/*   33   */          cndeq r8, c255.zzzx, r4.zxyy, c255.xxxx
/*   34   */          dp4 r3.x___, c23.zxyw, r8
/*   35   */          dp4 r3._y__, c24.zxyw, r8
/*   36   */          dp4 r3.__z_, c25.zxyw, r8
/*   37   */          dp4 r3.___w, c26.zxyw, r8
                label L8
/*    4.0 */       alloc position
/*    4.1 */       exec
/*   38   */          mad r3.__z_, -r3.wwww, c6.xxxx, r3.zzzz
/*   39   */          max oPos, r3, r3
/*    5.0 */       alloc interpolators
/*    5.1 */       exec
/*   40   */          dp3 r8.x___, r5.zxyy, r2.zxyy
/*   41   */          dp3 r8._y__, r5.zxyy, r6.zxyy
/*   42   */          dp3 r8.__z_, r5.zxyy, r1.zxyy
              +       maxs r5.x___, r7.xx
/*   43   */          max r5._y__, r7.yyyy, r7.yyyy
              +       maxs r5.__z_, r7.zz
/*   44   */          dp3 r9.__z_, r5.zxyy, r1.zxyy
              +       maxs r7.__z_, c31.xx
/*   45   */          dp3 r9._y__, r5.zxyy, r2.zxyy
              +       addsc r7.x___, c4.x, r0.y
/*    6.0 */       exec
/*   46   */          dp3 r9.x___, r5.zxyy, r6.zxyy
              +       addsc r7._y__, c4.y, r0.z
/*   47   */          add o3.xy__, r0.xwww, c5.xyyy
/*   48   */          max o2.xyz_, r4.xyzz, r4.xyzz
/*   49   */          max o4.xyz_, r9.xyzz, r9.xyzz
/*   50   */          max o6.xyz_, r8.yxzz, r8.yxzz
/*   51   */          max o1, r7, r7
/*    6.1 */       exec
/*   52   */          max o0, r3, r3
/*   53   */          mul r1.xy__, r9.xxxx, r8.zxxx
/*   54   */          mul r0, r9.yzyz, r8.zxyy
/*   55   */          add r0.__z_, r1.yyyy, -r0.zzzz
/*   56   */          add r0.___w, r0.wwww, -r1.xxxx
              +       subs r0._y__, r0.xy
/*   57   */          dp3 r0.x___, r0.zyww, r0.zyww
/*    7.0 */       exece
/*   58   */          rsq r0.x___, r_abs[0].x
/*   59   */          mul r0.xyz_, r0.yzww, r0.xxxx
/*   60   */          mul o5.xyz_, r0.xzyy, c3.zzzz
/*    7.1 */       cnop
