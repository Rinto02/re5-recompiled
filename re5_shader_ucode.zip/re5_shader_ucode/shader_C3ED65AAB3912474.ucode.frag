/*    0.0 */       exec
/*    2   */          add r3._y__, c2.zzzz, c255.xxxx
              +       rcp r3.x___, r2.w
/*    3   */          mad r3.x_z_, r3.xxxx, r2.xyyy, c3.xyyy
/*    4   */          mul r3.x_z_, r3.xzzz, c4.xyyy
/*    5   */          tfetch2D r4, r1.xy, tf0
/*    6   */          tfetch2D r3.x___, r3.xz, tf1
/*    0.1 */       alloc colors
/*    1.0 */       exec
/*    7   */          add r3.x___, r3.yyyy, -r3.xxxx
/*    8   */          mul r3._yzw, r4.xxyz, c23.xxxx
/*    9   */          mul oC0.xyz_, r3.yzww, r0.xyzz
/*   10   */          mul r0._y__, r4.wwww, r0.wwww
              +       rcp r0.x___, r3.x
/*   11   */          mad r0.x___, r0.xxxx, c2.wwww, -r2.zzzz
/*   12   */          mul r0.x___, r_abs[0].xxxx, r1.wwww
/*    1.1 */       exece
/*   13   */          min r0.x___, r0.xxxx, c255.xxxx
/*   14   */          mul oC0.___w, r0.yyyy, r0.xxxx
