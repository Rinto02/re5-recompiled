/*    0.0 */       exec
/*   20   */          tfetch2D r5.yxzw, r1.xy, tf0
/*   21   */          serialize
                      max r1._, r1, r1
              +       rcp r1.x___, r0.w
/*   22   */          mul r6.xy__, c4.zwww, c3.xyyy
              +       maxs r1._y__, r5.ww
/*   23   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   24   */          mul r0.xy__, r6.xyyy, r0.yxxx
              +       subsc r1.x___, -c1.x, -r1.y
/*   25   */          kill_gt r1._, c255.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   26   */          tfetch2D r0, r0.xy, tf1
/*    1.0 */       alloc colors
/*    1.1 */       exec
/*   27   */          dp3 r1.x___, r3.zxyy, r3.zxyy
              +       sgts r7._y__, -r_abs[1].x
/*   28   */          add r6.xyz_, r2.zyxx, -c23.zyxx
              +       sgts r7.__z_, -r_abs[1].x
/*   29   */          dp3 r4.___w, r6.xzyy, r6.xzyy
              +       sgts r7.x___, -r_abs[1].x
/*   30   */          mul r0, r0.wzyx, c5.wzyx
              +       rsq r1.x___, r_abs[1].x
/*   31   */          mul r8.xyz_, r1.xxxx, r3.xyzz
              +       maxs r1.x___, r5.zz
/*   32   */          min r0, r0, c8.xxxx
              +       mulsc r5.__z_, c14.z, r1.x
/*    2.0 */       exec
/*   33   */          max r3, r0.wzyx, c9.xxxx
              +       mulsc r5.x___, c14.y, r5.x
/*   34   */          max r0.xy__, r3.yxxx, r3.wzzz
              +       mulsc r5._y__, c14.x, r5.y
/*   35   */          max r1._y__, r0.yyyy, r0.xxxx
              +       sqrt r0.___w, r_abs[4].w
/*    2.1 */       cjmp !b128, L21
/*    3.0 */       exec
/*   36   */          mul r9, r3.wzyx, c48.wzyx
              +       retain_prev r1._
/*   37   */          add r7.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   38   */          dp3 r7.___w, r7.xzyy, r7.xzyy
              +       retain_prev r1._
/*   39   */          max4 r0.__z_, r9.zxwy
              +       rsq r1.x___, r_abs[7].w
/*   40   */          mul r7, r7, r1.xxxx
              +       retain_prev r1._
/*   41   */          dp3 r0._y__, r8.zxyy, r7.xzyy
              +       retain_prev r1._
/*    3.1 */       exec
/*   42   */          dp3 r2.___w, r7.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   43   */          add r1.x___, r7.wwww, -c32.wwww
              +       retain_prev r1._
/*   44   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   45   */          max r0._y__, r0.yyyy, c255.xxxx
              +       mulsc r2.___w, c35.y, r2.w
/*   46   */          max r2.___w, r2.wwww, c35.wwww
              +       subsc r6.___w, c255.y, r0.x
/*   47   */          min r7.x___, r2.wwww, c255.yyyy
              +       subsc r2.___w, c255.y, r0.z
/*    4.0 */       exec
/*   48   */          mul r7._y__, r6.wwww, r7.xxxx
              +       retain_prev r1._
/*   49   */          mul r7._yzw, r7.xxyy, c32.xxzy
              +       retain_prev r1._
/*   50   */          mul r7.x___, r7.yyyy, r6.wwww
              +       retain_prev r1._
/*   51   */          mul r0.xyz_, r7.xzww, r0.yyyy
              +       retain_prev r1._
/*   52   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       retain_prev r1._
/*   53   */          mul r7.xyz_, r0.xzyy, c35.zzzz
              +       retain_prev r1._
/*    4.1 */       cjmp !b129, L21
/*    5.0 */       exec
/*   54   */          mul r10, r3.wzyx, c49.wzyx
              +       retain_prev r1._
/*   55   */          add r9.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   56   */          dp3 r9.___w, r9.zxyy, r9.zxyy
              +       retain_prev r1._
/*   57   */          max4 r0.x___, r10.zxwy
              +       rsq r1.x___, r_abs[9].w
/*   58   */          mul r9, r9, r1.xxxx
              +       retain_prev r1._
/*   59   */          dp3 r0._y__, r8.zxyy, r9.zxyy
              +       retain_prev r1._
/*    5.1 */       exec
/*   60   */          dp3 r2.___w, r9.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   61   */          add r1.x___, r9.wwww, -c36.wwww
              +       retain_prev r1._
/*   62   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   63   */          max r0._y__, r0.yyyy, c255.xxxx
              +       mulsc r2.___w, c39.y, r2.w
/*   64   */          max r6.___w, r2.wwww, c39.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   65   */          min r9.x___, r6.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*    6.0 */       exec
/*   66   */          mul r9._y__, r0.xxxx, r9.xxxx
              +       retain_prev r1._
/*   67   */          mul r9.xy_w, r9.yyxx, c36.zyxx
              +       retain_prev r1._
/*   68   */          mul r9.__z_, r9.wwww, r0.xxxx
              +       retain_prev r1._
/*   69   */          mul r0.xyz_, r9.xyzz, r0.yyyy
              +       retain_prev r1._
/*   70   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   71   */          mad r7.xyz_, r0.xzyy, c39.zzzz, r7.xyzz
              +       retain_prev r1._
/*    6.1 */       cjmp !b130, L21
/*    7.0 */       exec
/*   72   */          mul r10, r3, c50
              +       retain_prev r1._
/*   73   */          add r9.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   74   */          dp3 r9.___w, r9.xzyy, r9.xzyy
              +       retain_prev r1._
/*   75   */          max4 r0.x___, r10.ywxz
              +       rsq r1.x___, r_abs[9].w
/*   76   */          mul r9, r9, r1.xxxx
              +       retain_prev r1._
/*   77   */          dp3 r0._y__, r8.zxyy, r9.xzyy
              +       retain_prev r1._
/*    7.1 */       exec
/*   78   */          dp3 r2.___w, r9.xzyy, -c42.zxyy
              +       retain_prev r1._
/*   79   */          add r1.x___, r9.wwww, -c40.wwww
              +       retain_prev r1._
/*   80   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*   81   */          max r0._y__, r0.yyyy, c255.xxxx
              +       mulsc r2.___w, c43.y, r2.w
/*   82   */          max r6.___w, r2.wwww, c43.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   83   */          min r9.x___, r6.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*    8.0 */       exec
/*   84   */          mul r9._y__, r0.xxxx, r9.xxxx
              +       retain_prev r1._
/*   85   */          mul r9.xy_w, r9.yyxx, c40.zyxx
              +       retain_prev r1._
/*   86   */          mul r9.__z_, r9.wwww, r0.xxxx
              +       retain_prev r1._
/*   87   */          mul r0.xyz_, r9.xyzz, r0.yyyy
              +       retain_prev r1._
/*   88   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   89   */          mad r7.xyz_, r0.xzyy, c43.zzzz, r7.xyzz
              +       retain_prev r1._
/*    8.1 */       cjmp !b131, L21
/*    9.0 */       exec
/*   90   */          mul r10, r3.wzyx, c51.wzyx
              +       retain_prev r1._
/*   91   */          add r9.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*   92   */          dp3 r9.___w, r9.zxyy, r9.zxyy
              +       retain_prev r1._
/*   93   */          max4 r0.x___, r10.zxwy
              +       rsq r1.x___, r_abs[9].w
/*   94   */          mul r9, r9, r1.xxxx
              +       retain_prev r1._
/*   95   */          dp3 r0._y__, r8.zxyy, r9.zxyy
              +       retain_prev r1._
/*    9.1 */       exec
/*   96   */          dp3 r2.___w, r9.zxyy, -c46.zxyy
              +       retain_prev r1._
/*   97   */          add r1.x___, r9.wwww, -c44.wwww
              +       retain_prev r1._
/*   98   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*   99   */          max r0._y__, r0.yyyy, c255.xxxx
              +       mulsc r2.___w, c47.y, r2.w
/*  100   */          max r6.___w, r2.wwww, c47.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  101   */          min r9.x___, r6.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*   10.0 */       exec
/*  102   */          mul r9._y__, r0.xxxx, r9.xxxx
              +       retain_prev r1._
/*  103   */          mul r9.xy_w, r9.yyxx, c44.zyxx
              +       retain_prev r1._
/*  104   */          mul r9.__z_, r9.wwww, r0.xxxx
              +       retain_prev r1._
/*  105   */          mul r0.xyz_, r9.xyzz, r0.yyyy
              +       retain_prev r1._
/*  106   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  107   */          mad r7.xyz_, r0.xzyy, c47.zzzz, r7.xyzz
              +       retain_prev r1._
                label L21
/*   10.1 */       cjmp !b132, L33
/*   11.0 */       exec
/*  108   */          add r10.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  109   */          dp3 r10.___w, r10.xzyy, r10.xzyy
              +       retain_prev r1._
/*  110   */          mul r9, r3.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[10].w
/*  111   */          mul r10, r10, r1.xxxx
              +       retain_prev r1._
/*  112   */          add r1.x___, r10.wwww, -c24.wwww
              +       retain_prev r1._
/*  113   */          dp3 r2.___w, r10.xzyy, r8.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   11.1 */       exec
/*  114   */          max4 r0._y__, r9.zxwy
              +       maxs r10.x___, r2.ww
/*  115   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r10._y__, c255.xx
/*  116   */          mul r9.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r10.xy
/*  117   */          mul r9.xyz_, r9.xyzz, r2.wwww
              +       retain_prev r1._
/*  118   */          mad r7.xyz_, r9.zxyy, r0.yyyy, r7.xyzz
              +       retain_prev r1._
/*   12.0 */       cjmp !b133, L33
/*   12.1 */       exec
/*  119   */          add r10.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  120   */          dp3 r10.___w, r10.zxyy, r10.zxyy
              +       retain_prev r1._
/*  121   */          mul r9, r3, c53
              +       rsq r1.x___, r_abs[10].w
/*  122   */          mul r10, r10, r1.xxxx
              +       retain_prev r1._
/*  123   */          add r1.x___, r10.wwww, -c26.wwww
              +       retain_prev r1._
/*  124   */          dp3 r2.___w, r10.zxyy, r8.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   13.0 */       exec
/*  125   */          max4 r0._y__, r9.ywxz
              +       maxs r10.x___, r2.ww
/*  126   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r10._y__, c255.xx
/*  127   */          mul r9.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r10.xy
/*  128   */          mul r9.xyz_, r9.xyzz, r2.wwww
              +       retain_prev r1._
/*  129   */          mad r7.xyz_, r9.zxyy, r0.yyyy, r7.xyzz
              +       retain_prev r1._
/*   13.1 */       cjmp !b134, L33
/*   14.0 */       exec
/*  130   */          add r10.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  131   */          dp3 r10.___w, r10.xzyy, r10.xzyy
              +       retain_prev r1._
/*  132   */          mul r9, r3.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[10].w
/*  133   */          mul r10, r10, r1.xxxx
              +       retain_prev r1._
/*  134   */          add r1.x___, r10.wwww, -c28.wwww
              +       retain_prev r1._
/*  135   */          dp3 r2.___w, r10.xzyy, r8.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   14.1 */       exec
/*  136   */          max4 r0._y__, r9.zxwy
              +       maxs r10.x___, r2.ww
/*  137   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r10._y__, c255.xx
/*  138   */          mul r9.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r10.xy
/*  139   */          mul r9.xyz_, r9.xyzz, r2.wwww
              +       retain_prev r1._
/*  140   */          mad r7.xyz_, r9.zxyy, r0.yyyy, r7.xyzz
              +       retain_prev r1._
/*   15.0 */       cjmp !b135, L33
/*   15.1 */       exec
/*  141   */          add r9.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  142   */          dp3 r9.___w, r9.zxyy, r9.zxyy
              +       retain_prev r1._
/*  143   */          mul r3, r3, c55
              +       rsq r1.x___, r_abs[9].w
/*  144   */          mul r9, r9, r1.xxxx
              +       retain_prev r1._
/*  145   */          add r1.x___, r9.wwww, -c30.wwww
              +       retain_prev r1._
/*  146   */          dp3 r2.___w, r9.zxyy, r8.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   16.0 */       exec
/*  147   */          max4 r0._y__, r3.ywxz
              +       maxs r8.x___, r2.ww
/*  148   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r8._y__, c255.xx
/*  149   */          mul r3.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r8.xy
/*  150   */          mul r3.xyz_, r3.xyzz, r2.wwww
              +       retain_prev r1._
/*  151   */          mad r7.xyz_, r3.zxyy, r0.yyyy, r7.xyzz
              +       retain_prev r1._
                label L33
/*   16.1 */       exec
/*  152   */          mul r0.xyz_, r4.zxyy, c56.zxyy
              +       subsc r1.x___, -c255.y, -r1.w
/*  153   */          mad r1.x___, r1.xxxx, c15.wwww, c255.yyyy
              +       retain_prev r1._
/*  154   */          mul r0.xyz_, r0.xzyy, r1.xxxx
              +       mulsc r1.x___, c6.x, r1.y
/*  155   */          add r4.xyz_, -r0.xyzz, c7.zyxx
              +       maxs r1._, r5.ww
/*  156   */          mad r0.xyz_, r1.xxxx, r4.zyxx, r0.zyxx
              +       retain_prev r1._
/*  157   */          mad r1.xy_w, r7.xyzz, r1.wwww, r0.xzyy
              +       retain_prev r1._
/*   17.0 */       exec
/*  158   */          mul r0.xyz_, r5.yxzz, r1.xwyy
              +       muls_prev r1.___w, r1.z
/*   17.1 */       cjmp !b136, L39
/*   18.0 */       exec
/*  159   */          mad r2.___w, r0.wwww, c13.yyyy, c13.zzzz
              +       retain_prev r1._
/*  160   */          add r1.x___, r0.wwww, -c10.xxxx
              +       rsq r1._y__, r_abs[4].w
/*  161   */          mul r4.xyz_, r6.xyzz, r1.yyyy
              +       retain_prev r1._
/*  162   */          cndeq r3, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  163   */          dp4 r1._y__, c11.zxyw, r3
              +       retain_prev r1._
/*  164   */          dp3 r1.__z_, r4.xzyy, c11.zxyy
              +       retain_prev r1._
/*   18.1 */       exec
/*  165   */          add r2.xyz_, -r0.xyzz, c12.xyzz
              +       mulsc r0.___w, c10.z, r1.x
/*  166   */          min r4.xy__, r1.yzzz, c255.xzzz
              +       mulsc r1.x___, c10.w, r1.y
/*  167   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r4.y
/*  168   */          max r1._, r1, r1
              +       mulsc r1.x___, c13.x, r1.y
/*  169   */          mad r1.x___, r1.xxxx, r4.xxxx, r2.wwww
              +       retain_prev r1._
/*  170   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*   19.0 */       exec
/*  171   */          min r1.x___, r1.xxxx, c12.wwww
              +       retain_prev r1._
/*  172   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*  173   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L39
/*   19.1 */       exece
/*  174   */          mul r1.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  175   */          max oC0, r1, r1
