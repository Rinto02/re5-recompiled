/*    0.0 */       exec
/*    3   */          vfetch_full r1.xyz1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=6
/*    4   */          vfetch_mini r0.xy__, Offset=4, DataFormat=FMT_32_32_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    5   */          max oPos, r1, r1
/*    1.1 */       alloc interpolators
/*    2.0 */       exece
/*    6   */          mad r0.__zw, c0.zzzw, c255.xxxx, r0.xxxy
/*    7   */          max r0, r0.xzwy, c1.xxyy
/*    8   */          min o0, r0.xwyw, c2.xyxy
/*    9   */          min o1, r0.xzyz, c2.xyxy
/*    2.1 */       cnop
