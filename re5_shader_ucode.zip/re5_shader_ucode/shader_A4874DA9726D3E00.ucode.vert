/*    0.0 */       exec
/*    4   */          vfetch_full r2.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    5   */          vfetch_mini r1.xy__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    6   */          vfetch_mini r0.___x, Offset=3, DataFormat=FMT_8_8_8_8
/*    7   */          vfetch_mini r0.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    8   */          mad r6._yzw, r2.xxyz, c215.xxyz, c4.xxyz
/*    9   */          mul r4.xy__, r1.xyyy, c255.xxxx
/*   10   */          add r0.__z_, -r0.wwww, c255.yyyy
              +       maxas r0._, r4.xx
/*   11   */          mul r3, r0.wwww, c[24+a0]
/*   12   */          mul r2, r0.wwww, c[25+a0]
/*   13   */          mul r1, r0.wwww, c[23+a0].wxyz
              +       maxas r0._, r4.yy
/*    1.1 */       exec
/*   14   */          mul r4, r0.zzzz, c[24+a0]
/*   15   */          mul r8, r0.zzzz, c[25+a0]
/*   16   */          mul r5, r0.zzzz, c[23+a0]
/*   17   */          add r7.xyz_, r1.yzww, r5.xyzz
/*   18   */          add r9.xyz_, r2.xyzz, r8.xyzz
/*   19   */          add r10.xyz_, r3.xyzz, r4.xyzz
/*    2.0 */       exec
/*   20   */          dp3 r6.x___, r10.zxyy, r6.wyzz
/*   21   */          dp3 r0.__z_, r9.zxyy, r6.wyzz
/*   22   */          add r0.__z_, r0.zzzz, r8.wwww
              +       sges r1.___w, r_abs[0].x
/*   23   */          dp3 r0.___w, r7.zxyy, r6.wyzz
              +       maxs r0._, r6.xx
/*   24   */          add r0.___w, r0.wwww, r5.wwww
              +       adds_prev r4.x___, r4.w
/*   25   */          add r1._y__, r4.xxxx, r3.wwww
              +       maxs r0._, r0.ww
/*    2.1 */       exec
/*   26   */          add r1.__z_, r0.zzzz, r2.wwww
              +       adds_prev r1.x___, r1.x
/*   27   */          mad r1.xyz_, c7.xyzz, c6.xxxx, r1.xyzz
/*   28   */          dp4 oPos.x___, c0.zxyw, r1.zxyw
/*   29   */          dp4 oPos._y__, c1.zxyw, r1.zxyw
/*   30   */          dp4 oPos.__z_, c2.zxyw, r1.zxyw
/*   31   */          dp4 oPos.___w, c3.zxyw, r1.zxyw
/*    3.0 */       alloc interpolators
/*    3.1 */       exece
/*   32   */          add o0.xy__, r0.xyyy, c5.xyyy
