/*    0.0 */       exec
/*    7   */          vfetch_full r2.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=6
/*    8   */          vfetch_mini r6.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*    9   */          vfetch_mini r4.__w_, Offset=4, DataFormat=FMT_8_8_8_8, Signed=true
/*   10   */          vfetch_mini r4.yx__, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   11   */          serialize
                      max r0, c28, c28
/*   12   */          max r5, c29, c29
/*    0.1 */       exec
/*   13   */          max r1, c30, c30
/*   14   */          cndeq r2, c255.zzzx, r2.zxyy, c255.xxxx
/*   15   */          dp4 r3.x___, r0.zxyw, r2
/*   16   */          dp4 r3._y__, r5.zxyw, r2
/*   17   */          dp4 r3.__z_, r1.zxyw, r2
/*    1.0 */       cjmp !b0, L7
/*    1.1 */       exec
/*   18   */          cndeq r2, c255.zzzx, r3.zxyy, c255.xxxx
/*   19   */          dp4 r7.x___, c0.zxyw, r2
/*   20   */          dp4 r7._y__, c1.zxyw, r2
/*   21   */          dp4 r7.__z_, c2.zxyw, r2
/*   22   */          dp2add r2.x___, r7.xyyy, r7.xyyy, c255.zzzz
/*   23   */          dp3 r2._y__, r7.zxyy, r7.zxyy
/*    2.0 */       exec
/*   24   */          sqrt r2.___w, r_abs[2].y
/*   25   */          mad r2.__z_, r2.wwww, c27.xxxx, c27.yyyy
/*   26   */          add r2._y__, -r7.zzzz, r2.wwww
/*   27   */          mul r8.xy__, r7.xyyy, r2.wwww
/*   28   */          mul r8.xy__, r8.yxxx, r2.yyyy
              +       rcp r2.x___, r2.x
/*   29   */          mul r2.xy__, r8.yxxx, r2.xxxx
/*    2.1 */       exec
/*   30   */          cndge r2.__zw, r7.zzzz, r2.zzzw, c255.xxxy
/*    3.0 */       jmp L8
                label L7
/*    3.1 */       exec
/*   31   */          cndeq r7, c255.zzzx, r3.zxyy, c255.xxxx
/*   32   */          dp4 r2.x___, c23.zxyw, r7
/*   33   */          dp4 r2._y__, c24.zxyw, r7
/*   34   */          dp4 r2.__z_, c25.zxyw, r7
/*   35   */          dp4 r2.___w, c26.zxyw, r7
                label L8
/*    4.0 */       alloc position
/*    4.1 */       exec
/*   36   */          mad r2.__z_, -r2.wwww, c4.xxxx, r2.zzzz
/*   37   */          max oPos, r2, r2
/*    5.0 */       alloc interpolators
/*    5.1 */       exec
/*   38   */          add r4.xy__, r4.xyyy, c3.xyyy
              +       maxs r4.___w, c31.xx
/*   39   */          dp3 o3.x___, r6.zxyy, r0.zxyy
/*   40   */          dp3 o3._y__, r6.zxyy, r5.zxyy
/*   41   */          dp3 o3.__z_, r6.zxyy, r1.zxyy
/*   42   */          max o2.xyz_, r3.xyzz, r3.xyzz
/*   43   */          max o1, r4.xywz, r4.xywz
/*    6.0 */       exece
/*   44   */          max o0, r2, r2
/*    6.1 */       cnop
