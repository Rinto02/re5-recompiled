/*    0.0 */       exec
/*    7   */          vfetch_full r0._xyz, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=6
/*    8   */          vfetch_mini r5.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*    9   */          vfetch_mini r1.yx__, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   10   */          serialize
                      max r3, c28, c28
/*   11   */          max r4, c29, c29
/*   12   */          max r2, c30, c30
/*    0.1 */       exec
/*   13   */          cndeq r0, c255.zzzx, r0.wyzz, c255.xxxx
/*   14   */          dp4 r6.x___, r3.zxyw, r0
/*   15   */          dp4 r6._y__, r4.zxyw, r0
/*   16   */          dp4 r6.__z_, r2.zxyw, r0
/*    1.0 */       cjmp !b0, L7
/*    1.1 */       exec
/*   17   */          cndeq r0, c255.zzzx, r6.zxyy, c255.xxxx
/*   18   */          dp4 r7.x___, c0.zxyw, r0
/*   19   */          dp4 r7._y__, c1.zxyw, r0
/*   20   */          dp4 r7.__z_, c2.zxyw, r0
/*   21   */          dp2add r0.x___, r7.xyyy, r7.xyyy, c255.zzzz
/*   22   */          dp3 r0._y__, r7.zxyy, r7.zxyy
/*    2.0 */       exec
/*   23   */          sqrt r0.___w, r_abs[0].y
/*   24   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   25   */          add r0._y__, -r7.zzzz, r0.wwww
/*   26   */          mul r1.__zw, r7.xxxy, r0.wwww
/*   27   */          mul r1.__zw, r1.wwwz, r0.yyyy
              +       rcp r0.x___, r0.x
/*   28   */          mul r0.xy__, r1.wzzz, r0.xxxx
/*    2.1 */       exec
/*   29   */          cndge r0.__zw, r7.zzzz, r0.zzzw, c255.xxxy
/*    3.0 */       jmp L8
                label L7
/*    3.1 */       exec
/*   30   */          cndeq r7, c255.zzzx, r6.zxyy, c255.xxxx
/*   31   */          dp4 r0.x___, c23.zxyw, r7
/*   32   */          dp4 r0._y__, c24.zxyw, r7
/*   33   */          dp4 r0.__z_, c25.zxyw, r7
/*   34   */          dp4 r0.___w, c26.zxyw, r7
                label L8
/*    4.0 */       alloc position
/*    4.1 */       exec
/*   35   */          max oPos, r0, r0
/*    5.0 */       alloc interpolators
/*    5.1 */       exec
/*   36   */          dp3 r3.x___, r5.zxyy, r3.zxyy
/*   37   */          dp3 r3._y__, r5.zxyy, r4.zxyy
/*   38   */          dp3 r0.x___, r6.zxyy, c2.zxyy
/*   39   */          dp3 r3.__z_, r5.zxyy, r2.zxyy
              +       addsc r0.___w, -c2.w, -r0.x
/*   40   */          add o2.xy__, r1.xyyy, c31.xyyy
/*   41   */          mad r1.xyz_, -r0.wwww, c3.xyzz, r6.xyzz
/*    6.0 */       exec
/*   42   */          dp3 r0.x___, r3.zxyy, r3.zxyy
/*   43   */          sge r1.___w, r_abs[0].xxxx, c255.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   44   */          dp4 o1.x___, c32.zxyw, r1.zxyw
/*   45   */          dp4 o1._y__, c33.zxyw, r1.zxyw
/*   46   */          dp4 o1.__z_, c34.zxyw, r1.zxyw
/*   47   */          dp4 o1.___w, c35.zxyw, r1.zxyw
/*    6.1 */       exece
/*   48   */          mul r0.xyz_, r3.xyzz, r0.xxxx
/*   49   */          max o0, r0, r0
