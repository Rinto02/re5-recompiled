/*    0.0 */       exec
/*    9   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=5
/*   10   */          vfetch_mini r6.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   11   */          vfetch_mini r1, Offset=3, DataFormat=FMT_8_8_8_8
/*   12   */          vfetch_mini r5.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   13   */          serialize
                      mul r7.xy__, r6.zwww, c255.wwww
/*   14   */          maxas r0._, r7.yy
/*    0.1 */       exec    // PredicateClean=false
/*   15   */          mul r2, r1.yyyy, c[30+a0]
/*   16   */          mul r4, r1.yyyy, c[29+a0]
              +       setp_gt r0._, r1.z
/*   17   */          mul r3, r1.yyyy, c[28+a0]
              +       maxas r0._, r7.xx
/*   18   */          mad r3, r1.xxxx, c[28+a0], r3
/*   19   */          mad r4, r1.xxxx, c[29+a0], r4
/*   20   */          mad r2, r1.xxxx, c[30+a0], r2
/*    1.0 */  (p0) exec
/*   21   */     (p0) mul r1.xy__, r6.xyyy, c255.wwww
/*   22   */     (p0) maxas r0._, r1.yy
/*   23   */     (p0) mad r2, r1.wwww, c[30+a0], r2
/*   24   */     (p0) mad r4, r1.wwww, c[29+a0], r4
/*   25   */     (p0) mad r3, r1.wwww, c[28+a0], r3
/*   26   */     (p0) maxas r0._, r1.xx
/*    1.1 */  (p0) exec
/*   27   */     (p0) mad r3, r1.zzzz, c[28+a0], r3
/*   28   */     (p0) mad r4, r1.zzzz, c[29+a0], r4
/*   29   */     (p0) mad r2, r1.zzzz, c[30+a0], r2
/*    2.0 */       exec
/*   30   */          mad r0.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*   31   */          cndeq r1, c255.zzzx, r0.zxyy, c255.xxxx
/*   32   */          dp4 r0._y__, r3.zxyw, r1
/*   33   */          dp4 r0.__z_, r4.zxyw, r1
/*   34   */          dp4 r0.___w, r2.zxyw, r1
/*    2.1 */       cjmp !b0, L10
/*    3.0 */       exec
/*   35   */          cndeq r1, c255.zzzx, r0.wyzz, c255.xxxx
/*   36   */          dp4 r6.x___, c0.zxyw, r1
/*   37   */          dp4 r6._y__, c1.zxyw, r1
/*   38   */          dp4 r6.__z_, c2.zxyw, r1
/*   39   */          dp2add r0.x___, r6.xyyy, r6.xyyy, c255.zzzz
/*   40   */          dp3 r1.x___, r6.zxyy, r6.zxyy
/*    3.1 */       exec
/*   41   */          sqrt r1.___w, r_abs[1].x
/*   42   */          mad r1.__z_, r1.wwww, c27.xxxx, c27.yyyy
/*   43   */          add r1.x___, -r6.zzzz, r1.wwww
/*   44   */          mul r7.xy__, r6.xyyy, r1.wwww
/*   45   */          mul r1.xy__, r7.yxxx, r1.xxxx
              +       rcp r0.x___, r0.x
/*   46   */          mul r1.xy__, r1.yxxx, r0.xxxx
/*    4.0 */       exec
/*   47   */          cndge r1.__zw, r6.zzzz, r1.zzzw, c255.xxxy
/*    4.1 */       jmp L11
                label L10
/*    5.0 */       exec
/*   48   */          cndeq r6, c255.zzzx, r0.wyzz, c255.xxxx
/*   49   */          dp4 r1.x___, c23.zxyw, r6
/*   50   */          dp4 r1._y__, c24.zxyw, r6
/*   51   */          dp4 r1.__z_, c25.zxyw, r6
/*   52   */          dp4 r1.___w, c26.zxyw, r6
                label L11
/*    5.1 */       alloc position
/*    6.0 */       exec
/*   53   */          max oPos, r1, r1
/*    6.1 */       alloc interpolators
/*    7.0 */       exec
/*   54   */          dp3 r1._y__, r5.zxyy, r4.zxyy
/*   55   */          dp3 r1.__z_, r5.zxyy, r2.zxyy
/*   56   */          dp3 r0.x___, r0.wyzz, c2.zxyy
/*   57   */          dp3 r1.x___, r5.zxyy, r3.zxyy
              +       addsc r1.___w, -c2.w, -r0.x
/*   58   */          mad r2.xyz_, -r1.wwww, c5.xyzz, r0.yzww
/*   59   */          dp3 r0.x___, r1.zxyy, r1.zxyy
/*    7.1 */       exec
/*   60   */          sge r2.___w, r_abs[0].xxxx, c255.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   61   */          dp4 o1.x___, c220.zxyw, r2.zxyw
/*   62   */          dp4 o1._y__, c221.zxyw, r2.zxyw
/*   63   */          dp4 o1.__z_, c222.zxyw, r2.zxyw
/*   64   */          dp4 o1.___w, c223.zxyw, r2.zxyw
/*   65   */          dp4 o2.x___, c224.zxyw, r2.zxyw
/*    8.0 */       exec
/*   66   */          dp4 o2._y__, c225.zxyw, r2.zxyw
/*   67   */          dp4 o2.__z_, c226.zxyw, r2.zxyw
/*   68   */          dp4 o2.___w, c227.zxyw, r2.zxyw
/*   69   */          dp4 o3.x___, c228.zxyw, r2.zxyw
/*   70   */          dp4 o3._y__, c229.zxyw, r2.zxyw
/*   71   */          dp4 o3.__z_, c230.zxyw, r2.zxyw
/*    8.1 */       exece
/*   72   */          dp4 o3.___w, c231.zxyw, r2.zxyw
/*   73   */          mul r1.xyz_, r1.xyzz, r0.xxxx
/*   74   */          max o0, r1, r1
