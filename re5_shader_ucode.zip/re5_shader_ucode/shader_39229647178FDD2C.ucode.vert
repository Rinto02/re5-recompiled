/*    0.0 */       exec
/*   10   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=8
/*   11   */          vfetch_mini r2, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   12   */          vfetch_mini r7, Offset=3, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   13   */          vfetch_mini r8, Offset=4, DataFormat=FMT_8_8_8_8
/*   14   */          vfetch_mini r3, Offset=5, DataFormat=FMT_8_8_8_8
/*   15   */          vfetch_mini r6.xyz_, Offset=6, DataFormat=FMT_2_10_10_10, Signed=true
/*    0.1 */       exec    // PredicateClean=false
/*   16   */          vfetch_mini r1.yx__, Offset=7, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   17   */          vfetch_full r1.___w, r0.x, vf1, Offset=1, DataFormat=FMT_8_8_8_8, Signed=true
/*   18   */          serialize
                      mul r9, r2, c255.wwww
/*   19   */          maxas r0._, r9.ww
/*   20   */          mul r4, r8.wwww, c[30+a0]
/*   21   */          mul r5, r8.wwww, c[29+a0]
              +       setp_gt r0._, r3.x
/*    1.0 */       exec
/*   22   */          mul r2, r8.wwww, c[28+a0]
              +       maxas r0._, r9.zz
/*   23   */          mad r2, r8.zzzz, c[28+a0].wyzx, r2.wyzx
/*   24   */          mad r5, r8.zzzz, c[29+a0].wyzx, r5.wyzx
/*   25   */          mad r4, r8.zzzz, c[30+a0].wyzx, r4.wyzx
/*   26   */          maxas r0._, r9.yy
/*   27   */          mad r4, r8.yyyy, c[30+a0].wzxy, r4.xzwy
/*    1.1 */       exec
/*   28   */          mad r5, r8.yyyy, c[29+a0].wzxy, r5.xzwy
/*   29   */          mad r2, r8.yyyy, c[28+a0].wzxy, r2.xzwy
/*   30   */          maxas r0._, r9.xx
/*   31   */          mad r2, r8.xxxx, c[28+a0], r2.zwyx
/*   32   */          mad r5, r8.xxxx, c[29+a0], r5.zwyx
/*   33   */          mad r4, r8.xxxx, c[30+a0], r4.zwyx
/*    2.0 */  (p0) exec
/*   34   */     (p0) mul r7, r7, c255.wwww
/*   35   */     (p0) maxas r0._, r7.ww
/*   36   */     (p0) mad r4, r3.wwww, c[30+a0].xywz, r4.xywz
/*   37   */     (p0) mad r5, r3.wwww, c[29+a0].xywz, r5.xywz
/*   38   */     (p0) mad r2, r3.wwww, c[28+a0].xywz, r2.xywz
/*   39   */     (p0) maxas r0._, r7.zz
/*    2.1 */  (p0) exec
/*   40   */     (p0) mad r2, r3.zzzz, c[28+a0].wxzy, r2.zxwy
/*   41   */     (p0) mad r5, r3.zzzz, c[29+a0].wxzy, r5.zxwy
/*   42   */     (p0) mad r4, r3.zzzz, c[30+a0].wxzy, r4.zxwy
/*   43   */     (p0) maxas r0._, r7.yy
/*   44   */     (p0) mad r4, r3.yyyy, c[30+a0].wzyx, r4.xzwy
/*   45   */     (p0) mad r5, r3.yyyy, c[29+a0].wzyx, r5.xzwy
/*    3.0 */  (p0) exec
/*   46   */     (p0) mad r2, r3.yyyy, c[28+a0].wzyx, r2.xzwy
/*   47   */     (p0) maxas r0._, r7.xx
/*   48   */     (p0) mad r2, r3.xxxx, c[28+a0], r2.wzyx
/*   49   */     (p0) mad r5, r3.xxxx, c[29+a0], r5.wzyx
/*   50   */     (p0) mad r4, r3.xxxx, c[30+a0], r4.wzyx
/*    3.1 */       exec
/*   51   */          mad r0.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*   52   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   53   */          dp4 r3.x___, r2.zxyw, r0
/*   54   */          dp4 r3._y__, r5.zxyw, r0
/*   55   */          dp4 r3.__z_, r4.zxyw, r0
/*    4.0 */       cjmp !b0, L13
/*    4.1 */       exec
/*   56   */          cndeq r0, c255.zzzx, r3.zxyy, c255.xxxx
/*   57   */          dp4 r7.x___, c0.zxyw, r0
/*   58   */          dp4 r7._y__, c1.zxyw, r0
/*   59   */          dp4 r7.__z_, c2.zxyw, r0
/*   60   */          dp2add r0.x___, r7.xyyy, r7.xyyy, c255.zzzz
/*   61   */          dp3 r0._y__, r7.zxyy, r7.zxyy
/*    5.0 */       exec
/*   62   */          sqrt r0.___w, r_abs[0].y
/*   63   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   64   */          add r0._y__, -r7.zzzz, r0.wwww
/*   65   */          mul r8.xy__, r7.xyyy, r0.wwww
/*   66   */          mul r8.xy__, r8.yxxx, r0.yyyy
              +       rcp r0.x___, r0.x
/*   67   */          mul r0.xy__, r8.yxxx, r0.xxxx
/*    5.1 */       exec
/*   68   */          cndge r0.__zw, r7.zzzz, r0.zzzw, c255.xxxy
/*    6.0 */       jmp L14
                label L13
/*    6.1 */       exec
/*   69   */          cndeq r7, c255.zzzx, r3.zxyy, c255.xxxx
/*   70   */          dp4 r0.x___, c23.zxyw, r7
/*   71   */          dp4 r0._y__, c24.zxyw, r7
/*   72   */          dp4 r0.__z_, c25.zxyw, r7
/*   73   */          dp4 r0.___w, c26.zxyw, r7
                label L14
/*    7.0 */       alloc position
/*    7.1 */       exec
/*   74   */          mad r0.__z_, -r0.wwww, c7.xxxx, r0.zzzz
/*   75   */          max oPos, r0, r0
/*    8.0 */       alloc interpolators
/*    8.1 */       exec
/*   76   */          dp3 r2.x___, r6.zxyy, r2.zxyy
/*   77   */          dp3 r2._y__, r6.zxyy, r5.zxyy
/*   78   */          dp3 r2.__z_, r6.zxyy, r4.zxyy
/*   79   */          add r1.xy__, r1.xyyy, c6.xyyy
              +       maxs r1.__z_, c5.xx
/*   80   */          max o2.xyz_, r3.xyzz, r3.xyzz
/*   81   */          max o1, r1, r1
/*    9.0 */       exece
/*   82   */          max o0, r0, r0
/*   83   */          dp3 r0.x___, r2.zxyy, r2.zxyy
/*   84   */          rsq r0.x___, r_abs[0].x
/*   85   */          mul o3.xyz_, r2.xyzz, r0.xxxx
/*    9.1 */       cnop
