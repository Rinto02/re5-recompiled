/*    0.0 */       exec
/*   20   */          tfetch2D r6.yxzw, r1.xy, tf0
/*   21   */          tfetch2D r1.x___, r4.xy, tf2
/*   22   */          serialize
                      mul r4.xy__, c4.zwww, c3.xyyy
              +       rcp r1._y__, r0.w
/*   23   */          mad r0.xy__, r1.yyyy, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   24   */          mul r1._y__, r6.wwww, r1.xxxx
              +       retain_prev r1._
/*   25   */          mul r0.xy__, r4.xyyy, r0.yxxx
              +       subsc r1.x___, -c1.x, -r1.y
/*    0.1 */       exec
/*   26   */          kill_gt r1._, c255.xxxx, r1.xxxx
              +       retain_prev r1._
/*   27   */          tfetch2D r0, r0.xy, tf1
/*    1.0 */       alloc colors
/*    1.1 */       exec
/*   28   */          dp3 r1.x___, r5.zxyy, r5.zxyy
              +       sgts r7._y__, -r_abs[1].x
/*   29   */          add r4.xyz_, r2.zyxx, -c23.zyxx
              +       sgts r7.__z_, -r_abs[1].x
/*   30   */          dp3 r3.___w, r4.xzyy, r4.xzyy
              +       sgts r7.x___, -r_abs[1].x
/*   31   */          mul r0, r0.wzyx, c5.wzyx
              +       rsq r1.x___, r_abs[1].x
/*   32   */          mul r9.xyz_, r1.xxxx, r5.xyzz
              +       maxs r1.x___, r6.zz
/*   33   */          min r0, r0, c8.xxxx
              +       mulsc r5.__z_, c14.z, r1.x
/*    2.0 */       exec
/*   34   */          max r8, r0.wzyx, c9.xxxx
              +       mulsc r5._y__, c14.y, r6.x
/*   35   */          max r0.xy__, r8.yxxx, r8.wzzz
              +       mulsc r5.x___, c14.x, r6.y
/*   36   */          max r0._y__, r0.yyyy, r0.xxxx
              +       sqrt r0.___w, r_abs[3].w
/*    2.1 */       cjmp !b128, L21
/*    3.0 */       exec
/*   37   */          mul r7, r8.wzyx, c48.wzyx
              +       retain_prev r1._
/*   38   */          add r6.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   39   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   40   */          max4 r0.__z_, r7.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   41   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   42   */          dp3 r4.___w, r9.zxyy, r6.xzyy
              +       retain_prev r1._
/*    3.1 */       exec
/*   43   */          dp3 r2.___w, r6.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   44   */          add r1.x___, r6.wwww, -c32.wwww
              +       retain_prev r1._
/*   45   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   46   */          max r4.___w, r4.wwww, c255.xxxx
              +       mulsc r2.___w, c35.y, r2.w
/*   47   */          max r2.___w, r2.wwww, c35.wwww
              +       subsc r5.___w, c255.y, r0.x
/*   48   */          min r6.x___, r2.wwww, c255.yyyy
              +       subsc r2.___w, c255.y, r0.z
/*    4.0 */       exec
/*   49   */          mul r6._y__, r5.wwww, r6.xxxx
              +       retain_prev r1._
/*   50   */          mul r6._yzw, r6.xxyy, c32.xxzy
              +       retain_prev r1._
/*   51   */          mul r6.x___, r6.yyyy, r5.wwww
              +       retain_prev r1._
/*   52   */          mul r6.xyz_, r6.xzww, r4.wwww
              +       retain_prev r1._
/*   53   */          mul r6.xyz_, r6.xzyy, r2.wwww
              +       retain_prev r1._
/*   54   */          mul r7.xyz_, r6.xzyy, c35.zzzz
              +       retain_prev r1._
/*    4.1 */       cjmp !b129, L21
/*    5.0 */       exec
/*   55   */          mul r10, r8.wzyx, c49.wzyx
              +       retain_prev r1._
/*   56   */          add r6.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   57   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*   58   */          max4 r0.x___, r10.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   59   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   60   */          dp3 r4.___w, r9.zxyy, r6.zxyy
              +       retain_prev r1._
/*    5.1 */       exec
/*   61   */          dp3 r2.___w, r6.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   62   */          add r1.x___, r6.wwww, -c36.wwww
              +       retain_prev r1._
/*   63   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   64   */          max r4.___w, r4.wwww, c255.xxxx
              +       mulsc r2.___w, c39.y, r2.w
/*   65   */          max r5.___w, r2.wwww, c39.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   66   */          min r6.x___, r5.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*    6.0 */       exec
/*   67   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*   68   */          mul r6.xy_w, r6.yyxx, c36.zyxx
              +       retain_prev r1._
/*   69   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*   70   */          mul r6.xyz_, r6.xyzz, r4.wwww
              +       retain_prev r1._
/*   71   */          mul r6.xyz_, r6.zyxx, r2.wwww
              +       retain_prev r1._
/*   72   */          mad r7.xyz_, r6.xzyy, c39.zzzz, r7.xyzz
              +       retain_prev r1._
/*    6.1 */       cjmp !b130, L21
/*    7.0 */       exec
/*   73   */          mul r10, r8, c50
              +       retain_prev r1._
/*   74   */          add r6.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   75   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   76   */          max4 r0.x___, r10.ywxz
              +       rsq r1.x___, r_abs[6].w
/*   77   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   78   */          dp3 r4.___w, r9.zxyy, r6.xzyy
              +       retain_prev r1._
/*    7.1 */       exec
/*   79   */          dp3 r2.___w, r6.xzyy, -c42.zxyy
              +       retain_prev r1._
/*   80   */          add r1.x___, r6.wwww, -c40.wwww
              +       retain_prev r1._
/*   81   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*   82   */          max r4.___w, r4.wwww, c255.xxxx
              +       mulsc r2.___w, c43.y, r2.w
/*   83   */          max r5.___w, r2.wwww, c43.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   84   */          min r6.x___, r5.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*    8.0 */       exec
/*   85   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*   86   */          mul r6.xy_w, r6.yyxx, c40.zyxx
              +       retain_prev r1._
/*   87   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*   88   */          mul r6.xyz_, r6.xyzz, r4.wwww
              +       retain_prev r1._
/*   89   */          mul r6.xyz_, r6.zyxx, r2.wwww
              +       retain_prev r1._
/*   90   */          mad r7.xyz_, r6.xzyy, c43.zzzz, r7.xyzz
              +       retain_prev r1._
/*    8.1 */       cjmp !b131, L21
/*    9.0 */       exec
/*   91   */          mul r10, r8.wzyx, c51.wzyx
              +       retain_prev r1._
/*   92   */          add r6.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*   93   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*   94   */          max4 r0.x___, r10.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   95   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   96   */          dp3 r4.___w, r9.zxyy, r6.zxyy
              +       retain_prev r1._
/*    9.1 */       exec
/*   97   */          dp3 r2.___w, r6.zxyy, -c46.zxyy
              +       retain_prev r1._
/*   98   */          add r1.x___, r6.wwww, -c44.wwww
              +       retain_prev r1._
/*   99   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  100   */          max r4.___w, r4.wwww, c255.xxxx
              +       mulsc r2.___w, c47.y, r2.w
/*  101   */          max r5.___w, r2.wwww, c47.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  102   */          min r6.x___, r5.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*   10.0 */       exec
/*  103   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*  104   */          mul r6.xy_w, r6.yyxx, c44.zyxx
              +       retain_prev r1._
/*  105   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*  106   */          mul r6.xyz_, r6.xyzz, r4.wwww
              +       retain_prev r1._
/*  107   */          mul r6.xyz_, r6.zyxx, r2.wwww
              +       retain_prev r1._
/*  108   */          mad r7.xyz_, r6.xzyy, c47.zzzz, r7.xyzz
              +       retain_prev r1._
                label L21
/*   10.1 */       cjmp !b132, L33
/*   11.0 */       exec
/*  109   */          add r10.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  110   */          dp3 r10.___w, r10.xzyy, r10.xzyy
              +       retain_prev r1._
/*  111   */          mul r6, r8.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[10].w
/*  112   */          mul r10, r10, r1.xxxx
              +       retain_prev r1._
/*  113   */          add r1.x___, r10.wwww, -c24.wwww
              +       retain_prev r1._
/*  114   */          dp3 r2.___w, r10.xzyy, r9.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   11.1 */       exec
/*  115   */          max4 r0.__z_, r6.zxwy
              +       maxs r10.x___, r2.ww
/*  116   */          add r0.x_z_, -r0.xzzz, c255.yyyy
              +       maxs r10._y__, c255.xx
/*  117   */          mul r6.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r10.xy
/*  118   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  119   */          mad r7.xyz_, r6.zxyy, r0.zzzz, r7.xyzz
              +       retain_prev r1._
/*   12.0 */       cjmp !b133, L33
/*   12.1 */       exec
/*  120   */          add r10.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  121   */          dp3 r10.___w, r10.zxyy, r10.zxyy
              +       retain_prev r1._
/*  122   */          mul r6, r8, c53
              +       rsq r1.x___, r_abs[10].w
/*  123   */          mul r10, r10, r1.xxxx
              +       retain_prev r1._
/*  124   */          add r1.x___, r10.wwww, -c26.wwww
              +       retain_prev r1._
/*  125   */          dp3 r2.___w, r10.zxyy, r9.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   13.0 */       exec
/*  126   */          max4 r0.__z_, r6.ywxz
              +       maxs r10.x___, r2.ww
/*  127   */          add r0.x_z_, -r0.xzzz, c255.yyyy
              +       maxs r10._y__, c255.xx
/*  128   */          mul r6.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r10.xy
/*  129   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  130   */          mad r7.xyz_, r6.zxyy, r0.zzzz, r7.xyzz
              +       retain_prev r1._
/*   13.1 */       cjmp !b134, L33
/*   14.0 */       exec
/*  131   */          add r10.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  132   */          dp3 r10.___w, r10.xzyy, r10.xzyy
              +       retain_prev r1._
/*  133   */          mul r6, r8.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[10].w
/*  134   */          mul r10, r10, r1.xxxx
              +       retain_prev r1._
/*  135   */          add r1.x___, r10.wwww, -c28.wwww
              +       retain_prev r1._
/*  136   */          dp3 r2.___w, r10.xzyy, r9.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   14.1 */       exec
/*  137   */          max4 r0.__z_, r6.zxwy
              +       maxs r10.x___, r2.ww
/*  138   */          add r0.x_z_, -r0.xzzz, c255.yyyy
              +       maxs r10._y__, c255.xx
/*  139   */          mul r6.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r10.xy
/*  140   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  141   */          mad r7.xyz_, r6.zxyy, r0.zzzz, r7.xyzz
              +       retain_prev r1._
/*   15.0 */       cjmp !b135, L33
/*   15.1 */       exec
/*  142   */          add r10.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  143   */          dp3 r10.___w, r10.zxyy, r10.zxyy
              +       retain_prev r1._
/*  144   */          mul r6, r8, c55
              +       rsq r1.x___, r_abs[10].w
/*  145   */          mul r8, r10, r1.xxxx
              +       retain_prev r1._
/*  146   */          add r1.x___, r8.wwww, -c30.wwww
              +       retain_prev r1._
/*  147   */          dp3 r2.___w, r8.zxyy, r9.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   16.0 */       exec
/*  148   */          max4 r0.__z_, r6.ywxz
              +       maxs r8.x___, r2.ww
/*  149   */          add r0.x_z_, -r0.xzzz, c255.yyyy
              +       maxs r8._y__, c255.xx
/*  150   */          mul r6.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r8.xy
/*  151   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  152   */          mad r7.xyz_, r6.zxyy, r0.zzzz, r7.xyzz
              +       retain_prev r1._
                label L33
/*   16.1 */       exec
/*  153   */          mul r3.xyz_, r3.zxyy, c56.zxyy
              +       subsc r1.x___, -c255.y, -r1.w
/*  154   */          mad r1.x___, r1.xxxx, c15.wwww, c255.yyyy
              +       retain_prev r1._
/*  155   */          mul r3.xyz_, r3.xzyy, r1.xxxx
              +       mulsc r1.x___, c6.x, r0.y
/*  156   */          add r0.xyz_, -r3.xyzz, c7.zyxx
              +       maxs r1._, r1.yy
/*  157   */          mad r0.xyz_, r1.xxxx, r0.zyxx, r3.zyxx
              +       retain_prev r1._
/*  158   */          mad r1.xy_w, r7.xyzz, r1.wwww, r0.xzyy
              +       retain_prev r1._
/*   17.0 */       exec
/*  159   */          mul r0.xyz_, r5.xyzz, r1.xwyy
              +       muls_prev r1.___w, r1.z
/*   17.1 */       cjmp !b136, L39
/*   18.0 */       exec
/*  160   */          mad r2.___w, r0.wwww, c13.yyyy, c13.zzzz
              +       retain_prev r1._
/*  161   */          add r1.x___, r0.wwww, -c10.xxxx
              +       rsq r1._y__, r_abs[3].w
/*  162   */          mul r3.xyz_, r4.xyzz, r1.yyyy
              +       retain_prev r1._
/*  163   */          cndeq r4, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  164   */          dp4 r1._y__, c11.zxyw, r4
              +       retain_prev r1._
/*  165   */          dp3 r1.__z_, r3.xzyy, c11.zxyy
              +       retain_prev r1._
/*   18.1 */       exec
/*  166   */          add r2.xyz_, -r0.xyzz, c12.xyzz
              +       mulsc r0.___w, c10.z, r1.x
/*  167   */          min r3.xy__, r1.yzzz, c255.xzzz
              +       mulsc r1.x___, c10.w, r1.y
/*  168   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  169   */          max r1._, r1, r1
              +       mulsc r1.x___, c13.x, r1.y
/*  170   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  171   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*   19.0 */       exec
/*  172   */          min r1.x___, r1.xxxx, c12.wwww
              +       retain_prev r1._
/*  173   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*  174   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L39
/*   19.1 */       exece
/*  175   */          mul r1.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  176   */          max oC0, r1, r1
