/*    0.0 */       exec
/*    5   */          max r1.__z_, c53.wwww, c53.wwww
              +       rcp r0.__z_, c54.x
/*    6   */          tfetch2D r1.__x_, r1.zy, tf1, FetchValidOnly=false
/*    7   */          serialize
                      add r1.___w, r0.yyyy, c53.yyyy
              +       rcp r0.___w, c54.y
/*    8   */          mad r1.__z_, r1.zzzz, c251.wwww, c253.wwww
/*    9   */          mad r1.__z_, r1.zzzz, c53.xxxx, r0.xxxx
/*   10   */          mul r0.xy__, r1.zwww, r0.zwww
/*    0.1 */       exec
/*   11   */          frc r0.xy__, r0.xyyy
/*   12   */          mul r0.__zw, r0.xxxy, c54.xxxy
/*   13   */          sge r1.__zw, r0.zzzw, c254.wwww
/*   14   */          sge r0.xy__, c254.zzzz, r0.zwww
/*   15   */          mul r2.x___, r1.zzzz, r0.xxxx
/*   16   */          snes r1.__z_, r2.x
/*    1.0 */       exec    // PredicateClean=false
/*   17   */          mul r1.__z_, r1.wwww, r1.zzzz
/*   18   */          snes r0.x___, r1.z
/*   19   */          mul r1.__z_, r0.yyyy, r0.xxxx
/*   20   */          add r0.xy__, c49.xyyy, -c48.xyyy
              +       setp_ne r0._, r1.z
/*    1.1 */  (p0) exec
/*   21   */     (p0) mad r0.xy__, r0.zwww, r0.xyyy, c48.xyyy
/*   22   */     (p0) tfetch2D r0.xyz_, r0.xy, tf0
/*   23   */          serialize
                      max r0._, c0, c0
/*    2.0 */       exec
/*   24   */    (!p0) max r0.xyz_, c55.xyzz, c55.xyzz
/*   25   */          rcp r0.___w, c52.x
/*   26   */          mul r1.__zw, r0.wwww, r1.xxxy
/*   27   */          mad r2, r1.xxyy, c50.zwwz, c51.xxyy
/*   28   */          tfetch2D r2.x___, r2.xw, tf1
/*   29   */          tfetch2D r2._yz_, r2.yz, tf1
/*    2.1 */       exec
/*   30   */          tfetch2D r0.___x, r1.zw, tf2
/*    3.0 */       alloc colors
/*    3.1 */       exec
/*   31   */          dp3 r1.x___, r0.zxyy, c252.xyzz
/*   32   */          dp3 r1._y__, r0.zxyy, c251.xyzz
              +       maxs r0._, c53.zz
/*   33   */          dp3 r1.__z_, r0.zxyy, c253.xyzz
              +       adds_prev r0.__z_, c254.z
/*   34   */          add r0.x___, -r0.wwww, c254.zzzz
              +       mulsc r0._y__, c50.x, r0.z
/*   35   */          mad r0.x___, -r0.xxxx, c52.yyyy, c254.zzzz
/*   36   */          add r2.xyz_, r2.xzyy, c252.wwww
              +       mulsc r0.___w, c50.y, r0.z
/*    4.0 */       exece
/*   37   */          mad r1.xyz_, r0.ywww, r2.xyzz, r1.zxyy
/*   38   */          mad r0.__zw, r1.yyyz, c255.xxxy, r1.xxxx
/*   39   */          dp3 r0._y__, r1.yzxx, c254.xyzz
/*   40   */          mul oC0.xyz1, r0.zyww, r0.xxxx
/*    4.1 */       cnop
