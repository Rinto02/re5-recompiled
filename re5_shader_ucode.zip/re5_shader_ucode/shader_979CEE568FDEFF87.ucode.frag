/*    0.0 */       exec
/*    3   */          tfetch2D r4.xyz_, r0.xy, tf0
/*    4   */          tfetch2D r3.xyz_, r1.zw, tf0
/*    5   */          tfetch2D r0.zxy_, r0.zw, tf0
/*    6   */          tfetch2D r1.xyz_, r1.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exec
/*    7   */          mul r2.xyz_, r1.xyzz, c255.xyzz
/*    8   */          mul r3.xyz_, r3.xyzz, c255.xyzz
              +       mulsc r1._y__, c255.x, r0.y
/*    9   */          mul r4.xyz_, r4.xyzz, c255.xyzz
              +       mulsc r1.__z_, c255.y, r0.z
/*   10   */          dp3 r1.x___, r4.zxyy, c0.xxxx
              +       mulsc r1.___w, c255.z, r0.x
/*   11   */          dp3 r1._y__, r1.wyzz, c0.xxxx
/*   12   */          dp3 r1.__z_, r3.zxyy, c0.xxxx
/*    1.1 */       exec
/*   13   */          dp3 r1.___w, r2.zxyy, c0.xxxx
/*   14   */          add r0, r1.xywz, c253.xxxx
/*   15   */          log r0.x___, r_abs[0].x
/*   16   */          log r0._y__, r_abs[0].y
/*   17   */          log r0.__z_, r_abs[0].z
/*   18   */          log r0.___w, r_abs[0].w
/*    2.0 */       exec
/*   19   */          dp4 r0.x___, r0.wzxy, c253.yyyy
/*   20   */          mulsc r0.x___, c254.z, r0.x
/*   21   */          sgt r0._y__, r0.xxxx, -r0.xxxx
              +       maxs r0._, r_abs[0].xx
/*   22   */          sgt r0.x___, -r0.xxxx, r0.xxxx
              +       muls_prev r0.___w, c255.w
/*   23   */          add r0.x___, r0.yyyy, -r0.xxxx
              +       frcs r0._y__, r0.w
/*   24   */          mulsc r0.__z_, c255.w, r0.y
/*    2.1 */       exece
/*   25   */          floor r1.xy__, r0.zwww
              +       addsc r1.__z_, c254.w, r0.x
/*   26   */          mul oC0.x_zw, r1.xyyz, c254.xxxy
              +       frcs oC0._y__, r0.z
