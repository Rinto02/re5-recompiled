/*    0.0 */       exec
/*   25   */          tfetch2D r5, r1.xy, tf0
/*   26   */          serialize
                      max r1._, r1, r1
              +       rcp r2.___w, r0.w
/*   27   */          mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r5.ww
/*   28   */          mad r0.xy__, r2.wwww, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   29   */          mul r0.xy__, r3.zwww, r0.yxxx
              +       subsc r2.___w, -c1.x, -r1.y
/*   30   */          kill_gt r1._, c254.xxxx, r2.wwww
              +       retain_prev r1._
/*    0.1 */       exec
/*   31   */          tfetch2D r8.xyz_, r3.xy, tf1
/*   32   */          tfetch2D r0, r0.xy, tf3
/*   33   */          serialize
                      sgt r9.xyz_, -r_abs[1].xxxx, c254.xxxx
              +       maxs r3.x___, c15.xx
/*   34   */          add r3._yzw, r2.xxyz, -c23.xxyz
              +       sgts r7._y__, -r_abs[1].x
/*   35   */          dp3 r2.___w, r4.zxyy, r4.zxyy
              +       sgts r7.__z_, -r_abs[1].x
/*   36   */          mul r13.xyz_, r5.xyzz, c13.xyzz
              +       sgts r7.x___, -r_abs[1].x
/*    1.0 */       exec
/*   37   */          mul r6, r0.wzyx, c5.wzyx
              +       rsq r2.___w, r_abs[2].w
/*   38   */          dp3 r0.x___, r3.wyzz, r3.wyzz
              +       mulsc r14.__z_, c16.x, r2.w
/*   39   */          mul r11.xyz_, r2.wwww, c18.xyzz
              +       mulsc r14._y__, c16.y, r2.w
/*   40   */          mul r5.xyz_, r2.wwww, r4.zyxx
              +       mulsc r14.x___, c16.z, r2.w
/*   41   */          min r12, r6, c7.xxxx
              +       rsq r0._y__, r_abs[0].x
/*   42   */          mul r6.xyz_, r3.wzyy, r0.yyyy
              +       mulsc r10.__z_, c17.z, r2.w
/*    1.1 */       exec
/*   43   */          max r12, r12.wzyx, c8.xxxx
              +       mulsc r10._y__, c17.y, r2.w
/*   44   */          max r0._yz_, r12.yyxx, r12.wwzz
              +       mulsc r10.x___, c17.x, r2.w
/*   45   */          max r3.__z_, r0.zzzz, r0.yyyy
              +       sqrt r3._y__, r_abs[0].x
/*    2.0 */       cjmp !b128, L24
/*    2.1 */       exec
/*   46   */          mul r0, r12.wzyx, c48.wzyx
              +       retain_prev r1._
/*   47   */          add r7.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   48   */          dp3 r7.___w, r7.xzyy, r7.xzyy
              +       retain_prev r1._
/*   49   */          max4 r0.__z_, r0.zxwy
              +       rsq r1.x___, r_abs[7].w
/*   50   */          mul r9, r7, r1.xxxx
              +       retain_prev r1._
/*   51   */          dp3 r7.__z_, r5.xzyy, r9.xzyy
              +       retain_prev r1._
/*    3.0 */       exec
/*   52   */          add r7.xy_w, r9.zyxx, -r6.zyxx
              +       retain_prev r1._
/*   53   */          dp3 r2.___w, r9.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   54   */          add r1.x___, r9.wwww, -c32.wwww
              +       retain_prev r1._
/*   55   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   56   */          dp3 r0._y__, r7.wxyy, r7.wxyy
              +       mulsc r1.x___, c35.y, r2.w
/*   57   */          max r1.x___, r1.xxxx, c35.wwww
              +       rsq r2.___w, r_abs[0].y
/*    3.1 */       exec
/*   58   */          mul r9.xyz_, r7.wyxx, r2.wwww
              +       subsc r0.___w, c254.y, r0.x
/*   59   */          min r7.x___, r1.xxxx, c254.yyyy
              +       subsc r2.___w, c254.y, r0.z
/*   60   */          dp3 r7._y__, r5.xzyy, r9.xzyy
              +       maxs r1._, r0.ww
/*   61   */          max r0._yz_, r7.zzyy, c254.xxxx
              +       muls_prev r7._y__, r7.x
/*   62   */          mul r7._yzw, r7.xxyy, c32.xxzy
              +       log r1.x___, r_abs[0].z
/*   63   */          max r1._, r1, r1
              +       mulsc r0.x___, c14.z, r1.x
/*    4.0 */       exec
/*   64   */          mul r7.x___, r7.yyyy, r0.wwww
              +       exp r0.x___, r0.x
/*   65   */          mul r9.xy__, r7.zwww, r0.xxxx
              +       retain_prev r1._
/*   66   */          mul r9.xy__, r9.xyyy, r2.wwww
              +       retain_prev r1._
/*   67   */          mul r0, r7.xzwx, r0.yyyx
              +       retain_prev r1._
/*   68   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       maxs r1._, r0.ww
/*   69   */          mul r7.xyz_, r0.xzyy, c35.zzzz
              +       muls_prev r9.__z_, r2.w
/*    4.1 */       cjmp !b129, L24
/*    5.0 */       exec
/*   70   */          mul r0, r12.wzyx, c49.wzyx
              +       retain_prev r1._
/*   71   */          add r15.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   72   */          dp3 r15.___w, r15.zxyy, r15.zxyy
              +       retain_prev r1._
/*   73   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[15].w
/*   74   */          mul r16, r15, r1.xxxx
              +       retain_prev r1._
/*   75   */          dp3 r15.__z_, r5.xzyy, r16.zxyy
              +       retain_prev r1._
/*    5.1 */       exec
/*   76   */          add r15.xy_w, r16.xyzz, -r6.zyxx
              +       retain_prev r1._
/*   77   */          dp3 r2.___w, r16.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   78   */          add r1.x___, r16.wwww, -c36.wwww
              +       retain_prev r1._
/*   79   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   80   */          dp3 r0._y__, r15.wxyy, r15.wxyy
              +       mulsc r1.x___, c39.y, r2.w
/*   81   */          max r1.x___, r1.xxxx, c39.wwww
              +       rsq r2.___w, r_abs[0].y
/*    6.0 */       exec
/*   82   */          mul r16.xyz_, r15.wyxx, r2.wwww
              +       subsc r2.___w, c254.y, r0.x
/*   83   */          min r15.x___, r1.xxxx, c254.yyyy
              +       subsc r0._y__, c254.y, r0.z
/*   84   */          dp3 r15._y__, r5.xzyy, r16.xzyy
              +       maxs r1._, r0.yy
/*   85   */          max r0.x__w, r15.zyyy, c254.xxxx
              +       muls_prev r15._y__, r15.x
/*   86   */          mul r15.xy_w, r15.yyxx, c36.zyxx
              +       log r1.x___, r_abs[0].w
/*   87   */          mul r15.__z_, r15.wwww, r0.yyyy
              +       mulsc r0.___w, c14.z, r1.x
/*    6.1 */       exec
/*   88   */          mul r0.xyz_, r15.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*   89   */          mul r15.xyz_, r15.xyzz, r0.wwww
              +       retain_prev r1._
/*   90   */          mad r9.xyz_, r15.xyzz, r2.wwww, r9.xyzz
              +       retain_prev r1._
/*   91   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   92   */          mad r7.xyz_, r0.xzyy, c39.zzzz, r7.xyzz
              +       retain_prev r1._
/*    7.0 */       cjmp !b130, L24
/*    7.1 */       exec
/*   93   */          mul r0, r12, c50
              +       retain_prev r1._
/*   94   */          add r15.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   95   */          dp3 r15.___w, r15.xzyy, r15.xzyy
              +       retain_prev r1._
/*   96   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[15].w
/*   97   */          mul r16, r15, r1.xxxx
              +       retain_prev r1._
/*   98   */          dp3 r15.__z_, r5.xzyy, r16.xzyy
              +       retain_prev r1._
/*    8.0 */       exec
/*   99   */          add r15.xy_w, r16.zyxx, -r6.zyxx
              +       retain_prev r1._
/*  100   */          dp3 r1.x___, r16.xzyy, -c42.zxyy
              +       retain_prev r1._
/*  101   */          add r1._y__, r16.wwww, -c40.wwww
              +       retain_prev r1._
/*  102   */          add r1.x___, r1.xxxx, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.y
/*  103   */          dp3 r2.___w, r15.wxyy, r15.wxyy
              +       mulsc r1.x___, c43.y, r1.x
/*  104   */          max r1.x___, r1.xxxx, c43.wwww
              +       rsq r2.___w, r_abs[2].w
/*    8.1 */       exec
/*  105   */          mul r16.xyz_, r15.xyww, r2.wwww
              +       subsc r2.___w, c254.y, r0.x
/*  106   */          min r15.x___, r1.xxxx, c254.yyyy
              +       subsc r0._y__, c254.y, r0.z
/*  107   */          dp3 r15._y__, r5.xzyy, r16.zxyy
              +       maxs r1._, r0.yy
/*  108   */          max r0.x__w, r15.zyyy, c254.xxxx
              +       muls_prev r15._y__, r15.x
/*  109   */          mul r15.xy_w, r15.yyxx, c40.zyxx
              +       log r1.x___, r_abs[0].w
/*  110   */          mul r15.__z_, r15.wwww, r0.yyyy
              +       mulsc r0.___w, c14.z, r1.x
/*    9.0 */       exec
/*  111   */          mul r0.xyz_, r15.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  112   */          mul r15.xyz_, r15.xyzz, r0.wwww
              +       retain_prev r1._
/*  113   */          mad r9.xyz_, r15.xyzz, r2.wwww, r9.xyzz
              +       retain_prev r1._
/*  114   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  115   */          mad r7.xyz_, r0.xzyy, c43.zzzz, r7.xyzz
              +       retain_prev r1._
/*    9.1 */       cjmp !b131, L24
/*   10.0 */       exec
/*  116   */          mul r0, r12.wzyx, c51.wzyx
              +       retain_prev r1._
/*  117   */          add r15.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*  118   */          dp3 r15.___w, r15.zxyy, r15.zxyy
              +       retain_prev r1._
/*  119   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[15].w
/*  120   */          mul r16, r15, r1.xxxx
              +       retain_prev r1._
/*  121   */          dp3 r15.__z_, r5.xzyy, r16.zxyy
              +       retain_prev r1._
/*   10.1 */       exec
/*  122   */          add r15.xy_w, r16.xyzz, -r6.zyxx
              +       retain_prev r1._
/*  123   */          dp3 r2.___w, r16.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  124   */          add r1.x___, r16.wwww, -c44.wwww
              +       retain_prev r1._
/*  125   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  126   */          dp3 r0._y__, r15.wxyy, r15.wxyy
              +       mulsc r1.x___, c47.y, r2.w
/*  127   */          max r1.x___, r1.xxxx, c47.wwww
              +       rsq r2.___w, r_abs[0].y
/*   11.0 */       exec
/*  128   */          mul r16.xyz_, r15.wyxx, r2.wwww
              +       subsc r2.___w, c254.y, r0.x
/*  129   */          min r15.x___, r1.xxxx, c254.yyyy
              +       subsc r0._y__, c254.y, r0.z
/*  130   */          dp3 r15._y__, r5.xzyy, r16.xzyy
              +       maxs r1._, r0.yy
/*  131   */          max r0.x__w, r15.zyyy, c254.xxxx
              +       muls_prev r15._y__, r15.x
/*  132   */          mul r15.xy_w, r15.yyxx, c44.zyxx
              +       log r1.x___, r_abs[0].w
/*  133   */          mul r15.__z_, r15.wwww, r0.yyyy
              +       mulsc r0.___w, c14.z, r1.x
/*   11.1 */       exec
/*  134   */          mul r0.xyz_, r15.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  135   */          mul r15.xyz_, r15.xyzz, r0.wwww
              +       retain_prev r1._
/*  136   */          mad r9.xyz_, r15.xyzz, r2.wwww, r9.xyzz
              +       retain_prev r1._
/*  137   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  138   */          mad r7.xyz_, r0.xzyy, c47.zzzz, r7.xyzz
              +       retain_prev r1._
                label L24
/*   12.0 */       cjmp !b132, L36
/*   12.1 */       exec
/*  139   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  140   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  141   */          mul r15, r12.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  142   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  143   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  144   */          dp3 r2.___w, r0.xzyy, r5.xzyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   13.0 */       exec
/*  145   */          max4 r0._y__, r15.zxwy
              +       maxs r0.__z_, r2.ww
/*  146   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  147   */          mul r15.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  148   */          mul r15.xyz_, r15.xyzz, r2.wwww
              +       retain_prev r1._
/*  149   */          mad r7.xyz_, r15.zxyy, r0.yyyy, r7.xyzz
              +       retain_prev r1._
/*   13.1 */       cjmp !b133, L36
/*   14.0 */       exec
/*  150   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  151   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  152   */          mul r15, r12, c53
              +       rsq r1.x___, r_abs[0].w
/*  153   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  154   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  155   */          dp3 r2.___w, r0.zxyy, r5.xzyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   14.1 */       exec
/*  156   */          max4 r0._y__, r15.ywxz
              +       maxs r0.__z_, r2.ww
/*  157   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  158   */          mul r15.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  159   */          mul r15.xyz_, r15.xyzz, r2.wwww
              +       retain_prev r1._
/*  160   */          mad r7.xyz_, r15.zxyy, r0.yyyy, r7.xyzz
              +       retain_prev r1._
/*   15.0 */       cjmp !b134, L36
/*   15.1 */       exec
/*  161   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  162   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  163   */          mul r15, r12.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  164   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  165   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  166   */          dp3 r2.___w, r0.xzyy, r5.xzyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   16.0 */       exec
/*  167   */          max4 r0._y__, r15.zxwy
              +       maxs r0.__z_, r2.ww
/*  168   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  169   */          mul r15.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  170   */          mul r15.xyz_, r15.xyzz, r2.wwww
              +       retain_prev r1._
/*  171   */          mad r7.xyz_, r15.zxyy, r0.yyyy, r7.xyzz
              +       retain_prev r1._
/*   16.1 */       cjmp !b135, L36
/*   17.0 */       exec
/*  172   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  173   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  174   */          mul r12, r12, c55
              +       rsq r1.x___, r_abs[0].w
/*  175   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  176   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  177   */          dp3 r2.___w, r0.zxyy, r5.xzyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   17.1 */       exec
/*  178   */          max4 r0._y__, r12.ywxz
              +       maxs r0.__z_, r2.ww
/*  179   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  180   */          mul r12.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  181   */          mul r12.xyz_, r12.xyzz, r2.wwww
              +       retain_prev r1._
/*  182   */          mad r7.xyz_, r12.zxyy, r0.yyyy, r7.xyzz
              +       retain_prev r1._
                label L36
/*   18.0 */       exec
/*  183   */          mul r12, r5.zyxx, r5.yxxz
              +       retain_prev r1._
/*  184   */          dp3 r1._y__, r11.zxyy, r4.zxyy
              +       retain_prev r1._
/*  185   */          dp3 r0.x___, r10.zxyy, r4.zxyy
              +       retain_prev r1._
/*  186   */          mul r0._yz_, r5.zzyy, r5.zzyy
              +       retain_prev r1._
/*  187   */          dp3 r1.x___, r14.xzyy, r4.zxyy
              +       subs r2.___w, r0.yz
/*  188   */          dp4 r0._y__, r12.wzxy, c19.wzxy
              +       addsc r4.x___, c16.w, r1.x
/*   18.1 */       exec    // PredicateClean=false
/*  189   */          dp4 r0.__z_, r12.wzxy, c20.wzxy
              +       addsc r4._y__, c17.w, r0.x
/*  190   */          dp4 r0.___w, r12.wzxy, c21.wzxy
              +       addsc r4.__z_, c18.w, r1.y
/*  191   */          add r0.xyz_, r4.zxyy, r0.wyzz
              +       setp_gt r1._, c_abs[56].x
/*  192   */          mad r0.xyz_, r2.wwww, c22.xyzz, r0.yzxx
              +       retain_prev r1._
/*  193   */          mad r4.xyz_, r7.xzyy, r1.wwww, r0.xyzz
              +       retain_prev r1._
/*   19.0 */  (p0) exec
/*  194   */     (p0) mul r7.xyz_, r4.zyxx, c59.xxxx
              +  (p0) retain_prev r1._
/*  195   */     (p0) mul r0.xyz_, r4.zyxx, c60.xxxx
              +  (p0) retain_prev r1._
/*  196   */     (p0) mul r0.xyz_, r0.xyzz, c58.xxxx
              +  (p0) retain_prev r1._
/*  197   */     (p0) mad r4.xyz_, r7.zyxx, c57.xxxx, r0.zyxx
              +  (p0) retain_prev r1._
/*   19.1 */       exec
/*  198   */          dp3 r10._y__, r6.xzyy, r5.xzyy
              +       retain_prev r1._
/*  199   */          max r1._, r1, r1
              +       adds r1.x___, r10.yy
/*  200   */          mad r0.xyz_, -r5.xyzz, r1.xxxx, r6.xyzz
              +       retain_prev r1._
/*  201   */          cube r0, r0.xxzy, r0.yzxx
              +       retain_prev r1._
/*  202   */          max r7.__z_, r0.wwww, r0.wwww
              +       rcp r1.x___, r_abs[0].z
/*  203   */          mad r7.xy__, r0.yxxx, r1.xxxx, c254.wwww
              +       retain_prev r1._
/*   20.0 */       exec
/*  204   */          setTexLOD r3.x
/*  205   */          tfetchCube r7, r7.xyz, tf2, UseComputedLOD=false, UseRegisterLOD=true
/*   20.1 */       alloc colors
/*   21.0 */       exec
/*  206   */          max r1.x___, r7.wwww, c255.xxxx
              +       mulsc r10.x___, c6.x, r3.z
/*  207   */          add r0.xy__, -r10.xyyy, c254.yyyy
              +       rcp r1.x___, r1.x
/*  208   */          mul r3.x_zw, r1.xxxx, r7.xyyz
              +       retain_prev r1._
/*  209   */          mul r7.xyz_, r3.wzxx, r0.xxxx
              +       muls r1.x___, r_abs[0].yy
/*  210   */          max r1._, r1, r1
              +       muls r1.x___, r1.xx
/*  211   */          mul r7.___w, r1.xxxx, r_abs[0].yyyy
              +       retain_prev r1._
/*   21.1 */       exec    // PredicateClean=false
/*  212   */          mad r0.xyz_, r7.zyxx, c14.wwww, r9.zyxx
              +       retain_prev r1._
/*  213   */          mad_sat r1.x___, r7.wwww, c14.xxxx, c14.yyyy
              +       retain_prev r1._
/*  214   */          max r1._, r1, r1
              +       subsc r1.x___, c254.y, r1.x
/*  215   */          mul r1.x___, r1.xxxx, r1.wwww
              +       setp_ne r1._, c56.x
/*  216   */     (p0) mul r0.xyz_, r0.xyzz, c61.xxxx
              +  (p0) retain_prev r1._
/*  217   */          mul r1.xy_w, r1.xxxx, r8.xyzz
              +       maxs r1._, r5.ww
/*   22.0 */       exec
/*  218   */          mul r0.xyz_, r1.xyww, r0.xyzz
              +       muls_prev r1.___w, r1.z
/*  219   */          mad r0.xyz_, r13.xyzz, r4.xyzz, r0.xyzz
              +       retain_prev r1._
/*   22.1 */       cjmp !b136, L49
/*   23.0 */       exec
/*  220   */          mad r2.___w, r3.yyyy, c12.yyyy, c12.zzzz
              +       retain_prev r1._
/*  221   */          dp3 r1.__z_, r6.xzyy, c10.zxyy
              +       retain_prev r1._
/*  222   */          cndeq r4, c254.xxxy, r2.zxyy, c254.yyyy
              +       retain_prev r1._
/*  223   */          dp4 r1._y__, c10.zxyw, r4
              +       subsc r1.x___, -c9.x, -r3.y
/*  224   */          add r2.xyz_, -r0.xyzz, c11.xyzz
              +       mulsc r0.___w, c9.z, r1.x
/*  225   */          min r3.xy__, r1.yzzz, c254.xzzz
              +       mulsc r1.x___, c9.w, r1.y
/*   23.1 */       exec
/*  226   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  227   */          max r1._, r1, r1
              +       mulsc r1.x___, c12.x, r1.y
/*  228   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  229   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  230   */          min r1.x___, r1.xxxx, c11.wwww
              +       retain_prev r1._
/*  231   */          max r1.x___, r1.xxxx, c254.xxxx
              +       retain_prev r1._
/*   24.0 */       exec
/*  232   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L49
/*   24.1 */       exece
/*  233   */          mul r1.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  234   */          max oC0, r1, r1
