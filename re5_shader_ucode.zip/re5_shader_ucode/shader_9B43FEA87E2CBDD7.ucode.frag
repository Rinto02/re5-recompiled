/*    0.0 */       exec
/*   31   */          tfetch2D r7.yxzw, r1.xy, tf0
/*   32   */          serialize
                      mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r7.ww
/*   33   */          sgt r9.xyz_, -r_abs[1].xxxx, c254.xxxx
              +       rcp r1.x___, r0.w
/*   34   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   35   */          mul r0.__zw, r3.zzzw, r0.yyyx
              +       subsc r1.x___, -c1.x, -r1.y
/*   36   */          kill_gt r1._, c254.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   37   */          tfetch2D r10.xyz_, r3.xy, tf6
/*   38   */          tfetch2D r0.xy__, r3.xy, tf5
/*   39   */          tfetch2D r8, r0.zw, tf8
/*   40   */          serialize
                      sgt r12.xyz_, -r_abs[1].xxxx, c254.xxxx
              +       maxs r3.___w, c15.xx
/*   41   */          add r3.xyz_, r2.xyzz, -c23.xyzz
              +       maxs r1.x___, r7.zz
/*   42   */          mul r8, r8.wzyx, c5.wzyx
              +       mulsc r7.__z_, c13.z, r1.x
/*    1.0 */       exec
/*   43   */          dp3 r2.___w, r3.zxyy, r3.zxyy
              +       mulsc r7.x___, c13.y, r7.x
/*   44   */          mad r0.x__w, r0.yxxx, c255.xxxx, c253.yyyy
              +       retain_prev r1._
/*   45   */          dp2add r0._y__, -r0.xwww, r0.xwww, c254.yyyy
              +       retain_prev r1._
/*   46   */          min r8, r8, c7.xxxx
              +       rsq r0.__z_, r_abs[2].w
/*   47   */          mul r11.xyz_, r3.zyxx, r0.zzzz
              +       mulsc r7._y__, c13.x, r7.y
/*   48   */          max r8, r8.wzyx, c8.xxxx
              +       sqrt r0._y__, r_abs[0].y
/*    1.1 */       exec
/*   49   */          mul r6.xyz_, r0.yyyy, r6.xyzz
              +       maxs r3.x___, r8.yw
/*   50   */          mad r0.xyz_, r0.xxxx, r5.zyxx, r6.zyxx
              +       retain_prev r1._
/*   51   */          mad r0._yzw, r0.wwww, r4.xxzy, r0.zzxy
              +       retain_prev r1._
/*   52   */          dp3 r0.x___, r0.zyww, r0.zyww
              +       maxs r3._y__, r8.xz
/*   53   */          max r3.__z_, r3.yyyy, r3.xxxx
              +       rsq r0.x___, r_abs[0].x
/*   54   */          mul r4.xyz_, r0.ywzz, r0.xxxx
              +       sqrt r3._y__, r_abs[2].w
/*    2.0 */       cjmp !b128, L36
/*    2.1 */       exec
/*   55   */          sgt r4.___w, c62.zzzz, c254.wwww
              +       retain_prev r1._
/*   56   */          add r0._yzw, -r2.zzyx, c33.zzyx
              +       retain_prev r1._
/*   57   */          mul r5, r8.wzyx, c48.wzyx
              +       retain_prev r1._
/*   58   */          dp3 r1._y__, r0.ywzz, r0.ywzz
              +       retain_prev r1._
/*   59   */          max4 r1.x___, r5.zxwy
              +       retain_prev r1._
/*   60   */          add r0.x___, -r1.xxxx, c254.yyyy
              +       rsq r1.x___, r_abs[1].y
/*    3.0 */       exec
/*   61   */          mul r5.xyz_, r0.yzww, r1.xxxx
              +       retain_prev r1._
/*   62   */          dp3 r0.__z_, r4.zxyy, r5.xzyy
              +       retain_prev r1._
/*   63   */          dp3 r3.x___, r5.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   64   */          add r5.xyz_, r5.zyxx, -r11.zyxx
              +       retain_prev r1._
/*   65   */          dp3 r2.___w, r5.zxyy, r5.zxyy
              +       maxs r1._, r1.yy
/*   66   */          add r1._y__, r3.xxxx, -c35.xxxx
              +       muls_prev r1.x___, r1.x
/*    3.1 */       exec
/*   67   */          mul r0._y__, r1.yyyy, c35.yyyy
              +       subsc r1._y__, -c32.w, -r1.x
/*   68   */          max r0._y__, r0.yyyy, c35.wwww
              +       rsq r2.___w, r_abs[2].w
/*   69   */          mul r5._yzw, r5.zzyx, r2.wwww
              +       mulsc_sat r2.___w, c33.w, r1.y
/*   70   */          min r5.x___, r0.yyyy, c254.yyyy
              +       subsc r2.___w, c254.y, r2.w
/*   71   */          dp3 r0._y__, r4.zxyy, r5.ywzz
              +       maxs r1._, r2.ww
/*   72   */          max r0._yz_, r0.yyzz, c254.xxxx
              +       muls_prev r5._y__, r5.x
/*    4.0 */       exec    // PredicateClean=false
/*   73   */          mul r5.xyz_, r5.xyyy, c32.xzyy
              +       log r1._y__, r_abs[0].y
/*   74   */          mul r5.___w, r5.xxxx, r2.wwww
              +       mulsc r2.___w, c14.z, r1.y
/*   75   */          mul r0._yzw, r5.yyzw, r0.zzzz
              +       exp r2.___w, r2.w
/*   76   */          mul r5.xyz_, r5.wzyy, r2.wwww
              +       setp_ne r1._, r4.w
/*    4.1 */  (p0) exec
/*   77   */     (p0) max r1._, r1, r1
              +  (p0) maxs r9.___w, c254.yy
/*   78   */     (p0) mul r6.xyz_, r1.xxxx, c34.xyzz
              +  (p0) rcp r1._y__, c62.z
/*   79   */     (p0) mad r6.xyz_, r6.xyzz, r3.xxxx, c33.xyzz
              +  (p0) retain_prev r1._
/*   80   */     (p0) add r9.xyz_, -r6.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*   81   */     (p0) dp4 r6.x___, c66.zxyw, r9.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*   82   */     (p0) dp4 r6._y__, c67.zxyw, r9.zxyw
              +  (p0) mulsc r1.x___, c62.w, r1.x
/*    5.0 */  (p0) exec
/*   83   */     (p0) mul r6.xy__, r6.xyyy, c253.xxxx
              +  (p0) rcp r1.x___, r1.x
/*   84   */     (p0) mul r1.xy__, r6.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*   85   */     (p0) add r6.x___, r1.xxxx, c253.xxxx
              +  (p0) subsc r6._y__, c253.x, r1.y
/*   86   */     (p0) tfetch2D r6.xyz_, r6.xy, tf1
/*   87   */          serialize
                 (p0) mul r0._yzw, r0.yyzw, r6.zzyx
              +  (p0) retain_prev r1._
/*   88   */     (p0) mul r5.xyz_, r5.xyzz, r6.xyzz
              +  (p0) retain_prev r1._
/*    5.1 */       exec
/*   89   */          max r1._, r1, r1
              +       mulsc r2.___w, c35.z, r0.x
/*   90   */          mul r12.xyz_, r2.wwww, r0.wyzz
              +       retain_prev r1._
/*   91   */          mul r9.xyz_, r0.xxxx, r5.zyxx
              +       retain_prev r1._
/*    6.0 */       cjmp !b129, L36
/*    6.1 */       exec
/*   92   */          sgt r0.__z_, c63.zzzz, c254.wwww
              +       retain_prev r1._
/*   93   */          add r5.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   94   */          mul r6, r8, c49
              +       retain_prev r1._
/*   95   */          dp3 r1._y__, r5.zxyy, r5.zxyy
              +       retain_prev r1._
/*   96   */          max4 r1.x___, r6.ywxz
              +       retain_prev r1._
/*   97   */          add r0.x___, -r1.xxxx, c254.yyyy
              +       rsq r1.x___, r_abs[1].y
/*    7.0 */       exec
/*   98   */          mul r5.xy_w, r5.xyzz, r1.xxxx
              +       retain_prev r1._
/*   99   */          dp3 r5.__z_, r4.zxyy, r5.wxyy
              +       retain_prev r1._
/*  100   */          dp3 r0._y__, r5.wxyy, -c38.zxyy
              +       retain_prev r1._
/*  101   */          add r5.xy_w, r5.xyww, -r11.zyxx
              +       retain_prev r1._
/*  102   */          dp3 r2.___w, r5.wxyy, r5.wxyy
              +       maxs r1._, r1.yy
/*  103   */          add r1._y__, r0.yyyy, -c39.xxxx
              +       muls_prev r1.x___, r1.x
/*    7.1 */       exec
/*  104   */          mul r0.___w, r1.yyyy, c39.yyyy
              +       subsc r1._y__, -c36.w, -r1.x
/*  105   */          max r0.___w, r0.wwww, c39.wwww
              +       rsq r2.___w, r_abs[2].w
/*  106   */          mul r6.xyz_, r5.xyww, r2.wwww
              +       mulsc_sat r2.___w, c37.w, r1.y
/*  107   */          min r5.x___, r0.wwww, c254.yyyy
              +       subsc r2.___w, c254.y, r2.w
/*  108   */          dp3 r5._y__, r4.zxyy, r6.zxyy
              +       maxs r1._, r2.ww
/*  109   */          max r6.xy__, r5.yzzz, c254.xxxx
              +       muls_prev r5._y__, r5.x
/*    8.0 */       exec    // PredicateClean=false
/*  110   */          mul r5.xyz_, r5.xyyy, c36.xzyy
              +       log r1._y__, r_abs[6].x
/*  111   */          mul r5.___w, r5.xxxx, r2.wwww
              +       mulsc r2.___w, c14.z, r1.y
/*  112   */          mul r6.xyz_, r5.yzww, r6.yyyy
              +       exp r2.___w, r2.w
/*  113   */          mul r5.xyz_, r5.wzyy, r2.wwww
              +       setp_ne r1._, r0.z
/*    8.1 */  (p0) exec
/*  114   */     (p0) max r1._, r1, r1
              +  (p0) maxs r13.___w, c254.yy
/*  115   */     (p0) mul r13.xyz_, r1.xxxx, c38.xyzz
              +  (p0) rcp r1._y__, c63.z
/*  116   */     (p0) mad r0._yzw, r13.xxyz, r0.yyyy, c37.xxyz
              +  (p0) retain_prev r1._
/*  117   */     (p0) add r13.xyz_, -r0.yzww, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  118   */     (p0) dp4 r0._y__, c68.zxyw, r13.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  119   */     (p0) dp4 r0.__z_, c69.zxyw, r13.zxyw
              +  (p0) mulsc r1.x___, c63.w, r1.x
/*    9.0 */  (p0) exec
/*  120   */     (p0) mul r0._yz_, r0.yyzz, c253.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  121   */     (p0) mul r1.xy__, r0.yzzz, r1.xxxx
              +  (p0) retain_prev r1._
/*  122   */     (p0) add r0._y__, r1.xxxx, c253.xxxx
              +  (p0) subsc r0.__z_, c253.x, r1.y
/*  123   */     (p0) tfetch2D r0._xyz, r0.yz, tf2
/*  124   */          serialize
                 (p0) mul r6.xyz_, r6.xyzz, r0.wzyy
              +  (p0) retain_prev r1._
/*  125   */     (p0) mul r5.xyz_, r5.xyzz, r0.yzww
              +  (p0) retain_prev r1._
/*    9.1 */       exec
/*  126   */          max r1._, r1, r1
              +       mulsc r2.___w, c39.z, r0.x
/*  127   */          mad r12.xyz_, r2.wwww, r6.zxyy, r12.xyzz
              +       retain_prev r1._
/*  128   */          mad r9.xyz_, r0.xxxx, r5.zyxx, r9.xyzz
              +       retain_prev r1._
/*   10.0 */       cjmp !b130, L36
/*   10.1 */       exec
/*  129   */          sgt r4.___w, c64.zzzz, c254.wwww
              +       retain_prev r1._
/*  130   */          add r0._yzw, -r2.xxyz, c41.xxyz
              +       retain_prev r1._
/*  131   */          mul r5, r8, c50
              +       retain_prev r1._
/*  132   */          dp3 r1._y__, r0.wyzz, r0.wyzz
              +       retain_prev r1._
/*  133   */          max4 r1.x___, r5.ywxz
              +       retain_prev r1._
/*  134   */          add r0.x___, -r1.xxxx, c254.yyyy
              +       rsq r1.x___, r_abs[1].y
/*   11.0 */       exec
/*  135   */          mul r5.xyz_, r0.yzww, r1.xxxx
              +       retain_prev r1._
/*  136   */          dp3 r0.__z_, r4.zxyy, r5.zxyy
              +       retain_prev r1._
/*  137   */          dp3 r3.x___, r5.zxyy, -c42.zxyy
              +       retain_prev r1._
/*  138   */          add r5.xyz_, r5.xyzz, -r11.zyxx
              +       retain_prev r1._
/*  139   */          dp3 r2.___w, r5.zxyy, r5.zxyy
              +       maxs r1._, r1.yy
/*  140   */          add r1._y__, r3.xxxx, -c43.xxxx
              +       muls_prev r1.x___, r1.x
/*   11.1 */       exec
/*  141   */          mul r0._y__, r1.yyyy, c43.yyyy
              +       subsc r1._y__, -c40.w, -r1.x
/*  142   */          max r0._y__, r0.yyyy, c43.wwww
              +       rsq r2.___w, r_abs[2].w
/*  143   */          mul r5._yzw, r5.xxyz, r2.wwww
              +       mulsc_sat r2.___w, c41.w, r1.y
/*  144   */          min r5.x___, r0.yyyy, c254.yyyy
              +       subsc r2.___w, c254.y, r2.w
/*  145   */          dp3 r0._y__, r4.zxyy, r5.wyzz
              +       maxs r1._, r2.ww
/*  146   */          max r0._yz_, r0.yyzz, c254.xxxx
              +       muls_prev r5._y__, r5.x
/*   12.0 */       exec    // PredicateClean=false
/*  147   */          mul r5.xyz_, r5.xyyy, c40.xzyy
              +       log r1._y__, r_abs[0].y
/*  148   */          mul r5.___w, r5.xxxx, r2.wwww
              +       mulsc r2.___w, c14.z, r1.y
/*  149   */          mul r0._yzw, r5.yyzw, r0.zzzz
              +       exp r2.___w, r2.w
/*  150   */          mul r5.xyz_, r5.wzyy, r2.wwww
              +       setp_ne r1._, r4.w
/*   12.1 */  (p0) exec
/*  151   */     (p0) max r1._, r1, r1
              +  (p0) maxs r13.___w, c254.yy
/*  152   */     (p0) mul r6.xyz_, r1.xxxx, c42.xyzz
              +  (p0) rcp r1._y__, c64.z
/*  153   */     (p0) mad r6.xyz_, r6.xyzz, r3.xxxx, c41.xyzz
              +  (p0) retain_prev r1._
/*  154   */     (p0) add r13.xyz_, -r6.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  155   */     (p0) dp4 r6.x___, c70.zxyw, r13.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  156   */     (p0) dp4 r6._y__, c71.zxyw, r13.zxyw
              +  (p0) mulsc r1.x___, c64.w, r1.x
/*   13.0 */  (p0) exec
/*  157   */     (p0) mul r6.xy__, r6.xyyy, c253.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  158   */     (p0) mul r1.xy__, r6.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*  159   */     (p0) add r6.x___, r1.xxxx, c253.xxxx
              +  (p0) subsc r6._y__, c253.x, r1.y
/*  160   */     (p0) tfetch2D r6.xyz_, r6.xy, tf3
/*  161   */          serialize
                 (p0) mul r0._yzw, r0.yyzw, r6.zzyx
              +  (p0) retain_prev r1._
/*  162   */     (p0) mul r5.xyz_, r5.xyzz, r6.xyzz
              +  (p0) retain_prev r1._
/*   13.1 */       exec
/*  163   */          max r1._, r1, r1
              +       mulsc r2.___w, c43.z, r0.x
/*  164   */          mad r12.xyz_, r2.wwww, r0.wyzz, r12.xyzz
              +       retain_prev r1._
/*  165   */          mad r9.xyz_, r0.xxxx, r5.zyxx, r9.xyzz
              +       retain_prev r1._
/*   14.0 */       cjmp !b131, L36
/*   14.1 */       exec
/*  166   */          sgt r4.___w, c65.zzzz, c254.wwww
              +       retain_prev r1._
/*  167   */          add r0._yzw, -r2.xxyz, c45.xxyz
              +       retain_prev r1._
/*  168   */          mul r5, r8, c51
              +       retain_prev r1._
/*  169   */          dp3 r1._y__, r0.wyzz, r0.wyzz
              +       retain_prev r1._
/*  170   */          max4 r1.x___, r5.ywxz
              +       retain_prev r1._
/*  171   */          add r0.x___, -r1.xxxx, c254.yyyy
              +       rsq r1.x___, r_abs[1].y
/*   15.0 */       exec
/*  172   */          mul r5.xyz_, r0.yzww, r1.xxxx
              +       retain_prev r1._
/*  173   */          dp3 r0.__z_, r4.zxyy, r5.zxyy
              +       retain_prev r1._
/*  174   */          dp3 r3.x___, r5.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  175   */          add r5.xyz_, r5.xyzz, -r11.zyxx
              +       retain_prev r1._
/*  176   */          dp3 r2.___w, r5.zxyy, r5.zxyy
              +       maxs r1._, r1.yy
/*  177   */          add r1._y__, r3.xxxx, -c47.xxxx
              +       muls_prev r1.x___, r1.x
/*   15.1 */       exec
/*  178   */          mul r0._y__, r1.yyyy, c47.yyyy
              +       subsc r1._y__, -c44.w, -r1.x
/*  179   */          max r0._y__, r0.yyyy, c47.wwww
              +       rsq r2.___w, r_abs[2].w
/*  180   */          mul r5._yzw, r5.xxyz, r2.wwww
              +       mulsc_sat r2.___w, c45.w, r1.y
/*  181   */          min r5.x___, r0.yyyy, c254.yyyy
              +       subsc r2.___w, c254.y, r2.w
/*  182   */          dp3 r0._y__, r4.zxyy, r5.wyzz
              +       maxs r1._, r2.ww
/*  183   */          max r0._yz_, r0.yyzz, c254.xxxx
              +       muls_prev r5._y__, r5.x
/*   16.0 */       exec    // PredicateClean=false
/*  184   */          mul r6.xyz_, r5.xyyy, c44.xzyy
              +       log r1._y__, r_abs[0].y
/*  185   */          mul r6.___w, r6.xxxx, r2.wwww
              +       mulsc r2.___w, c14.z, r1.y
/*  186   */          mul r5.xyz_, r6.yzww, r0.zzzz
              +       exp r2.___w, r2.w
/*  187   */          mul r0._yzw, r6.wwzy, r2.wwww
              +       setp_ne r1._, r4.w
/*   16.1 */  (p0) exec
/*  188   */     (p0) max r1._, r1, r1
              +  (p0) maxs r13.___w, c254.yy
/*  189   */     (p0) mul r6.xyz_, r1.xxxx, c46.xyzz
              +  (p0) rcp r1._y__, c65.z
/*  190   */     (p0) mad r6.xyz_, r6.xyzz, r3.xxxx, c45.xyzz
              +  (p0) retain_prev r1._
/*  191   */     (p0) add r13.xyz_, -r6.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  192   */     (p0) dp4 r6.x___, c72.zxyw, r13.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  193   */     (p0) dp4 r6._y__, c73.zxyw, r13.zxyw
              +  (p0) mulsc r1.x___, c65.w, r1.x
/*   17.0 */  (p0) exec
/*  194   */     (p0) mul r6.xy__, r6.xyyy, c253.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  195   */     (p0) mul r1.xy__, r6.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*  196   */     (p0) add r6.x___, r1.xxxx, c253.xxxx
              +  (p0) subsc r6._y__, c253.x, r1.y
/*  197   */     (p0) tfetch2D r6.xyz_, r6.xy, tf4
/*  198   */          serialize
                 (p0) mul r5.xyz_, r5.xyzz, r6.zyxx
              +  (p0) retain_prev r1._
/*  199   */     (p0) mul r0._yzw, r0.yyzw, r6.xxyz
              +  (p0) retain_prev r1._
/*   17.1 */       exec
/*  200   */          max r1._, r1, r1
              +       mulsc r2.___w, c47.z, r0.x
/*  201   */          mad r12.xyz_, r2.wwww, r5.zxyy, r12.xyzz
              +       retain_prev r1._
/*  202   */          mad r9.xyz_, r0.xxxx, r0.wzyy, r9.xyzz
              +       retain_prev r1._
                label L36
/*   18.0 */       cjmp !b132, L48
/*   18.1 */       exec
/*  203   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  204   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  205   */          mul r5, r8.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  206   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  207   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  208   */          dp3 r2.___w, r0.xzyy, r4.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   19.0 */       exec
/*  209   */          max4 r0._y__, r5.zxwy
              +       maxs r0.__z_, r2.ww
/*  210   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  211   */          mul r5.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  212   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  213   */          mad r12.xyz_, r5.zxyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
/*   19.1 */       cjmp !b133, L48
/*   20.0 */       exec
/*  214   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  215   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  216   */          mul r5, r8, c53
              +       rsq r1.x___, r_abs[0].w
/*  217   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  218   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  219   */          dp3 r2.___w, r0.zxyy, r4.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   20.1 */       exec
/*  220   */          max4 r0._y__, r5.ywxz
              +       maxs r0.__z_, r2.ww
/*  221   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  222   */          mul r5.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  223   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  224   */          mad r12.xyz_, r5.zxyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
/*   21.0 */       cjmp !b134, L48
/*   21.1 */       exec
/*  225   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  226   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  227   */          mul r5, r8.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  228   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  229   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  230   */          dp3 r2.___w, r0.xzyy, r4.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   22.0 */       exec
/*  231   */          max4 r0._y__, r5.zxwy
              +       maxs r0.__z_, r2.ww
/*  232   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  233   */          mul r5.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  234   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  235   */          mad r12.xyz_, r5.zxyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
/*   22.1 */       cjmp !b135, L48
/*   23.0 */       exec
/*  236   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  237   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  238   */          mul r5, r8, c55
              +       rsq r1.x___, r_abs[0].w
/*  239   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  240   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  241   */          dp3 r2.___w, r0.zxyy, r4.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   23.1 */       exec
/*  242   */          max4 r0._y__, r5.ywxz
              +       maxs r0.__z_, r2.ww
/*  243   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  244   */          mul r5.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  245   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  246   */          mad r12.xyz_, r5.zxyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
                label L48
/*   24.0 */       exec
/*  247   */          mul r8, r4.xyzz, r4.yzzx
              +       retain_prev r1._
/*  248   */          cndeq r0, c254.xxxy, r4.zxyy, c254.yyyy
              +       retain_prev r1._
/*  249   */          dp4 r5.x___, c16.zxyw, r0
              +       retain_prev r1._
/*  250   */          dp4 r5._y__, c18.zxyw, r0
              +       retain_prev r1._
/*  251   */          dp4 r5.__z_, c17.zxyw, r0
              +       retain_prev r1._
/*  252   */          dp4 r0.x___, r8.wzxy, c19.wzxy
              +       muls r6.x___, r4.xx
/*   24.1 */       exec    // PredicateClean=false
/*  253   */          dp4 r0._y__, r8.wzxy, c21.wzxy
              +       muls r6._y__, r4.yy
/*  254   */          dp4 r0.__z_, r8.wzxy, c20.wzxy
              +       subs r2.___w, r6.xy
/*  255   */          add r0.xyz_, r5.zxyy, r0.zxyy
              +       setp_gt r1._, c_abs[56].x
/*  256   */          mad r0.xyz_, r2.wwww, c22.xyzz, r0.yxzz
              +       retain_prev r1._
/*  257   */          mad r5.xyz_, r12.xzyy, r1.wwww, r0.xyzz
              +       retain_prev r1._
/*   25.0 */  (p0) exec
/*  258   */     (p0) mul r6.xyz_, r5.zyxx, c59.xxxx
              +  (p0) retain_prev r1._
/*  259   */     (p0) mul r0.xyz_, r5.zyxx, c60.xxxx
              +  (p0) retain_prev r1._
/*  260   */     (p0) mul r0.xyz_, r0.xyzz, c58.xxxx
              +  (p0) retain_prev r1._
/*  261   */     (p0) mad r5.xyz_, r6.zyxx, c57.xxxx, r0.zyxx
              +  (p0) retain_prev r1._
/*   25.1 */       exec
/*  262   */          dp3 r6._y__, r11.xzyy, r4.zxyy
              +       retain_prev r1._
/*  263   */          max r1._, r1, r1
              +       adds r1.x___, r6.yy
/*  264   */          mad r0.xyz_, -r4.xyzz, r1.xxxx, r11.zyxx
              +       retain_prev r1._
/*  265   */          cube r0, r0.zzxy, r0.yxzz
              +       retain_prev r1._
/*  266   */          max r4.__z_, r0.wwww, r0.wwww
              +       rcp r1.x___, r_abs[0].z
/*  267   */          mad r4.xy__, r0.yxxx, r1.xxxx, c253.zzzz
              +       retain_prev r1._
/*   26.0 */       exec
/*  268   */          setTexLOD r3.w
/*  269   */          tfetchCube r4, r4.xyz, tf7, UseComputedLOD=false, UseRegisterLOD=true
/*   26.1 */       alloc colors
/*   27.0 */       exec
/*  270   */          max r1.x___, r4.wwww, c253.wwww
              +       mulsc r6.x___, c6.x, r3.z
/*  271   */          add r0.xy__, -r6.xyyy, c254.yyyy
              +       rcp r1.x___, r1.x
/*  272   */          mul r3.x_zw, r1.xxxx, r4.xyyz
              +       retain_prev r1._
/*  273   */          mul r4.xyz_, r3.wzxx, r0.xxxx
              +       muls r1.x___, r_abs[0].yy
/*  274   */          max r1._, r1, r1
              +       muls r1.x___, r1.xx
/*  275   */          mul r4.___w, r1.xxxx, r_abs[0].yyyy
              +       retain_prev r1._
/*   27.1 */       exec    // PredicateClean=false
/*  276   */          mad r0.xyz_, r4.zyxx, c14.wwww, r9.zyxx
              +       retain_prev r1._
/*  277   */          mad_sat r1.x___, r4.wwww, c14.xxxx, c14.yyyy
              +       retain_prev r1._
/*  278   */          max r1._, r1, r1
              +       subsc r1.x___, c254.y, r1.x
/*  279   */          mul r1.x___, r1.xxxx, r1.wwww
              +       setp_ne r1._, c56.x
/*  280   */     (p0) mul r0.xyz_, r0.xyzz, c61.xxxx
              +  (p0) retain_prev r1._
/*  281   */          mul r1.xy_w, r1.xxxx, r10.xyzz
              +       maxs r1._, r7.ww
/*   28.0 */       exec
/*  282   */          mul r0.xyz_, r1.xyww, r0.xyzz
              +       muls_prev r1.___w, r1.z
/*  283   */          mad r0.xyz_, r7.yxzz, r5.xyzz, r0.xyzz
              +       retain_prev r1._
/*   28.1 */       cjmp !b136, L61
/*   29.0 */       exec
/*  284   */          mad r2.___w, r3.yyyy, c12.yyyy, c12.zzzz
              +       retain_prev r1._
/*  285   */          dp3 r1.__z_, r11.xzyy, c10.zxyy
              +       retain_prev r1._
/*  286   */          cndeq r4, c254.xxxy, r2.zxyy, c254.yyyy
              +       retain_prev r1._
/*  287   */          dp4 r1._y__, c10.zxyw, r4
              +       subsc r1.x___, -c9.x, -r3.y
/*  288   */          add r2.xyz_, -r0.xyzz, c11.xyzz
              +       mulsc r0.___w, c9.z, r1.x
/*  289   */          min r3.xy__, r1.yzzz, c254.xzzz
              +       mulsc r1.x___, c9.w, r1.y
/*   29.1 */       exec
/*  290   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  291   */          max r1._, r1, r1
              +       mulsc r1.x___, c12.x, r1.y
/*  292   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  293   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  294   */          min r1.x___, r1.xxxx, c11.wwww
              +       retain_prev r1._
/*  295   */          max r1.x___, r1.xxxx, c254.xxxx
              +       retain_prev r1._
/*   30.0 */       exec
/*  296   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L61
/*   30.1 */       exece
/*  297   */          mul r1.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  298   */          max oC0, r1, r1
