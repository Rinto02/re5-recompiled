/*    0.0 */       exec    // PredicateClean=false
/*    6   */          sgt r2.x___, c1.xxxx, r0.wwww
/*    7   */          setp_ne_push r8.x___, c255.yyyy, r2.xxxx
              +       sgts r2.x___, -r_abs[0].x
/*    0.1 */ (!p0) jmp L10
/*    1.0 */  (p0) exec
/*    8   */     (p0) rcp r1.___w, r1.w
/*    9   */     (p0) mul r4.xyz_, r1.wwww, r1.yzxx
/*   10   */     (p0) tfetch2D r10.x___, r4.zx, tf0, OffsetX=-2, OffsetY=1
/*   11   */     (p0) tfetch2D r10.___x, r4.zx, tf0, OffsetX=1, OffsetY=1
/*   12   */     (p0) tfetch2D r10.__x_, r4.zx, tf0, OffsetY=1
/*   13   */     (p0) tfetch2D r10._x__, r4.zx, tf0, OffsetX=-1, OffsetY=1
/*    1.1 */  (p0) exec
/*   14   */     (p0) tfetch2D r9.x___, r4.zx, tf0, OffsetX=-2
/*   15   */     (p0) tfetch2D r9.___x, r4.zx, tf0, OffsetX=1
/*   16   */     (p0) tfetch2D r9.__x_, r4.zx, tf0
/*   17   */     (p0) tfetch2D r9._x__, r4.zx, tf0, OffsetX=-1
/*   18   */     (p0) tfetch2D r2.x___, r4.zx, tf0, OffsetX=-2, OffsetY=-1
/*   19   */     (p0) tfetch2D r2.___x, r4.zx, tf0, OffsetX=1, OffsetY=-1
/*    2.0 */  (p0) exec
/*   20   */     (p0) tfetch2D r2.__x_, r4.zx, tf0, OffsetY=-1
/*   21   */     (p0) tfetch2D r2._x__, r4.zx, tf0, OffsetX=-1, OffsetY=-1
/*   22   */     (p0) tfetch2D r3.x___, r4.zx, tf0, OffsetX=-2, OffsetY=-2
/*   23   */     (p0) tfetch2D r3.___x, r4.zx, tf0, OffsetX=1, OffsetY=-2
/*   24   */     (p0) tfetch2D r3.__x_, r4.zx, tf0, OffsetY=-2
/*   25   */     (p0) tfetch2D r3._x__, r4.zx, tf0, OffsetX=-1, OffsetY=-2
/*    2.1 */  (p0) exec
/*   26   */          serialize
                 (p0) dp3 r4.x___, r0.zxyy, r0.zxyy
/*   27   */     (p0) add r1.__z_, -r4.yyyy, c255.xxxx
              +  (p0) rsq r4.x___, r_abs[4].x
/*   28   */     (p0) mul r8._yzw, r4.xxxx, -c23.xxyz
/*   29   */     (p0) sge r4, r3, r1.zzzz
/*   30   */     (p0) sge r7, r2, r1.zzzz
/*   31   */     (p0) sge r5, r9, r1.zzzz
/*    3.0 */       exec    // PredicateClean=false
/*   32   */     (p0) sge r6, r10, r1.zzzz
/*   33   */     (p0) dp3 r0._y__, r8.wyzz, r0.zxyy
              +  (p0) mulsc r0.x___, c0.y, r1.w
/*   34   */          setp_gt_push r8.x___, r8.xxxx, c4.xxxx
/*   35   */     (p0) add r6, -r1.zzzz, r10
/*   36   */     (p0) add r5, -r1.zzzz, r9
/*   37   */     (p0) add r2, -r1.zzzz, r2
/*    3.1 */       exec    // PredicateClean=false
/*   38   */     (p0) add r3, -r1.zzzz, r3
/*   39   */     (p0) mul_sat r4, r3, c4.xxxx
/*   40   */     (p0) mul_sat r7, r2, c4.xxxx
/*   41   */     (p0) mul_sat r5, r5, c4.xxxx
/*   42   */     (p0) mul_sat r6, r6, c4.xxxx
/*   43   */          setp_pop r8.x___, r8.x
/*    4.0 */  (p0) exec
/*   44   */     (p0) mad_sat r2._y__, r0.wwww, c2.xxxx, c2.yyyy
/*   45   */     (p0) mul r0.x_z_, r0.xxxx, r1.xyyy
/*   46   */     (p0) add r1, r5, r7
/*   47   */     (p0) frc r2.__zw, r0.zzzx
              +  (p0) mulsc_sat r2.x___, c3.x, r0.y
/*   48   */     (p0) add r0.xyz_, -r2.zxyy, c255.xxxx
/*   49   */     (p0) mad r1, r0.xxxx, r4, r1
/*    4.1 */  (p0) exec
/*   50   */     (p0) mad r1, r2.zzzz, r6, r1
/*   51   */     (p0) dp3 r0.___w, r1.zxyy, c255.xxxx
              +  (p0) subs r1.x___, r1.wx
/*   52   */     (p0) mad r0.___w, r1.xxxx, r2.wwww, r0.wwww
/*   53   */     (p0) mul r1.x___, r0.wwww, c255.zzzz
              +  (p0) mulsc r0.___w, c6.x, r0.y
/*   54   */     (p0) max r0.___w, r1.xxxx, r0.wwww
/*   55   */     (p0) mul r2.x___, r0.zzzz, r0.wwww
                label L10
/*    5.0 */       alloc colors
/*    5.1 */       exece
/*   56   */          mul oC0, r2.xxxx, c5.xxxx
