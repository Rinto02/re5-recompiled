/*    0.0 */       exec
/*    4   */          vfetch_full r1.xyz1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=6
/*    5   */          vfetch_mini r0.xy0_, Offset=4, DataFormat=FMT_32_32_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    6   */          max oPos, r1, r1
/*    1.1 */       alloc interpolators
/*    2.0 */       exec
/*    7   */          add o1.xy__, r0.xyyy, -c0.xyyy
/*    8   */          add o1.__zw, r0.xxxy, c0.xxxy
/*    9   */          add o2.xy__, r0.xyyy, -c1.xyyy
/*   10   */          add o2.__zw, r0.xxxy, c1.xxxy
/*   11   */          add o3.xy__, r0.xyyy, -c2.xyyy
/*   12   */          add o3.__zw, r0.xxxy, c2.xxxy
/*    2.1 */       exec
/*   13   */          add o4.xy__, r0.xyyy, -c3.xyyy
/*   14   */          add o4.__zw, r0.xxxy, c3.xxxy
/*   15   */          add o5.xy__, r0.xyyy, -c4.xyyy
/*   16   */          add o5.__zw, r0.xxxy, c4.xxxy
/*   17   */          add o6.xy__, r0.xyyy, -c5.xyyy
/*   18   */          add o6.__zw, r0.xxxy, c5.xxxy
/*    3.0 */       exece
/*   19   */          add o7.xy__, r0.xyyy, -c6.xyyy
/*   20   */          add o7.__zw, r0.xxxy, c6.xxxy
/*   21   */          max o0, r0.xyzz, r0.xyzz
/*    3.1 */       cnop
