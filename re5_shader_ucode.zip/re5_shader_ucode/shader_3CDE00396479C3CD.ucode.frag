/*    0.0 */       exec
/*   22   */          tfetch2D r7.yxzw, r1.xy, tf0
/*   23   */          serialize
                      mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r7.ww
/*   24   */          add r9.xyz_, r2.xyzz, -c23.xyzz
              +       rcp r1.x___, r0.w
/*   25   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   26   */          mul r0.__zw, r3.zzzw, r0.yyyx
              +       subsc r1.x___, -c1.x, -r1.y
/*   27   */          kill_gt r1._, c254.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   28   */          tfetch2D r0.xy__, r3.xy, tf1
/*   29   */          tfetch2D r10, r0.zw, tf2
/*   30   */          serialize
                      sgt r8.xyz_, -r_abs[1].xxxx, c254.xxxx
              +       retain_prev r1._
/*   31   */          dp3 r3.__z_, r9.zxyy, r9.zxyy
              +       maxs r1.x___, r7.zz
/*   32   */          mul r10, r10.wzyx, c5.wzyx
              +       mulsc r7.__z_, c12.z, r1.x
/*   33   */          mad r0.x__w, r0.yxxx, c254.wwww, c255.xxxx
              +       retain_prev r1._
/*    1.0 */       exec
/*   34   */          dp2add r2.___w, -r0.xwww, r0.xwww, c254.yyyy
              +       retain_prev r1._
/*   35   */          min r10, r10, c6.xxxx
              +       sqrt r2.___w, r_abs[2].w
/*   36   */          mul r6.xyz_, r2.wwww, r6.xyzz
              +       mulsc r7.x___, c12.y, r7.x
/*   37   */          mad r0.xyz_, r0.xxxx, r5.zyxx, r6.zyxx
              +       retain_prev r1._
/*   38   */          mad r0.xyz_, r0.wwww, r4.xzyy, r0.zxyy
              +       retain_prev r1._
/*   39   */          dp3 r2.___w, r0.yxzz, r0.yxzz
              +       mulsc r7._y__, c12.x, r7.y
/*    1.1 */       exec
/*   40   */          max r4, r10.wzyx, c7.xxxx
              +       rsq r2.___w, r_abs[2].w
/*   41   */          mul r5.xyz_, r0.xzyy, r2.wwww
              +       sqrt r3.___w, r_abs[3].z
/*    2.0 */       cjmp !b128, L20
/*    2.1 */       exec
/*   42   */          mul r0, r4.wzyx, c48.wzyx
              +       retain_prev r1._
/*   43   */          add r6.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   44   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   45   */          max4 r0.__z_, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   46   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   47   */          dp3 r0._y__, r5.zxyy, r6.xzyy
              +       retain_prev r1._
/*    3.0 */       exec
/*   48   */          dp3 r2.___w, r6.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   49   */          add r1.x___, r6.wwww, -c32.wwww
              +       retain_prev r1._
/*   50   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   51   */          max r0._y__, r0.yyyy, c254.xxxx
              +       mulsc r2.___w, c35.y, r2.w
/*   52   */          max r2.___w, r2.wwww, c35.wwww
              +       subsc r0.___w, c254.y, r0.x
/*   53   */          min r6.x___, r2.wwww, c254.yyyy
              +       subsc r2.___w, c254.y, r0.z
/*    3.1 */       exec
/*   54   */          mul r6._y__, r0.wwww, r6.xxxx
              +       retain_prev r1._
/*   55   */          mul r6._yzw, r6.xxyy, c32.xxzy
              +       retain_prev r1._
/*   56   */          mul r6.x___, r6.yyyy, r0.wwww
              +       retain_prev r1._
/*   57   */          mul r0.xyz_, r6.xzww, r0.yyyy
              +       retain_prev r1._
/*   58   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       retain_prev r1._
/*   59   */          mul r8.xyz_, r0.xzyy, c35.zzzz
              +       retain_prev r1._
/*    4.0 */       cjmp !b129, L20
/*    4.1 */       exec
/*   60   */          mul r0, r4.wzyx, c49.wzyx
              +       retain_prev r1._
/*   61   */          add r6.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   62   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*   63   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   64   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   65   */          dp3 r0._y__, r5.zxyy, r6.zxyy
              +       retain_prev r1._
/*    5.0 */       exec
/*   66   */          dp3 r2.___w, r6.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   67   */          add r1.x___, r6.wwww, -c36.wwww
              +       retain_prev r1._
/*   68   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   69   */          max r0._y__, r0.yyyy, c254.xxxx
              +       mulsc r2.___w, c39.y, r2.w
/*   70   */          max r0.___w, r2.wwww, c39.wwww
              +       subsc r2.___w, c254.y, r0.x
/*   71   */          min r6.x___, r0.wwww, c254.yyyy
              +       subsc r0.x___, c254.y, r0.z
/*    5.1 */       exec
/*   72   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*   73   */          mul r6.xy_w, r6.yyxx, c36.zyxx
              +       retain_prev r1._
/*   74   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*   75   */          mul r0.xyz_, r6.xyzz, r0.yyyy
              +       retain_prev r1._
/*   76   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   77   */          mad r8.xyz_, r0.xzyy, c39.zzzz, r8.xyzz
              +       retain_prev r1._
/*    6.0 */       cjmp !b130, L20
/*    6.1 */       exec
/*   78   */          mul r0, r4, c50
              +       retain_prev r1._
/*   79   */          add r6.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   80   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   81   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[6].w
/*   82   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   83   */          dp3 r0._y__, r5.zxyy, r6.xzyy
              +       retain_prev r1._
/*    7.0 */       exec
/*   84   */          dp3 r2.___w, r6.xzyy, -c42.zxyy
              +       retain_prev r1._
/*   85   */          add r1.x___, r6.wwww, -c40.wwww
              +       retain_prev r1._
/*   86   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*   87   */          max r0._y__, r0.yyyy, c254.xxxx
              +       mulsc r2.___w, c43.y, r2.w
/*   88   */          max r0.___w, r2.wwww, c43.wwww
              +       subsc r2.___w, c254.y, r0.x
/*   89   */          min r6.x___, r0.wwww, c254.yyyy
              +       subsc r0.x___, c254.y, r0.z
/*    7.1 */       exec
/*   90   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*   91   */          mul r6.xy_w, r6.yyxx, c40.zyxx
              +       retain_prev r1._
/*   92   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*   93   */          mul r0.xyz_, r6.xyzz, r0.yyyy
              +       retain_prev r1._
/*   94   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   95   */          mad r8.xyz_, r0.xzyy, c43.zzzz, r8.xyzz
              +       retain_prev r1._
/*    8.0 */       cjmp !b131, L20
/*    8.1 */       exec
/*   96   */          mul r0, r4.wzyx, c51.wzyx
              +       retain_prev r1._
/*   97   */          add r6.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*   98   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*   99   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*  100   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*  101   */          dp3 r0._y__, r5.zxyy, r6.zxyy
              +       retain_prev r1._
/*    9.0 */       exec
/*  102   */          dp3 r2.___w, r6.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  103   */          add r1.x___, r6.wwww, -c44.wwww
              +       retain_prev r1._
/*  104   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  105   */          max r0._y__, r0.yyyy, c254.xxxx
              +       mulsc r2.___w, c47.y, r2.w
/*  106   */          max r0.___w, r2.wwww, c47.wwww
              +       subsc r2.___w, c254.y, r0.x
/*  107   */          min r6.x___, r0.wwww, c254.yyyy
              +       subsc r0.x___, c254.y, r0.z
/*    9.1 */       exec
/*  108   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*  109   */          mul r6.xy_w, r6.yyxx, c44.zyxx
              +       retain_prev r1._
/*  110   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*  111   */          mul r0.xyz_, r6.xyzz, r0.yyyy
              +       retain_prev r1._
/*  112   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  113   */          mad r8.xyz_, r0.xzyy, c47.zzzz, r8.xyzz
              +       retain_prev r1._
                label L20
/*   10.0 */       cjmp !b132, L32
/*   10.1 */       exec
/*  114   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  115   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  116   */          mul r6, r4.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  117   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  118   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  119   */          dp3 r2.___w, r0.xzyy, r5.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   11.0 */       exec
/*  120   */          max4 r0._y__, r6.zxwy
              +       maxs r0.__z_, r2.ww
/*  121   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  122   */          mul r6.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  123   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  124   */          mad r8.xyz_, r6.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   11.1 */       cjmp !b133, L32
/*   12.0 */       exec
/*  125   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  126   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  127   */          mul r6, r4, c53
              +       rsq r1.x___, r_abs[0].w
/*  128   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  129   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  130   */          dp3 r2.___w, r0.zxyy, r5.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   12.1 */       exec
/*  131   */          max4 r0._y__, r6.ywxz
              +       maxs r0.__z_, r2.ww
/*  132   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  133   */          mul r6.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  134   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  135   */          mad r8.xyz_, r6.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   13.0 */       cjmp !b134, L32
/*   13.1 */       exec
/*  136   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  137   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  138   */          mul r6, r4.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  139   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  140   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  141   */          dp3 r2.___w, r0.xzyy, r5.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   14.0 */       exec
/*  142   */          max4 r0._y__, r6.zxwy
              +       maxs r0.__z_, r2.ww
/*  143   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  144   */          mul r6.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  145   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  146   */          mad r8.xyz_, r6.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   14.1 */       cjmp !b135, L32
/*   15.0 */       exec
/*  147   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  148   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  149   */          mul r4, r4, c55
              +       rsq r1.x___, r_abs[0].w
/*  150   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  151   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  152   */          dp3 r2.___w, r0.zxyy, r5.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   15.1 */       exec
/*  153   */          max4 r0._y__, r4.ywxz
              +       maxs r0.__z_, r2.ww
/*  154   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  155   */          mul r4.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  156   */          mul r4.xyz_, r4.xyzz, r2.wwww
              +       retain_prev r1._
/*  157   */          mad r8.xyz_, r4.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
                label L32
/*   16.0 */       exec
/*  158   */          tfetch2D r2.___x, r3.xy, tf3
/*   16.1 */       alloc colors
/*   17.0 */       exec
/*  159   */          mul r6, r5.xyzz, r5.yzzx
              +       retain_prev r1._
/*  160   */          cndeq r0, c254.xxxy, r5.zxyy, c254.yyyy
              +       retain_prev r1._
/*  161   */          dp4 r4.x___, c16.zxyw, r0
              +       retain_prev r1._
/*  162   */          dp4 r4._y__, c18.zxyw, r0
              +       retain_prev r1._
/*  163   */          dp4 r4.__z_, c17.zxyw, r0
              +       retain_prev r1._
/*  164   */          dp4 r0.x___, r6.wzxy, c19.wzxy
              +       muls r1.x___, r5.xx
/*   17.1 */       exec    // PredicateClean=false
/*  165   */          dp4 r0._y__, r6.wzxy, c21.wzxy
              +       muls r1._y__, r5.yy
/*  166   */          dp4 r0.__z_, r6.wzxy, c20.wzxy
              +       subs r1.x___, r1.xy
/*  167   */          add r0.xyz_, r4.zxyy, r0.zxyy
              +       setp_gt r1._, c_abs[14].x
/*  168   */          mad r0.xyz_, r1.xxxx, c22.xyzz, r0.yxzz
              +       retain_prev r1._
/*  169   */          mad r1.xy_w, r8.xyzz, r1.wwww, r0.xzyy
              +       retain_prev r1._
/*  170   */          mad r1.xy_w, r2.wwww, c13.xyzz, r1.xwyy
              +       retain_prev r1._
/*   18.0 */  (p0) exec
/*  171   */     (p0) mul r0.xyz_, r1.wyxx, c57.xxxx
              +  (p0) retain_prev r1._
/*  172   */     (p0) mul r1.xy_w, r1.wyxx, c58.xxxx
              +  (p0) retain_prev r1._
/*  173   */     (p0) mul r1.xy_w, r1.xyww, c56.xxxx
              +  (p0) retain_prev r1._
/*  174   */     (p0) mad r1.xy_w, r0.zyxx, c15.xxxx, r1.wyxx
              +  (p0) retain_prev r1._
/*   18.1 */       exec
/*  175   */          mul r0, r7.yxzw, r1.xywz
              +       retain_prev r1._
/*   19.0 */       cjmp !b136, L42
/*   19.1 */       exec
/*  176   */          mad r1.___w, r3.wwww, c11.yyyy, c11.zzzz
              +       retain_prev r1._
/*  177   */          add r1.x___, r3.wwww, -c8.xxxx
              +       rsq r1._y__, r_abs[3].z
/*  178   */          mul r3.xyz_, r9.xyzz, r1.yyyy
              +       retain_prev r1._
/*  179   */          cndeq r2, c254.xxxy, r2.zxyy, c254.yyyy
              +       retain_prev r1._
/*  180   */          dp4 r1._y__, c9.zxyw, r2
              +       retain_prev r1._
/*  181   */          dp3 r1.__z_, r3.zxyy, c9.zxyy
              +       retain_prev r1._
/*   20.0 */       exec
/*  182   */          add r2.xyz_, -r0.xyzz, c10.xyzz
              +       mulsc r2.___w, c8.z, r1.x
/*  183   */          min r3.xy__, r1.yzzz, c254.xzzz
              +       mulsc r1.x___, c8.w, r1.y
/*  184   */          max r1.__z_, r2.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  185   */          max r1._, r1, r1
              +       mulsc r1.x___, c11.x, r1.y
/*  186   */          mad r1.x___, r1.xxxx, r3.xxxx, r1.wwww
              +       retain_prev r1._
/*  187   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*   20.1 */       exec
/*  188   */          min r1.x___, r1.xxxx, c10.wwww
              +       retain_prev r1._
/*  189   */          max r1.x___, r1.xxxx, c254.xxxx
              +       retain_prev r1._
/*  190   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L42
/*   21.0 */       exece
/*  191   */          mul r0.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  192   */          max oC0, r0, r0
/*   21.1 */       cnop
