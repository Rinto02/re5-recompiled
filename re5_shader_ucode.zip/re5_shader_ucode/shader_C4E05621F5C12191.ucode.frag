/*    0.0 */       exec
/*   21   */          tfetch2D r8.yxzw, r1.xy, tf0
/*   22   */          serialize
                      mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r8.ww
/*   23   */          sgt r9.xyz_, -r_abs[1].xxxx, c254.xxxx
              +       rcp r1.x___, r0.w
/*   24   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   25   */          mul r0.xy__, r3.zwww, r0.yxxx
              +       subsc r1.x___, -c1.x, -r1.y
/*   26   */          kill_gt r1._, c254.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   27   */          tfetch2D r11, r0.xy, tf3
/*   28   */          tfetch2D r0.xy__, r3.xy, tf1
/*   29   */          serialize
                      add r10.xyz_, r2.zyxx, -c23.zyxx
              +       maxs r1.x___, r8.zz
/*   30   */          dp3 r4.__z_, r10.xzyy, r10.xzyy
              +       mulsc r8.__z_, c14.z, r1.x
/*   31   */          mad r0.x__w, r0.yxxx, c254.wwww, c255.xxxx
              +       retain_prev r1._
/*   32   */          mul r3, r11.wzyx, c5.wzyx
              +       mulsc r8.x___, c14.y, r8.x
/*    1.0 */       exec
/*   33   */          min r3, r3, c8.xxxx
              +       mulsc r8._y__, c14.x, r8.y
/*   34   */          dp2add r1._y__, -r0.xwww, r0.xwww, c254.yyyy
              +       retain_prev r1._
/*   35   */          max r3, r3.wzyx, c9.xxxx
              +       sqrt r1._y__, r_abs[1].y
/*   36   */          mul r7.xyz_, r1.yyyy, r7.xyzz
              +       maxs r1._y__, r3.yw
/*   37   */          mad r0.xyz_, r0.xxxx, r6.zyxx, r7.zyxx
              +       retain_prev r1._
/*   38   */          mad r0.xyz_, r0.wwww, r5.xzyy, r0.zxyy
              +       retain_prev r1._
/*    1.1 */       exec
/*   39   */          dp3 r2.___w, r0.yxzz, r0.yxzz
              +       maxs r0.___w, r3.xz
/*   40   */          max r1._y__, r0.wwww, r1.yyyy
              +       rsq r2.___w, r_abs[2].w
/*   41   */          mul r5.xyz_, r0.xzyy, r2.wwww
              +       sqrt r0._y__, r_abs[4].z
/*    2.0 */       cjmp !b128, L20
/*    2.1 */       exec
/*   42   */          mul r7, r3.wzyx, c48.wzyx
              +       retain_prev r1._
/*   43   */          add r6.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   44   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   45   */          max4 r0.__z_, r7.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   46   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   47   */          dp3 r0.___w, r5.zxyy, r6.xzyy
              +       retain_prev r1._
/*    3.0 */       exec
/*   48   */          dp3 r2.___w, r6.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   49   */          add r1.x___, r6.wwww, -c32.wwww
              +       retain_prev r1._
/*   50   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   51   */          max r0.___w, r0.wwww, c254.xxxx
              +       mulsc r2.___w, c35.y, r2.w
/*   52   */          max r2.___w, r2.wwww, c35.wwww
              +       subsc r4.___w, c254.y, r0.x
/*   53   */          min r6.x___, r2.wwww, c254.yyyy
              +       subsc r2.___w, c254.y, r0.z
/*    3.1 */       exec
/*   54   */          mul r6._y__, r4.wwww, r6.xxxx
              +       retain_prev r1._
/*   55   */          mul r6._yzw, r6.xxyy, c32.xxzy
              +       retain_prev r1._
/*   56   */          mul r6.x___, r6.yyyy, r4.wwww
              +       retain_prev r1._
/*   57   */          mul r0.x_zw, r6.xzzw, r0.wwww
              +       retain_prev r1._
/*   58   */          mul r0.x_zw, r0.xwwz, r2.wwww
              +       retain_prev r1._
/*   59   */          mul r9.xyz_, r0.wzxx, c35.zzzz
              +       retain_prev r1._
/*    4.0 */       cjmp !b129, L20
/*    4.1 */       exec
/*   60   */          mul r7, r3.wzyx, c49.wzyx
              +       retain_prev r1._
/*   61   */          add r6.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   62   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*   63   */          max4 r0.x___, r7.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   64   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   65   */          dp3 r0.___w, r5.zxyy, r6.zxyy
              +       retain_prev r1._
/*    5.0 */       exec
/*   66   */          dp3 r2.___w, r6.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   67   */          add r1.x___, r6.wwww, -c36.wwww
              +       retain_prev r1._
/*   68   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   69   */          max r0.___w, r0.wwww, c254.xxxx
              +       mulsc r2.___w, c39.y, r2.w
/*   70   */          max r4.___w, r2.wwww, c39.wwww
              +       subsc r2.___w, c254.y, r0.x
/*   71   */          min r6.x___, r4.wwww, c254.yyyy
              +       subsc r0.x___, c254.y, r0.z
/*    5.1 */       exec
/*   72   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*   73   */          mul r6.xy_w, r6.yyxx, c36.zyxx
              +       retain_prev r1._
/*   74   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*   75   */          mul r0.x_zw, r6.xyyz, r0.wwww
              +       retain_prev r1._
/*   76   */          mul r0.x_zw, r0.wzzx, r2.wwww
              +       retain_prev r1._
/*   77   */          mad r9.xyz_, r0.wzxx, c39.zzzz, r9.xyzz
              +       retain_prev r1._
/*    6.0 */       cjmp !b130, L20
/*    6.1 */       exec
/*   78   */          mul r7, r3, c50
              +       retain_prev r1._
/*   79   */          add r6.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   80   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   81   */          max4 r0.x___, r7.ywxz
              +       rsq r1.x___, r_abs[6].w
/*   82   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*   83   */          dp3 r0.___w, r5.zxyy, r6.xzyy
              +       retain_prev r1._
/*    7.0 */       exec
/*   84   */          dp3 r2.___w, r6.xzyy, -c42.zxyy
              +       retain_prev r1._
/*   85   */          add r1.x___, r6.wwww, -c40.wwww
              +       retain_prev r1._
/*   86   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*   87   */          max r0.___w, r0.wwww, c254.xxxx
              +       mulsc r2.___w, c43.y, r2.w
/*   88   */          max r4.___w, r2.wwww, c43.wwww
              +       subsc r2.___w, c254.y, r0.x
/*   89   */          min r6.x___, r4.wwww, c254.yyyy
              +       subsc r0.x___, c254.y, r0.z
/*    7.1 */       exec
/*   90   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*   91   */          mul r6.xy_w, r6.yyxx, c40.zyxx
              +       retain_prev r1._
/*   92   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*   93   */          mul r0.x_zw, r6.xyyz, r0.wwww
              +       retain_prev r1._
/*   94   */          mul r0.x_zw, r0.wzzx, r2.wwww
              +       retain_prev r1._
/*   95   */          mad r9.xyz_, r0.wzxx, c43.zzzz, r9.xyzz
              +       retain_prev r1._
/*    8.0 */       cjmp !b131, L20
/*    8.1 */       exec
/*   96   */          mul r7, r3.wzyx, c51.wzyx
              +       retain_prev r1._
/*   97   */          add r6.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*   98   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*   99   */          max4 r0.x___, r7.zxwy
              +       rsq r1.x___, r_abs[6].w
/*  100   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*  101   */          dp3 r0.___w, r5.zxyy, r6.zxyy
              +       retain_prev r1._
/*    9.0 */       exec
/*  102   */          dp3 r2.___w, r6.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  103   */          add r1.x___, r6.wwww, -c44.wwww
              +       retain_prev r1._
/*  104   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  105   */          max r0.___w, r0.wwww, c254.xxxx
              +       mulsc r2.___w, c47.y, r2.w
/*  106   */          max r4.___w, r2.wwww, c47.wwww
              +       subsc r2.___w, c254.y, r0.x
/*  107   */          min r6.x___, r4.wwww, c254.yyyy
              +       subsc r0.x___, c254.y, r0.z
/*    9.1 */       exec
/*  108   */          mul r6._y__, r0.xxxx, r6.xxxx
              +       retain_prev r1._
/*  109   */          mul r6.xy_w, r6.yyxx, c44.zyxx
              +       retain_prev r1._
/*  110   */          mul r6.__z_, r6.wwww, r0.xxxx
              +       retain_prev r1._
/*  111   */          mul r0.x_zw, r6.xyyz, r0.wwww
              +       retain_prev r1._
/*  112   */          mul r0.x_zw, r0.wzzx, r2.wwww
              +       retain_prev r1._
/*  113   */          mad r9.xyz_, r0.wzxx, c47.zzzz, r9.xyzz
              +       retain_prev r1._
                label L20
/*   10.0 */       cjmp !b132, L32
/*   10.1 */       exec
/*  114   */          add r7.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  115   */          dp3 r7.___w, r7.xzyy, r7.xzyy
              +       retain_prev r1._
/*  116   */          mul r6, r3.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[7].w
/*  117   */          mul r7, r7, r1.xxxx
              +       retain_prev r1._
/*  118   */          add r1.x___, r7.wwww, -c24.wwww
              +       retain_prev r1._
/*  119   */          dp3 r2.___w, r7.xzyy, r5.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   11.0 */       exec
/*  120   */          max4 r0.__z_, r6.zxwy
              +       maxs r7.x___, r2.ww
/*  121   */          add r0.x_z_, -r0.xzzz, c254.yyyy
              +       maxs r7._y__, c254.xx
/*  122   */          mul r6.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r7.xy
/*  123   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  124   */          mad r9.xyz_, r6.xyzz, r0.zzzz, r9.xyzz
              +       retain_prev r1._
/*   11.1 */       cjmp !b133, L32
/*   12.0 */       exec
/*  125   */          add r7.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  126   */          dp3 r7.___w, r7.zxyy, r7.zxyy
              +       retain_prev r1._
/*  127   */          mul r6, r3, c53
              +       rsq r1.x___, r_abs[7].w
/*  128   */          mul r7, r7, r1.xxxx
              +       retain_prev r1._
/*  129   */          add r1.x___, r7.wwww, -c26.wwww
              +       retain_prev r1._
/*  130   */          dp3 r2.___w, r7.zxyy, r5.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   12.1 */       exec
/*  131   */          max4 r0.__z_, r6.ywxz
              +       maxs r7.x___, r2.ww
/*  132   */          add r0.x_z_, -r0.xzzz, c254.yyyy
              +       maxs r7._y__, c254.xx
/*  133   */          mul r6.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r7.xy
/*  134   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  135   */          mad r9.xyz_, r6.xyzz, r0.zzzz, r9.xyzz
              +       retain_prev r1._
/*   13.0 */       cjmp !b134, L32
/*   13.1 */       exec
/*  136   */          add r7.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  137   */          dp3 r7.___w, r7.xzyy, r7.xzyy
              +       retain_prev r1._
/*  138   */          mul r6, r3.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[7].w
/*  139   */          mul r7, r7, r1.xxxx
              +       retain_prev r1._
/*  140   */          add r1.x___, r7.wwww, -c28.wwww
              +       retain_prev r1._
/*  141   */          dp3 r2.___w, r7.xzyy, r5.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   14.0 */       exec
/*  142   */          max4 r0.__z_, r6.zxwy
              +       maxs r7.x___, r2.ww
/*  143   */          add r0.x_z_, -r0.xzzz, c254.yyyy
              +       maxs r7._y__, c254.xx
/*  144   */          mul r6.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r7.xy
/*  145   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  146   */          mad r9.xyz_, r6.xyzz, r0.zzzz, r9.xyzz
              +       retain_prev r1._
/*   14.1 */       cjmp !b135, L32
/*   15.0 */       exec
/*  147   */          add r6.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  148   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*  149   */          mul r3, r3, c55
              +       rsq r1.x___, r_abs[6].w
/*  150   */          mul r6, r6, r1.xxxx
              +       retain_prev r1._
/*  151   */          add r1.x___, r6.wwww, -c30.wwww
              +       retain_prev r1._
/*  152   */          dp3 r2.___w, r6.zxyy, r5.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   15.1 */       exec
/*  153   */          max4 r0.__z_, r3.ywxz
              +       maxs r5.x___, r2.ww
/*  154   */          add r0.x_z_, -r0.xzzz, c254.yyyy
              +       maxs r5._y__, c254.xx
/*  155   */          mul r3.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r5.xy
/*  156   */          mul r3.xyz_, r3.xyzz, r2.wwww
              +       retain_prev r1._
/*  157   */          mad r9.xyz_, r3.xyzz, r0.zzzz, r9.xyzz
              +       retain_prev r1._
                label L32
/*   16.0 */       exec
/*  158   */          tfetch2D r3, r4.xy, tf2
/*   16.1 */       alloc colors
/*   17.0 */       exec
/*  159   */          mul r0.x_zw, r3.xyyz, r3.wwww
              +       subsc r1.x___, -c254.y, -r1.w
/*  160   */          mad r1.x___, r1.xxxx, c15.wwww, c254.yyyy
              +       retain_prev r1._
/*  161   */          mul r0.x_zw, r0.wxxz, c56.zxxy
              +       retain_prev r1._
/*  162   */          mul r0.x_zw, r0.xwwz, r1.xxxx
              +       mulsc r1.x___, c6.x, r1.y
/*  163   */          add r3.xyz_, -r0.xwzz, c7.zxyy
              +       maxs r1._, r8.ww
/*  164   */          mad r0.x_zw, r1.xxxx, r3.xyyz, r0.xwwz
              +       retain_prev r1._
/*   17.1 */       exec
/*  165   */          mad r1.xy_w, r9.xyzz, r1.wwww, r0.xwzz
              +       retain_prev r1._
/*  166   */          mul r0.x_zw, r8.yxxz, r1.wyyx
              +       muls_prev r1.___w, r1.z
/*   18.0 */       cjmp !b136, L40
/*   18.1 */       exec
/*  167   */          mad r2.___w, r0.yyyy, c13.yyyy, c13.zzzz
              +       retain_prev r1._
/*  168   */          add r1.x___, r0.yyyy, -c10.xxxx
              +       rsq r1._y__, r_abs[4].z
/*  169   */          mul r3.xyz_, r10.xyzz, r1.yyyy
              +       retain_prev r1._
/*  170   */          cndeq r4, c254.xxxy, r2.zxyy, c254.yyyy
              +       retain_prev r1._
/*  171   */          dp4 r1._y__, c11.zxyw, r4
              +       retain_prev r1._
/*  172   */          dp3 r1.__z_, r3.xzyy, c11.zxyy
              +       retain_prev r1._
/*   19.0 */       exec
/*  173   */          add r2.xyz_, -r0.xzww, c12.xyzz
              +       mulsc r0._y__, c10.z, r1.x
/*  174   */          min r3.xy__, r1.yzzz, c254.xzzz
              +       mulsc r1.x___, c10.w, r1.y
/*  175   */          max r1.__z_, r0.yyyy, r1.xxxx
              +       rcp r1._y__, r3.y
/*  176   */          max r1._, r1, r1
              +       mulsc r1.x___, c13.x, r1.y
/*  177   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  178   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*   19.1 */       exec
/*  179   */          min r1.x___, r1.xxxx, c12.wwww
              +       retain_prev r1._
/*  180   */          max r1.x___, r1.xxxx, c254.xxxx
              +       retain_prev r1._
/*  181   */          mad r0.x_zw, r2.xyyz, r1.xxxx, r0.xzzw
              +       retain_prev r1._
                label L40
/*   20.0 */       exece
/*  182   */          mul r1.xyz_, r0.xzww, c0.xxxx
              +       retain_prev r1._
/*  183   */          max oC0, r1, r1
/*   20.1 */       cnop
