/*    0.0 */       exec
/*    9   */          vfetch_full r1.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=6
/*   10   */          vfetch_mini r2, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   11   */          vfetch_mini r5, Offset=3, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   12   */          vfetch_mini r6, Offset=4, DataFormat=FMT_8_8_8_8
/*   13   */          vfetch_mini r0, Offset=5, DataFormat=FMT_8_8_8_8
/*   14   */          serialize
                      mul r7, r2, c255.wwww
/*    0.1 */       exec    // PredicateClean=false
/*   15   */          maxas r0._, r7.ww
/*   16   */          mul r4, r6.wwww, c[30+a0]
/*   17   */          mul r2, r6.wwww, c[29+a0]
              +       setp_gt r0._, r0.x
/*   18   */          mul r3, r6.wwww, c[28+a0]
              +       maxas r0._, r7.zz
/*   19   */          mad r3, r6.zzzz, c[28+a0].wyzx, r3.wyzx
/*   20   */          mad r2, r6.zzzz, c[29+a0].wyzx, r2.wyzx
/*    1.0 */       exec
/*   21   */          mad r4, r6.zzzz, c[30+a0].wyzx, r4.wyzx
/*   22   */          maxas r0._, r7.yy
/*   23   */          mad r4, r6.yyyy, c[30+a0].wzxy, r4.xzwy
/*   24   */          mad r2, r6.yyyy, c[29+a0].wzxy, r2.xzwy
/*   25   */          mad r3, r6.yyyy, c[28+a0].wzxy, r3.xzwy
/*   26   */          maxas r0._, r7.xx
/*    1.1 */       exec
/*   27   */          mad r3, r6.xxxx, c[28+a0], r3.zwyx
/*   28   */          mad r2, r6.xxxx, c[29+a0], r2.zwyx
/*   29   */          mad r4, r6.xxxx, c[30+a0].zyxw, r4.ywzx
/*    2.0 */  (p0) exec
/*   30   */     (p0) mul r5, r5, c255.wwww
/*   31   */     (p0) maxas r0._, r5.ww
/*   32   */     (p0) mad r4, r0.wwww, c[30+a0].xywz, r4.zywx
/*   33   */     (p0) mad r2, r0.wwww, c[29+a0].xywz, r2.xywz
/*   34   */     (p0) mad r3, r0.wwww, c[28+a0].xywz, r3.xywz
/*   35   */     (p0) maxas r0._, r5.zz
/*    2.1 */  (p0) exec
/*   36   */     (p0) mad r3, r0.zzzz, c[28+a0].wxzy, r3.zxwy
/*   37   */     (p0) mad r2, r0.zzzz, c[29+a0].wxzy, r2.zxwy
/*   38   */     (p0) mad r4, r0.zzzz, c[30+a0].wxzy, r4.zxwy
/*   39   */     (p0) maxas r0._, r5.yy
/*   40   */     (p0) mad r4, r0.yyyy, c[30+a0].wzyx, r4.xzwy
/*   41   */     (p0) mad r2, r0.yyyy, c[29+a0].wzyx, r2.xzwy
/*    3.0 */  (p0) exec
/*   42   */     (p0) mad r3, r0.yyyy, c[28+a0].wzyx, r3.xzwy
/*   43   */     (p0) maxas r0._, r5.xx
/*   44   */     (p0) mad r3, r0.xxxx, c[28+a0], r3.wzyx
/*   45   */     (p0) mad r2, r0.xxxx, c[29+a0], r2.wzyx
/*   46   */     (p0) mad r4, r0.xxxx, c[30+a0].zyxw, r4.yzwx
/*    3.1 */       exec
/*   47   */          mad r0.xyz_, r1.xyzz, c3.xyzz, c4.xyzz
/*   48   */          cndeq r1, c255.zzzx, r0.zxyy, c255.xxxx
/*   49   */          dp4 r0.x___, r3.zxyw, r1
/*   50   */          dp4 r0._y__, r2.zxyw, r1
/*   51   */          dp4 r0.__z_, r4.xzyw, r1
/*    4.0 */       cjmp !b0, L13
/*    4.1 */       exec
/*   52   */          cndeq r0, c255.zzzx, r0.zxyy, c255.xxxx
/*   53   */          dp4 r1.x___, c0.zxyw, r0
/*   54   */          dp4 r1._y__, c1.zxyw, r0
/*   55   */          dp4 r1.__z_, c2.zxyw, r0
/*   56   */          dp2add r0.x___, r1.xyyy, r1.xyyy, c255.zzzz
/*   57   */          dp3 r0._y__, r1.zxyy, r1.zxyy
/*    5.0 */       exec
/*   58   */          sqrt r0.___w, r_abs[0].y
/*   59   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   60   */          add r0._y__, -r1.zzzz, r0.wwww
/*   61   */          mul r2.xy__, r1.xyyy, r0.wwww
/*   62   */          mul r2.xy__, r2.yxxx, r0.yyyy
              +       rcp r0.x___, r0.x
/*   63   */          mul r0.xy__, r2.yxxx, r0.xxxx
/*    5.1 */       exec
/*   64   */          cndge r0.__zw, r1.zzzz, r0.zzzw, c255.xxxy
/*    6.0 */       jmp L14
                label L13
/*    6.1 */       exec
/*   65   */          cndeq r1, c255.zzzx, r0.zxyy, c255.xxxx
/*   66   */          dp4 r0.x___, c23.zxyw, r1
/*   67   */          dp4 r0._y__, c24.zxyw, r1
/*   68   */          dp4 r0.__z_, c25.zxyw, r1
/*   69   */          dp4 r0.___w, c26.zxyw, r1
                label L14
/*    7.0 */       alloc position
/*    7.1 */       exec
/*   70   */          max oPos, r0, r0
/*    8.0 */       alloc interpolators
/*    8.1 */       exece
