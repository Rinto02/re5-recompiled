/*    0.0 */       exec
/*   21   */          tfetch2D r11, r1.xy, tf0
/*   22   */          serialize
                      mul r4.xy__, c4.zwww, c3.xyyy
              +       maxs r2.___w, r11.ww
/*   23   */          add r7.xyz_, r2.zyxx, -c23.zyxx
              +       rcp r3.___w, r0.w
/*   24   */          mad r0.xy__, r3.wwww, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   25   */          mul r0.xy__, r4.xyyy, r0.yxxx
              +       subsc r2.___w, -c1.x, -r2.w
/*   26   */          kill_gt r1._, c255.xxxx, r2.wwww
              +       retain_prev r1._
/*    0.1 */       exec
/*   27   */          tfetch2D r0, r0.xy, tf1
/*   28   */          serialize
                      dp3 r2.___w, r3.zxyy, r3.zxyy
              +       retain_prev r1._
/*   29   */          mul r11.xyz_, r11.zyxx, c12.zyxx
              +       sgts r4._y__, -r_abs[1].x
/*   30   */          dp3 r3.___w, r7.xzyy, r7.xzyy
              +       sgts r4.__z_, -r_abs[1].x
/*   31   */          mul r0, r0.wzyx, c5.wzyx
              +       rsq r2.___w, r_abs[2].w
/*   32   */          mul r9.xyz_, r2.wwww, c18.zyxx
              +       sgts r4.x___, -r_abs[1].x
/*    1.0 */       exec
/*   33   */          mul r8.xyz_, r2.wwww, c17.zyxx
              +       mulsc r10.__z_, c16.x, r2.w
/*   34   */          mul r6.xyz_, r2.wwww, r3.zxyy
              +       mulsc r10._y__, c16.y, r2.w
/*   35   */          min r0, r0, c6.xxxx
              +       mulsc r10.x___, c16.z, r2.w
/*   36   */          max r5, r0.wzyx, c7.xxxx
              +       sqrt r0.___w, r_abs[3].w
/*    1.1 */       cjmp !b128, L19
/*    2.0 */       exec
/*   37   */          mul r12, r5.wzyx, c48.wzyx
              +       retain_prev r1._
/*   38   */          add r4.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   39   */          dp3 r4.___w, r4.xzyy, r4.xzyy
              +       retain_prev r1._
/*   40   */          max4 r0.__z_, r12.zxwy
              +       rsq r2.___w, r_abs[4].w
/*   41   */          mul r4, r4, r2.wwww
              +       retain_prev r1._
/*   42   */          dp3 r0._y__, r6.xyzz, r4.xzyy
              +       retain_prev r1._
/*    2.1 */       exec
/*   43   */          dp3 r2.___w, r4.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   44   */          add r0.x___, r4.wwww, -c32.wwww
              +       retain_prev r1._
/*   45   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r0.x
/*   46   */          max r0._y__, r0.yyyy, c255.xxxx
              +       mulsc r2.___w, c35.y, r2.w
/*   47   */          max r2.___w, r2.wwww, c35.wwww
              +       subsc r4.x___, c255.y, r0.x
/*   48   */          min r4._y__, r2.wwww, c255.yyyy
              +       subsc r2.___w, c255.y, r0.z
/*    3.0 */       exec
/*   49   */          mul r4.__z_, r4.xxxx, r4.yyyy
              +       retain_prev r1._
/*   50   */          mul r4._yzw, r4.yyzz, c32.xxzy
              +       retain_prev r1._
/*   51   */          mul r4.x___, r4.yyyy, r4.xxxx
              +       retain_prev r1._
/*   52   */          mul r0.xyz_, r4.xzww, r0.yyyy
              +       retain_prev r1._
/*   53   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       retain_prev r1._
/*   54   */          mul r4.xyz_, r0.xzyy, c35.zzzz
              +       retain_prev r1._
/*    3.1 */       cjmp !b129, L19
/*    4.0 */       exec
/*   55   */          mul r13, r5.wzyx, c49.wzyx
              +       retain_prev r1._
/*   56   */          add r12.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   57   */          dp3 r12.___w, r12.zxyy, r12.zxyy
              +       retain_prev r1._
/*   58   */          max4 r0.__z_, r13.zxwy
              +       rsq r2.___w, r_abs[12].w
/*   59   */          mul r12, r12, r2.wwww
              +       retain_prev r1._
/*   60   */          dp3 r0._y__, r6.xyzz, r12.zxyy
              +       retain_prev r1._
/*    4.1 */       exec
/*   61   */          dp3 r2.___w, r12.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   62   */          add r0.x___, r12.wwww, -c36.wwww
              +       retain_prev r1._
/*   63   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.x___, c37.w, r0.x
/*   64   */          max r0._y__, r0.yyyy, c255.xxxx
              +       mulsc r2.___w, c39.y, r2.w
/*   65   */          max r4.___w, r2.wwww, c39.wwww
              +       subsc r2.___w, c255.y, r0.z
/*   66   */          min r12.x___, r4.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.x
/*    5.0 */       exec
/*   67   */          mul r12._y__, r0.xxxx, r12.xxxx
              +       retain_prev r1._
/*   68   */          mul r12.xy_w, r12.yyxx, c36.zyxx
              +       retain_prev r1._
/*   69   */          mul r12.__z_, r12.wwww, r0.xxxx
              +       retain_prev r1._
/*   70   */          mul r0.xyz_, r12.xyzz, r0.yyyy
              +       retain_prev r1._
/*   71   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   72   */          mad r4.xyz_, r0.xzyy, c39.zzzz, r4.xyzz
              +       retain_prev r1._
/*    5.1 */       cjmp !b130, L19
/*    6.0 */       exec
/*   73   */          mul r13, r5, c50
              +       retain_prev r1._
/*   74   */          add r12.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   75   */          dp3 r12.___w, r12.xzyy, r12.xzyy
              +       retain_prev r1._
/*   76   */          max4 r0.x___, r13.ywxz
              +       rsq r2.___w, r_abs[12].w
/*   77   */          mul r12, r12, r2.wwww
              +       retain_prev r1._
/*   78   */          dp3 r4.___w, r6.xyzz, r12.xzyy
              +       retain_prev r1._
/*    6.1 */       exec
/*   79   */          dp3 r2.___w, r12.xzyy, -c42.zxyy
              +       retain_prev r1._
/*   80   */          add r0._y__, r12.wwww, -c40.wwww
              +       retain_prev r1._
/*   81   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r0.y
/*   82   */          max r0._y__, r4.wwww, c255.xxxx
              +       mulsc r2.___w, c43.y, r2.w
/*   83   */          max r4.___w, r2.wwww, c43.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   84   */          min r12.x___, r4.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.z
/*    7.0 */       exec
/*   85   */          mul r12._y__, r0.xxxx, r12.xxxx
              +       retain_prev r1._
/*   86   */          mul r12.xy_w, r12.yyxx, c40.zyxx
              +       retain_prev r1._
/*   87   */          mul r12.__z_, r12.wwww, r0.xxxx
              +       retain_prev r1._
/*   88   */          mul r0.xyz_, r12.xyzz, r0.yyyy
              +       retain_prev r1._
/*   89   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   90   */          mad r4.xyz_, r0.xzyy, c43.zzzz, r4.xyzz
              +       retain_prev r1._
/*    7.1 */       cjmp !b131, L19
/*    8.0 */       exec
/*   91   */          mul r13, r5.wzyx, c51.wzyx
              +       retain_prev r1._
/*   92   */          add r12.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*   93   */          dp3 r12.___w, r12.zxyy, r12.zxyy
              +       retain_prev r1._
/*   94   */          max4 r0.__z_, r13.zxwy
              +       rsq r2.___w, r_abs[12].w
/*   95   */          mul r12, r12, r2.wwww
              +       retain_prev r1._
/*   96   */          dp3 r0._y__, r6.xyzz, r12.zxyy
              +       retain_prev r1._
/*    8.1 */       exec
/*   97   */          dp3 r2.___w, r12.zxyy, -c46.zxyy
              +       retain_prev r1._
/*   98   */          add r0.x___, r12.wwww, -c44.wwww
              +       retain_prev r1._
/*   99   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.x___, c45.w, r0.x
/*  100   */          max r0._y__, r0.yyyy, c255.xxxx
              +       mulsc r2.___w, c47.y, r2.w
/*  101   */          max r4.___w, r2.wwww, c47.wwww
              +       subsc r2.___w, c255.y, r0.z
/*  102   */          min r12.x___, r4.wwww, c255.yyyy
              +       subsc r0.x___, c255.y, r0.x
/*    9.0 */       exec
/*  103   */          mul r12._y__, r0.xxxx, r12.xxxx
              +       retain_prev r1._
/*  104   */          mul r12.xy_w, r12.yyxx, c44.zyxx
              +       retain_prev r1._
/*  105   */          mul r12.__z_, r12.wwww, r0.xxxx
              +       retain_prev r1._
/*  106   */          mul r0.xyz_, r12.xyzz, r0.yyyy
              +       retain_prev r1._
/*  107   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  108   */          mad r4.xyz_, r0.xzyy, c47.zzzz, r4.xyzz
              +       retain_prev r1._
                label L19
/*    9.1 */       cjmp !b132, L31
/*   10.0 */       exec
/*  109   */          add r13.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  110   */          dp3 r13.___w, r13.xzyy, r13.xzyy
              +       retain_prev r1._
/*  111   */          mul r12, r5.wzyx, c52.wzyx
              +       rsq r2.___w, r_abs[13].w
/*  112   */          mul r13, r13, r2.wwww
              +       retain_prev r1._
/*  113   */          add r0.x___, r13.wwww, -c24.wwww
              +       retain_prev r1._
/*  114   */          dp3 r2.___w, r13.xzyy, r6.xyzz
              +       mulsc_sat r0.x___, c25.w, r0.x
/*   10.1 */       exec
/*  115   */          max4 r0._y__, r12.zxwy
              +       maxs r13.x___, r2.ww
/*  116   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r13._y__, c255.xx
/*  117   */          mul r12.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r13.xy
/*  118   */          mul r12.xyz_, r12.xyzz, r2.wwww
              +       retain_prev r1._
/*  119   */          mad r4.xyz_, r12.zxyy, r0.yyyy, r4.xyzz
              +       retain_prev r1._
/*   11.0 */       cjmp !b133, L31
/*   11.1 */       exec
/*  120   */          add r13.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  121   */          dp3 r13.___w, r13.zxyy, r13.zxyy
              +       retain_prev r1._
/*  122   */          mul r12, r5, c53
              +       rsq r2.___w, r_abs[13].w
/*  123   */          mul r13, r13, r2.wwww
              +       retain_prev r1._
/*  124   */          add r0.x___, r13.wwww, -c26.wwww
              +       retain_prev r1._
/*  125   */          dp3 r2.___w, r13.zxyy, r6.xyzz
              +       mulsc_sat r0.x___, c27.w, r0.x
/*   12.0 */       exec
/*  126   */          max4 r0._y__, r12.ywxz
              +       maxs r13.x___, r2.ww
/*  127   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r13._y__, c255.xx
/*  128   */          mul r12.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r13.xy
/*  129   */          mul r12.xyz_, r12.xyzz, r2.wwww
              +       retain_prev r1._
/*  130   */          mad r4.xyz_, r12.zxyy, r0.yyyy, r4.xyzz
              +       retain_prev r1._
/*   12.1 */       cjmp !b134, L31
/*   13.0 */       exec
/*  131   */          add r13.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  132   */          dp3 r13.___w, r13.xzyy, r13.xzyy
              +       retain_prev r1._
/*  133   */          mul r12, r5.wzyx, c54.wzyx
              +       rsq r2.___w, r_abs[13].w
/*  134   */          mul r13, r13, r2.wwww
              +       retain_prev r1._
/*  135   */          add r0.x___, r13.wwww, -c28.wwww
              +       retain_prev r1._
/*  136   */          dp3 r2.___w, r13.xzyy, r6.xyzz
              +       mulsc_sat r0.x___, c29.w, r0.x
/*   13.1 */       exec
/*  137   */          max4 r0._y__, r12.zxwy
              +       maxs r13.x___, r2.ww
/*  138   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r13._y__, c255.xx
/*  139   */          mul r12.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r13.xy
/*  140   */          mul r12.xyz_, r12.xyzz, r2.wwww
              +       retain_prev r1._
/*  141   */          mad r4.xyz_, r12.zxyy, r0.yyyy, r4.xyzz
              +       retain_prev r1._
/*   14.0 */       cjmp !b135, L31
/*   14.1 */       exec
/*  142   */          add r12.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  143   */          dp3 r12.___w, r12.zxyy, r12.zxyy
              +       retain_prev r1._
/*  144   */          mul r5, r5, c55
              +       rsq r2.___w, r_abs[12].w
/*  145   */          mul r12, r12, r2.wwww
              +       retain_prev r1._
/*  146   */          add r0.x___, r12.wwww, -c30.wwww
              +       retain_prev r1._
/*  147   */          dp3 r2.___w, r12.zxyy, r6.xyzz
              +       mulsc_sat r0.x___, c31.w, r0.x
/*   15.0 */       exec
/*  148   */          max4 r0._y__, r5.ywxz
              +       maxs r12.x___, r2.ww
/*  149   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r12._y__, c255.xx
/*  150   */          mul r5.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r12.xy
/*  151   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  152   */          mad r4.xyz_, r5.zxyy, r0.yyyy, r4.xyzz
              +       retain_prev r1._
                label L31
/*   15.1 */       exec
/*  153   */          tfetch2D r2.___x, r1.xy, tf2
/*   16.0 */       alloc colors
/*   16.1 */       exec
/*  154   */          mul r12, r6.xxzy, r6.yxxz
              +       retain_prev r1._
/*  155   */          dp3 r0.x___, r9.xzyy, r3.zxyy
              +       retain_prev r1._
/*  156   */          dp3 r1.x___, r8.xzyy, r3.zxyy
              +       retain_prev r1._
/*  157   */          mul r0._yz_, r6.yyzz, r6.yyzz
              +       retain_prev r1._
/*  158   */          dp3 r1._y__, r10.xzyy, r3.zxyy
              +       subs r3.x___, r0.yz
/*  159   */          dp4 r5.x___, r12.xywz, c19.wzxy
              +       addsc r6.x___, c16.w, r1.y
/*   17.0 */       exec    // PredicateClean=false
/*  160   */          dp4 r5._y__, r12.xywz, c20.wzxy
              +       addsc r6._y__, c17.w, r1.x
/*  161   */          dp4 r5.__z_, r12.xywz, c21.wzxy
              +       addsc r6.__z_, c18.w, r0.x
/*  162   */          add r0.xyz_, r6.zxyy, r5.zxyy
              +       setp_gt r1._, c_abs[14].x
/*  163   */          mad r0.xyz_, r3.xxxx, c22.xyzz, r0.yzxx
              +       retain_prev r1._
/*  164   */          mad r1.xy_w, r4.xyzz, r1.wwww, r0.xzyy
              +       retain_prev r1._
/*  165   */          mad r1.xy_w, r2.wwww, c13.zyxx, r1.ywxx
              +       retain_prev r1._
/*   17.1 */  (p0) exec
/*  166   */     (p0) mul r0.xyz_, r1.xyww, c57.xxxx
              +  (p0) retain_prev r1._
/*  167   */     (p0) mul r1.xy_w, r1.xyww, c58.xxxx
              +  (p0) retain_prev r1._
/*  168   */     (p0) mul r1.xy_w, r1.xyww, c56.xxxx
              +  (p0) retain_prev r1._
/*  169   */     (p0) mad r1.xy_w, r0.xyzz, c15.xxxx, r1.xyww
              +  (p0) retain_prev r1._
/*   18.0 */       exec
/*  170   */          mul r4, r11.zyxw, r1.wyxz
              +       retain_prev r1._
/*   18.1 */       cjmp !b136, L41
/*   19.0 */       exec
/*  171   */          mad r1.___w, r0.wwww, c11.yyyy, c11.zzzz
              +       retain_prev r1._
/*  172   */          add r1.x___, r0.wwww, -c8.xxxx
              +       rsq r1._y__, r_abs[3].w
/*  173   */          mul r0.xyz_, r7.xyzz, r1.yyyy
              +       retain_prev r1._
/*  174   */          cndeq r2, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  175   */          dp4 r1._y__, c9.zxyw, r2
              +       retain_prev r1._
/*  176   */          dp3 r1.__z_, r0.xzyy, c9.zxyy
              +       retain_prev r1._
/*   19.1 */       exec
/*  177   */          add r2.xyz_, -r4.xyzz, c10.xyzz
              +       mulsc r2.___w, c8.z, r1.x
/*  178   */          min r0.xy__, r1.yzzz, c255.xzzz
              +       mulsc r1.x___, c8.w, r1.y
/*  179   */          max r1.__z_, r2.wwww, r1.xxxx
              +       rcp r1._y__, r0.y
/*  180   */          max r1._, r1, r1
              +       mulsc r1.x___, c11.x, r1.y
/*  181   */          mad r1.x___, r1.xxxx, r0.xxxx, r1.wwww
              +       retain_prev r1._
/*  182   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*   20.0 */       exec
/*  183   */          min r1.x___, r1.xxxx, c10.wwww
              +       retain_prev r1._
/*  184   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*  185   */          mad r4.xyz_, r2.xyzz, r1.xxxx, r4.xyzz
              +       retain_prev r1._
                label L41
/*   20.1 */       exece
/*  186   */          mul r4.xyz_, r4.zyxx, c0.xxxx
              +       retain_prev r1._
/*  187   */          max oC0, r4.zyxw, r4.zyxw
