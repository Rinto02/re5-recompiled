/*    0.0 */       exec
/*   13   */          tfetch2D r0.___x, r0.xy, tf1, FetchValidOnly=false
/*   14   */          serialize
                      mul r1.x___, c1.xxxx, c56.xxxx
              +       subsc r1._y__, c255.z, r0.w
/*   15   */          mad r0.__z_, r1.yyyy, c54.xxxx, -c55.xxxx
/*   16   */          mul r3.x___, r1.xxxx, r_abs[0].zzzz
/*   17   */          mul r0.__z_, r_abs[0].zzzz, c56.xxxx
/*   18   */          mul r2.xy__, r0.zzzz, c2.xyyy
              +       mulsc r3._y__, c1.y, r0.z
/*    0.1 */       exec
/*   19   */          mul r2.__zw, r0.zzzz, c3.xxxy
              +       mulsc r3.__z_, c0.x, r0.z
/*   20   */          add r2, r2, r0.xyxy
              +       mulsc r3.___w, c0.y, r0.z
/*   21   */          add r3, r3.zwxy, r0.xyxy
/*   22   */          tfetch2D r8, r3.xy, tf2
/*   23   */          tfetch2D r6, r3.zw, tf2
/*   24   */          tfetch2D r5, r2.xy, tf2
/*    1.0 */       exec
/*   25   */          tfetch2D r1.x_yz, r0.xy, tf0
/*   26   */          tfetch2D r4, r2.zw, tf2
/*   27   */          serialize
                      add r2.___w, c51.xxxx, -c49.xxxx
              +       maxs r0._, c49.xx
/*   28   */          add r2.x___, -c49.xxxx, c255.zzzz
              +       adds_prev r3._y__, -c50.x
/*   29   */          mad r5.xyz_, r5.xyzz, c48.xyzz, -r1.xzww
/*   30   */          mad r7.xyz_, r6.xyzz, c48.xyzz, -r1.xzww
/*    1.1 */       exec
/*   31   */          mad r8.xyz_, r8.xyzz, c48.xyzz, -r1.xzww
/*   32   */          add r3.__z_, r2.xxxx, -r0.wwww
              +       rcp r3.x___, r2.w
/*   33   */          add r2.x___, r6.wwww, -c49.xxxx
              +       rcp r2.__z_, r2.w
/*   34   */          add r2._y__, r5.wwww, -c49.xxxx
              +       rcp r9.x___, r2.w
/*   35   */          add r0.___w, r8.wwww, -c49.xxxx
              +       rcp r9._y__, r3.y
/*   36   */          mul r10.__zw, r0.wwww, r9.xxxy
              +       rcp r2.___w, r3.y
/*    2.0 */       exec
/*   37   */          mul r6.xyz_, r4.xyzz, c48.xyzz
/*   38   */          sgt r9._y__, c49.xxxx, r8.wwww
/*   39   */          sgt r9.__z_, c49.xxxx, r6.wwww
/*   40   */          sgt r9.___w, c49.xxxx, r5.wwww
/*   41   */          sgt r9.x___, c49.xxxx, r1.yyyy
              +       subsc r3.___w, -c49.x, -r1.y
/*   42   */          mul r2, r2.xyxy, r2.zzww
              +       rcp r3._y__, r3.y
/*    2.1 */       exec
/*   43   */          mul r10.xy__, r3.zwww, r3.xyyy
/*   44   */          max r2.__zw, r2.zzzw, -c53.xxxx
/*   45   */          max r3.__zw, r2.xxxy, c255.xxxx
/*   46   */          max r2.xy__, r10.ywww, -c53.xxxx
/*   47   */          max r3.xy__, r10.xzzz, c255.xxxx
/*   48   */          min r3, r3, c52.xxxx
/*    3.0 */       exec
/*   49   */          min r2, r2, c255.xxxx
/*   50   */          cndeq r3, r9.yxzw, r3.yxzw, r2.yxzw
/*   51   */          sgt r1._y__, c49.xxxx, r4.wwww
              +       sgts r9.x___, -r3.x
/*   52   */          max r2, r_abs[3], r_abs[3].yyyy
              +       sgts r9._y__, -r3.z
/*   53   */          sgt r10.xyz_, r3.yyyy, r3.xzww
              +       sgts r9.__z_, -r3.w
/*   54   */          mul r9.xyz_, r10.xyzz, r9.xyzz
/*    3.1 */       exec    // PredicateClean=false
/*   55   */          cndeq r2.xyz_, r9.xyzz, r2.yyyy, r2.xzww
/*   56   */          mul r4.xyz_, r8.xyzz, r2.xxxx
              +       maxs r0.___w, r4.ww
/*   57   */          mul r9.xyz_, r7.xyzz, r2.yyyy
              +       subsc r0.___w, -c49.x, -r0.w
/*   58   */          mul r8.xyz_, r5.xyzz, r2.zzzz
              +       setp_ne r0._, r1.y
/*   59   */     (p0) add r1._y__, c49.xxxx, -c50.xxxx
/*   60   */     (p0) rcp r1._y__, r1.y
/*    4.0 */       exec
/*   61   */     (p0) mul r0.___w, r0.wwww, r1.yyyy
/*   62   */     (p0) max r0.___w, r0.wwww, -c53.xxxx
/*   63   */     (p0) min r3.x___, r0.wwww, c255.xxxx
/*   64   */    (!p0) add r1._y__, c51.xxxx, -c49.xxxx
/*   65   */    (!p0) rcp r1._y__, r1.y
/*   66   */    (!p0) mul r0.___w, r0.wwww, r1.yyyy
/*    4.1 */       exec
/*   67   */    (!p0) max r0.___w, r0.wwww, c255.xxxx
/*   68   */    (!p0) min r3.x___, r0.wwww, c52.xxxx
/*   69   */          mad r2.xy__, r0.zzzz, c4.xyyy, r0.xyyy
/*   70   */          tfetch2D r2.xywz, r2.xy, tf2
/*   71   */          serialize
                      sgt r4.___w, r3.yyyy, r3.xxxx
              +       sgts r1._y__, -r3.x
/*   72   */          mul r5.xyz_, r2.xyww, c48.xyzz
              +       maxs r0.___w, r2.zz
/*    5.0 */       exec    // PredicateClean=false
/*   73   */          add r6.xyz_, r6.xyzz, -r1.xzww
              +       subsc r0.___w, -c49.x, -r0.w
/*   74   */          max r2.xy__, r_abs[3].xyyy, r_abs[3].yyyy
              +       maxs r0._, r4.ww
/*   75   */          sgt r2.__z_, c49.xxxx, r2.zzzz
              +       muls_prev r1._y__, r1.y
/*   76   */          cndeq r1._y__, r1.yyyy, r2.yyyy, r2.xxxx
/*   77   */          mul r7.xyz_, r6.xyzz, r1.yyyy
              +       setp_ne r0._, r2.z
/*   78   */     (p0) add r1._y__, c49.xxxx, -c50.xxxx
/*    5.1 */       exec
/*   79   */     (p0) rcp r1._y__, r1.y
/*   80   */     (p0) mul r0.___w, r0.wwww, r1.yyyy
/*   81   */     (p0) max r0.___w, r0.wwww, -c53.xxxx
/*   82   */     (p0) min r3.x___, r0.wwww, c255.xxxx
/*   83   */    (!p0) add r1._y__, c51.xxxx, -c49.xxxx
/*   84   */    (!p0) rcp r1._y__, r1.y
/*    6.0 */       exec
/*   85   */    (!p0) mul r0.___w, r0.wwww, r1.yyyy
/*   86   */    (!p0) max r0.___w, r0.wwww, c255.xxxx
/*   87   */    (!p0) min r3.x___, r0.wwww, c52.xxxx
/*   88   */          mad r2.xy__, r0.zzzz, c5.xyyy, r0.xyyy
/*   89   */          tfetch2D r2.xywz, r2.xy, tf2
/*   90   */          serialize
                      sgt r4.___w, r3.yyyy, r3.xxxx
              +       sgts r1._y__, -r3.x
/*    6.1 */       exec    // PredicateClean=false
/*   91   */          mul r6.xyz_, r2.xyww, c48.xyzz
              +       maxs r0.___w, r2.zz
/*   92   */          add r5.xyz_, r5.xyzz, -r1.xzww
              +       subsc r0.___w, -c49.x, -r0.w
/*   93   */          max r2.xy__, r_abs[3].xyyy, r_abs[3].yyyy
              +       maxs r0._, r4.ww
/*   94   */          sgt r2.__z_, c49.xxxx, r2.zzzz
              +       muls_prev r1._y__, r1.y
/*   95   */          cndeq r1._y__, r1.yyyy, r2.yyyy, r2.xxxx
/*   96   */          mul r5.xyz_, r5.xyzz, r1.yyyy
              +       setp_ne r0._, r2.z
/*    7.0 */       exec
/*   97   */     (p0) add r1._y__, c49.xxxx, -c50.xxxx
/*   98   */     (p0) rcp r1._y__, r1.y
/*   99   */     (p0) mul r0.___w, r0.wwww, r1.yyyy
/*  100   */     (p0) max r0.___w, r0.wwww, -c53.xxxx
/*  101   */     (p0) min r3.x___, r0.wwww, c255.xxxx
/*  102   */    (!p0) add r1._y__, c51.xxxx, -c49.xxxx
/*    7.1 */       exec
/*  103   */    (!p0) rcp r1._y__, r1.y
/*  104   */    (!p0) mul r0.___w, r0.wwww, r1.yyyy
/*  105   */    (!p0) max r0.___w, r0.wwww, c255.xxxx
/*  106   */    (!p0) min r3.x___, r0.wwww, c52.xxxx
/*  107   */          mad r2.xy__, r0.zzzz, c6.xyyy, r0.xyyy
/*  108   */          tfetch2D r10, r2.xy, tf2
/*    8.0 */       exec
/*  109   */          serialize
                      sgt r2.__z_, r3.yyyy, r3.xxxx
              +       sgts r2.___w, -r3.x
/*  110   */          mul r11.xyz_, r10.xyzz, c48.xyzz
              +       maxs r0.___w, r10.ww
/*  111   */          add r6.xyz_, r6.xyzz, -r1.xzww
              +       subsc r1._y__, -c49.x, -r0.w
/*  112   */          max r2.xy__, r_abs[3].xyyy, r_abs[3].yyyy
              +       maxs r0._, r2.zz
/*  113   */          sgt r2.__z_, c49.xxxx, r10.wwww
              +       muls_prev r0.___w, r2.w
/*  114   */          cndeq r0.___w, r0.wwww, r2.yyyy, r2.xxxx
/*    8.1 */       exec    // PredicateClean=false
/*  115   */          mul r10.xyz_, r6.xyzz, r0.wwww
              +       setp_ne r0._, r2.z
/*  116   */     (p0) add r0.___w, c49.xxxx, -c50.xxxx
/*  117   */     (p0) rcp r0.___w, r0.w
/*  118   */     (p0) mul r0.___w, r1.yyyy, r0.wwww
/*  119   */     (p0) max r0.___w, r0.wwww, -c53.xxxx
/*  120   */     (p0) min r3.x___, r0.wwww, c255.xxxx
/*    9.0 */       exec
/*  121   */    (!p0) add r0.___w, c51.xxxx, -c49.xxxx
/*  122   */    (!p0) rcp r0.___w, r0.w
/*  123   */    (!p0) mul r0.___w, r1.yyyy, r0.wwww
/*  124   */    (!p0) max r0.___w, r0.wwww, c255.xxxx
/*  125   */    (!p0) min r3.x___, r0.wwww, c52.xxxx
/*  126   */          mad r0.xy__, r0.zzzz, c7.xyyy, r0.xyyy
/*    9.1 */       exec
/*  127   */          tfetch2D r0, r0.xy, tf2
/*   10.0 */       alloc colors
/*   10.1 */       exec
/*  128   */          sgt r2.___w, r3.yyyy, r3.xxxx
              +       sgts r1._y__, -r3.x
/*  129   */          mul r6.xyz_, r0.xyzz, c48.xyzz
              +       maxs r0._y__, r0.ww
/*  130   */          add r2.xyz_, r11.xyzz, -r1.xzww
              +       subsc r0.__z_, -c49.x, -r0.y
/*  131   */          max r0.xy__, r_abs[3].xyyy, r_abs[3].yyyy
              +       maxs r0._, r2.ww
/*  132   */          sgt r0.___w, c49.xxxx, r0.wwww
              +       muls_prev r1._y__, r1.y
/*  133   */          cndeq r0.x___, r1.yyyy, r0.yyyy, r0.xxxx
/*   11.0 */       exec    // PredicateClean=false
/*  134   */          mul r2.xyz_, r2.xyzz, r0.xxxx
              +       setp_ne r0._, r0.w
/*  135   */     (p0) add r0.x___, c49.xxxx, -c50.xxxx
/*  136   */     (p0) rcp r0.x___, r0.x
/*  137   */     (p0) mul r0.x___, r0.zzzz, r0.xxxx
/*  138   */     (p0) max r0.x___, r0.xxxx, -c53.xxxx
/*  139   */     (p0) min r3.x___, r0.xxxx, c255.xxxx
/*   11.1 */       exec
/*  140   */    (!p0) add r0.x___, c51.xxxx, -c49.xxxx
/*  141   */    (!p0) rcp r0.x___, r0.x
/*  142   */    (!p0) mul r0.x___, r0.zzzz, r0.xxxx
/*  143   */    (!p0) max r0.x___, r0.xxxx, c255.xxxx
/*  144   */    (!p0) min r3.x___, r0.xxxx, c52.xxxx
/*  145   */          sgt r0.x___, r3.yyyy, r3.xxxx
              +       sgts r0.__z_, -r3.x
/*   12.0 */       exec
/*  146   */          add r6.xyz_, r6.xyzz, -r1.xzww
              +       maxs r0._, r0.xx
/*  147   */          max r0.xy__, r_abs[3].xyyy, r_abs[3].yyyy
              +       muls_prev r0.__z_, r0.z
/*  148   */          cndeq r0.x___, r0.zzzz, r0.yyyy, r0.xxxx
/*  149   */          mad r0.xyz_, r6.xyzz, r0.xxxx, r2.xyzz
/*  150   */          add r0.xyz_, r0.xyzz, r10.xyzz
/*  151   */          add r0.xyz_, r0.xyzz, r5.xyzz
/*   12.1 */       exece
/*  152   */          add r0.xyz_, r0.xyzz, r7.xyzz
/*  153   */          add r0.xyz_, r0.xyzz, r8.xyzz
/*  154   */          add r0.xyz_, r0.xyzz, r9.xyzz
/*  155   */          add r0.xyz_, r0.xyzz, r4.xyzz
/*  156   */          mad r0.xyz_, r1.xzww, c255.yyyy, r0.xyzz
/*  157   */          mul oC0.xyz1, r0.xyzz, c255.wwww
