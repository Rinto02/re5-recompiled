/*    0.0 */       exec
/*    2   */          tfetch2D r0.xyz_, r0.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    3   */          mul oC0.xyz1, r0.xyzz, c48.xyzz
/*    1.1 */       cnop
