/*    0.0 */       exec
/*    8   */          vfetch_full r1.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    9   */          vfetch_mini r0._x__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   10   */          vfetch_mini r5.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   11   */          vfetch_mini r0.__yx, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   12   */          serialize
                      mad r2.xyz_, r1.xyzz, c3.xyzz, c4.xyzz
/*   13   */          mulsc r0.x___, c255.w, r0.y
/*    0.1 */       exec
/*   14   */          maxas r0._, r0.xx
/*   15   */          max r6, c[28+a0], c[28+a0]
/*   16   */          max r4, c[29+a0], c[29+a0]
/*   17   */          max r1, c[30+a0], c[30+a0]
/*   18   */          cndeq r2, c255.zzzx, r2.zxyy, c255.xxxx
/*   19   */          dp4 r3.x___, r6.zxyw, r2
/*    1.0 */       exec
/*   20   */          dp4 r3._y__, r4.zxyw, r2
/*   21   */          dp4 r3.__z_, r1.zxyw, r2
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   22   */          cndeq r2, c255.zzzx, r3.zxyy, c255.xxxx
/*   23   */          dp4 r7.x___, c0.zxyw, r2
/*   24   */          dp4 r7._y__, c1.zxyw, r2
/*   25   */          dp4 r7.__z_, c2.zxyw, r2
/*   26   */          dp2add r2.x___, r7.xyyy, r7.xyyy, c255.zzzz
/*   27   */          dp3 r0.x___, r7.zxyy, r7.zxyy
/*    2.1 */       exec
/*   28   */          sqrt r0._y__, r_abs[0].x
/*   29   */          mad r0.x___, r0.yyyy, c27.xxxx, c27.yyyy
/*   30   */          add r2._y__, -r7.zzzz, r0.yyyy
/*   31   */          mul r2.__zw, r7.xxxy, r0.yyyy
/*   32   */          mul r2._yz_, r2.wwzz, r2.yyyy
              +       rcp r2.x___, r2.x
/*   33   */          mul r2.xy__, r2.zyyy, r2.xxxx
/*    3.0 */       exec
/*   34   */          cndge r2.__zw, r7.zzzz, r0.xxxy, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   35   */          cndeq r7, c255.zzzx, r3.zxyy, c255.xxxx
/*   36   */          dp4 r2.x___, c23.zxyw, r7
/*   37   */          dp4 r2._y__, c24.zxyw, r7
/*   38   */          dp4 r2.__z_, c25.zxyw, r7
/*   39   */          dp4 r2.___w, c26.zxyw, r7
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   40   */          max oPos, r2, r2
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   41   */          dp3 r2.x___, r5.zxyy, r6.zxyy
/*   42   */          dp3 r2._y__, r5.zxyy, r4.zxyy
/*   43   */          dp3 r0.x___, r3.zxyy, c2.zxyy
/*   44   */          dp3 r2.__z_, r5.zxyy, r1.zxyy
              +       addsc r1.___w, -c2.w, -r0.x
/*   45   */          add o4.xy__, r0.zwww, c5.xyyy
/*   46   */          mad r3.xyz_, -r1.wwww, c6.xyzz, r3.xyzz
/*    6.1 */       exec
/*   47   */          dp3 r0.x___, r2.zxyy, r2.zxyy
/*   48   */          sge r3.___w, r_abs[0].xxxx, c255.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   49   */          dp4 o1.x___, c220.zxyw, r3.zxyw
/*   50   */          dp4 o1._y__, c221.zxyw, r3.zxyw
/*   51   */          dp4 o1.__z_, c222.zxyw, r3.zxyw
/*   52   */          dp4 o1.___w, c223.zxyw, r3.zxyw
/*    7.0 */       exec
/*   53   */          dp4 o2.x___, c224.zxyw, r3.zxyw
/*   54   */          dp4 o2._y__, c225.zxyw, r3.zxyw
/*   55   */          dp4 o2.__z_, c226.zxyw, r3.zxyw
/*   56   */          dp4 o2.___w, c227.zxyw, r3.zxyw
/*   57   */          dp4 o3.x___, c228.zxyw, r3.zxyw
/*   58   */          dp4 o3._y__, c229.zxyw, r3.zxyw
/*    7.1 */       exece
/*   59   */          dp4 o3.__z_, c230.zxyw, r3.zxyw
/*   60   */          dp4 o3.___w, c231.zxyw, r3.zxyw
/*   61   */          mul r1.xyz_, r2.xyzz, r0.xxxx
/*   62   */          max o0, r1, r1
