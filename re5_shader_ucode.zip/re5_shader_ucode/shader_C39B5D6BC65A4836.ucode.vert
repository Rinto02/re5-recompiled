/*    0.0 */       exec
/*    9   */          vfetch_full r0._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*   10   */          vfetch_mini r4.zwxy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   11   */          vfetch_mini r3, Offset=3, DataFormat=FMT_8_8_8_8
/*   12   */          vfetch_mini r7.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   13   */          vfetch_mini r1.___w, Offset=5, DataFormat=FMT_8_8_8_8, Signed=true
/*   14   */          vfetch_mini r1.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       exec    // PredicateClean=false
/*   15   */          serialize
                      mul r8.xy__, r4.zwww, c255.wwww
/*   16   */          maxas r0._, r8.yy
/*   17   */          mul r5, r3.yyyy, c[30+a0]
/*   18   */          mul r6, r3.yyyy, c[29+a0]
              +       setp_gt r0._, r3.z
/*   19   */          mul r2, r3.yyyy, c[28+a0]
              +       maxas r0._, r8.xx
/*   20   */          mad r2, r3.xxxx, c[28+a0], r2
/*    1.0 */       exec
/*   21   */          mad r6, r3.xxxx, c[29+a0], r6
/*   22   */          mad r5, r3.xxxx, c[30+a0], r5
/*    1.1 */  (p0) exec
/*   23   */     (p0) mul r3.xy__, r4.xyyy, c255.wwww
/*   24   */     (p0) maxas r0._, r3.yy
/*   25   */     (p0) mad r4, r3.wwww, c[30+a0], r5
/*   26   */     (p0) mad r5, r3.wwww, c[29+a0], r6
/*   27   */     (p0) mad r2, r3.wwww, c[28+a0], r2
/*   28   */     (p0) maxas r0._, r3.xx
/*    2.0 */  (p0) exec
/*   29   */     (p0) mad r2, r3.zzzz, c[28+a0], r2
/*   30   */     (p0) mad r6, r3.zzzz, c[29+a0], r5
/*   31   */     (p0) mad r5, r3.zzzz, c[30+a0], r4
/*    2.1 */       exec
/*   32   */          mad r0.xyz_, r0.yzww, c3.xyzz, c4.xyzz
/*   33   */          cndeq r3, c255.zzzx, r0.zxyy, c255.xxxx
/*   34   */          dp4 r0.x___, r2.zxyw, r3
/*   35   */          dp4 r0._y__, r6.zxyw, r3
/*   36   */          dp4 r0.__z_, r5.zxyw, r3
/*    3.0 */       cjmp !b0, L11
/*    3.1 */       exec
/*   37   */          cndeq r3, c255.zzzx, r0.zxyy, c255.xxxx
/*   38   */          dp4 r4.x___, c0.zxyw, r3
/*   39   */          dp4 r4._y__, c1.zxyw, r3
/*   40   */          dp4 r4.__z_, c2.zxyw, r3
/*   41   */          dp2add r0.___w, r4.xyyy, r4.xyyy, c255.zzzz
/*   42   */          dp3 r1.__z_, r4.zxyy, r4.zxyy
/*    4.0 */       exec
/*   43   */          sqrt r3._y__, r_abs[1].z
/*   44   */          mad r3.x___, r3.yyyy, c27.xxxx, c27.yyyy
/*   45   */          add r1.__z_, -r4.zzzz, r3.yyyy
/*   46   */          mul r3.__zw, r4.xxxy, r3.yyyy
/*   47   */          mul r3.__zw, r3.wwwz, r1.zzzz
              +       rcp r0.___w, r0.w
/*   48   */          mul r3.__zw, r3.wwwz, r0.wwww
/*    4.1 */       exec
/*   49   */          cndge r3.xy__, r4.zzzz, r3.xyyy, c255.xyyy
/*    5.0 */       jmp L12
                label L11
/*    5.1 */       exec
/*   50   */          cndeq r4, c255.zzzx, r0.zxyy, c255.xxxx
/*   51   */          dp4 r3.__z_, c23.zxyw, r4
/*   52   */          dp4 r3.___w, c24.zxyw, r4
/*   53   */          dp4 r3.x___, c25.zxyw, r4
/*   54   */          dp4 r3._y__, c26.zxyw, r4
                label L12
/*    6.0 */       alloc position
/*    6.1 */       exec
/*   55   */          mad r3.x___, -r3.yyyy, c7.xxxx, r3.xxxx
/*   56   */          max oPos, r3.zwxy, r3.zwxy
/*    7.0 */       alloc interpolators
/*    7.1 */       exec
/*   57   */          dp3 r2.x___, r7.zxyy, r2.zxyy
/*   58   */          dp3 r2._y__, r7.zxyy, r6.zxyy
/*   59   */          dp3 r2.__z_, r7.zxyy, r5.zxyy
/*   60   */          add r1.xy__, r1.xyyy, c6.xyyy
              +       maxs r1.__z_, c5.xx
/*   61   */          max o2.xyz_, r0.xyzz, r0.xyzz
/*   62   */          max o1, r1, r1
/*    8.0 */       exece
/*   63   */          max o0, r3.zwxy, r3.zwxy
/*   64   */          dp3 r0.x___, r2.zxyy, r2.zxyy
/*   65   */          rsq r0.x___, r_abs[0].x
/*   66   */          mul o3.xyz_, r2.xyzz, r0.xxxx
/*    8.1 */       cnop
