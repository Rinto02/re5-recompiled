/*    0.0 */       alloc colors
/*    0.1 */       exece
/*    1   */          mul oC0.xyz_, r0.xyzz, c23.wwww
              +       maxs oC0.___w, r0.ww
