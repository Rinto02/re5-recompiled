/*    0.0 */       exec
/*    7   */          vfetch_full r3.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=7
/*    8   */          vfetch_mini r6.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*    9   */          vfetch_mini r7.___w, Offset=4, DataFormat=FMT_8_8_8_8, Signed=true
/*   10   */          vfetch_mini r1.__yx, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   11   */          vfetch_mini r1.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   12   */          serialize
                      max r0, c28, c28
/*    0.1 */       exec
/*   13   */          max r5, c29, c29
/*   14   */          max r2, c30, c30
/*   15   */          cndeq r3, c255.zzzx, r3.zxyy, c255.xxxx
/*   16   */          dp4 r4.x___, r0.zxyw, r3
/*   17   */          dp4 r4._y__, r5.zxyw, r3
/*   18   */          dp4 r4.__z_, r2.zxyw, r3
/*    1.0 */       cjmp !b0, L7
/*    1.1 */       exec
/*   19   */          cndeq r3, c255.zzzx, r4.zxyy, c255.xxxx
/*   20   */          dp4 r7.x___, c0.zxyw, r3
/*   21   */          dp4 r7._y__, c1.zxyw, r3
/*   22   */          dp4 r7.__z_, c2.zxyw, r3
/*   23   */          dp2add r3.x___, r7.xyyy, r7.xyyy, c255.zzzz
/*   24   */          dp3 r3._y__, r7.zxyy, r7.zxyy
/*    2.0 */       exec
/*   25   */          sqrt r3.___w, r_abs[3].y
/*   26   */          mad r3.__z_, r3.wwww, c27.xxxx, c27.yyyy
/*   27   */          add r3._y__, -r7.zzzz, r3.wwww
/*   28   */          mul r8.xy__, r7.xyyy, r3.wwww
/*   29   */          mul r8.xy__, r8.yxxx, r3.yyyy
              +       rcp r3.x___, r3.x
/*   30   */          mul r3.xy__, r8.yxxx, r3.xxxx
/*    2.1 */       exec
/*   31   */          cndge r3.__zw, r7.zzzz, r3.zzzw, c255.xxxy
/*    3.0 */       jmp L8
                label L7
/*    3.1 */       exec
/*   32   */          cndeq r8, c255.zzzx, r4.zxyy, c255.xxxx
/*   33   */          dp4 r3.x___, c23.zxyw, r8
/*   34   */          dp4 r3._y__, c24.zxyw, r8
/*   35   */          dp4 r3.__z_, c25.zxyw, r8
/*   36   */          dp4 r3.___w, c26.zxyw, r8
                label L8
/*    4.0 */       alloc position
/*    4.1 */       exec
/*   37   */          mad r3.__z_, -r3.wwww, c5.xxxx, r3.zzzz
/*   38   */          max oPos, r3, r3
/*    5.0 */       alloc interpolators
/*    5.1 */       exec
/*   39   */          add r7.xy__, r1.zwww, c3.xyyy
              +       maxs r7.__z_, c31.xx
/*   40   */          dp3 o4.x___, r6.zxyy, r0.zxyy
/*   41   */          dp3 o4._y__, r6.zxyy, r5.zxyy
/*   42   */          dp3 o4.__z_, r6.zxyy, r2.zxyy
/*   43   */          add o3.xy__, r1.xyyy, c4.xyyy
/*   44   */          max o2.xyz_, r4.xyzz, r4.xyzz
/*    6.0 */       exece
/*   45   */          max o1, r7, r7
/*   46   */          max o0, r3, r3
/*    6.1 */       cnop
