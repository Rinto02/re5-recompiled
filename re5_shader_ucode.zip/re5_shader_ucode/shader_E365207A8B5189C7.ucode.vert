/*    0.0 */       exec
/*    7   */          vfetch_full r1.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*    8   */          vfetch_mini r7.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*    9   */          vfetch_mini r5.__w_, Offset=4, DataFormat=FMT_8_8_8_8, Signed=true
/*   10   */          vfetch_mini r5.yx__, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   11   */          vfetch_mini r2.__yx, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   12   */          vfetch_mini r2.yx__, Offset=7, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       exec
/*   13   */          serialize
                      max r0, c28, c28
/*   14   */          max r6, c29, c29
/*   15   */          max r3, c30, c30
/*   16   */          cndeq r4, c255.zzzx, r1.zxyy, c255.xxxx
/*   17   */          dp4 r1.x___, r0.zxyw, r4
/*   18   */          dp4 r1._y__, r6.zxyw, r4
/*    1.0 */       exec
/*   19   */          dp4 r1.__z_, r3.zxyw, r4
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   20   */          cndeq r4, c255.zzzx, r1.zxyy, c255.xxxx
/*   21   */          dp4 r8.x___, c0.zxyw, r4
/*   22   */          dp4 r8._y__, c1.zxyw, r4
/*   23   */          dp4 r8.__z_, c2.zxyw, r4
/*   24   */          dp2add r1.___w, r8.xyyy, r8.xyyy, c255.zzzz
/*   25   */          dp3 r4.x___, r8.zxyy, r8.zxyy
/*    2.1 */       exec
/*   26   */          sqrt r4.___w, r_abs[4].x
/*   27   */          mad r4.__z_, r4.wwww, c27.xxxx, c27.yyyy
/*   28   */          add r4.x___, -r8.zzzz, r4.wwww
/*   29   */          mul r9.xy__, r8.xyyy, r4.wwww
/*   30   */          mul r4.xy__, r9.yxxx, r4.xxxx
              +       rcp r1.___w, r1.w
/*   31   */          mul r4.xy__, r4.yxxx, r1.wwww
/*    3.0 */       exec
/*   32   */          cndge r4.__zw, r8.zzzz, r4.zzzw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   33   */          cndeq r8, c255.zzzx, r1.zxyy, c255.xxxx
/*   34   */          dp4 r4.x___, c23.zxyw, r8
/*   35   */          dp4 r4._y__, c24.zxyw, r8
/*   36   */          dp4 r4.__z_, c25.zxyw, r8
/*   37   */          dp4 r4.___w, c26.zxyw, r8
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   38   */          mad r4.__z_, -r4.wwww, c5.xxxx, r4.zzzz
/*   39   */          max oPos, r4, r4
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   40   */          add r5.xy__, r5.xyyy, c3.xyyy
              +       maxs r5.___w, c31.xx
/*   41   */          dp3 o5.x___, r7.zxyy, r0.zxyy
/*   42   */          dp3 o5._y__, r7.zxyy, r6.zxyy
/*   43   */          dp3 o5.__z_, r7.zxyy, r3.zxyy
/*   44   */          max o3.xy__, r2.zwww, r2.zwww
/*   45   */          add o4.xy00, r2.xyyy, c4.zwww
/*    6.1 */       exece
/*   46   */          max o2.xyz_, r1.xyzz, r1.xyzz
/*   47   */          max o1, r5.xywz, r5.xywz
/*   48   */          max o0, r4, r4
