/*    0.0 */       exec
/*   11   */          vfetch_full r7.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=5
/*   12   */          vfetch_mini r1.xy__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   13   */          vfetch_mini r0._x__, Offset=3, DataFormat=FMT_8_8_8_8
/*   14   */          vfetch_mini r10.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   15   */          serialize
                      add r0.x_z_, r1.xyyy, c4.xxxx
/*   16   */          mul r0.__zw, r0.xxxz, c4.zzzz
              +       maxs r0.x___, c4.yy
/*    0.1 */       exec
/*   17   */          tfetch2D r2, r0.wx, tf16, UseComputedLOD=false, OffsetX=1
/*   18   */          tfetch2D r3, r0.wx, tf16, UseComputedLOD=false
/*   19   */          tfetch2D r5, r0.zx, tf16, UseComputedLOD=false, OffsetX=2
/*   20   */          tfetch2D r4, r0.zx, tf16, UseComputedLOD=false, OffsetX=1
/*   21   */          tfetch2D r6, r0.zx, tf16, UseComputedLOD=false
/*   22   */          tfetch2D r15, r0.wx, tf16, UseComputedLOD=false, OffsetX=2
/*    1.0 */       exec
/*   23   */          serialize
                      mad r8.xyz_, r7.xyzz, c227.xyzz, c3.xyzz
/*   24   */          mul r7, r0.yyyy, r6
/*   25   */          mul r4, r0.yyyy, r4.xywz
/*   26   */          mul r11, r0.yyyy, r5
              +       subsc r14.___w, c255.x, r0.y
/*   27   */          mad r14.xyz_, r14.wwww, r15.xyzz, r11.xyzz
/*   28   */          mul r6, r14.wwww, r3.zyxw
              +       mulsc r1.__z_, c255.z, r1.x
/*    1.1 */       exec
/*   29   */          mul r9, r14.wwww, r2.zyxw
              +       mulsc r5.x___, c255.z, r1.y
/*   30   */          add r0.x_zw, r4.xyyw, r9.zyyx
              +       maxas r0._, r1.zz
/*   31   */          mul r3, r0.yyyy, c[36+a0]
/*   32   */          mul r1, r0.yyyy, c[35+a0].xywz
/*   33   */          mul r2, r0.yyyy, c[37+a0]
/*   34   */          add r16.xyz_, r7.xyzz, r6.zyxx
              +       maxas r0._, r5.xx
/*    2.0 */       exec
/*   35   */          mul r5, r14.wwww, c[36+a0]
/*   36   */          mul r12, r14.wwww, c[35+a0]
/*   37   */          mul r13, r14.wwww, c[37+a0]
/*   38   */          dp3 r0._y__, r16.zxyy, r8.zxyy
/*   39   */          dp3 r0.___w, r0.wxzz, r8.zxyy
              +       maxs r8.___w, r15.ww
/*   40   */          dp4 r10.___w, r14.zxyw, r8.zxyw
/*    2.1 */       exec
/*   41   */          add r11.xyz_, r2.xyzz, r13.xyzz
/*   42   */          dp3 r0.x___, r11.zxyy, r8.zxyy
/*   43   */          add r0.x___, r0.xxxx, r13.wwww
/*   44   */          add r12.xyz_, r1.xyww, r12.xyzz
              +       sges r4.___w, r_abs[0].x
/*   45   */          dp3 r0.__z_, r12.zxyy, r8.zxyy
              +       maxs r0._, r10.ww
/*   46   */          add r0.__z_, r0.zzzz, r12.wwww
              +       adds_prev r4._y__, r11.w
/*    3.0 */       exec
/*   47   */          add r9.xyz_, r3.xyzz, r5.xyzz
              +       maxs r0._, r0.ww
/*   48   */          dp3 r6.x___, r12.zxyy, r10.zxyy
              +       adds_prev r0.___w, r9.w
/*   49   */          dp3 r6._y__, r9.zxyy, r10.zxyy
              +       maxs r0._, r0.yy
/*   50   */          dp3 r6.__z_, r11.zxyy, r10.zxyy
              +       adds_prev r6.___w, r6.w
/*   51   */          dp3 r0._y__, r9.zxyy, r8.zxyy
              +       maxs r0._, r6.ww
/*   52   */          dp3 r3.__z_, r6.zxyy, c0.zxyy
              +       adds_prev r4.x___, r7.w
/*    3.1 */       exec
/*   53   */          dp3 r3._y__, r6.zxyy, c1.zxyy
              +       maxs r0._, r0.ww
/*   54   */          dp3 r3.x___, r6.zxyy, c2.zxyy
              +       adds_prev r4.__z_, r4.z
/*   55   */          dp4 r1.x___, c27.zxyw, r4.yxzw
              +       maxs r0._, r0.yy
/*   56   */          dp4 r1._y__, c29.zxyw, r4.yxzw
              +       adds_prev r0._y__, r5.w
/*   57   */          add r0._y__, r0.yyyy, r3.wwww
              +       sges r0.___w, r_abs[0].x
/*   58   */          dp4 r1.___w, c28.zxyw, r4.yxzw
              +       maxs r0._, r0.zz
/*    4.0 */       exec
/*   59   */          add r0.__z_, r0.xxxx, r2.wwww
              +       adds_prev r0.x___, r1.z
/*   60   */          dp4 r4.x___, c0.zxyw, r0.zxyw
/*   61   */          dp4 r4.__z_, c1.zxyw, r0.zxyw
/*   62   */          dp4 r4._y__, c2.zxyw, r0.zxyw
              +       sges r4.___w, r_abs[0].x
/*   63   */          mad r1.__z_, -r4.yyyy, c5.xxxx, -c5.wwww
/*   64   */          dp4 r2._y__, c24.zxyw, r4.yxzw
/*    4.1 */       exec
/*   65   */          dp4 r0.___w, c25.zxyw, r4.yxzw
/*   66   */          dp4 r2.__z_, c26.zxyw, r4.yxzw
/*   67   */          add r0.xyz_, r4.xyzz, -r1.xyww
/*   68   */          dp3 r0.x___, r0.yxzz, r0.yxzz
/*   69   */          add r1.xy_w, r1.xyww, -r4.xyzz
              +       rsq r0.x___, r_abs[0].x
/*   70   */          dp4 r2.x___, c23.zxyw, r4.yxzw
              +       mulsc r0.x___, c5.y, r0.x
/*    5.0 */       exec
/*   71   */          min r0.x___, r0.xxxx, c255.xxxx
/*   72   */          mad r0.xyz_, r1.xyww, r0.xxxx, r4.xyzz
/*   73   */          add r0.xyz_, -r0.xyzz, r4.xyzz
/*   74   */          mul r0.xyz_, r0.yzxx, c5.zzzz
/*   75   */          add r5.xyz_, r4.xzyy, -r0.zyxx
              +       sges r5.___w, r_abs[0].x
/*   76   */          dp4 r1.x___, c30.zxyw, r5.zxyw
/*    5.1 */       exec
/*   77   */          dp4 r1._y__, c31.zxyw, r5.zxyw
              +       maxs r4.x___, r1.zz
/*   78   */          dp4 r1.___w, c32.zxyw, r5.zxyw
              +       maxs r4._y__, c255.xx
/*   79   */          dp4 r1.__z_, c33.zxyw, r5.zxyw
              +       mins r2.___w, r4.xy
/*    6.0 */       cjmp b0, L16
/*    6.1 */       exec
/*   80   */          rcp r0.x___, r2.z
/*   81   */          mad r0.___w, -r0.xxxx, c255.wwww, r0.wwww
/*   82   */          dp2add r0.x___, r3.zyyy, r3.zyyy, c255.yyyy
/*   83   */          max r0.__z_, r2.zzzz, r2.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   84   */          mul r0.xy__, r3.yzzz, r0.xxxx
/*   85   */          mul r0.xy__, r0.xyyy, c34.wzzz
/*    7.0 */       exec
/*   86   */          mad r0.xy__, r0.yxxx, r2.zzzz, r2.xyyy
/*    7.1 */       jmp L17
                label L16
/*    8.0 */       exec
/*   87   */          dp3 r3.x___, r0.xzyy, r3.xzyy
/*   88   */          cndgt r0.xyz_, r3.xxxx, r2.xyzz, r1.xyzz
/*   89   */          cndgt r0.___w, r3.xxxx, r0.wwww, r1.wwww
                label L17
/*    8.1 */       alloc position
/*    9.0 */       exec
/*   90   */          max oPos, r0.xywz, r0.xywz
/*    9.1 */       alloc interpolators
/*   10.0 */       exece
/*   91   */          max o0, r2.xywz, r2.xywz
/*   92   */          max o1, r1.xywz, r1.xywz
/*   10.1 */       cnop
