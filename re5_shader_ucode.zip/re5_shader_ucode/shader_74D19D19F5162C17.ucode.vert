/*    0.0 */       exec
/*    7   */          vfetch_full r0._xyz, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=4
/*    8   */          vfetch_mini r4.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*    9   */          serialize
                      max r2, c28, c28
/*   10   */          max r3, c29, c29
/*   11   */          max r1, c30, c30
/*   12   */          cndeq r0, c255.zzzx, r0.wyzz, c255.xxxx
/*    0.1 */       exec
/*   13   */          dp4 r5.x___, r2.zxyw, r0
/*   14   */          dp4 r5._y__, r3.zxyw, r0
/*   15   */          dp4 r5.__z_, r1.zxyw, r0
/*    1.0 */       cjmp !b0, L7
/*    1.1 */       exec
/*   16   */          cndeq r0, c255.zzzx, r5.zxyy, c255.xxxx
/*   17   */          dp4 r6.x___, c0.zxyw, r0
/*   18   */          dp4 r6._y__, c1.zxyw, r0
/*   19   */          dp4 r6.__z_, c2.zxyw, r0
/*   20   */          dp2add r0.x___, r6.xyyy, r6.xyyy, c255.zzzz
/*   21   */          dp3 r0._y__, r6.zxyy, r6.zxyy
/*    2.0 */       exec
/*   22   */          sqrt r0.___w, r_abs[0].y
/*   23   */          mad r0.__z_, r0.wwww, c27.xxxx, c27.yyyy
/*   24   */          add r0._y__, -r6.zzzz, r0.wwww
/*   25   */          mul r7.xy__, r6.xyyy, r0.wwww
/*   26   */          mul r7.xy__, r7.yxxx, r0.yyyy
              +       rcp r0.x___, r0.x
/*   27   */          mul r0.xy__, r7.yxxx, r0.xxxx
/*    2.1 */       exec
/*   28   */          cndge r0.__zw, r6.zzzz, r0.zzzw, c255.xxxy
/*    3.0 */       jmp L8
                label L7
/*    3.1 */       exec
/*   29   */          cndeq r6, c255.zzzx, r5.zxyy, c255.xxxx
/*   30   */          dp4 r0.x___, c23.zxyw, r6
/*   31   */          dp4 r0._y__, c24.zxyw, r6
/*   32   */          dp4 r0.__z_, c25.zxyw, r6
/*   33   */          dp4 r0.___w, c26.zxyw, r6
                label L8
/*    4.0 */       alloc position
/*    4.1 */       exec
/*   34   */          max oPos, r0, r0
/*    5.0 */       alloc interpolators
/*    5.1 */       exec
/*   35   */          dp3 r3._y__, r4.zxyy, r3.zxyy
/*   36   */          dp3 r3.__z_, r4.zxyy, r1.zxyy
/*   37   */          dp3 r0.x___, r5.zxyy, c2.zxyy
/*   38   */          dp3 r3.x___, r4.zxyy, r2.zxyy
              +       addsc r0.___w, -c2.w, -r0.x
/*   39   */          mad r1.xyz_, -r0.wwww, c35.xyzz, r5.xyzz
/*   40   */          dp3 r0.x___, r3.zxyy, r3.zxyy
/*    6.0 */       exec
/*   41   */          sge r1.___w, r_abs[0].xxxx, c255.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   42   */          dp4 o1.x___, c31.zxyw, r1.zxyw
/*   43   */          dp4 o1._y__, c32.zxyw, r1.zxyw
/*   44   */          dp4 o1.__z_, c33.zxyw, r1.zxyw
/*   45   */          dp4 o1.___w, c34.zxyw, r1.zxyw
/*   46   */          mul r0.xyz_, r3.xyzz, r0.xxxx
/*    6.1 */       exece
/*   47   */          max o0, r0, r0
