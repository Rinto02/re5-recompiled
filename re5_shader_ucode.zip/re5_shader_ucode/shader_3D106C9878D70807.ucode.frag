/*    0.0 */       exec
/*    3   */          tfetch2D r0.__x_, r0.xy, tf1
/*    4   */          tfetch2D r3, r0.xy, tf2
/*    5   */          tfetch2D r1.xyz_, r0.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exec
/*    6   */          add r2.___w, c49.xxxx, -c50.xxxx
              +       maxs r0._, c51.xx
/*    7   */          add r0.x___, -c49.xxxx, c255.yyyy
              +       adds_prev r1.___w, -c49.x
/*    8   */          mad r2.xyz_, r3.xyzz, c48.xyzz, -r1.xyzz
/*    9   */          add r0.___w, r3.wwww, -c49.xxxx
              +       maxs r0._, r0.xx
/*   10   */          sgt r3._y__, c49.xxxx, r3.wwww
              +       adds_prev r3.___w, -r0.z
/*   11   */          add r0._y__, -r0.zzzz, c255.yyyy
              +       rcp r0.x___, r2.w
/*    1.1 */       exec
/*   12   */          sgt r3.x___, c49.xxxx, r0.yyyy
              +       rcp r0.__z_, r1.w
/*   13   */          mul r4._yz_, r0.wwww, r0.xxzz
              +       subsc r3.__z_, -c49.x, -r0.y
/*   14   */          mul r4.x__w, r3.zwww, r0.xzzz
/*   15   */          max r0.xy__, r4.xyyy, -c53.xxxx
/*   16   */          max r0.__zw, r4.wwwz, c255.xxxx
/*   17   */          min r0.__zw, r0.zzzw, c52.xxxx
/*    2.0 */       exec
/*   18   */          min r0.xy__, r0.xyyy, c255.xxxx
/*   19   */          cndeq r0.xy__, r3.xyyy, r0.zwww, r0.xyyy
/*   20   */          sgts r0.__z_, -r0.y
/*   21   */          sgt r0.___w, r0.xxxx, r0.yyyy
              +       maxs r0._y__, r_abs[0].yx
/*   22   */          mul r0.__z_, r0.wwww, r0.zzzz
              +       maxs r0.x___, r_abs[0].xx
/*   23   */          cndeq r0.x___, r0.zzzz, r0.xxxx, r0.yyyy
/*    2.1 */       exece
/*   24   */          mad oC0.xyz1, r2.xyzz, r0.xxxx, r1.xyzz
