/*    0.0 */       exec
/*    2   */          tfetch2D r2.xyz_, r1.zw, tf0
/*    3   */          tfetch2D r1.xyz_, r1.xy, tf0
/*    4   */          tfetch2D r3.xyz_, r0.xy, tf0
/*    5   */          tfetch2D r0.xyz_, r0.zw, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    6   */          add r0.xyz_, r3.xyzz, r0.xyzz
/*    7   */          add r0.xyz_, r0.xyzz, r1.xyzz
/*    8   */          add r0.xyz_, r0.xyzz, r2.xyzz
/*    9   */          mul oC0.xyz1, r0.xyzz, c255.xxxx
/*    1.1 */       cnop
