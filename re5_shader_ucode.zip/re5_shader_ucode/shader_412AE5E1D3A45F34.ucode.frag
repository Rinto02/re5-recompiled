/*    0.0 */       exec
/*    2   */          tfetch2D r1.x___, r0.xy, tf0
/*    3   */          tfetch2D r1._x__, r0.xy, tf2
/*    4   */          tfetch2D r1.__x_, r0.xy, tf1
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    5   */          add r0.xyz_, r1.yxzz, c254.yxyy
/*    6   */          mul r1.xyz_, r0.yxzz, c255.xyzz
              +       mulsc r0.___w, c255.w, r0.x
/*    7   */          mad r1.___w, -r0.zzzz, c254.zzzz, -r0.wwww
/*    8   */          add oC0.xyz1, r1.xwxx, r1.yxzz
/*    1.1 */       cnop
