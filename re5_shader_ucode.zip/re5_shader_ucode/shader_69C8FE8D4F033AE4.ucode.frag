/*    0.0 */       exec
/*    2   */          tfetch2D r0._w__, r0.xy, tf0
/*    0.1 */       alloc colors
/*    1.0 */       exece
/*    3   */          subsc r0.x___, -c23.x, -r0.y
/*    4   */          kill_gt r0._, c255.xxxx, r0.xxxx
/*    5   */          max oC0._001, r0, r0
              +       sgts oC0.x___, -r_abs[0].x
/*    1.1 */       cnop
