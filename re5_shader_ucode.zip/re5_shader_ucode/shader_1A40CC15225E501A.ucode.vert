/*    0.0 */       exec
/*    8   */          vfetch_full r1.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    9   */          vfetch_mini r0._x__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   10   */          vfetch_mini r7.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   11   */          vfetch_mini r6, Offset=5, DataFormat=FMT_8_8_8_8, Signed=true
/*   12   */          vfetch_mini r4.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   13   */          serialize
                      mad r2.xyz_, r1.xyzz, c3.xyzz, c4.xyzz
/*    0.1 */       exec
/*   14   */          mulsc r0.x___, c255.w, r0.y
/*   15   */          maxas r0._, r0.xx
/*   16   */          max r0, c[28+a0], c[28+a0]
/*   17   */          max r1, c[29+a0], c[29+a0]
/*   18   */          max r5, c[30+a0], c[30+a0]
/*   19   */          cndeq r2, c255.zzzx, r2.zxyy, c255.xxxx
/*    1.0 */       exec
/*   20   */          dp4 r3.x___, r0.zxyw, r2
/*   21   */          dp4 r3._y__, r1.zxyw, r2
/*   22   */          dp4 r3.__z_, r5.zxyw, r2
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   23   */          cndeq r2, c255.zzzx, r3.zxyy, c255.xxxx
/*   24   */          dp4 r8.x___, c0.zxyw, r2
/*   25   */          dp4 r8._y__, c1.zxyw, r2
/*   26   */          dp4 r8.__z_, c2.zxyw, r2
/*   27   */          dp2add r2.x___, r8.xyyy, r8.xyyy, c255.zzzz
/*   28   */          dp3 r2._y__, r8.zxyy, r8.zxyy
/*    2.1 */       exec
/*   29   */          sqrt r2.___w, r_abs[2].y
/*   30   */          mad r2.__z_, r2.wwww, c27.xxxx, c27.yyyy
/*   31   */          add r2._y__, -r8.zzzz, r2.wwww
/*   32   */          mul r4.__zw, r8.xxxy, r2.wwww
/*   33   */          mul r4.__zw, r4.wwwz, r2.yyyy
              +       rcp r2.x___, r2.x
/*   34   */          mul r2.xy__, r4.wzzz, r2.xxxx
/*    3.0 */       exec
/*   35   */          cndge r2.__zw, r8.zzzz, r2.zzzw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   36   */          cndeq r8, c255.zzzx, r3.zxyy, c255.xxxx
/*   37   */          dp4 r2.x___, c23.zxyw, r8
/*   38   */          dp4 r2._y__, c24.zxyw, r8
/*   39   */          dp4 r2.__z_, c25.zxyw, r8
/*   40   */          dp4 r2.___w, c26.zxyw, r8
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   41   */          mad r2.__z_, -r2.wwww, c9.xxxx, r2.zzzz
/*   42   */          max oPos, r2, r2
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   43   */          dp3 r8.x___, r6.zxyy, r1.zxyy
/*   44   */          dp3 r8._y__, r6.zxyy, r5.zxyy
/*   45   */          dp3 r8.__z_, r6.zxyy, r0.zxyy
/*   46   */          dp3 r0._y__, r7.zxyy, r0.zxyy
/*   47   */          dp3 r0.__z_, r7.zxyy, r1.zxyy
/*   48   */          dp3 r0.___w, r7.zxyy, r5.zxyy
/*    6.1 */       exec
/*   49   */          add r6.xy__, r4.xyyy, c7.xyyy
              +       maxs r6.__z_, c5.xx
/*   50   */          add o3.xy__, r4.xyyy, c8.xyyy
/*   51   */          max o2.xyz_, r3.xyzz, r3.xyzz
/*   52   */          max o1, r6, r6
/*   53   */          max o0, r2, r2
/*   54   */          dp3 r1.x___, r0.wyzz, r0.wyzz
/*    7.0 */       exec
/*   55   */          dp3 r0.x___, r8.yzxx, r8.yzxx
              +       rsq r1.___w, r_abs[1].x
/*   56   */          mul r1.xyz_, r0.yzww, r1.wwww
              +       rsq r0.x___, r_abs[0].x
/*   57   */          mul o4.xyz_, r8.zxyy, r0.xxxx
/*   58   */          mul o6.xyz_, r0.yzww, r1.wwww
/*   59   */          mul r2.xyz_, r8.xyzz, r0.xxxx
/*   60   */          mul r0.xyz_, r2.yzxx, r1.yzxx
/*    7.1 */       exece
/*   61   */          mad r0._yzw, r2.xxyz, r1.zzxy, -r0.xxyz
/*   62   */          dp3 r0.x___, r0.wyzz, r0.wyzz
/*   63   */          rsq r0.x___, r_abs[0].x
/*   64   */          mul r0.xyz_, r0.yzww, r0.xxxx
/*   65   */          mul o5.xyz_, r0.xyzz, c6.zzzz
