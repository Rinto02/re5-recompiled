/*    0.0 */       exec
/*    8   */          vfetch_full r2.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    9   */          vfetch_mini r1.__xy, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   10   */          vfetch_mini r0.___x, Offset=3, DataFormat=FMT_8_8_8_8
/*   11   */          vfetch_mini r5.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   12   */          vfetch_mini r1.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   13   */          serialize
                      mad r0.xyz_, r2.xyzz, c3.xyzz, c4.xyzz
/*    0.1 */       exec
/*   14   */          mul r1.__zw, r1.zzzw, c255.wwww
/*   15   */          add r4.x___, -r0.wwww, c255.xxxx
              +       maxas r0._, r1.ww
/*   16   */          mul r2, r4.xxxx, c[30+a0]
/*   17   */          mul r3, r4.xxxx, c[29+a0]
/*   18   */          mul r4, r4.xxxx, c[28+a0]
              +       maxas r0._, r1.zz
/*   19   */          mad r6, r0.wwww, c[28+a0], r4
/*    1.0 */       exec
/*   20   */          mad r4, r0.wwww, c[29+a0], r3
/*   21   */          mad r2, r0.wwww, c[30+a0], r2
/*   22   */          cndeq r3, c255.zzzx, r0.zxyy, c255.xxxx
/*   23   */          dp4 r0._y__, r6.zxyw, r3
/*   24   */          dp4 r0.__z_, r4.zxyw, r3
/*   25   */          dp4 r0.___w, r2.zxyw, r3
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   26   */          cndeq r3, c255.zzzx, r0.wyzz, c255.xxxx
/*   27   */          dp4 r7.x___, c0.zxyw, r3
/*   28   */          dp4 r7._y__, c1.zxyw, r3
/*   29   */          dp4 r7.__z_, c2.zxyw, r3
/*   30   */          dp2add r0.x___, r7.xyyy, r7.xyyy, c255.zzzz
/*   31   */          dp3 r1.__z_, r7.zxyy, r7.zxyy
/*    2.1 */       exec
/*   32   */          sqrt r1.___w, r_abs[1].z
/*   33   */          mad r1.__z_, r1.wwww, c27.xxxx, c27.yyyy
/*   34   */          add r3.x___, -r7.zzzz, r1.wwww
/*   35   */          mul r3._yz_, r7.xxyy, r1.wwww
/*   36   */          mul r3.xy__, r3.zyyy, r3.xxxx
              +       rcp r0.x___, r0.x
/*   37   */          mul r3.xy__, r3.yxxx, r0.xxxx
/*    3.0 */       exec
/*   38   */          cndge r3.__zw, r7.zzzz, r1.zzzw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   39   */          cndeq r7, c255.zzzx, r0.wyzz, c255.xxxx
/*   40   */          dp4 r3.x___, c23.zxyw, r7
/*   41   */          dp4 r3._y__, c24.zxyw, r7
/*   42   */          dp4 r3.__z_, c25.zxyw, r7
/*   43   */          dp4 r3.___w, c26.zxyw, r7
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   44   */          max oPos, r3, r3
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   45   */          dp3 r3.x___, r5.zxyy, r6.zxyy
/*   46   */          dp3 r3._y__, r5.zxyy, r4.zxyy
/*   47   */          dp3 r0.x___, r0.wyzz, c2.zxyy
/*   48   */          dp3 r3.__z_, r5.zxyy, r2.zxyy
              +       addsc r2.___w, -c2.w, -r0.x
/*   49   */          add o4.xy__, r1.xyyy, c5.xyyy
/*   50   */          mad r1.xyz_, -r2.wwww, c6.xyzz, r0.yzww
/*    6.1 */       exec
/*   51   */          dp3 r0.x___, r3.zxyy, r3.zxyy
/*   52   */          sge r1.___w, r_abs[0].xxxx, c255.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   53   */          dp4 o1.x___, c220.zxyw, r1.zxyw
/*   54   */          dp4 o1._y__, c221.zxyw, r1.zxyw
/*   55   */          dp4 o1.__z_, c222.zxyw, r1.zxyw
/*   56   */          dp4 o1.___w, c223.zxyw, r1.zxyw
/*    7.0 */       exec
/*   57   */          dp4 o2.x___, c224.zxyw, r1.zxyw
/*   58   */          dp4 o2._y__, c225.zxyw, r1.zxyw
/*   59   */          dp4 o2.__z_, c226.zxyw, r1.zxyw
/*   60   */          dp4 o2.___w, c227.zxyw, r1.zxyw
/*   61   */          dp4 o3.x___, c228.zxyw, r1.zxyw
/*   62   */          dp4 o3._y__, c229.zxyw, r1.zxyw
/*    7.1 */       exece
/*   63   */          dp4 o3.__z_, c230.zxyw, r1.zxyw
/*   64   */          dp4 o3.___w, c231.zxyw, r1.zxyw
/*   65   */          mul r2.xyz_, r3.xyzz, r0.xxxx
/*   66   */          max o0, r2, r2
