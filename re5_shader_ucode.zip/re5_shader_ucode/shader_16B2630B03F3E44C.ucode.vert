/*    0.0 */       exec
/*    4   */          vfetch_full r1._yxw, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=4
/*    5   */          vfetch_mini r1.x___, Offset=3, DataFormat=FMT_8_8_8_8
/*    6   */          vfetch_mini r0.xy__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    7   */          mad r5.x_zw, r1.yzzw, c215.xyyz, c4.xyyz
/*    8   */          mul r3.xy__, r0.xyyy, c255.xxxx
/*    9   */          add r4.x___, -r1.xxxx, c255.yyyy
              +       maxas r0._, r3.xx
/*   10   */          mul r0, r1.xxxx, c[24+a0].xwyz
/*   11   */          mul r2, r1.xxxx, c[25+a0]
/*   12   */          mul r1, r1.xxxx, c[23+a0]
              +       maxas r0._, r3.yy
/*    1.1 */       exec
/*   13   */          mul r3, r4.xxxx, c[24+a0]
/*   14   */          mul r7, r4.xxxx, c[25+a0]
/*   15   */          mul r4, r4.xxxx, c[23+a0]
/*   16   */          add r6.xyz_, r1.xyzz, r4.xyzz
/*   17   */          add r8.xyz_, r2.xyzz, r7.xyzz
/*   18   */          add r9.xyz_, r0.xzww, r3.xyzz
/*    2.0 */       exec
/*   19   */          dp3 r5._y__, r9.zxyy, r5.wxzz
/*   20   */          dp3 r6.___w, r8.zxyy, r5.wxzz
/*   21   */          add r0.x___, r6.wwww, r7.wwww
              +       sges r0.___w, r_abs[0].x
/*   22   */          dp3 r5.x___, r6.zxyy, r5.wxzz
              +       maxs r0._, r5.yy
/*   23   */          add r0.__z_, r5.xxxx, r4.wwww
              +       adds_prev r3.x___, r3.w
/*   24   */          add r0._y__, r3.xxxx, r0.yyyy
              +       maxs r0._, r0.zz
/*    2.1 */       exec
/*   25   */          add r0.__z_, r0.xxxx, r2.wwww
              +       adds_prev r0.x___, r1.w
/*   26   */          mad r0.xyz_, c6.xyzz, c5.xxxx, r0.xyzz
/*   27   */          dp4 oPos.x___, c0.zxyw, r0.zxyw
/*   28   */          dp4 oPos._y__, c1.zxyw, r0.zxyw
/*   29   */          dp4 oPos.__z_, c2.zxyw, r0.zxyw
/*   30   */          dp4 oPos.___w, c3.zxyw, r0.zxyw
/*    3.0 */       alloc interpolators
/*    3.1 */       exece
