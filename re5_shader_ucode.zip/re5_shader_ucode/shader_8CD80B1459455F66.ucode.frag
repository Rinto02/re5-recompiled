/*    0.0 */       exec
/*   25   */          tfetch2D r7.yxzw, r1.xy, tf0
/*   26   */          serialize
                      mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r7.ww
/*   27   */          sgt r10.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       rcp r1.x___, r0.w
/*   28   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   29   */          mul r0.xy__, r3.zwww, r0.yxxx
              +       subsc r1.x___, -c1.x, -r1.y
/*   30   */          kill_gt r1._, c255.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   31   */          tfetch2D r11.xyz_, r3.xy, tf2
/*   32   */          tfetch2D r9.xy__, r3.xy, tf1
/*   33   */          tfetch2D r0, r0.xy, tf4
/*   34   */          serialize
                      sgt r8.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       maxs r4.___w, c15.xx
/*   35   */          add r3._yzw, r2.xxyz, -c23.xxyz
              +       maxs r1.x___, r7.zz
/*   36   */          mul r0, r0.wzyx, c5.wzyx
              +       mulsc r7.__z_, c13.z, r1.x
/*    1.0 */       exec
/*   37   */          dp3 r1._y__, r3.wyzz, r3.wyzz
              +       mulsc r7.x___, c13.y, r7.x
/*   38   */          mad r12.xy__, r9.yxxx, c254.xxxx, c255.wwww
              +       retain_prev r1._
/*   39   */          dp2add r2.___w, -r12.xyyy, r12.xyyy, c255.yyyy
              +       retain_prev r1._
/*   40   */          min r0, r0, c7.xxxx
              +       rsq r3.x___, r_abs[1].y
/*   41   */          mul r3.x_zw, r3.wzzy, r3.xxxx
              +       mulsc r7._y__, c13.x, r7.y
/*   42   */          max r9, r0.wzyx, c8.xxxx
              +       sqrt r2.___w, r_abs[2].w
/*    1.1 */       exec
/*   43   */          mul r0.xyz_, r2.wwww, r6.xyzz
              +       maxs r0.___w, r9.yw
/*   44   */          mad r0.xyz_, r12.xxxx, r5.zyxx, r0.zyxx
              +       retain_prev r1._
/*   45   */          mad r0.xyz_, r12.yyyy, r4.xzyy, r0.zxyy
              +       retain_prev r1._
/*   46   */          dp3 r2.___w, r0.yxzz, r0.yxzz
              +       maxs r3._y__, r9.xz
/*   47   */          max r3._y__, r3.yyyy, r0.wwww
              +       rsq r2.___w, r_abs[2].w
/*   48   */          mul r4.xyz_, r0.xzyy, r2.wwww
              +       sqrt r1._y__, r_abs[1].y
/*    2.0 */       cjmp !b128, L24
/*    2.1 */       exec
/*   49   */          mul r0, r9.wzyx, c48.wzyx
              +       retain_prev r1._
/*   50   */          add r5.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   51   */          dp3 r5.___w, r5.xzyy, r5.xzyy
              +       retain_prev r1._
/*   52   */          max4 r0.__z_, r0.zxwy
              +       rsq r1.x___, r_abs[5].w
/*   53   */          mul r6, r5, r1.xxxx
              +       retain_prev r1._
/*   54   */          dp3 r5.__z_, r4.zxyy, r6.xzyy
              +       retain_prev r1._
/*    3.0 */       exec
/*   55   */          add r5.xy_w, r6.zyxx, -r3.wzxx
              +       retain_prev r1._
/*   56   */          dp3 r2.___w, r6.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   57   */          add r1.x___, r6.wwww, -c32.wwww
              +       retain_prev r1._
/*   58   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   59   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c35.y, r2.w
/*   60   */          max r1.x___, r1.xxxx, c35.wwww
              +       rsq r2.___w, r_abs[0].y
/*    3.1 */       exec
/*   61   */          mul r6.xyz_, r5.wyxx, r2.wwww
              +       subsc r0.___w, c255.y, r0.x
/*   62   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r2.___w, c255.y, r0.z
/*   63   */          dp3 r5._y__, r4.zxyy, r6.xzyy
              +       maxs r1._, r0.ww
/*   64   */          max r0._yz_, r5.zzyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*   65   */          mul r5._yzw, r5.xxyy, c32.xxzy
              +       log r1.x___, r_abs[0].z
/*   66   */          max r1._, r1, r1
              +       mulsc r0.x___, c14.z, r1.x
/*    4.0 */       exec
/*   67   */          mul r5.x___, r5.yyyy, r0.wwww
              +       exp r0.x___, r0.x
/*   68   */          mul r6.xy__, r5.zwww, r0.xxxx
              +       retain_prev r1._
/*   69   */          mul r10.xy__, r6.xyyy, r2.wwww
              +       retain_prev r1._
/*   70   */          mul r0, r5.xzwx, r0.yyyx
              +       retain_prev r1._
/*   71   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       maxs r1._, r0.ww
/*   72   */          mul r8.xyz_, r0.xzyy, c35.zzzz
              +       muls_prev r10.__z_, r2.w
/*    4.1 */       cjmp !b129, L24
/*    5.0 */       exec
/*   73   */          mul r0, r9.wzyx, c49.wzyx
              +       retain_prev r1._
/*   74   */          add r5.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   75   */          dp3 r5.___w, r5.zxyy, r5.zxyy
              +       retain_prev r1._
/*   76   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[5].w
/*   77   */          mul r6, r5, r1.xxxx
              +       retain_prev r1._
/*   78   */          dp3 r5.__z_, r4.zxyy, r6.zxyy
              +       retain_prev r1._
/*    5.1 */       exec
/*   79   */          add r5.xy_w, r6.xyzz, -r3.wzxx
              +       retain_prev r1._
/*   80   */          dp3 r2.___w, r6.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   81   */          add r1.x___, r6.wwww, -c36.wwww
              +       retain_prev r1._
/*   82   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   83   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c39.y, r2.w
/*   84   */          max r1.x___, r1.xxxx, c39.wwww
              +       rsq r2.___w, r_abs[0].y
/*    6.0 */       exec
/*   85   */          mul r6.xyz_, r5.wyxx, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   86   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*   87   */          dp3 r5._y__, r4.zxyy, r6.xzyy
              +       maxs r1._, r0.yy
/*   88   */          max r0.x__w, r5.zyyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*   89   */          mul r5.xy_w, r5.yyxx, c36.zyxx
              +       log r1.x___, r_abs[0].w
/*   90   */          mul r5.__z_, r5.wwww, r0.yyyy
              +       mulsc r0.___w, c14.z, r1.x
/*    6.1 */       exec
/*   91   */          mul r0.xyz_, r5.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*   92   */          mul r5.xyz_, r5.xyzz, r0.wwww
              +       retain_prev r1._
/*   93   */          mad r10.xyz_, r5.xyzz, r2.wwww, r10.xyzz
              +       retain_prev r1._
/*   94   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   95   */          mad r8.xyz_, r0.xzyy, c39.zzzz, r8.xyzz
              +       retain_prev r1._
/*    7.0 */       cjmp !b130, L24
/*    7.1 */       exec
/*   96   */          mul r0, r9, c50
              +       retain_prev r1._
/*   97   */          add r5.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   98   */          dp3 r5.___w, r5.xzyy, r5.xzyy
              +       retain_prev r1._
/*   99   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[5].w
/*  100   */          mul r6, r5, r1.xxxx
              +       retain_prev r1._
/*  101   */          dp3 r5.__z_, r4.zxyy, r6.xzyy
              +       retain_prev r1._
/*    8.0 */       exec
/*  102   */          add r5.xy_w, r6.zyxx, -r3.wzxx
              +       retain_prev r1._
/*  103   */          dp3 r2.___w, r6.xzyy, -c42.zxyy
              +       retain_prev r1._
/*  104   */          add r1.x___, r6.wwww, -c40.wwww
              +       retain_prev r1._
/*  105   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*  106   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c43.y, r2.w
/*  107   */          max r1.x___, r1.xxxx, c43.wwww
              +       rsq r2.___w, r_abs[0].y
/*    8.1 */       exec
/*  108   */          mul r6.xyz_, r5.xyww, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  109   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*  110   */          dp3 r5._y__, r4.zxyy, r6.zxyy
              +       maxs r1._, r0.yy
/*  111   */          max r0.x__w, r5.zyyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*  112   */          mul r5.xy_w, r5.yyxx, c40.zyxx
              +       log r1.x___, r_abs[0].w
/*  113   */          mul r5.__z_, r5.wwww, r0.yyyy
              +       mulsc r0.___w, c14.z, r1.x
/*    9.0 */       exec
/*  114   */          mul r0.xyz_, r5.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  115   */          mul r5.xyz_, r5.xyzz, r0.wwww
              +       retain_prev r1._
/*  116   */          mad r10.xyz_, r5.xyzz, r2.wwww, r10.xyzz
              +       retain_prev r1._
/*  117   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  118   */          mad r8.xyz_, r0.xzyy, c43.zzzz, r8.xyzz
              +       retain_prev r1._
/*    9.1 */       cjmp !b131, L24
/*   10.0 */       exec
/*  119   */          mul r0, r9.wzyx, c51.wzyx
              +       retain_prev r1._
/*  120   */          add r5.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*  121   */          dp3 r5.___w, r5.zxyy, r5.zxyy
              +       retain_prev r1._
/*  122   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[5].w
/*  123   */          mul r6, r5, r1.xxxx
              +       retain_prev r1._
/*  124   */          dp3 r5.__z_, r4.zxyy, r6.zxyy
              +       retain_prev r1._
/*   10.1 */       exec
/*  125   */          add r5.xy_w, r6.xyzz, -r3.wzxx
              +       retain_prev r1._
/*  126   */          dp3 r2.___w, r6.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  127   */          add r1.x___, r6.wwww, -c44.wwww
              +       retain_prev r1._
/*  128   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  129   */          dp3 r0._y__, r5.wxyy, r5.wxyy
              +       mulsc r1.x___, c47.y, r2.w
/*  130   */          max r1.x___, r1.xxxx, c47.wwww
              +       rsq r2.___w, r_abs[0].y
/*   11.0 */       exec
/*  131   */          mul r6.xyz_, r5.wyxx, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  132   */          min r5.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*  133   */          dp3 r5._y__, r4.zxyy, r6.xzyy
              +       maxs r1._, r0.yy
/*  134   */          max r0.x__w, r5.zyyy, c255.xxxx
              +       muls_prev r5._y__, r5.x
/*  135   */          mul r5.xy_w, r5.yyxx, c44.zyxx
              +       log r1.x___, r_abs[0].w
/*  136   */          mul r5.__z_, r5.wwww, r0.yyyy
              +       mulsc r0.___w, c14.z, r1.x
/*   11.1 */       exec
/*  137   */          mul r0.xyz_, r5.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  138   */          mul r5.xyz_, r5.xyzz, r0.wwww
              +       retain_prev r1._
/*  139   */          mad r10.xyz_, r5.xyzz, r2.wwww, r10.xyzz
              +       retain_prev r1._
/*  140   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  141   */          mad r8.xyz_, r0.xzyy, c47.zzzz, r8.xyzz
              +       retain_prev r1._
                label L24
/*   12.0 */       cjmp !b132, L36
/*   12.1 */       exec
/*  142   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  143   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  144   */          mul r5, r9.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  145   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  146   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  147   */          dp3 r2.___w, r0.xzyy, r4.zxyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   13.0 */       exec
/*  148   */          max4 r0._y__, r5.zxwy
              +       maxs r0.__z_, r2.ww
/*  149   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  150   */          mul r5.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  151   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  152   */          mad r8.xyz_, r5.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   13.1 */       cjmp !b133, L36
/*   14.0 */       exec
/*  153   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  154   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  155   */          mul r5, r9, c53
              +       rsq r1.x___, r_abs[0].w
/*  156   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  157   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  158   */          dp3 r2.___w, r0.zxyy, r4.zxyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   14.1 */       exec
/*  159   */          max4 r0._y__, r5.ywxz
              +       maxs r0.__z_, r2.ww
/*  160   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  161   */          mul r5.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  162   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  163   */          mad r8.xyz_, r5.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   15.0 */       cjmp !b134, L36
/*   15.1 */       exec
/*  164   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  165   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  166   */          mul r5, r9.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  167   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  168   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  169   */          dp3 r2.___w, r0.xzyy, r4.zxyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   16.0 */       exec
/*  170   */          max4 r0._y__, r5.zxwy
              +       maxs r0.__z_, r2.ww
/*  171   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  172   */          mul r5.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  173   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  174   */          mad r8.xyz_, r5.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   16.1 */       cjmp !b135, L36
/*   17.0 */       exec
/*  175   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  176   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  177   */          mul r5, r9, c55
              +       rsq r1.x___, r_abs[0].w
/*  178   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  179   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  180   */          dp3 r2.___w, r0.zxyy, r4.zxyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   17.1 */       exec
/*  181   */          max4 r0._y__, r5.ywxz
              +       maxs r0.__z_, r2.ww
/*  182   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  183   */          mul r5.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  184   */          mul r5.xyz_, r5.xyzz, r2.wwww
              +       retain_prev r1._
/*  185   */          mad r8.xyz_, r5.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
                label L36
/*   18.0 */       exec
/*  186   */          mul r9, r4.xyzz, r4.yzzx
              +       retain_prev r1._
/*  187   */          cndeq r0, c255.xxxy, r4.zxyy, c255.yyyy
              +       retain_prev r1._
/*  188   */          dp4 r5.x___, c16.zxyw, r0
              +       retain_prev r1._
/*  189   */          dp4 r5._y__, c18.zxyw, r0
              +       retain_prev r1._
/*  190   */          dp4 r5.__z_, c17.zxyw, r0
              +       retain_prev r1._
/*  191   */          dp4 r0.x___, r9.wzxy, c19.wzxy
              +       muls r6.x___, r4.xx
/*   18.1 */       exec    // PredicateClean=false
/*  192   */          dp4 r0._y__, r9.wzxy, c21.wzxy
              +       muls r6._y__, r4.yy
/*  193   */          dp4 r0.__z_, r9.wzxy, c20.wzxy
              +       subs r2.___w, r6.xy
/*  194   */          add r0.xyz_, r5.zxyy, r0.zxyy
              +       setp_gt r1._, c_abs[56].x
/*  195   */          mad r0.xyz_, r2.wwww, c22.xyzz, r0.yxzz
              +       retain_prev r1._
/*  196   */          mad r5.xyz_, r8.xzyy, r1.wwww, r0.xyzz
              +       retain_prev r1._
/*   19.0 */  (p0) exec
/*  197   */     (p0) mul r6.xyz_, r5.zyxx, c59.xxxx
              +  (p0) retain_prev r1._
/*  198   */     (p0) mul r0.xyz_, r5.zyxx, c60.xxxx
              +  (p0) retain_prev r1._
/*  199   */     (p0) mul r0.xyz_, r0.xyzz, c58.xxxx
              +  (p0) retain_prev r1._
/*  200   */     (p0) mad r5.xyz_, r6.zyxx, c57.xxxx, r0.zyxx
              +  (p0) retain_prev r1._
/*   19.1 */       exec
/*  201   */          dp3 r6._y__, r3.xwzz, r4.zxyy
              +       retain_prev r1._
/*  202   */          max r1._, r1, r1
              +       adds r1.x___, r6.yy
/*  203   */          mad r0.xyz_, -r4.xyzz, r1.xxxx, r3.wzxx
              +       retain_prev r1._
/*  204   */          cube r0, r0.zzxy, r0.yxzz
              +       retain_prev r1._
/*  205   */          max r4.__z_, r0.wwww, r0.wwww
              +       rcp r1.x___, r_abs[0].z
/*  206   */          mad r4.xy__, r0.yxxx, r1.xxxx, c254.yyyy
              +       retain_prev r1._
/*   20.0 */       exec
/*  207   */          setTexLOD r4.w
/*  208   */          tfetchCube r4, r4.xyz, tf3, UseComputedLOD=false, UseRegisterLOD=true
/*   20.1 */       alloc colors
/*   21.0 */       exec
/*  209   */          max r1.x___, r4.wwww, c254.zzzz
              +       mulsc r6.x___, c6.x, r3.y
/*  210   */          add r0.xy__, -r6.xyyy, c255.yyyy
              +       rcp r1.x___, r1.x
/*  211   */          mul r4.xyz_, r1.xxxx, r4.xyzz
              +       retain_prev r1._
/*  212   */          mul r4.xyz_, r4.zyxx, r0.xxxx
              +       muls r1.x___, r_abs[0].yy
/*  213   */          max r1._, r1, r1
              +       muls r1.x___, r1.xx
/*  214   */          mul r4.___w, r1.xxxx, r_abs[0].yyyy
              +       retain_prev r1._
/*   21.1 */       exec    // PredicateClean=false
/*  215   */          mad r0.xyz_, r4.zyxx, c14.wwww, r10.zyxx
              +       retain_prev r1._
/*  216   */          mad_sat r1.x___, r4.wwww, c14.xxxx, c14.yyyy
              +       retain_prev r1._
/*  217   */          max r1._, r1, r1
              +       subsc r1.x___, c255.y, r1.x
/*  218   */          mul r1.x___, r1.xxxx, r1.wwww
              +       setp_ne r1._, c56.x
/*  219   */     (p0) mul r0.xyz_, r0.xyzz, c61.xxxx
              +  (p0) retain_prev r1._
/*  220   */          mul r4.xyz_, r1.xxxx, r11.xyzz
              +       maxs r1._, r7.ww
/*   22.0 */       exec
/*  221   */          mul r0.xyz_, r4.xyzz, r0.xyzz
              +       muls_prev r1.___w, r1.z
/*  222   */          mad r0.xyz_, r7.yxzz, r5.xyzz, r0.xyzz
              +       retain_prev r1._
/*   22.1 */       cjmp !b136, L49
/*   23.0 */       exec
/*  223   */          mad r2.___w, r1.yyyy, c12.yyyy, c12.zzzz
              +       retain_prev r1._
/*  224   */          dp3 r1.__z_, r3.xwzz, c10.zxyy
              +       retain_prev r1._
/*  225   */          cndeq r3, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  226   */          dp4 r1.x___, c10.zxyw, r3
              +       subsc r1._y__, -c9.x, -r1.y
/*  227   */          add r2.xyz_, -r0.xyzz, c11.xyzz
              +       mulsc r0.___w, c9.z, r1.y
/*  228   */          min r3.xy__, r1.xzzz, c255.xzzz
              +       mulsc r1.x___, c9.w, r1.x
/*   23.1 */       exec
/*  229   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  230   */          max r1._, r1, r1
              +       mulsc r1.x___, c12.x, r1.y
/*  231   */          mad r1.x___, r1.xxxx, r3.xxxx, r2.wwww
              +       retain_prev r1._
/*  232   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  233   */          min r1.x___, r1.xxxx, c11.wwww
              +       retain_prev r1._
/*  234   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*   24.0 */       exec
/*  235   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L49
/*   24.1 */       exece
/*  236   */          mul r1.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  237   */          max oC0, r1, r1
