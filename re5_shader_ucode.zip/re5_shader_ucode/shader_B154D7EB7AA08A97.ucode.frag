/*    0.0 */       exec
/*    5   */          dp2add r4.__z_, r0.xxxx, c49.xxxx, c253.xxxx
/*    6   */          dp2add r0.__z_, -r0.yyyy, c50.yyyy, c253.xxxx
/*    7   */          dp2add r0.___w, c49.zzzz, c253.yyyy, c253.xxxx
/*    8   */          mul r1.x___, r0.xxxx, c50.xxxx
/*    9   */          mul r1.__z_, -r0.yyyy, c50.yyyy
/*   10   */          dp2add r1.___w, -r0.yyyy, c49.yyyy, c253.xxxx
/*    0.1 */       exec
/*   11   */          mul r10.x___, r0.xxxx, c48.xxxx
              +       maxs r0._, c50.zz
/*   12   */          mul r10.__z_, -r0.yyyy, c48.yyyy
              +       muls_prev r1._y__, c253.y
/*   13   */          mul r10.___w, c49.zzzz, c253.yyyy
              +       maxs r0._, c48.zz
/*   14   */          mul r2.x___, -r0.yyyy, c49.yyyy
              +       muls_prev r10._y__, c253.y
/*   15   */          mad r3.__z_, r0.xxxx, c49.xxxx, r2.xxxx
/*   16   */          add r4.xy__, r1.xyyy, r1.zxxx
/*    1.0 */       exec
/*   17   */          add r9._y_w, r4.zzyy, r0.wwzz
/*   18   */          add r9.__z_, r9.wwww, r1.yyyy
              +       adds r3.x___, r10.xz
/*   19   */          add r2.xyz_, c51.xyzz, c254.zzzz
              +       adds r3._y__, r10.yx
/*   20   */          add r3.xy_w, r3.xzyy, r10.ywzz
              +       maxs r0._, r4.xx
/*   21   */          add r0.__z_, r3.wwww, r10.yyyy
              +       adds_prev r3.__z_, r1.y
/*   22   */          mad r5.xyz_, r3.xyzz, c51.wwww, c51.xyzz
/*    1.1 */       exec
/*   23   */          mad r8.xyz_, r3.xyzz, c51.wwww, r2.xyzz
/*   24   */          mul r7.xyz_, r3.xyzz, c253.wwww
              +       maxs r0._, r0.zz
/*   25   */          mul r6.xyz_, r3.xyzz, c253.zzzz
              +       adds_prev r0.__z_, r10.x
/*   26   */          mad r3.xyz_, r6.xyzz, c51.wwww, c51.xyzz
/*   27   */          mad r4.xyz_, r7.xyzz, c51.wwww, c51.xyzz
/*   28   */          mad r6.xyz_, r6.xyzz, c51.wwww, r2.xyzz
/*    2.0 */       exec
/*   29   */          mad r7.xyz_, r7.xyzz, c51.wwww, r2.xyzz
/*   30   */          add r9.x___, r0.zzzz, r10.zzzz
/*   31   */          add r9._yz_, r9.yyzz, r1.wwxx
/*   32   */          mad r1._yzw, r9.xxyz, c51.wwww, c51.xxyz
/*   33   */          mad r2._yzw, r9.xxyz, c51.wwww, r2.xxyz
/*   34   */          tfetch3D r2.x___, r8.xyz, tf2, FetchValidOnly=false
/*    2.1 */       exec
/*   35   */          tfetch3D r2._x__, r2.yzw, tf2, FetchValidOnly=false
/*   36   */          tfetch3D r2.__x_, r7.xyz, tf2, FetchValidOnly=false
/*   37   */          tfetch3D r2.___x, r6.xyz, tf2, FetchValidOnly=false
/*   38   */          tfetch3D r1.x___, r5.xyz, tf2, FetchValidOnly=false
/*   39   */          tfetch3D r1._x__, r1.yzw, tf2, FetchValidOnly=false
/*   40   */          tfetch3D r1.__x_, r4.xyz, tf2, FetchValidOnly=false
/*    3.0 */       exec
/*   41   */          tfetch3D r1.___x, r3.xyz, tf2, FetchValidOnly=false
/*   42   */          tfetch2D r0.__x_, r0.xy, tf1, FetchValidOnly=false
/*   43   */          serialize
                      dp4 r1._y__, r1.wzxy, c254
/*   44   */          dp4 r1.__z_, r2.wzxy, c254
              +       mulsc r1.x___, c52.x, r0.z
/*   45   */          mad r0.__zw, r1.yyyz, c255.xxxx, c253.yyyy
/*   46   */          mad r0.xy__, r1.xxxx, r0.zwww, r0.xyyy
/*    3.1 */       exec
/*   47   */          tfetch2D r0.xyz1, r0.xy, tf0
/*    4.0 */       alloc colors
/*    4.1 */       exece
/*   48   */          max oC0, r0, r0
