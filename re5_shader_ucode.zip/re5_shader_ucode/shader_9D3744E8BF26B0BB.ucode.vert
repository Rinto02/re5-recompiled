/*    0.0 */       exec
/*    8   */          vfetch_full r1.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=5
/*    9   */          vfetch_mini r2.___x, Offset=3, DataFormat=FMT_8_8_8_8
/*   10   */          vfetch_mini r4.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   11   */          vfetch_mini r0.xy__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   12   */          serialize
                      mad r2.xyz_, r1.xyzz, c3.xyzz, c4.xyzz
/*   13   */          mul r5.xy__, r0.xyyy, c255.wwww
/*    0.1 */       exec
/*   14   */          add r1.x___, -r2.wwww, c255.xxxx
              +       maxas r0._, r5.yy
/*   15   */          mul r0, r1.xxxx, c[30+a0]
/*   16   */          mul r3, r1.xxxx, c[29+a0]
/*   17   */          mul r1, r1.xxxx, c[28+a0]
              +       maxas r0._, r5.xx
/*   18   */          mad r1, r2.wwww, c[28+a0], r1
/*   19   */          mad r3, r2.wwww, c[29+a0], r3
/*    1.0 */       exec
/*   20   */          mad r0, r2.wwww, c[30+a0], r0
/*   21   */          cndeq r2, c255.zzzx, r2.zxyy, c255.xxxx
/*   22   */          dp4 r5.x___, r1.zxyw, r2
/*   23   */          dp4 r5._y__, r3.zxyw, r2
/*   24   */          dp4 r5.__z_, r0.zxyw, r2
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   25   */          cndeq r2, c255.zzzx, r5.zxyy, c255.xxxx
/*   26   */          dp4 r6.x___, c0.zxyw, r2
/*   27   */          dp4 r6._y__, c1.zxyw, r2
/*   28   */          dp4 r6.__z_, c2.zxyw, r2
/*   29   */          dp2add r2.x___, r6.xyyy, r6.xyyy, c255.zzzz
/*   30   */          dp3 r2._y__, r6.zxyy, r6.zxyy
/*    2.1 */       exec
/*   31   */          sqrt r2.___w, r_abs[2].y
/*   32   */          mad r2.__z_, r2.wwww, c27.xxxx, c27.yyyy
/*   33   */          add r2._y__, -r6.zzzz, r2.wwww
/*   34   */          mul r7.xy__, r6.xyyy, r2.wwww
/*   35   */          mul r7.xy__, r7.yxxx, r2.yyyy
              +       rcp r2.x___, r2.x
/*   36   */          mul r2.xy__, r7.yxxx, r2.xxxx
/*    3.0 */       exec
/*   37   */          cndge r2.__zw, r6.zzzz, r2.zzzw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   38   */          cndeq r6, c255.zzzx, r5.zxyy, c255.xxxx
/*   39   */          dp4 r2.x___, c23.zxyw, r6
/*   40   */          dp4 r2._y__, c24.zxyw, r6
/*   41   */          dp4 r2.__z_, c25.zxyw, r6
/*   42   */          dp4 r2.___w, c26.zxyw, r6
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   43   */          max oPos, r2, r2
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   44   */          dp3 r2._y__, r4.zxyy, r3.zxyy
/*   45   */          dp3 r2.__z_, r4.zxyy, r0.zxyy
/*   46   */          dp3 r0.x___, r5.zxyy, c2.zxyy
/*   47   */          dp3 r2.x___, r4.zxyy, r1.zxyy
              +       addsc r0.___w, -c2.w, -r0.x
/*   48   */          mad r1.xyz_, -r0.wwww, c5.xyzz, r5.xyzz
/*   49   */          dp3 r0.x___, r2.zxyy, r2.zxyy
/*    6.1 */       exec
/*   50   */          sge r1.___w, r_abs[0].xxxx, c255.zzzz
              +       rsq r0.x___, r_abs[0].x
/*   51   */          dp4 o1.x___, c220.zxyw, r1.zxyw
/*   52   */          dp4 o1._y__, c221.zxyw, r1.zxyw
/*   53   */          dp4 o1.__z_, c222.zxyw, r1.zxyw
/*   54   */          dp4 o1.___w, c223.zxyw, r1.zxyw
/*   55   */          mul r0.xyz_, r2.xyzz, r0.xxxx
/*    7.0 */       exece
/*   56   */          max o0, r0, r0
/*    7.1 */       cnop
