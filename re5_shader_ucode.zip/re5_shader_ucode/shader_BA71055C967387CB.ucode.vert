/*    0.0 */       exec
/*    4   */          vfetch_full r1.xyz1, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=6
/*    5   */          vfetch_mini r2.yx__, Offset=4, DataFormat=FMT_32_32_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       alloc position
/*    1.0 */       exec
/*    6   */          max oPos, r1, r1
/*    1.1 */       alloc interpolators
/*    2.0 */       exec
/*    7   */          maxs r1.___w, r2.yy
/*    8   */          mad r0.x_zw, c0.wwwz, c255.yzzx, r2.xxxy
/*    9   */          mad r3.xyz_, c0.zwzz, c255.zxyy, r2.yxyy
/*   10   */          maxs o2._y__, r2.xx
/*   11   */          max r1._y__, r3.zzzz, r3.zzzz
              +       maxs r0._y__, r3.xx
/*   12   */          max o2.x_z_, r0.wwww, r0.wwww
              +       maxs o2.___w, r3.yy
/*    2.1 */       exec
/*   13   */          max r1.x_z_, r0.xzzz, r0.xzzz
              +       maxs r2.__z_, r3.yy
/*   14   */          max o4.x_zw, r3.zzzy, r3.zzzy
              +       maxs o4._y__, r2.xx
/*   15   */          max o6.x_zw, r3.xxxy, r3.xxxy
              +       maxs o6._y__, r2.xx
/*   16   */          max o3, r0.wxwz, r0.wxwz
/*   17   */          max o0, r2.yxyz, r2.yxyz
/*   18   */          max o1, r1.wxwz, r1.wxwz
/*    3.0 */       exece
/*   19   */          max o5, r1.yxyz, r1.yxyz
/*   20   */          max o7, r0.yxyz, r0.yxyz
/*    3.1 */       cnop
