/*    0.0 */       exec
/*    8   */          vfetch_full r1.xyz_, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*    9   */          vfetch_mini r2.xyz_, Offset=3, DataFormat=FMT_2_10_10_10, Signed=true
/*   10   */          vfetch_mini r9, Offset=4, DataFormat=FMT_8_8_8_8, Signed=true
/*   11   */          vfetch_mini r0._yx_, Offset=5, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   12   */          vfetch_mini r7.__yx, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   13   */          vfetch_mini r6.yx__, Offset=7, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*    0.1 */       exec
/*   14   */          vfetch_full r7.yx__, r0.x, vf1, DataFormat=FMT_16_16_FLOAT, Stride=1, Signed=true, NumFormat=integer
/*   15   */          serialize
                      max r8, c28, c28
/*   16   */          max r4, c29, c29
/*   17   */          max r3, c30, c30
/*   18   */          cndeq r5, c255.zzzx, r1.zxyy, c255.xxxx
/*   19   */          dp4 r1.x___, r8.zxyw, r5
/*    1.0 */       exec
/*   20   */          dp4 r1._y__, r4.zxyw, r5
/*   21   */          dp4 r1.__z_, r3.zxyw, r5
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   22   */          cndeq r5, c255.zzzx, r1.zxyy, c255.xxxx
/*   23   */          dp4 r10.x___, c0.zxyw, r5
/*   24   */          dp4 r10._y__, c1.zxyw, r5
/*   25   */          dp4 r10.__z_, c2.zxyw, r5
/*   26   */          dp2add r1.___w, r10.xyyy, r10.xyyy, c255.zzzz
/*   27   */          dp3 r0.x___, r10.zxyy, r10.zxyy
/*    2.1 */       exec
/*   28   */          sqrt r0.___w, r_abs[0].x
/*   29   */          mad r0.x___, r0.wwww, c27.xxxx, c27.yyyy
/*   30   */          add r2.___w, -r10.zzzz, r0.wwww
/*   31   */          mul r5.xy__, r10.xyyy, r0.wwww
/*   32   */          mul r5.xy__, r5.yxxx, r2.wwww
              +       rcp r1.___w, r1.w
/*   33   */          mul r5.xy__, r5.yxxx, r1.wwww
/*    3.0 */       exec
/*   34   */          cndge r5.__zw, r10.zzzz, r0.xxxw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   35   */          cndeq r10, c255.zzzx, r1.zxyy, c255.xxxx
/*   36   */          dp4 r5.x___, c23.zxyw, r10
/*   37   */          dp4 r5._y__, c24.zxyw, r10
/*   38   */          dp4 r5.__z_, c25.zxyw, r10
/*   39   */          dp4 r5.___w, c26.zxyw, r10
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   40   */          mad r5.__z_, -r5.wwww, c6.xxxx, r5.zzzz
/*   41   */          max oPos, r5, r5
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   42   */          dp3 r10.x___, r2.zxyy, r4.zxyy
/*   43   */          dp3 r10._y__, r2.zxyy, r8.zxyy
/*   44   */          dp3 r10.__z_, r2.zxyy, r3.zxyy
              +       maxs r2.x___, r9.xx
/*   45   */          max r2._y__, r9.yyyy, r9.yyyy
              +       maxs r2.__z_, r9.zz
/*   46   */          dp3 r3.__z_, r2.zxyy, r3.zxyy
              +       maxs r9.__z_, c31.xx
/*   47   */          dp3 r3._y__, r2.zxyy, r4.zxyy
              +       addsc r9.x___, c4.x, r0.y
/*    6.1 */       exec
/*   48   */          dp3 r3.x___, r2.zxyy, r8.zxyy
              +       addsc r9._y__, c4.y, r0.z
/*   49   */          max o4.xy__, r6.xyyy, r6.xyyy
/*   50   */          max o2.xyz_, r1.xyzz, r1.xyzz
/*   51   */          add o3.xy__, r7.zwww, c5.xyyy
/*   52   */          add o5.xy00, r7.xyyy, c5.zwww
/*   53   */          max o6.xyz_, r3.xyzz, r3.xyzz
/*    7.0 */       exec
/*   54   */          max o8.xyz_, r10.yxzz, r10.yxzz
/*   55   */          max o1, r9, r9
/*   56   */          max o0, r5, r5
/*   57   */          mul r1.xy__, r3.xxxx, r10.zxxx
/*   58   */          mul r0, r3.yzyz, r10.zxyy
/*   59   */          add r0.__z_, r1.yyyy, -r0.zzzz
/*    7.1 */       exece
/*   60   */          add r0.___w, r0.wwww, -r1.xxxx
              +       subs r0._y__, r0.xy
/*   61   */          dp3 r0.x___, r0.zyww, r0.zyww
/*   62   */          rsq r0.x___, r_abs[0].x
/*   63   */          mul r0.xyz_, r0.yzww, r0.xxxx
/*   64   */          mul o7.xyz_, r0.xzyy, c3.zzzz
