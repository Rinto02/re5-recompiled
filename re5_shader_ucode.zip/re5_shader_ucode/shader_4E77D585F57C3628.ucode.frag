/*    0.0 */       exec
/*   24   */          tfetch2D r6.yxzw, r1.xy, tf0
/*   25   */          serialize
                      max r1._, r1, r1
              +       rcp r1.x___, r0.w
/*   26   */          mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r6.ww
/*   27   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   28   */          mul r0.xy__, r3.zwww, r0.yxxx
              +       subsc r1.x___, -c1.x, -r1.y
/*   29   */          kill_gt r1._, c254.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   30   */          tfetch2D r10.zyx_, r3.xy, tf1
/*   31   */          tfetch2D r0, r0.xy, tf4
/*   32   */          serialize
                      sgt r3.x_zw, -r_abs[1].xxxx, c254.xxxx
              +       maxs r4.__z_, c58.xx
/*   33   */          add r7.xyz_, r2.xyzz, -c23.xyzz
              +       sgts r8.x___, -r_abs[1].x
/*   34   */          dp3 r1.x___, r5.zxyy, r5.zxyy
              +       sgts r8.__z_, -r_abs[1].x
/*   35   */          mul r0, r0.wzyx, c5.wzyx
              +       sgts r8._y__, -r_abs[1].x
/*    1.0 */       exec
/*   36   */          dp3 r1._y__, r7.zxyy, r7.zxyy
              +       rsq r1.x___, r_abs[1].x
/*   37   */          mul r9.xyz_, r1.xxxx, r5.zyxx
              +       maxs r1.x___, r6.zz
/*   38   */          min r0, r0, c9.xxxx
              +       rsq r2.___w, r_abs[1].y
/*   39   */          mul r5.xyz_, r7.zyxx, r2.wwww
              +       mulsc r6.__z_, c15.z, r1.x
/*   40   */          max r7, r0.wzyx, c10.xxxx
              +       mulsc r6.x___, c15.y, r6.x
/*   41   */          max r0.xy__, r7.yxxx, r7.wzzz
              +       mulsc r6._y__, c15.x, r6.y
/*    1.1 */       exec
/*   42   */          max r3._y__, r0.yyyy, r0.xxxx
              +       sqrt r1._y__, r_abs[1].y
/*    2.0 */       cjmp !b128, L24
/*    2.1 */       exec
/*   43   */          mul r0, r7.wzyx, c48.wzyx
              +       retain_prev r1._
/*   44   */          add r8.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   45   */          dp3 r8.___w, r8.xzyy, r8.xzyy
              +       retain_prev r1._
/*   46   */          max4 r0.__z_, r0.zxwy
              +       rsq r1.x___, r_abs[8].w
/*   47   */          mul r11, r8, r1.xxxx
              +       retain_prev r1._
/*   48   */          dp3 r3.___w, r9.xzyy, r11.xzyy
              +       retain_prev r1._
/*    3.0 */       exec
/*   49   */          add r8.xyz_, r11.zyxx, -r5.zyxx
              +       retain_prev r1._
/*   50   */          dp3 r1.x___, r11.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   51   */          add r0.x___, r11.wwww, -c32.wwww
              +       retain_prev r1._
/*   52   */          add r1.x___, r1.xxxx, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r0.x
/*   53   */          dp3 r2.___w, r8.zxyy, r8.zxyy
              +       mulsc r1.x___, c35.y, r1.x
/*   54   */          max r1.x___, r1.xxxx, c35.wwww
              +       rsq r2.___w, r_abs[2].w
/*    3.1 */       exec
/*   55   */          mul r8.xyz_, r8.zyxx, r2.wwww
              +       subsc r0.___w, c254.y, r0.x
/*   56   */          min r3.x___, r1.xxxx, c254.yyyy
              +       subsc r2.___w, c254.y, r0.z
/*   57   */          dp3 r3.__z_, r9.xzyy, r8.xzyy
              +       maxs r1._, r0.ww
/*   58   */          max r0._yz_, r3.wwzz, c254.xxxx
              +       muls_prev r3.__z_, r3.x
/*   59   */          mul r8._yzw, r3.xxzz, c32.xxzy
              +       log r1.x___, r_abs[0].z
/*   60   */          max r1._, r1, r1
              +       mulsc r0.x___, c57.z, r1.x
/*    4.0 */       exec
/*   61   */          mul r8.x___, r8.yyyy, r0.wwww
              +       exp r0.x___, r0.x
/*   62   */          mul r3.x_z_, r8.zwww, r0.xxxx
              +       retain_prev r1._
/*   63   */          mul r3.x_z_, r3.xzzz, r2.wwww
              +       retain_prev r1._
/*   64   */          mul r0, r8.xzwx, r0.yyyx
              +       retain_prev r1._
/*   65   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       maxs r1._, r0.ww
/*   66   */          mul r8.xyz_, r0.zxyy, c35.zzzz
              +       muls_prev r3.___w, r2.w
/*    4.1 */       cjmp !b129, L24
/*    5.0 */       exec
/*   67   */          mul r0, r7.wzyx, c49.wzyx
              +       retain_prev r1._
/*   68   */          add r11.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   69   */          dp3 r11.___w, r11.zxyy, r11.zxyy
              +       retain_prev r1._
/*   70   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[11].w
/*   71   */          mul r12, r11, r1.xxxx
              +       retain_prev r1._
/*   72   */          dp3 r11.__z_, r9.xzyy, r12.zxyy
              +       retain_prev r1._
/*    5.1 */       exec
/*   73   */          add r11.xy_w, r12.xyzz, -r5.zyxx
              +       retain_prev r1._
/*   74   */          dp3 r2.___w, r12.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   75   */          add r1.x___, r12.wwww, -c36.wwww
              +       retain_prev r1._
/*   76   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   77   */          dp3 r0._y__, r11.wxyy, r11.wxyy
              +       mulsc r1.x___, c39.y, r2.w
/*   78   */          max r1.x___, r1.xxxx, c39.wwww
              +       rsq r2.___w, r_abs[0].y
/*    6.0 */       exec
/*   79   */          mul r12.xyz_, r11.wyxx, r2.wwww
              +       subsc r2.___w, c254.y, r0.x
/*   80   */          min r11.x___, r1.xxxx, c254.yyyy
              +       subsc r0._y__, c254.y, r0.z
/*   81   */          dp3 r11._y__, r9.xzyy, r12.xzyy
              +       maxs r1._, r0.yy
/*   82   */          max r0.x__w, r11.zyyy, c254.xxxx
              +       muls_prev r11._y__, r11.x
/*   83   */          mul r11.xy_w, r11.yyxx, c36.zyxx
              +       log r1.x___, r_abs[0].w
/*   84   */          mul r11.__z_, r11.wwww, r0.yyyy
              +       mulsc r0.___w, c57.z, r1.x
/*    6.1 */       exec
/*   85   */          mul r0.xyz_, r11.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*   86   */          mul r11.xyz_, r11.xyzz, r0.wwww
              +       retain_prev r1._
/*   87   */          mad r3.x_zw, r11.xyyz, r2.wwww, r3.xzzw
              +       retain_prev r1._
/*   88   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   89   */          mad r8.xyz_, r0.zxyy, c39.zzzz, r8.xyzz
              +       retain_prev r1._
/*    7.0 */       cjmp !b130, L24
/*    7.1 */       exec
/*   90   */          mul r0, r7, c50
              +       retain_prev r1._
/*   91   */          add r11.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   92   */          dp3 r11.___w, r11.xzyy, r11.xzyy
              +       retain_prev r1._
/*   93   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[11].w
/*   94   */          mul r12, r11, r1.xxxx
              +       retain_prev r1._
/*   95   */          dp3 r11.__z_, r9.xzyy, r12.xzyy
              +       retain_prev r1._
/*    8.0 */       exec
/*   96   */          add r11.xy_w, r12.zyxx, -r5.zyxx
              +       retain_prev r1._
/*   97   */          dp3 r2.___w, r12.xzyy, -c42.zxyy
              +       retain_prev r1._
/*   98   */          add r1.x___, r12.wwww, -c40.wwww
              +       retain_prev r1._
/*   99   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*  100   */          dp3 r0._y__, r11.wxyy, r11.wxyy
              +       mulsc r1.x___, c43.y, r2.w
/*  101   */          max r1.x___, r1.xxxx, c43.wwww
              +       rsq r2.___w, r_abs[0].y
/*    8.1 */       exec
/*  102   */          mul r12.xyz_, r11.xyww, r2.wwww
              +       subsc r2.___w, c254.y, r0.x
/*  103   */          min r11.x___, r1.xxxx, c254.yyyy
              +       subsc r0._y__, c254.y, r0.z
/*  104   */          dp3 r11._y__, r9.xzyy, r12.zxyy
              +       maxs r1._, r0.yy
/*  105   */          max r0.x__w, r11.zyyy, c254.xxxx
              +       muls_prev r11._y__, r11.x
/*  106   */          mul r11.xy_w, r11.yyxx, c40.zyxx
              +       log r1.x___, r_abs[0].w
/*  107   */          mul r11.__z_, r11.wwww, r0.yyyy
              +       mulsc r0.___w, c57.z, r1.x
/*    9.0 */       exec
/*  108   */          mul r0.xyz_, r11.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  109   */          mul r11.xyz_, r11.xyzz, r0.wwww
              +       retain_prev r1._
/*  110   */          mad r3.x_zw, r11.xyyz, r2.wwww, r3.xzzw
              +       retain_prev r1._
/*  111   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  112   */          mad r8.xyz_, r0.zxyy, c43.zzzz, r8.xyzz
              +       retain_prev r1._
/*    9.1 */       cjmp !b131, L24
/*   10.0 */       exec
/*  113   */          mul r0, r7.wzyx, c51.wzyx
              +       retain_prev r1._
/*  114   */          add r11.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*  115   */          dp3 r11.___w, r11.zxyy, r11.zxyy
              +       retain_prev r1._
/*  116   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[11].w
/*  117   */          mul r12, r11, r1.xxxx
              +       retain_prev r1._
/*  118   */          dp3 r11.__z_, r9.xzyy, r12.zxyy
              +       retain_prev r1._
/*   10.1 */       exec
/*  119   */          add r11.xy_w, r12.xyzz, -r5.zyxx
              +       retain_prev r1._
/*  120   */          dp3 r2.___w, r12.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  121   */          add r1.x___, r12.wwww, -c44.wwww
              +       retain_prev r1._
/*  122   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  123   */          dp3 r0._y__, r11.wxyy, r11.wxyy
              +       mulsc r1.x___, c47.y, r2.w
/*  124   */          max r1.x___, r1.xxxx, c47.wwww
              +       rsq r2.___w, r_abs[0].y
/*   11.0 */       exec
/*  125   */          mul r12.xyz_, r11.wyxx, r2.wwww
              +       subsc r2.___w, c254.y, r0.x
/*  126   */          min r11.x___, r1.xxxx, c254.yyyy
              +       subsc r0._y__, c254.y, r0.z
/*  127   */          dp3 r11._y__, r9.xzyy, r12.xzyy
              +       maxs r1._, r0.yy
/*  128   */          max r0.x__w, r11.zyyy, c254.xxxx
              +       muls_prev r11._y__, r11.x
/*  129   */          mul r11.xy_w, r11.yyxx, c44.zyxx
              +       log r1.x___, r_abs[0].w
/*  130   */          mul r11.__z_, r11.wwww, r0.yyyy
              +       mulsc r0.___w, c57.z, r1.x
/*   11.1 */       exec
/*  131   */          mul r0.xyz_, r11.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  132   */          mul r11.xyz_, r11.xyzz, r0.wwww
              +       retain_prev r1._
/*  133   */          mad r3.x_zw, r11.xyyz, r2.wwww, r3.xzzw
              +       retain_prev r1._
/*  134   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  135   */          mad r8.xyz_, r0.zxyy, c47.zzzz, r8.xyzz
              +       retain_prev r1._
                label L24
/*   12.0 */       cjmp !b132, L36
/*   12.1 */       exec
/*  136   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  137   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  138   */          mul r11, r7.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  139   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  140   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  141   */          dp3 r2.___w, r0.xzyy, r9.xzyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   13.0 */       exec
/*  142   */          max4 r0._y__, r11.zxwy
              +       maxs r0.__z_, r2.ww
/*  143   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  144   */          mul r11.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  145   */          mul r11.xyz_, r11.xyzz, r2.wwww
              +       retain_prev r1._
/*  146   */          mad r8.xyz_, r11.xzyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   13.1 */       cjmp !b133, L36
/*   14.0 */       exec
/*  147   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  148   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  149   */          mul r11, r7, c53
              +       rsq r1.x___, r_abs[0].w
/*  150   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  151   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  152   */          dp3 r2.___w, r0.zxyy, r9.xzyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   14.1 */       exec
/*  153   */          max4 r0._y__, r11.ywxz
              +       maxs r0.__z_, r2.ww
/*  154   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  155   */          mul r11.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  156   */          mul r11.xyz_, r11.xyzz, r2.wwww
              +       retain_prev r1._
/*  157   */          mad r8.xyz_, r11.xzyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   15.0 */       cjmp !b134, L36
/*   15.1 */       exec
/*  158   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  159   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  160   */          mul r11, r7.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  161   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  162   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  163   */          dp3 r2.___w, r0.xzyy, r9.xzyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   16.0 */       exec
/*  164   */          max4 r0._y__, r11.zxwy
              +       maxs r0.__z_, r2.ww
/*  165   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  166   */          mul r11.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  167   */          mul r11.xyz_, r11.xyzz, r2.wwww
              +       retain_prev r1._
/*  168   */          mad r8.xyz_, r11.xzyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   16.1 */       cjmp !b135, L36
/*   17.0 */       exec
/*  169   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  170   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  171   */          mul r7, r7, c55
              +       rsq r1.x___, r_abs[0].w
/*  172   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  173   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  174   */          dp3 r2.___w, r0.zxyy, r9.xzyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   17.1 */       exec
/*  175   */          max4 r0._y__, r7.ywxz
              +       maxs r0.__z_, r2.ww
/*  176   */          add r0.xy__, -r0.xyyy, c254.yyyy
              +       maxs r0.___w, c254.xx
/*  177   */          mul r7.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  178   */          mul r7.xyz_, r7.xyzz, r2.wwww
              +       retain_prev r1._
/*  179   */          mad r8.xyz_, r7.xzyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
                label L36
/*   18.0 */       exec
/*  180   */          dp3 r7.__z_, r5.xzyy, r9.xzyy
              +       retain_prev r1._
/*  181   */          mul r7.x___, r3.yyyy, c6.xxxx
              +       adds r1.x___, r7.zz
/*  182   */          mad r0.xyz_, -r9.xyzz, r1.xxxx, r5.xyzz
              +       retain_prev r1._
/*  183   */          cube r0, r0.xxzy, r0.yzxx
              +       subsc r1.x___, -c254.y, -r1.w
/*  184   */          max r9.__z_, r0.wwww, r0.wwww
              +       rcp r2.___w, r_abs[0].z
/*  185   */          mul r0._yz_, r0.yyxx, r2.wwww
              +       mulsc r0.x___, c56.w, r1.x
/*   18.1 */       exec
/*  186   */          add r9.xy_w, r0.yzxx, c254.zzyy
              +       retain_prev r1._
/*  187   */          setTexLOD r4.z
/*  188   */          tfetchCube r11, r9.xyz, tf2, UseComputedLOD=false, UseRegisterLOD=true
/*  189   */          tfetch2D r0, r4.xy, tf3
/*   19.0 */       alloc colors
/*   19.1 */       exec
/*  190   */          mul r0.xyz_, r0.zxyy, r0.wwww
              +       mulsc r7._y__, c8.x, r3.y
/*  191   */          max r1.x___, r11.wwww, c255.xxxx
              +       mulsc r4.x___, c59.z, r0.x
/*  192   */          add r7._yz_, -r7.yyzz, c254.yyyy
              +       rcp r1.x___, r1.x
/*  193   */          mul r11.xyz_, r1.xxxx, r11.xyzz
              +       mulsc r4._y__, c59.y, r0.z
/*  194   */          mul r11.xyz_, r11.zyxx, r7.yyyy
              +       muls r1.x___, r_abs[7].zz
/*  195   */          mul r1.x___, r1.xxxx, r1.xxxx
              +       mulsc r4.__z_, c59.x, r0.y
/*   20.0 */       exec
/*  196   */          mul r11.___w, r1.xxxx, r_abs[7].zzzz
              +       maxs r1._, r4.yy
/*  197   */          mad r0.xyz_, r11.xyzz, c57.wwww, r3.xzww
              +       retain_prev r1._
/*  198   */          mad_sat r1.x___, r11.wwww, c57.xxxx, c57.yyyy
              +       retain_prev r1._
/*  199   */          mul r4.xyz_, r4.xzyy, r9.wwww
              +       muls_prev r7._y__, r1.w
/*  200   */          add r3.xyz_, -r4.xzyy, c7.zyxx
              +       subsc r3.___w, c254.y, r1.x
/*  201   */          mul r3, r7.xxxy, r3.xzyw
              +       retain_prev r1._
/*   20.1 */       exec
/*  202   */          add r3.xyz_, r4.xzyy, r3.xzyy
              +       retain_prev r1._
/*  203   */          mul r4.xyz_, r3.wwww, r10.xyzz
              +       maxs r1._, r6.ww
/*  204   */          mul r0.xyz_, r4.zyxx, r0.zyxx
              +       muls_prev r2.___w, r1.z
/*  205   */          mad r1.x_zw, r8.xyyz, r1.wwww, r3.xzzy
              +       retain_prev r1._
/*  206   */          mad r0.xyz_, r6.yxzz, r1.zwxx, r0.xyzz
              +       retain_prev r1._
/*   21.0 */       cjmp !b136, L46
/*   21.1 */       exec
/*  207   */          mad r1.___w, r1.yyyy, c14.yyyy, c14.zzzz
              +       retain_prev r1._
/*  208   */          dp3 r1.__z_, r5.xzyy, c12.zxyy
              +       retain_prev r1._
/*  209   */          cndeq r3, c254.xxxy, r2.zxyy, c254.yyyy
              +       retain_prev r1._
/*  210   */          dp4 r1.x___, c12.zxyw, r3
              +       subsc r1._y__, -c11.x, -r1.y
/*  211   */          add r2.xyz_, -r0.xyzz, c13.xyzz
              +       mulsc r0.___w, c11.z, r1.y
/*  212   */          min r3.xy__, r1.xzzz, c254.xwww
              +       mulsc r1.x___, c11.w, r1.x
/*   22.0 */       exec
/*  213   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  214   */          max r1._, r1, r1
              +       mulsc r1.x___, c14.x, r1.y
/*  215   */          mad r1.x___, r1.xxxx, r3.xxxx, r1.wwww
              +       retain_prev r1._
/*  216   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  217   */          min r1.x___, r1.xxxx, c13.wwww
              +       retain_prev r1._
/*  218   */          max r1.x___, r1.xxxx, c254.xxxx
              +       retain_prev r1._
/*   22.1 */       exec
/*  219   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L46
/*   23.0 */       exece
/*  220   */          mul r2.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  221   */          max oC0, r2, r2
/*   23.1 */       cnop
