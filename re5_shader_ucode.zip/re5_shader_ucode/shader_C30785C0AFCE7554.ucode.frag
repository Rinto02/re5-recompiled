/*    0.0 */       exec
/*   27   */          tfetch2D r11, r1.xy, tf0
/*   28   */          serialize
                      mul r4.xy__, c4.zwww, c3.xyyy
              +       maxs r1._y__, r11.ww
/*   29   */          add r5.xyz_, r2.zyxx, -c23.zyxx
              +       rcp r2.___w, r0.w
/*   30   */          mad r0.xy__, r2.wwww, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   31   */          mul r0.xy__, r4.xyyy, r0.yxxx
              +       subsc r2.___w, -c1.x, -r1.y
/*   32   */          kill_gt r1._, c255.xxxx, r2.wwww
              +       retain_prev r1._
/*    0.1 */       exec
/*   33   */          tfetch2D r0, r0.xy, tf5
/*    1.0 */       alloc colors
/*    1.1 */       exec
/*   34   */          dp3 r2.___w, r3.zxyy, r3.zxyy
              +       retain_prev r1._
/*   35   */          mul r11.xyz_, r11.zyxx, c12.zyxx
              +       sgts r8._y__, -r_abs[1].x
/*   36   */          dp3 r4.___w, r5.xzyy, r5.xzyy
              +       sgts r8.__z_, -r_abs[1].x
/*   37   */          mul r0, r0.wzyx, c5.wzyx
              +       rsq r2.___w, r_abs[2].w
/*   38   */          mul r9.xyz_, r2.wwww, c18.zyxx
              +       sgts r8.x___, -r_abs[1].x
/*   39   */          mul r10.xyz_, r2.wwww, c17.zyxx
              +       mulsc r7.__z_, c16.x, r2.w
/*    2.0 */       exec
/*   40   */          mul r4.xyz_, r2.wwww, r3.zxyy
              +       mulsc r7._y__, c16.y, r2.w
/*   41   */          min r0, r0, c6.xxxx
              +       mulsc r7.x___, c16.z, r2.w
/*   42   */          max r6, r0.wzyx, c7.xxxx
              +       sqrt r3.___w, r_abs[4].w
/*    2.1 */       cjmp !b128, L33
/*    3.0 */       exec
/*   43   */          sgt r5.___w, c58.zzzz, c255.wwww
              +       retain_prev r1._
/*   44   */          add r0.x_zw, -r2.zyyx, c33.zyyx
              +       retain_prev r1._
/*   45   */          mul r8, r6.wzyx, c48.wzyx
              +       retain_prev r1._
/*   46   */          dp3 r1._y__, r0.xwzz, r0.xwzz
              +       retain_prev r1._
/*   47   */          max4 r1.x___, r8.zxwy
              +       retain_prev r1._
/*   48   */          add r0._y__, -r1.xxxx, c255.zzzz
              +       rsq r1.x___, r_abs[1].y
/*    3.1 */       exec
/*   49   */          mul r8.xyz_, r0.xzww, r1.xxxx
              +       retain_prev r1._
/*   50   */          dp3 r0.x___, r4.xyzz, r8.xzyy
              +       retain_prev r1._
/*   51   */          dp3 r2.___w, r8.xzyy, -c34.zxyy
              +       maxs r1._, r1.yy
/*   52   */          add r1._y__, r2.wwww, -c35.xxxx
              +       muls_prev r1.x___, r1.x
/*   53   */          mul r0.__z_, r1.yyyy, c35.yyyy
              +       subsc r1._y__, -c32.w, -r1.x
/*   54   */          max r0.__z_, r0.zzzz, c35.wwww
              +       mulsc_sat r1._y__, c33.w, r1.y
/*    4.0 */       exec    // PredicateClean=false
/*   55   */          min r8.x___, r0.zzzz, c255.zzzz
              +       subsc r0.___w, c255.z, r1.y
/*   56   */          mul r8._y__, r0.wwww, r8.xxxx
              +       maxs r0.x___, r0.xx
/*   57   */          mul r8.xyz_, r8.xyyy, c32.xzyy
              +       maxs r0.__z_, c255.xx
/*   58   */          mul r8.___w, r8.xxxx, r0.wwww
              +       maxs r0.x___, r0.xz
/*   59   */          mul r0.x_zw, r8.yzzw, r0.xxxx
              +       setp_ne r1._, r5.w
/*    4.1 */  (p0) exec
/*   60   */     (p0) max r1._, r1, r1
              +  (p0) maxs r12.___w, c255.zz
/*   61   */     (p0) mul r8.xyz_, r1.xxxx, c34.xyzz
              +  (p0) rcp r1._y__, c58.z
/*   62   */     (p0) mad r8.xyz_, r8.xyzz, r2.wwww, c33.xyzz
              +  (p0) retain_prev r1._
/*   63   */     (p0) add r12.xyz_, -r8.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*   64   */     (p0) dp4 r8.x___, c62.zxyw, r12.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*   65   */     (p0) dp4 r8._y__, c63.zxyw, r12.zxyw
              +  (p0) mulsc r1.x___, c58.w, r1.x
/*    5.0 */  (p0) exec
/*   66   */     (p0) mul r8.xy__, r8.xyyy, c254.xxxx
              +  (p0) rcp r1.x___, r1.x
/*   67   */     (p0) mul r1.xy__, r8.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*   68   */     (p0) add r8.x___, r1.xxxx, c254.xxxx
              +  (p0) subsc r8._y__, c254.x, r1.y
/*   69   */     (p0) tfetch2D r8.xyz_, r8.xy, tf1
/*   70   */          serialize
                 (p0) mul r0.x_zw, r0.xzzw, r8.zyyx
              +  (p0) retain_prev r1._
/*    5.1 */       exec
/*   71   */          mul r8.xy__, r0.xyyy, c35.zzzz
              +       retain_prev r1._
/*   72   */          mul r8.xyz_, r8.yxyy, r0.wyzz
              +       retain_prev r1._
/*    6.0 */       cjmp !b129, L33
/*    6.1 */       exec
/*   73   */          sgt r5.___w, c59.zzzz, c255.wwww
              +       retain_prev r1._
/*   74   */          add r0.x_zw, -r2.xyyz, c37.xyyz
              +       retain_prev r1._
/*   75   */          mul r12, r6, c49
              +       retain_prev r1._
/*   76   */          dp3 r1._y__, r0.wxzz, r0.wxzz
              +       retain_prev r1._
/*   77   */          max4 r1.x___, r12.ywxz
              +       retain_prev r1._
/*   78   */          add r0._y__, -r1.xxxx, c255.zzzz
              +       rsq r1.x___, r_abs[1].y
/*    7.0 */       exec
/*   79   */          mul r12.xyz_, r0.xzww, r1.xxxx
              +       retain_prev r1._
/*   80   */          dp3 r0.x___, r4.xyzz, r12.zxyy
              +       retain_prev r1._
/*   81   */          dp3 r2.___w, r12.zxyy, -c38.zxyy
              +       maxs r1._, r1.yy
/*   82   */          add r1._y__, r2.wwww, -c39.xxxx
              +       muls_prev r1.x___, r1.x
/*   83   */          mul r0.__z_, r1.yyyy, c39.yyyy
              +       subsc r1._y__, -c36.w, -r1.x
/*   84   */          max r0.__z_, r0.zzzz, c39.wwww
              +       mulsc_sat r1._y__, c37.w, r1.y
/*    7.1 */       exec    // PredicateClean=false
/*   85   */          min r12.x___, r0.zzzz, c255.zzzz
              +       subsc r0.___w, c255.z, r1.y
/*   86   */          mul r12._y__, r0.wwww, r12.xxxx
              +       maxs r0.x___, r0.xx
/*   87   */          mul r12.xyz_, r12.xyyy, c36.xzyy
              +       maxs r0.__z_, c255.xx
/*   88   */          mul r12.___w, r12.xxxx, r0.wwww
              +       maxs r0.x___, r0.xz
/*   89   */          mul r0.x_zw, r12.yzzw, r0.xxxx
              +       setp_ne r1._, r5.w
/*    8.0 */  (p0) exec
/*   90   */     (p0) max r1._, r1, r1
              +  (p0) maxs r13.___w, c255.zz
/*   91   */     (p0) mul r12.xyz_, r1.xxxx, c38.xyzz
              +  (p0) rcp r1._y__, c59.z
/*   92   */     (p0) mad r12.xyz_, r12.xyzz, r2.wwww, c37.xyzz
              +  (p0) retain_prev r1._
/*   93   */     (p0) add r13.xyz_, -r12.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*   94   */     (p0) dp4 r12.x___, c64.zxyw, r13.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*   95   */     (p0) dp4 r12._y__, c65.zxyw, r13.zxyw
              +  (p0) mulsc r1.x___, c59.w, r1.x
/*    8.1 */  (p0) exec
/*   96   */     (p0) mul r12.xy__, r12.xyyy, c254.xxxx
              +  (p0) rcp r1.x___, r1.x
/*   97   */     (p0) mul r1.xy__, r12.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*   98   */     (p0) add r12.x___, r1.xxxx, c254.xxxx
              +  (p0) subsc r12._y__, c254.x, r1.y
/*   99   */     (p0) tfetch2D r12.xyz_, r12.xy, tf2
/*  100   */          serialize
                 (p0) mul r0.x_zw, r0.xzzw, r12.zyyx
              +  (p0) retain_prev r1._
/*    9.0 */       exec
/*  101   */          mul r12.xy__, r0.xyyy, c39.zzzz
              +       retain_prev r1._
/*  102   */          mad r8.xyz_, r12.yxyy, r0.wyzz, r8.xyzz
              +       retain_prev r1._
/*    9.1 */       cjmp !b130, L33
/*   10.0 */       exec
/*  103   */          sgt r5.___w, c60.zzzz, c255.wwww
              +       retain_prev r1._
/*  104   */          add r0.x_zw, -r2.xyyz, c41.xyyz
              +       retain_prev r1._
/*  105   */          mul r12, r6, c50
              +       retain_prev r1._
/*  106   */          dp3 r1._y__, r0.wxzz, r0.wxzz
              +       retain_prev r1._
/*  107   */          max4 r1.x___, r12.ywxz
              +       retain_prev r1._
/*  108   */          add r0._y__, -r1.xxxx, c255.zzzz
              +       rsq r1.x___, r_abs[1].y
/*   10.1 */       exec
/*  109   */          mul r12.xyz_, r0.xzww, r1.xxxx
              +       retain_prev r1._
/*  110   */          dp3 r0.x___, r4.xyzz, r12.zxyy
              +       retain_prev r1._
/*  111   */          dp3 r2.___w, r12.zxyy, -c42.zxyy
              +       maxs r1._, r1.yy
/*  112   */          add r1._y__, r2.wwww, -c43.xxxx
              +       muls_prev r1.x___, r1.x
/*  113   */          mul r0.__z_, r1.yyyy, c43.yyyy
              +       subsc r1._y__, -c40.w, -r1.x
/*  114   */          max r0.__z_, r0.zzzz, c43.wwww
              +       mulsc_sat r1._y__, c41.w, r1.y
/*   11.0 */       exec    // PredicateClean=false
/*  115   */          min r12.x___, r0.zzzz, c255.zzzz
              +       subsc r0.___w, c255.z, r1.y
/*  116   */          mul r12._y__, r0.wwww, r12.xxxx
              +       maxs r0.x___, r0.xx
/*  117   */          mul r12.xyz_, r12.xyyy, c40.xzyy
              +       maxs r0.__z_, c255.xx
/*  118   */          mul r12.___w, r12.xxxx, r0.wwww
              +       maxs r0.x___, r0.xz
/*  119   */          mul r0.x_zw, r12.yzzw, r0.xxxx
              +       setp_ne r1._, r5.w
/*   11.1 */  (p0) exec
/*  120   */     (p0) max r1._, r1, r1
              +  (p0) maxs r13.___w, c255.zz
/*  121   */     (p0) mul r12.xyz_, r1.xxxx, c42.xyzz
              +  (p0) rcp r1._y__, c60.z
/*  122   */     (p0) mad r12.xyz_, r12.xyzz, r2.wwww, c41.xyzz
              +  (p0) retain_prev r1._
/*  123   */     (p0) add r13.xyz_, -r12.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  124   */     (p0) dp4 r12.x___, c66.zxyw, r13.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  125   */     (p0) dp4 r12._y__, c67.zxyw, r13.zxyw
              +  (p0) mulsc r1.x___, c60.w, r1.x
/*   12.0 */  (p0) exec
/*  126   */     (p0) mul r12.xy__, r12.xyyy, c254.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  127   */     (p0) mul r1.xy__, r12.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*  128   */     (p0) add r12.x___, r1.xxxx, c254.xxxx
              +  (p0) subsc r12._y__, c254.x, r1.y
/*  129   */     (p0) tfetch2D r12.xyz_, r12.xy, tf3
/*  130   */          serialize
                 (p0) mul r0.x_zw, r0.xzzw, r12.zyyx
              +  (p0) retain_prev r1._
/*   12.1 */       exec
/*  131   */          mul r12.xy__, r0.xyyy, c43.zzzz
              +       retain_prev r1._
/*  132   */          mad r8.xyz_, r12.yxyy, r0.wyzz, r8.xyzz
              +       retain_prev r1._
/*   13.0 */       cjmp !b131, L33
/*   13.1 */       exec
/*  133   */          sgt r5.___w, c61.zzzz, c255.wwww
              +       retain_prev r1._
/*  134   */          add r0.x_zw, -r2.xyyz, c45.xyyz
              +       retain_prev r1._
/*  135   */          mul r12, r6, c51
              +       retain_prev r1._
/*  136   */          dp3 r1._y__, r0.wxzz, r0.wxzz
              +       retain_prev r1._
/*  137   */          max4 r1.x___, r12.ywxz
              +       retain_prev r1._
/*  138   */          add r0._y__, -r1.xxxx, c255.zzzz
              +       rsq r1.x___, r_abs[1].y
/*   14.0 */       exec
/*  139   */          mul r12.xyz_, r0.xzww, r1.xxxx
              +       retain_prev r1._
/*  140   */          dp3 r0.x___, r4.xyzz, r12.zxyy
              +       retain_prev r1._
/*  141   */          dp3 r2.___w, r12.zxyy, -c46.zxyy
              +       maxs r1._, r1.yy
/*  142   */          add r1._y__, r2.wwww, -c47.xxxx
              +       muls_prev r1.x___, r1.x
/*  143   */          mul r0.__z_, r1.yyyy, c47.yyyy
              +       subsc r1._y__, -c44.w, -r1.x
/*  144   */          max r0.__z_, r0.zzzz, c47.wwww
              +       mulsc_sat r1._y__, c45.w, r1.y
/*   14.1 */       exec    // PredicateClean=false
/*  145   */          min r12.x___, r0.zzzz, c255.zzzz
              +       subsc r0.___w, c255.z, r1.y
/*  146   */          mul r12._y__, r0.wwww, r12.xxxx
              +       maxs r0.x___, r0.xx
/*  147   */          mul r12.xyz_, r12.xyyy, c44.xzyy
              +       maxs r0.__z_, c255.xx
/*  148   */          mul r12.___w, r12.xxxx, r0.wwww
              +       maxs r0.x___, r0.xz
/*  149   */          mul r0.x_zw, r12.yzzw, r0.xxxx
              +       setp_ne r1._, r5.w
/*   15.0 */  (p0) exec
/*  150   */     (p0) max r1._, r1, r1
              +  (p0) maxs r13.___w, c255.zz
/*  151   */     (p0) mul r12.xyz_, r1.xxxx, c46.xyzz
              +  (p0) rcp r1._y__, c61.z
/*  152   */     (p0) mad r12.xyz_, r12.xyzz, r2.wwww, c45.xyzz
              +  (p0) retain_prev r1._
/*  153   */     (p0) add r13.xyz_, -r12.xyzz, r2.xyzz
              +  (p0) maxs r1._, r1.xx
/*  154   */     (p0) dp4 r12.x___, c68.zxyw, r13.zxyw
              +  (p0) muls_prev r1.x___, r1.y
/*  155   */     (p0) dp4 r12._y__, c69.zxyw, r13.zxyw
              +  (p0) mulsc r1.x___, c61.w, r1.x
/*   15.1 */  (p0) exec
/*  156   */     (p0) mul r12.xy__, r12.xyyy, c254.xxxx
              +  (p0) rcp r1.x___, r1.x
/*  157   */     (p0) mul r1.xy__, r12.xyyy, r1.xxxx
              +  (p0) retain_prev r1._
/*  158   */     (p0) add r12.x___, r1.xxxx, c254.xxxx
              +  (p0) subsc r12._y__, c254.x, r1.y
/*  159   */     (p0) tfetch2D r12.xyz_, r12.xy, tf4
/*  160   */          serialize
                 (p0) mul r0.x_zw, r0.xzzw, r12.zyyx
              +  (p0) retain_prev r1._
/*   16.0 */       exec
/*  161   */          mul r12.xy__, r0.xyyy, c47.zzzz
              +       retain_prev r1._
/*  162   */          mad r8.xyz_, r12.yxyy, r0.wyzz, r8.xyzz
              +       retain_prev r1._
                label L33
/*   16.1 */       cjmp !b132, L45
/*   17.0 */       exec
/*  163   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  164   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  165   */          mul r12, r6.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  166   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  167   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  168   */          dp3 r2.___w, r0.xzyy, r4.xyzz
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   17.1 */       exec
/*  169   */          max4 r0._y__, r12.zxwy
              +       maxs r0.__z_, r2.ww
/*  170   */          add r0.xy__, -r0.xyyy, c255.zzzz
              +       maxs r0.___w, c255.xx
/*  171   */          mul r12.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  172   */          mul r12.xyz_, r12.xyzz, r2.wwww
              +       retain_prev r1._
/*  173   */          mad r8.xyz_, r12.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   18.0 */       cjmp !b133, L45
/*   18.1 */       exec
/*  174   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  175   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  176   */          mul r12, r6, c53
              +       rsq r1.x___, r_abs[0].w
/*  177   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  178   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  179   */          dp3 r2.___w, r0.zxyy, r4.xyzz
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   19.0 */       exec
/*  180   */          max4 r0._y__, r12.ywxz
              +       maxs r0.__z_, r2.ww
/*  181   */          add r0.xy__, -r0.xyyy, c255.zzzz
              +       maxs r0.___w, c255.xx
/*  182   */          mul r12.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  183   */          mul r12.xyz_, r12.xyzz, r2.wwww
              +       retain_prev r1._
/*  184   */          mad r8.xyz_, r12.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   19.1 */       cjmp !b134, L45
/*   20.0 */       exec
/*  185   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  186   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  187   */          mul r12, r6.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  188   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  189   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  190   */          dp3 r2.___w, r0.xzyy, r4.xyzz
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   20.1 */       exec
/*  191   */          max4 r0._y__, r12.zxwy
              +       maxs r0.__z_, r2.ww
/*  192   */          add r0.xy__, -r0.xyyy, c255.zzzz
              +       maxs r0.___w, c255.xx
/*  193   */          mul r12.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  194   */          mul r12.xyz_, r12.xyzz, r2.wwww
              +       retain_prev r1._
/*  195   */          mad r8.xyz_, r12.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
/*   21.0 */       cjmp !b135, L45
/*   21.1 */       exec
/*  196   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  197   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  198   */          mul r6, r6, c55
              +       rsq r1.x___, r_abs[0].w
/*  199   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  200   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  201   */          dp3 r2.___w, r0.zxyy, r4.xyzz
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   22.0 */       exec
/*  202   */          max4 r0._y__, r6.ywxz
              +       maxs r0.__z_, r2.ww
/*  203   */          add r0.xy__, -r0.xyyy, c255.zzzz
              +       maxs r0.___w, c255.xx
/*  204   */          mul r6.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  205   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  206   */          mad r8.xyz_, r6.zxyy, r0.yyyy, r8.xyzz
              +       retain_prev r1._
                label L45
/*   22.1 */       exec
/*  207   */          mul r6, r4.xxzy, r4.yxxz
              +       retain_prev r1._
/*  208   */          dp3 r1.x___, r9.xzyy, r3.zxyy
              +       retain_prev r1._
/*  209   */          dp3 r1._y__, r10.xzyy, r3.zxyy
              +       retain_prev r1._
/*  210   */          mul r0._yz_, r4.yyzz, r4.yyzz
              +       retain_prev r1._
/*  211   */          dp3 r0.x___, r7.xzyy, r3.zxyy
              +       subs r2.___w, r0.yz
/*  212   */          dp4 r0._y__, r6.xywz, c19.wzxy
              +       addsc r3.x___, c16.w, r0.x
/*   23.0 */       exec    // PredicateClean=false
/*  213   */          dp4 r0.__z_, r6.xywz, c20.wzxy
              +       addsc r3._y__, c17.w, r1.y
/*  214   */          dp4 r0.___w, r6.xywz, c21.wzxy
              +       addsc r3.__z_, c18.w, r1.x
/*  215   */          add r0.xyz_, r3.zxyy, r0.wyzz
              +       setp_gt r1._, c_abs[13].x
/*  216   */          mad r0.xyz_, r2.wwww, c22.xyzz, r0.yzxx
              +       retain_prev r1._
/*  217   */          mad r1.xy_w, r8.yzxx, r1.wwww, r0.zyxx
              +       retain_prev r1._
/*   23.1 */  (p0) exec
/*  218   */     (p0) mul r0.xyz_, r1.xyww, c56.xxxx
              +  (p0) retain_prev r1._
/*  219   */     (p0) mul r1.xy_w, r1.xyww, c57.xxxx
              +  (p0) retain_prev r1._
/*  220   */     (p0) mul r1.xy_w, r1.xyww, c15.xxxx
              +  (p0) retain_prev r1._
/*  221   */     (p0) mad r1.xy_w, r0.xyzz, c14.xxxx, r1.xyww
              +  (p0) retain_prev r1._
/*   24.0 */       exec
/*  222   */          mul r0, r11.zyxw, r1.wyxz
              +       retain_prev r1._
/*   24.1 */       cjmp !b136, L53
/*   25.0 */       exec
/*  223   */          mad r1.___w, r3.wwww, c11.yyyy, c11.zzzz
              +       retain_prev r1._
/*  224   */          add r1.x___, r3.wwww, -c8.xxxx
              +       rsq r1._y__, r_abs[4].w
/*  225   */          mul r3.xyz_, r5.xyzz, r1.yyyy
              +       retain_prev r1._
/*  226   */          cndeq r2, c255.xxxz, r2.zxyy, c255.zzzz
              +       retain_prev r1._
/*  227   */          dp4 r1._y__, c9.zxyw, r2
              +       retain_prev r1._
/*  228   */          dp3 r1.__z_, r3.xzyy, c9.zxyy
              +       retain_prev r1._
/*   25.1 */       exec
/*  229   */          add r2.xyz_, -r0.xyzz, c10.xyzz
              +       mulsc r2.___w, c8.z, r1.x
/*  230   */          min r3.xy__, r1.yzzz, c255.xyyy
              +       mulsc r1.x___, c8.w, r1.y
/*  231   */          max r1.__z_, r2.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  232   */          max r1._, r1, r1
              +       mulsc r1.x___, c11.x, r1.y
/*  233   */          mad r1.x___, r1.xxxx, r3.xxxx, r1.wwww
              +       retain_prev r1._
/*  234   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*   26.0 */       exec
/*  235   */          min r1.x___, r1.xxxx, c10.wwww
              +       retain_prev r1._
/*  236   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*  237   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L53
/*   26.1 */       exece
/*  238   */          mul r0.xyz_, r0.zyxx, c0.xxxx
              +       retain_prev r1._
/*  239   */          max oC0, r0.zyxw, r0.zyxw
