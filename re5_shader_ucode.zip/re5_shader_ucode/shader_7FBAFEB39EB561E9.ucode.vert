/*    0.0 */       exec
/*   13   */          vfetch_full r3.1zyx, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*   14   */          vfetch_mini r4.zyxw, Offset=3, DataFormat=FMT_8_8_8_8
/*   15   */          vfetch_mini r1.xywz, Offset=4, DataFormat=FMT_16_16_16_16, Signed=true
/*   16   */          vfetch_mini r2.yzwx, Offset=6, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   17   */          vfetch_mini r0.zywx, Offset=7, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   18   */          serialize
                      mulsc r1.__z_, c252.y, r1.z
/*    0.1 */       exec
/*   19   */          dp4 r1.__z_, r1.zzzz, c5.wzxy
/*    1.0 */       cjmp !b0, L5
/*    1.1 */       exec
/*   20   */          dp4 r2.__z_, r3.xywz, c28.wzxy
/*   21   */          dp4 r2.x___, r3.xywz, c26.wzxy
              +       mulsc r1.x___, c253.w, r1.x
/*   22   */          dp4 r0.___w, r3.xywz, c29.wzxy
              +       mulsc r1._y__, c253.w, r1.y
/*   23   */          dp4 r2._y__, r3.xywz, c27.wzxy
              +       rcp r2.___w, r0.w
/*   24   */          mad r2.__z_, r1.zzzz, r2.wwww, r2.zzzz
/*    2.0 */       jmp L15
                label L5
/*    2.1 */       exec
/*   25   */          mul r1.xy__, r1.xyyy, c251.xxxx
              +       addsc r0._y__, c254.x, r0.y
/*   26   */          mul r1.xy__, r1.xyyy, c4.yxxx
              +       addsc r0.___w, c254.x, r0.w
/*    3.0 */       cjmp !b1, L11
/*    3.1 */       exec
/*   27   */          subsc r2.x___, -c251.x, -r2.y
/*   28   */          mad r2.x___, r2.zzzz, c255.yyyy, r2.xxxx
/*   29   */          mul r6.xy__, r0.ywww, c253.xxxx
              +       subsc r0._y__, -c253.z, -r0.x
/*   30   */          add r5.xyz_, r3.yzww, -c30.zyxx
              +       mulsc r6.__z_, c253.x, r0.y
/*   31   */          mul r2._yzw, r6.xxzy, r5.xxzy
/*   32   */          mad r5.xyz_, r6.zyxx, r5.yxzz, -r2.yzww
/*    4.0 */       exec
/*   33   */          dp3 r0.___w, r5.zxyy, r5.zxyy
/*   34   */          mul r2.xy__, r2.xxxx, c255.zwww
              +       rsq r0.___w, r_abs[0].w
/*   35   */          mul r5.xyz_, r5.zyxx, r0.wwww
/*   36   */          mul r5.xyz_, r5.zxyy, c255.zwww
/*   37   */          mad r3._yzw, r5.yyzx, r2.xxxy, r3.yyzw
/*   38   */          dp4 r2.__z_, r3.xywz, c28.wzxy
/*    4.1 */       exec
/*   39   */          dp4 r2.x___, r3.xywz, c26.wzxy
/*   40   */          dp4 r0.___w, r3.xywz, c29.wzxy
/*   41   */          dp4 r2._y__, r3.xywz, c27.wzxy
              +       rcp r2.___w, r0.w
/*   42   */          mad r2.__z_, r1.zzzz, r2.wwww, r2.zzzz
/*    5.0 */       jmp L15
                label L11
/*    5.1 */       exec
/*   43   */          mad r2.x_z_, r2.yxxx, c255.xyyy, r2.zwww
/*   44   */          mad r2._y__, r2.zzzz, c253.yyyy, c251.wwww
/*   45   */          frc r2._y__, r2.yyyy
              +       mulsc r5.x___, c251.y, r0.x
/*   46   */          mad r2.__z_, r2.yyyy, c252.wwww, c251.zzzz
/*   47   */          mul r2._y_w, r0.yyww, c252.zzzz
              +       cos r5._y__, r2.z
/*   48   */          mul r2.xy__, r2.ywww, r2.xxxx
              +       sin r5.__z_, r2.z
/*    6.0 */       exec
/*   49   */          mul r2.xyz_, r2.xxyy, r5.yzxx
/*   50   */          mul r5.xy__, r2.zzzz, r5.yzzz
/*   51   */          add r2.__z_, r5.xxxx, -r2.yyyy
/*   52   */          add r2.___w, r5.yyyy, r2.xxxx
/*   53   */          dp2add r2.x___, r2.wzzz, c0.yxxx, c252.xxxx
/*   54   */          dp2add r2._y__, r2.wzzz, c2.yxxx, c252.xxxx
/*    6.1 */       exec
/*   55   */          dp2add r2.__z_, r2.wzzz, c1.yxxx, c252.xxxx
/*   56   */          add r5.xyz_, r3.wyzz, r2.xyzz
              +       sges r5.___w, r_abs[0].x
/*   57   */          dp4 r2.__z_, c28.zxyw, r5.yxzw
/*   58   */          dp4 r2.x___, c26.zxyw, r5.yxzw
/*   59   */          dp4 r0.___w, c29.zxyw, r5.yxzw
/*   60   */          dp4 r2._y__, c27.zxyw, r5.yxzw
              +       rcp r2.___w, r0.w
/*    7.0 */       exec
/*   61   */          mad r2.__z_, r1.zzzz, r2.wwww, r2.zzzz
                label L15
/*    7.1 */       exec
/*   62   */          rcp r0.x___, r0.w
/*   63   */          mad r0.x___, r0.xxxx, r2.zzzz, c25.zzzz
/*   64   */          mul r1.__z_, r0.zzzz, c31.xxxx
              +       rcp r0.x___, r0.x
/*   65   */          mulsc r0.__z_, c25.w, r0.x
/*    8.0 */       cjmp !b3, L18
/*    8.1 */       exec
/*   66   */          dp4 r0._y__, r3.xywz, c3.wzxy
/*   67   */          subsc r0.x___, -c6.x, -r0.y
/*   68   */          mulsc_sat r0.x___, c6.y, r0.x
/*   69   */          mul r4.___w, r0.xxxx, r4.wwww
                label L18
/*    9.0 */       cjmp !b2, L21
/*    9.1 */       exec
/*   70   */          sgt r0.x___, c254.wwww, r4.wwww
/*   71   */          cndeq r2.___w, r0.xxxx, r0.wwww, c254.yyyy
/*   10.0 */       jmp L22
                label L21
/*   10.1 */       exec
/*   72   */          maxs r2.___w, r0.ww
                label L22
/*   11.0 */       alloc position
/*   11.1 */       exec
/*   73   */          max oPos, r2, r2
/*   12.0 */       alloc interpolators
/*   12.1 */       exece
/*   74   */          max r0.xy__, r2.xyyy, r2.xyyy
              +       mulsc r1.___w, c254.z, r1.w
/*   75   */          max o0, r4, r4
/*   76   */          max o1, r1.yxwz, r1.yxwz
/*   77   */          max o2, r0, r0
