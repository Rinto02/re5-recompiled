/*    0.0 */       exec
/*   17   */          vfetch_full r7.1zyx, r0.x, vf0, DataFormat=FMT_32_32_32_FLOAT, Stride=8, Signed=true, NumFormat=integer, PrefetchCount=8
/*   18   */          vfetch_mini r6, Offset=3, DataFormat=FMT_8_8_8_8
/*   19   */          vfetch_mini r0._zxy, Offset=4, DataFormat=FMT_16_16_16_16, Signed=true
/*   20   */          vfetch_mini r5.zywx, Offset=6, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   21   */          vfetch_mini r4.yxwz, Offset=7, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*   22   */          serialize
                      mad r2.xyz_, c0.yzxx, c4.wwww, c4.xxxx
/*    0.1 */       exec
/*   23   */          mad r3.xyz_, c1.zxyy, c4.wwww, c4.yyyy
/*   24   */          mad r1.xyz_, c2.zyxx, c4.wwww, c4.zzzz
/*   25   */          mul r9.xy__, r1.xzzz, c23.zzzz
              +       mulsc r0.x___, c25.y, r3.x
/*   26   */          mul r12.__zw, r2.yyyx, c24.xxxx
              +       mulsc r12.x___, c23.x, r2.y
/*   27   */          mul r11.xy__, r3.xyyy, c23.yyyy
              +       mulsc r12._y__, c23.x, r2.z
/*   28   */          mul r10.xyz_, r2.yxzz, c26.xxxx
              +       mulsc r11.__z_, c24.y, r3.x
/*    1.0 */       exec
/*   29   */          mul r8.xyz_, r3.xzyy, c26.yyyy
              +       mulsc r11.___w, c24.y, r3.z
/*   30   */          mad r10.___w, r2.yyyy, c25.xxxx, r0.xxxx
/*   31   */          add r2, r12, r11
              +       mulsc r8.___w, c25.z, r1.x
/*   32   */          add r8, r10.xwzy, r8.xwzy
              +       mulsc r9.__z_, c24.z, r1.x
/*   33   */          mad r3.xyz_, r1.xyzz, c26.zzzz, r8.xwzz
/*   34   */          add r3.xyz_, r3.xzyy, c26.wwww
              +       mulsc r9.___w, c24.z, r1.y
/*    1.1 */       exec
/*   35   */          add r2, r2.xzyw, r9.xzyw
              +       rcp r1._y__, r3.y
/*   36   */          add r2.x_z_, r2.xzzz, c23.wwww
              +       rcp r1.__z_, r3.x
/*   37   */          add r2._y_w, r2.yyww, c24.wwww
              +       rcp r1.___w, r3.z
/*   38   */          mad r2, r2.yzwx, r1.zywz, c27.yxyx
/*   39   */          mulsc r13.x___, c3.x, r2.w
/*   40   */          add r3, c27.yxyx, c248.xyyx
              +       maxs r0.x___, r2.xx
/*    2.0 */       exec
/*   41   */          mul r2._yz_, r2.yyzz, c3.xxyy
              +       mulsc r11.x___, c3.y, r0.x
/*   42   */          dp2add r11.___w, r2.wwww, c3.xxxx, -r2.yyyy
/*   43   */          dp2add r2.x___, r2.xxxx, c3.yyyy, -r2.zzzz
/*   44   */          mul r9, r3, c3.yxyx
              +       maxs r0._, r11.xx
/*   45   */          add r0.x___, r13.xxxx, -r2.yyyy
              +       adds_prev r1.x___, -r2.z
/*   46   */          mad r11._yz_, r0.xxxx, c252.xxyy, r13.xxxx
/*    2.1 */       exec
/*   47   */          mad r13._yzw, r1.xxxx, c250.xxyz, r11.xxxx
/*   48   */          mad r2._yz_, r1.xxxx, c254.xxyy, r11.xxxx
/*   49   */          mad r2.___w, r0.xxxx, c251.xxxx, r13.xxxx
/*   50   */          mad r10._yz_, r1.xxxx, c253.zzww, r11.xxxx
/*   51   */          mad r10.x__w, r0.xxxx, c251.yzzz, r13.xxxx
/*   52   */          mad r3._yz_, r1.xxxx, c254.zzww, r11.xxxx
/*    3.0 */       exec
/*   53   */          mad r3.x__w, r0.xxxx, c252.zwww, r13.xxxx
/*   54   */          mad r12.xy__, r0.xxxx, c253.xyyy, r13.xxxx
/*   55   */          max r8.x_z_, r12.xyyy, r9.yyyy
/*   56   */          min r16.x___, r9.wwww, r8.zzzz
/*   57   */          min r17.x_z_, r9.wwww, r8.zxxx
/*   58   */          max r3, r3, r9.yxxy
/*    3.1 */       exec
/*   59   */          max r10, r10, r9.yxxy
              +       maxs r12.x___, r9.ww
/*   60   */          max r2, r2.xzyw, r9.xxxy
              +       maxs r12._y__, r8.xx
/*   61   */          max r19, r13, r9.yxxx
              +       mins r15.x___, r12.xy
/*   62   */          max r12, r11, r9.xyyy
              +       maxs r11.x___, r9.ww
/*   63   */          min r18._y__, r9.zzzz, r12.xxxx
              +       maxs r11._y__, r19.xx
/*   64   */          min r17._y__, r9.zzzz, r19.zzzz
              +       mins r18.x___, r11.xy
/*    4.0 */       exec
/*   65   */          min r11._y__, r9.zzzz, r2.zzzz
              +       maxs r11.x___, r9.ww
/*   66   */          min r14._y__, r9.zzzz, r2.yyyy
              +       maxs r11.__z_, r12.zz
/*   67   */          min r18.__zw, r9.zzzw, r2.xxxw
              +       mins r13.x___, r11.xz
/*   68   */          min r11.x_zw, r9.wwwz, r12.ywwx
              +       maxs r13._y__, r9.zz
/*   69   */          min r16._yzw, r9.zzzw, r19.yywx
              +       maxs r13.__z_, r2.zz
/*   70   */          min r15._yzw, r9.zzzw, r19.yyzx
              +       mins r13._y__, r13.yz
/*    4.1 */       exec
/*   71   */          min r14.x_zw, r9.wwwz, r12.yzzx
              +       maxs r2.x___, r9.zz
/*   72   */          min r10, r9.zwzw, r10.yxzw
              +       maxs r2._y__, r2.yy
/*   73   */          min r12, r9.zwzw, r3.yxzw
              +       mins r13.__z_, r2.xy
/*   74   */          tfetch2D r3.x___, r15.wz, tf16, UseComputedLOD=false
/*   75   */          tfetch2D r3._x__, r12.yx, tf16, UseComputedLOD=false
/*   76   */          tfetch2D r3.__x_, r12.wx, tf16, UseComputedLOD=false
/*    5.0 */       exec
/*   77   */          tfetch2D r3.___x, r12.yz, tf16, UseComputedLOD=false
/*   78   */          tfetch2D r2.x___, r18.xy, tf16, UseComputedLOD=false
/*   79   */          tfetch2D r2._x__, r11.xw, tf16, UseComputedLOD=false
/*   80   */          tfetch2D r2.__x_, r14.zw, tf16, UseComputedLOD=false
/*   81   */          tfetch2D r2.___x, r16.wy, tf16, UseComputedLOD=false
/*   82   */          tfetch2D r9.x___, r18.xz, tf16, UseComputedLOD=false
/*    5.1 */       exec
/*   83   */          tfetch2D r9._x__, r10.yx, tf16, UseComputedLOD=false
/*   84   */          tfetch2D r9.__x_, r10.wx, tf16, UseComputedLOD=false
/*   85   */          tfetch2D r9.___x, r10.yz, tf16, UseComputedLOD=false
/*   86   */          tfetch2D r12.x___, r12.wz, tf16, UseComputedLOD=false
/*   87   */          tfetch2D r12._x__, r11.zw, tf16, UseComputedLOD=false
/*   88   */          tfetch2D r12.__x_, r18.wy, tf16, UseComputedLOD=false
/*    6.0 */       exec
/*   89   */          tfetch2D r12.___x, r16.wz, tf16, UseComputedLOD=false
/*   90   */          tfetch2D r10.x___, r10.wz, tf16, UseComputedLOD=false
/*   91   */          tfetch2D r10._x__, r17.xy, tf16, UseComputedLOD=false
/*   92   */          tfetch2D r10.__x_, r17.zy, tf16, UseComputedLOD=false
/*   93   */          tfetch2D r10.___x, r11.xy, tf16, UseComputedLOD=false
/*   94   */          tfetch2D r11.x___, r13.xy, tf16, UseComputedLOD=false
/*    6.1 */       exec
/*   95   */          tfetch2D r11._x__, r16.xy, tf16, UseComputedLOD=false
/*   96   */          tfetch2D r11.__x_, r15.xy, tf16, UseComputedLOD=false
/*   97   */          tfetch2D r11.___x, r14.xy, tf16, UseComputedLOD=false
/*   98   */          tfetch2D r0.x___, r13.xz, tf16, UseComputedLOD=false
/*   99   */          serialize
                      add r11, -r11, c251.wwww
/*  100   */          add r10, -r10, c251.wwww
              +       subsc r1.x___, c251.w, r0.x
/*    7.0 */       exec
/*  101   */          add r9, -r9, c251.wwww
              +       maxs r0._, -r12.xx
/*  102   */          add r2, -r2, c251.wwww
              +       adds_prev r8.x___, c251.w
/*  103   */          add r3, -r3, c251.wwww
              +       maxs r0._, -r12.yy
/*  104   */          add r0.x___, r8.yyyy, c25.wwww
              +       adds_prev r8._y__, c251.w
/*  105   */          mul r0.x___, r0.xxxx, r1.zzzz
              +       maxs r0._, -r12.zz
/*  106   */          sgt r1.x___, r1.xxxx, r0.xxxx
              +       adds_prev r8.__z_, c251.w
/*    7.1 */       exec
/*  107   */          sgt r3, r3, r0.xxxx
              +       maxs r0._, -r12.ww
/*  108   */          sgt r2, r2, r0.xxxx
              +       adds_prev r8.___w, c251.w
/*  109   */          sgt r8, r8, r0.xxxx
/*  110   */          sgt r9, r9, r0.xxxx
/*  111   */          sgt r10, r10, r0.xxxx
/*  112   */          sgt r11, r11, r0.xxxx
/*    8.0 */       exec
/*  113   */          dp4 r1._y__, r11.wzyx, c251.wwww
/*  114   */          dp4 r1.__z_, r10.wzyx, c251.wwww
/*  115   */          dp4 r1.___w, r9.wzyx, c251.wwww
/*  116   */          dp4 r0.x___, r8.wzyx, c251.wwww
/*  117   */          dp4 r2.___w, r2.wzxy, c251.wwww
              +       adds r2._y__, c6.yy
/*  118   */          dp4 r2.__z_, r3.wzyx, c251.wwww
              +       adds r2.x___, c6.xx
/*    8.1 */       exec
/*  119   */          add r2.__z_, r2.wwww, r2.zzzz
              +       maxs r0._, c9.xx
/*  120   */          add r2.__z_, r2.zzzz, r0.xxxx
              +       muls_prev r0.x___, c10.x
/*  121   */          add r1.___w, r2.zzzz, r1.wwww
              +       maxs r0._, c6.ww
/*  122   */          add r1.__z_, r1.wwww, r1.zzzz
              +       adds_prev r3.x___, c251.w
/*  123   */          add r1._y__, r1.zzzz, r1.yyyy
              +       maxs r0._, c6.zz
/*  124   */          add r1.x___, r1.yyyy, r1.xxxx
              +       adds_prev r3._y__, c251.x
/*    9.0 */       exec    // PredicateClean=false
/*  125   */          mul r2.__z_, r1.xxxx, c246.wwww
              +       setp_gt r0._, r_abs[0].x
/*    9.1 */ (!p0) jmp L24
/*   10.0 */       exec
/*  126   */          mad r5.x__w, r5.xyyy, c247.xyyy, r5.zwww
/*  127   */          mul r1.__zw, r4.zzzw, c248.zzzw
/*  128   */          add r1.xy__, r4.yxxx, c255.xxxx
              +       log r0.x___, r_abs[2].z
/*  129   */          mul r2.___w, r1.zzzz, r0.xxxx
              +       mulsc r0.x___, c250.w, r1.x
/*  130   */          mad r3.__z_, r5.wwww, c247.zzzz, c252.xxxx
/*  131   */          frc r4.__z_, r3.zzzz
              +       exp r5.__z_, r2.w
/*   10.1 */       exec
/*  132   */          mul r5._y__, r0.xxxx, r5.zzzz
/*  133   */          mul r4.xy__, r5.xyyy, r5.zxxx
/*  134   */          mul r4.xyz_, r4.xyzz, c249.xyzz
              +       mulsc r3.__z_, c246.x, r0.z
/*  135   */          add r0.x___, r4.zzzz, c246.zzzz
              +       mulsc r3.___w, c246.x, r0.w
/*  136   */          mul r0.__zw, r3.wwwz, c7.xxxy
              +       sin r3.__z_, r0.x
/*  137   */          mul r1.xy__, r4.xyyy, r1.ywww
              +       cos r3.___w, r0.x
/*   11.0 */       exec
/*  138   */          mul r1, r1.xxyy, r3.zwwz
/*  139   */          add r1._y__, r1.wwww, r1.yyyy
              +       subs r1.x___, r1.zx
/*  140   */          add r1.xy__, r1.xyyy, r7.wzzz
/*  141   */          mad r2.xy__, r1.xyyy, r2.xyyy, r3.yxxx
/*   11.1 */       jmp L25
                label L24
/*   12.0 */       exec
/*  142   */          mul r0.__zw, r0.wwwz, c246.yyyy
/*  143   */          mad r2.xy__, r2.xyyy, r7.wzzz, r3.yxxx
                label L25
/*   12.1 */       exec
/*  144   */          mulsc r0.x___, c247.w, r0.y
/*  145   */          mul r1.xyz_, r0.xxxx, r6.zyxx
/*   13.0 */       cjmp !b0, L28
/*   13.1 */       exec
/*  146   */          dp4 r0._y__, r7.xywz, c5.wzxy
/*  147   */          subsc r0.x___, -c8.x, -r0.y
/*  148   */          mulsc_sat r0.x___, c8.y, r0.x
/*  149   */          mul r6.___w, r0.xxxx, r6.wwww
                label L28
/*   14.0 */       exec    // PredicateClean=false
/*  150   */          sges r2.___w, r_abs[0].x
/*  151   */          mul r1.___w, r2.zzzz, r6.wwww
              +       setp_ne r0._, c10.x
/*   14.1 */  (p0) exec
/*  152   */     (p0) sgt r0.x___, c249.wwww, r1.wwww
/*  153   */     (p0) cndeq r2.___w, r0.xxxx, c251.wwww, c251.xxxx
/*   15.0 */       alloc position
/*   15.1 */       exec
/*  154   */          maxs r2.__z_, r7.yy
/*  155   */          max oPos, r2, r2
/*   16.0 */       alloc interpolators
/*   16.1 */       exece
/*  156   */          max o1.xy00, r0.zwww, r0.zwww
/*  157   */          max o0, r1, r1
