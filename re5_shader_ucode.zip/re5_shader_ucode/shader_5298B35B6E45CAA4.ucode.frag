/*    0.0 */       exec
/*   24   */          tfetch2D r8.yxzw, r1.xy, tf0
/*   25   */          serialize
                      mul r3.__zw, c4.zzzw, c3.xxxy
              +       maxs r1._y__, r8.ww
/*   26   */          sgt r11.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       rcp r1.x___, r0.w
/*   27   */          mad r0.xy__, r1.xxxx, r0.yxxx, c2.yxxx
              +       retain_prev r1._
/*   28   */          mul r0.xy__, r3.zwww, r0.yxxx
              +       subsc r1.x___, -c1.x, -r1.y
/*   29   */          kill_gt r1._, c255.xxxx, r1.xxxx
              +       retain_prev r1._
/*    0.1 */       exec
/*   30   */          tfetch2D r13.zyx_, r3.xy, tf2
/*   31   */          tfetch2D r3.xy__, r3.xy, tf1
/*   32   */          tfetch2D r0, r0.xy, tf5
/*   33   */          serialize
                      sgt r12.xyz_, -r_abs[1].xxxx, c255.xxxx
              +       maxs r3.__z_, c58.xx
/*   34   */          add r9.xyz_, r2.xyzz, -c23.xyzz
              +       maxs r1.x___, r8.zz
/*   35   */          mul r0, r0.wzyx, c5.wzyx
              +       mulsc r8.__z_, c15.z, r1.x
/*    1.0 */       exec
/*   36   */          dp3 r1._y__, r9.zxyy, r9.zxyy
              +       mulsc r8.x___, c15.y, r8.x
/*   37   */          mad r3.xy__, r3.yxxx, c254.xxxx, c254.yyyy
              +       retain_prev r1._
/*   38   */          dp2add r2.___w, -r3.xyyy, r3.xyyy, c255.yyyy
              +       retain_prev r1._
/*   39   */          min r0, r0, c9.xxxx
              +       rsq r3.___w, r_abs[1].y
/*   40   */          mul r9.xyz_, r9.zyxx, r3.wwww
              +       mulsc r8._y__, c15.x, r8.y
/*   41   */          max r10, r0.wzyx, c10.xxxx
              +       sqrt r2.___w, r_abs[2].w
/*    1.1 */       exec
/*   42   */          mul r0.xyz_, r2.wwww, r7.xyzz
              +       maxs r0.___w, r10.yw
/*   43   */          mad r0.xyz_, r3.xxxx, r6.zyxx, r0.zyxx
              +       retain_prev r1._
/*   44   */          mad r0.xyz_, r3.yyyy, r5.xzyy, r0.zxyy
              +       retain_prev r1._
/*   45   */          dp3 r2.___w, r0.yxzz, r0.yxzz
              +       maxs r3.x___, r10.xz
/*   46   */          max r3._y__, r3.xxxx, r0.wwww
              +       rsq r2.___w, r_abs[2].w
/*   47   */          mul r5.xyz_, r0.yzxx, r2.wwww
              +       sqrt r1._y__, r_abs[1].y
/*    2.0 */       cjmp !b128, L24
/*    2.1 */       exec
/*   48   */          mul r0, r10.wzyx, c48.wzyx
              +       retain_prev r1._
/*   49   */          add r6.xyz_, -r2.zyxx, c33.zyxx
              +       retain_prev r1._
/*   50   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   51   */          max4 r0.__z_, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   52   */          mul r7, r6, r1.xxxx
              +       retain_prev r1._
/*   53   */          dp3 r4.___w, r5.xzyy, r7.xzyy
              +       retain_prev r1._
/*    3.0 */       exec
/*   54   */          add r6.xyz_, r7.zyxx, -r9.zyxx
              +       retain_prev r1._
/*   55   */          dp3 r2.___w, r7.xzyy, -c34.zxyy
              +       retain_prev r1._
/*   56   */          add r1.x___, r7.wwww, -c32.wwww
              +       retain_prev r1._
/*   57   */          add r2.___w, r2.wwww, -c35.xxxx
              +       mulsc_sat r0.x___, c33.w, r1.x
/*   58   */          dp3 r0._y__, r6.zxyy, r6.zxyy
              +       mulsc r1.x___, c35.y, r2.w
/*   59   */          max r1.x___, r1.xxxx, c35.wwww
              +       rsq r2.___w, r_abs[0].y
/*    3.1 */       exec
/*   60   */          mul r6.xyz_, r6.zyxx, r2.wwww
              +       subsc r0.___w, c255.y, r0.x
/*   61   */          min r3.x___, r1.xxxx, c255.yyyy
              +       subsc r2.___w, c255.y, r0.z
/*   62   */          dp3 r4.__z_, r5.xzyy, r6.xzyy
              +       maxs r1._, r0.ww
/*   63   */          max r0._yz_, r4.wwzz, c255.xxxx
              +       muls_prev r3.___w, r3.x
/*   64   */          mul r6._yzw, r3.xxww, c32.xxzy
              +       log r1.x___, r_abs[0].z
/*   65   */          max r1._, r1, r1
              +       mulsc r0.x___, c57.z, r1.x
/*    4.0 */       exec
/*   66   */          mul r6.x___, r6.yyyy, r0.wwww
              +       exp r0.x___, r0.x
/*   67   */          mul r3.x__w, r6.zwww, r0.xxxx
              +       retain_prev r1._
/*   68   */          mul r11.xy__, r3.xwww, r2.wwww
              +       retain_prev r1._
/*   69   */          mul r0, r6.xzwx, r0.yyyx
              +       retain_prev r1._
/*   70   */          mul r0.xyz_, r0.xzyy, r2.wwww
              +       maxs r1._, r0.ww
/*   71   */          mul r12.xyz_, r0.zxyy, c35.zzzz
              +       muls_prev r11.__z_, r2.w
/*    4.1 */       cjmp !b129, L24
/*    5.0 */       exec
/*   72   */          mul r0, r10.wzyx, c49.wzyx
              +       retain_prev r1._
/*   73   */          add r6.xyz_, -r2.xyzz, c37.xyzz
              +       retain_prev r1._
/*   74   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*   75   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*   76   */          mul r7, r6, r1.xxxx
              +       retain_prev r1._
/*   77   */          dp3 r4.___w, r5.xzyy, r7.zxyy
              +       retain_prev r1._
/*    5.1 */       exec
/*   78   */          add r6.xyz_, r7.xyzz, -r9.zyxx
              +       retain_prev r1._
/*   79   */          dp3 r2.___w, r7.zxyy, -c38.zxyy
              +       retain_prev r1._
/*   80   */          add r1.x___, r7.wwww, -c36.wwww
              +       retain_prev r1._
/*   81   */          add r2.___w, r2.wwww, -c39.xxxx
              +       mulsc_sat r0.__z_, c37.w, r1.x
/*   82   */          dp3 r0._y__, r6.zxyy, r6.zxyy
              +       mulsc r1.x___, c39.y, r2.w
/*   83   */          max r1.x___, r1.xxxx, c39.wwww
              +       rsq r2.___w, r_abs[0].y
/*    6.0 */       exec
/*   84   */          mul r6.xyz_, r6.zyxx, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*   85   */          min r3.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*   86   */          dp3 r4.__z_, r5.xzyy, r6.xzyy
              +       maxs r1._, r0.yy
/*   87   */          max r0.x__w, r4.wzzz, c255.xxxx
              +       muls_prev r3.___w, r3.x
/*   88   */          mul r6.xy_w, r3.wwxx, c36.zyxx
              +       log r1.x___, r_abs[0].w
/*   89   */          mul r6.__z_, r6.wwww, r0.yyyy
              +       mulsc r0.___w, c57.z, r1.x
/*    6.1 */       exec
/*   90   */          mul r0.xyz_, r6.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*   91   */          mul r6.xyz_, r6.xyzz, r0.wwww
              +       retain_prev r1._
/*   92   */          mad r11.xyz_, r6.xyzz, r2.wwww, r11.xyzz
              +       retain_prev r1._
/*   93   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*   94   */          mad r12.xyz_, r0.zxyy, c39.zzzz, r12.xyzz
              +       retain_prev r1._
/*    7.0 */       cjmp !b130, L24
/*    7.1 */       exec
/*   95   */          mul r0, r10, c50
              +       retain_prev r1._
/*   96   */          add r6.xyz_, -r2.zyxx, c41.zyxx
              +       retain_prev r1._
/*   97   */          dp3 r6.___w, r6.xzyy, r6.xzyy
              +       retain_prev r1._
/*   98   */          max4 r0.x___, r0.ywxz
              +       rsq r1.x___, r_abs[6].w
/*   99   */          mul r7, r6, r1.xxxx
              +       retain_prev r1._
/*  100   */          dp3 r4.___w, r5.xzyy, r7.xzyy
              +       retain_prev r1._
/*    8.0 */       exec
/*  101   */          add r6.xyz_, r7.zyxx, -r9.zyxx
              +       retain_prev r1._
/*  102   */          dp3 r2.___w, r7.xzyy, -c42.zxyy
              +       retain_prev r1._
/*  103   */          add r1.x___, r7.wwww, -c40.wwww
              +       retain_prev r1._
/*  104   */          add r2.___w, r2.wwww, -c43.xxxx
              +       mulsc_sat r0.__z_, c41.w, r1.x
/*  105   */          dp3 r0._y__, r6.zxyy, r6.zxyy
              +       mulsc r1.x___, c43.y, r2.w
/*  106   */          max r1.x___, r1.xxxx, c43.wwww
              +       rsq r2.___w, r_abs[0].y
/*    8.1 */       exec
/*  107   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  108   */          min r3.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*  109   */          dp3 r4.__z_, r5.xzyy, r6.zxyy
              +       maxs r1._, r0.yy
/*  110   */          max r0.x__w, r4.wzzz, c255.xxxx
              +       muls_prev r3.___w, r3.x
/*  111   */          mul r6.xy_w, r3.wwxx, c40.zyxx
              +       log r1.x___, r_abs[0].w
/*  112   */          mul r6.__z_, r6.wwww, r0.yyyy
              +       mulsc r0.___w, c57.z, r1.x
/*    9.0 */       exec
/*  113   */          mul r0.xyz_, r6.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  114   */          mul r6.xyz_, r6.xyzz, r0.wwww
              +       retain_prev r1._
/*  115   */          mad r11.xyz_, r6.xyzz, r2.wwww, r11.xyzz
              +       retain_prev r1._
/*  116   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  117   */          mad r12.xyz_, r0.zxyy, c43.zzzz, r12.xyzz
              +       retain_prev r1._
/*    9.1 */       cjmp !b131, L24
/*   10.0 */       exec
/*  118   */          mul r0, r10.wzyx, c51.wzyx
              +       retain_prev r1._
/*  119   */          add r6.xyz_, -r2.xyzz, c45.xyzz
              +       retain_prev r1._
/*  120   */          dp3 r6.___w, r6.zxyy, r6.zxyy
              +       retain_prev r1._
/*  121   */          max4 r0.x___, r0.zxwy
              +       rsq r1.x___, r_abs[6].w
/*  122   */          mul r7, r6, r1.xxxx
              +       retain_prev r1._
/*  123   */          dp3 r4.___w, r5.xzyy, r7.zxyy
              +       retain_prev r1._
/*   10.1 */       exec
/*  124   */          add r6.xyz_, r7.xyzz, -r9.zyxx
              +       retain_prev r1._
/*  125   */          dp3 r2.___w, r7.zxyy, -c46.zxyy
              +       retain_prev r1._
/*  126   */          add r1.x___, r7.wwww, -c44.wwww
              +       retain_prev r1._
/*  127   */          add r2.___w, r2.wwww, -c47.xxxx
              +       mulsc_sat r0.__z_, c45.w, r1.x
/*  128   */          dp3 r0._y__, r6.zxyy, r6.zxyy
              +       mulsc r1.x___, c47.y, r2.w
/*  129   */          max r1.x___, r1.xxxx, c47.wwww
              +       rsq r2.___w, r_abs[0].y
/*   11.0 */       exec
/*  130   */          mul r6.xyz_, r6.zyxx, r2.wwww
              +       subsc r2.___w, c255.y, r0.x
/*  131   */          min r3.x___, r1.xxxx, c255.yyyy
              +       subsc r0._y__, c255.y, r0.z
/*  132   */          dp3 r4.__z_, r5.xzyy, r6.xzyy
              +       maxs r1._, r0.yy
/*  133   */          max r0.x__w, r4.wzzz, c255.xxxx
              +       muls_prev r3.___w, r3.x
/*  134   */          mul r6.xy_w, r3.wwxx, c44.zyxx
              +       log r1.x___, r_abs[0].w
/*  135   */          mul r6.__z_, r6.wwww, r0.yyyy
              +       mulsc r0.___w, c57.z, r1.x
/*   11.1 */       exec
/*  136   */          mul r0.xyz_, r6.xyzz, r0.xxxx
              +       exp r0.___w, r0.w
/*  137   */          mul r6.xyz_, r6.xyzz, r0.wwww
              +       retain_prev r1._
/*  138   */          mad r11.xyz_, r6.xyzz, r2.wwww, r11.xyzz
              +       retain_prev r1._
/*  139   */          mul r0.xyz_, r0.zyxx, r2.wwww
              +       retain_prev r1._
/*  140   */          mad r12.xyz_, r0.zxyy, c47.zzzz, r12.xyzz
              +       retain_prev r1._
                label L24
/*   12.0 */       cjmp !b132, L36
/*   12.1 */       exec
/*  141   */          add r0.xyz_, -r2.zyxx, c25.zyxx
              +       retain_prev r1._
/*  142   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  143   */          mul r6, r10.wzyx, c52.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  144   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  145   */          add r1.x___, r0.wwww, -c24.wwww
              +       retain_prev r1._
/*  146   */          dp3 r2.___w, r0.xzyy, r5.xzyy
              +       mulsc_sat r0.x___, c25.w, r1.x
/*   13.0 */       exec
/*  147   */          max4 r0._y__, r6.zxwy
              +       maxs r0.__z_, r2.ww
/*  148   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  149   */          mul r6.xyz_, r0.xxxx, c24.zyxx
              +       maxs r2.___w, r0.zw
/*  150   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  151   */          mad r12.xyz_, r6.xzyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
/*   13.1 */       cjmp !b133, L36
/*   14.0 */       exec
/*  152   */          add r0.xyz_, -r2.xyzz, c27.xyzz
              +       retain_prev r1._
/*  153   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  154   */          mul r6, r10, c53
              +       rsq r1.x___, r_abs[0].w
/*  155   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  156   */          add r1.x___, r0.wwww, -c26.wwww
              +       retain_prev r1._
/*  157   */          dp3 r2.___w, r0.zxyy, r5.xzyy
              +       mulsc_sat r0.x___, c27.w, r1.x
/*   14.1 */       exec
/*  158   */          max4 r0._y__, r6.ywxz
              +       maxs r0.__z_, r2.ww
/*  159   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  160   */          mul r6.xyz_, r0.xxxx, c26.zyxx
              +       maxs r2.___w, r0.zw
/*  161   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  162   */          mad r12.xyz_, r6.xzyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
/*   15.0 */       cjmp !b134, L36
/*   15.1 */       exec
/*  163   */          add r0.xyz_, -r2.zyxx, c29.zyxx
              +       retain_prev r1._
/*  164   */          dp3 r0.___w, r0.xzyy, r0.xzyy
              +       retain_prev r1._
/*  165   */          mul r6, r10.wzyx, c54.wzyx
              +       rsq r1.x___, r_abs[0].w
/*  166   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  167   */          add r1.x___, r0.wwww, -c28.wwww
              +       retain_prev r1._
/*  168   */          dp3 r2.___w, r0.xzyy, r5.xzyy
              +       mulsc_sat r0.x___, c29.w, r1.x
/*   16.0 */       exec
/*  169   */          max4 r0._y__, r6.zxwy
              +       maxs r0.__z_, r2.ww
/*  170   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  171   */          mul r6.xyz_, r0.xxxx, c28.zyxx
              +       maxs r2.___w, r0.zw
/*  172   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  173   */          mad r12.xyz_, r6.xzyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
/*   16.1 */       cjmp !b135, L36
/*   17.0 */       exec
/*  174   */          add r0.xyz_, -r2.xyzz, c31.xyzz
              +       retain_prev r1._
/*  175   */          dp3 r0.___w, r0.zxyy, r0.zxyy
              +       retain_prev r1._
/*  176   */          mul r6, r10, c55
              +       rsq r1.x___, r_abs[0].w
/*  177   */          mul r0, r0, r1.xxxx
              +       retain_prev r1._
/*  178   */          add r1.x___, r0.wwww, -c30.wwww
              +       retain_prev r1._
/*  179   */          dp3 r2.___w, r0.zxyy, r5.xzyy
              +       mulsc_sat r0.x___, c31.w, r1.x
/*   17.1 */       exec
/*  180   */          max4 r0._y__, r6.ywxz
              +       maxs r0.__z_, r2.ww
/*  181   */          add r0.xy__, -r0.xyyy, c255.yyyy
              +       maxs r0.___w, c255.xx
/*  182   */          mul r6.xyz_, r0.xxxx, c30.zyxx
              +       maxs r2.___w, r0.zw
/*  183   */          mul r6.xyz_, r6.xyzz, r2.wwww
              +       retain_prev r1._
/*  184   */          mad r12.xyz_, r6.xzyy, r0.yyyy, r12.xyzz
              +       retain_prev r1._
                label L36
/*   18.0 */       exec
/*  185   */          dp3 r3.x___, r9.xzyy, r5.xzyy
              +       retain_prev r1._
/*  186   */          max r1._, r1, r1
              +       adds r1.x___, r3.xx
/*  187   */          mad r0.xyz_, -r5.xyzz, r1.xxxx, r9.xyzz
              +       retain_prev r1._
/*  188   */          cube r0, r0.xxzy, r0.yzxx
              +       subsc r1.x___, -c255.y, -r1.w
/*  189   */          max r5.__z_, r0.wwww, r0.wwww
              +       rcp r2.___w, r_abs[0].z
/*  190   */          mul r0._yz_, r0.yyxx, r2.wwww
              +       mulsc r0.x___, c56.w, r1.x
/*   18.1 */       exec
/*  191   */          add r5.xy_w, r0.yzxx, c255.zzyy
              +       retain_prev r1._
/*  192   */          setTexLOD r3.z
/*  193   */          tfetch2D r4, r4.xy, tf4
/*  194   */          tfetchCube r0, r5.xyz, tf3, UseComputedLOD=false, UseRegisterLOD=true
/*   19.0 */       alloc colors
/*   19.1 */       exec
/*  195   */          max r1.x___, r0.wwww, c254.zzzz
              +       mulsc r3.__z_, c8.x, r3.y
/*  196   */          mul r4.xyz_, r4.xyzz, r4.wwww
              +       rcp r2.___w, r1.x
/*  197   */          mul r4.xyz_, r4.zyxx, c59.zyxx
              +       subsc r1.x___, c255.y, r3.x
/*  198   */          mul r0.xyz_, r2.wwww, r0.xyzz
              +       subsc r2.___w, c255.y, r3.z
/*  199   */          mul r6.xyz_, r0.zyxx, r2.wwww
              +       muls r2.___w, r_abs[1].xx
/*  200   */          max r1._, r1, r1
              +       muls r2.___w, r2.ww
/*   20.0 */       exec
/*  201   */          mul r6.___w, r2.wwww, r_abs[1].xxxx
              +       retain_prev r1._
/*  202   */          mad r0.xyz_, r6.xyzz, c57.wwww, r11.xyzz
              +       retain_prev r1._
/*  203   */          mad_sat r1.x___, r6.wwww, c57.xxxx, c57.yyyy
              +       retain_prev r1._
/*  204   */          add r1.x___, -r1.xxxx, c255.yyyy
              +       mulsc r2.___w, c6.x, r3.y
/*  205   */          mul r3.xyz_, r4.xzyy, r5.wwww
              +       maxs r1._, r1.xx
/*  206   */          add r4.xyz_, -r3.xzyy, c7.zyxx
              +       muls_prev r1.x___, r1.w
/*   20.1 */       exec
/*  207   */          mad r3.xyz_, r2.wwww, r4.xyzz, r3.xzyy
              +       retain_prev r1._
/*  208   */          mul r4.xyz_, r1.xxxx, r13.xyzz
              +       maxs r1._, r8.ww
/*  209   */          mul r0.xyz_, r4.zyxx, r0.zyxx
              +       muls_prev r2.___w, r1.z
/*  210   */          mad r1.x_zw, r12.xyyz, r1.wwww, r3.xzzy
              +       retain_prev r1._
/*  211   */          mad r0.xyz_, r8.yxzz, r1.zwxx, r0.xyzz
              +       retain_prev r1._
/*   21.0 */       cjmp !b136, L46
/*   21.1 */       exec
/*  212   */          mad r1.___w, r1.yyyy, c14.yyyy, c14.zzzz
              +       retain_prev r1._
/*  213   */          dp3 r1.__z_, r9.xzyy, c12.zxyy
              +       retain_prev r1._
/*  214   */          cndeq r3, c255.xxxy, r2.zxyy, c255.yyyy
              +       retain_prev r1._
/*  215   */          dp4 r1.x___, c12.zxyw, r3
              +       subsc r1._y__, -c11.x, -r1.y
/*  216   */          add r2.xyz_, -r0.xyzz, c13.xyzz
              +       mulsc r0.___w, c11.z, r1.y
/*  217   */          min r3.xy__, r1.xzzz, c255.xwww
              +       mulsc r1.x___, c11.w, r1.x
/*   22.0 */       exec
/*  218   */          max r1.__z_, r0.wwww, r1.xxxx
              +       rcp r1._y__, r3.y
/*  219   */          max r1._, r1, r1
              +       mulsc r1.x___, c14.x, r1.y
/*  220   */          mad r1.x___, r1.xxxx, r3.xxxx, r1.wwww
              +       retain_prev r1._
/*  221   */          max r1.x___, r1.zzzz, r1.xxxx
              +       retain_prev r1._
/*  222   */          min r1.x___, r1.xxxx, c13.wwww
              +       retain_prev r1._
/*  223   */          max r1.x___, r1.xxxx, c255.xxxx
              +       retain_prev r1._
/*   22.1 */       exec
/*  224   */          mad r0.xyz_, r2.xyzz, r1.xxxx, r0.xyzz
              +       retain_prev r1._
                label L46
/*   23.0 */       exece
/*  225   */          mul r2.xyz_, r0.xyzz, c0.xxxx
              +       retain_prev r1._
/*  226   */          max oC0, r2, r2
/*   23.1 */       cnop
