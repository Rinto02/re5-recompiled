/*    0.0 */       exec
/*    7   */          vfetch_full r1.yxw_, r0.x, vf0, DataFormat=FMT_16_16_16_16, Stride=8, PrefetchCount=7
/*    8   */          vfetch_mini r0._x__, Offset=2, DataFormat=FMT_8_8_8_8, NumFormat=integer
/*    9   */          vfetch_mini r4.xyz_, Offset=4, DataFormat=FMT_2_10_10_10, Signed=true
/*   10   */          vfetch_mini r4.___w, Offset=5, DataFormat=FMT_8_8_8_8, Signed=true
/*   11   */          vfetch_mini r6.yx__, Offset=6, DataFormat=FMT_16_16_FLOAT, Signed=true, NumFormat=integer
/*   12   */          serialize
                      mad r2.xyz_, r1.xyzz, c3.xyzz, c4.xyzz
/*    0.1 */       exec
/*   13   */          mulsc r0.x___, c255.w, r0.y
/*   14   */          maxas r0._, r0.xx
/*   15   */          max r0, c[28+a0], c[28+a0]
/*   16   */          max r5, c[29+a0], c[29+a0]
/*   17   */          max r1, c[30+a0], c[30+a0]
/*   18   */          cndeq r2, c255.zzzx, r2.zxyy, c255.xxxx
/*    1.0 */       exec
/*   19   */          dp4 r3.x___, r0.zxyw, r2
/*   20   */          dp4 r3._y__, r5.zxyw, r2
/*   21   */          dp4 r3.__z_, r1.zxyw, r2
/*    1.1 */       cjmp !b0, L8
/*    2.0 */       exec
/*   22   */          cndeq r2, c255.zzzx, r3.zxyy, c255.xxxx
/*   23   */          dp4 r7.x___, c0.zxyw, r2
/*   24   */          dp4 r7._y__, c1.zxyw, r2
/*   25   */          dp4 r7.__z_, c2.zxyw, r2
/*   26   */          dp2add r2.x___, r7.xyyy, r7.xyyy, c255.zzzz
/*   27   */          dp3 r2._y__, r7.zxyy, r7.zxyy
/*    2.1 */       exec
/*   28   */          sqrt r2.___w, r_abs[2].y
/*   29   */          mad r2.__z_, r2.wwww, c27.xxxx, c27.yyyy
/*   30   */          add r2._y__, -r7.zzzz, r2.wwww
/*   31   */          mul r6.__zw, r7.xxxy, r2.wwww
/*   32   */          mul r6.__zw, r6.wwwz, r2.yyyy
              +       rcp r2.x___, r2.x
/*   33   */          mul r2.xy__, r6.wzzz, r2.xxxx
/*    3.0 */       exec
/*   34   */          cndge r2.__zw, r7.zzzz, r2.zzzw, c255.xxxy
/*    3.1 */       jmp L9
                label L8
/*    4.0 */       exec
/*   35   */          cndeq r7, c255.zzzx, r3.zxyy, c255.xxxx
/*   36   */          dp4 r2.x___, c23.zxyw, r7
/*   37   */          dp4 r2._y__, c24.zxyw, r7
/*   38   */          dp4 r2.__z_, c25.zxyw, r7
/*   39   */          dp4 r2.___w, c26.zxyw, r7
                label L9
/*    4.1 */       alloc position
/*    5.0 */       exec
/*   40   */          mad r2.__z_, -r2.wwww, c7.xxxx, r2.zzzz
/*   41   */          max oPos, r2, r2
/*    5.1 */       alloc interpolators
/*    6.0 */       exec
/*   42   */          dp3 r0._y__, r4.zxyy, r0.zxyy
/*   43   */          dp3 r0.__z_, r4.zxyy, r5.zxyy
/*   44   */          dp3 r0.___w, r4.zxyy, r1.zxyy
/*   45   */          add r4.xy__, r6.xyyy, c6.xyyy
              +       maxs r4.__z_, c5.xx
/*   46   */          max o2.xyz_, r3.xyzz, r3.xyzz
/*   47   */          max o1, r4, r4
/*    6.1 */       exece
/*   48   */          max o0, r2, r2
/*   49   */          dp3 r0.x___, r0.wyzz, r0.wyzz
/*   50   */          rsq r0.x___, r_abs[0].x
/*   51   */          mul o3.xyz_, r0.yzww, r0.xxxx
